import { RULES } from '../src/proctoring.js';

export const ZALO_MESSAGE_URL = 'https://openapi.zalo.me/v3.0/oa/message/cs';
export function zaloConfig(env = process.env) {
  const value = Number(env.ZALO_MIN_RISK ?? 40);
  return {
    accessToken: env.ZALO_OA_ACCESS_TOKEN?.trim() || '',
    userId: env.ZALO_RECIPIENT_ID?.trim() || '',
    minRisk: Number.isInteger(value) && value >= 0 && value <= 100 ? value : 40,
  };
}

// One persisted job per event, including retries of the camera's upload request.
export function createNotifications(db, { config = zaloConfig(), fetchImpl = fetch, now = Date.now, onChange = () => {} } = {}) {
  const configured = Boolean(config.accessToken && config.userId);
  db.exec(`CREATE TABLE IF NOT EXISTS zalo_notifications(
    id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER UNIQUE REFERENCES events(id),
    room_id TEXT REFERENCES rooms(id), text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0,
    next_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, error TEXT
  ); CREATE INDEX IF NOT EXISTS zalo_pending ON zalo_notifications(status,next_at);`);
  db.prepare("UPDATE zalo_notifications SET status='pending' WHERE status='sending'").run();
  let stopped = false, running = null, nextSendAt = 0;
  function enqueue(event) {
    if (!configured || event.risk < config.minRisk || JSON.parse(event.payload).resolved !== null) return;
    const room = db.prepare('SELECT title FROM rooms WHERE id=?').get(event.room_id);
    const student = event.student_id && db.prepare('SELECT name,student_code FROM students WHERE id=?').get(event.student_id);
    const text = `FocusLab · Cảnh báo cần giám thị kiểm tra\nPhòng: ${room.title}\nHọc sinh/vùng: ${student ? student.name + ' (' + student.student_code + ')' : event.seat_id}\nChỗ: ${event.seat_id}\nQuan sát: ${RULES[event.rule].label}\nRủi ro: ${event.risk}/100\nNhận lúc: ${new Date(event.received_at).toISOString()}\nMở trang quản lý phòng để xem và xác minh.`;
    db.prepare('INSERT OR IGNORE INTO zalo_notifications(event_id,room_id,text,next_at,updated_at) VALUES(?,?,?,?,?)').run(event.id,event.room_id,text.slice(0,1800),now(),now());
  }
  function status(roomId) {
    const counts = { pending: 0, sending: 0, sent: 0, failed: 0 };
    for (const row of db.prepare('SELECT status,COUNT(*) n FROM zalo_notifications WHERE room_id=? GROUP BY status').all(roomId)) counts[row.status] = row.n;
    return { configured, minRisk: config.minRisk, ...counts };
  }
  async function send(text) {
    try {
      const response = await fetchImpl(ZALO_MESSAGE_URL, {
        method: 'POST', redirect: 'error', signal: AbortSignal.timeout(10000),
        headers: { 'Content-Type': 'application/json', access_token: config.accessToken },
        body: JSON.stringify({ recipient: { user_id: config.userId }, message: { text } }),
      });
      if (!response.ok) return { error: `HTTP ${response.status}`, retry: response.status === 429 || response.status >= 500 };
      const result = await response.json();
      if (result.error === 0) return { error: null };
      // Do not persist provider messages, which can contain account details or tokens.
      return { error: Number.isInteger(result.error) ? `Zalo ${result.error}` : 'Phản hồi Zalo không hợp lệ', retry: result.error === -32 };
    } catch { return { error: 'Không kết nối được Zalo hoặc phản hồi không hợp lệ', retry: true }; }
  }
  async function processOne() {
    if (!configured || stopped || now() < nextSendAt) return;
    const job = db.prepare("SELECT * FROM zalo_notifications WHERE status='pending' AND next_at<=? ORDER BY id LIMIT 1").get(now());
    if (!job) return;
    const attempts = job.attempts + 1;
    db.prepare("UPDATE zalo_notifications SET status='sending',attempts=?,updated_at=? WHERE id=?").run(attempts,now(),job.id);
    const result = await send(job.text);
    const state = !result.error ? 'sent' : result.retry && attempts < 3 ? 'pending' : 'failed';
    db.prepare('UPDATE zalo_notifications SET status=?,next_at=?,updated_at=?,error=? WHERE id=?').run(state,now()+30000*attempts,now(),result.error,job.id);
    nextSendAt = now() + 5000;
    onChange(job.room_id);
  }
  function wake() {
    if (stopped) return Promise.resolve();
    if (!running) running = processOne().finally(() => { running = null; });
    return running;
  }
  function testMessage(roomId) {
    if (!configured) return false;
    db.prepare('INSERT INTO zalo_notifications(room_id,text,next_at,updated_at) VALUES(?,?,?,?)').run(roomId,'FocusLab · Tin thử kết nối Zalo. Đây không phải cảnh báo học sinh.',now(),now());
    wake(); return true;
  }
  const timer = setInterval(wake, 5000); timer.unref();
  return { enqueue, status, wake, testMessage, async close() { stopped = true; clearInterval(timer); await running; } };
}
