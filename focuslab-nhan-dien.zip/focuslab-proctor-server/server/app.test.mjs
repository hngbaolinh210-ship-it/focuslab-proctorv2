import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync,rmSync,readFileSync,existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import {createApp} from './app.mjs';
import {binaries,validateCameraUrl} from './media.mjs';
const password='synthetic-test-password-only';
const sampleEvent=id=>({clientId:id,seatId:'S99',rule:'away',risk:40,time:new Date().toISOString(),resolved:null,duration:3,offset:null});
async function fixture(t, notificationOptions={config:{accessToken:"",userId:"",minRisk:40}}){
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-test-'));const system=createApp({dataDir:directory,adminPassword:password,cameraHosts:['192.0.2.10'],maxUploadBytes:1024*1024,notificationOptions});
 const server=system.app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));const base=`http://127.0.0.1:${server.address().port}`;
 t.after(async()=>{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await system.close();rmSync(directory,{recursive:true,force:true});});
 async function request(route,{cookie,body,method='GET',headers={}}={}){const isForm=body instanceof FormData;return fetch(base+route,{method,headers:{...(cookie?{Cookie:cookie}:{}),...(!isForm&&body!==undefined?{'Content-Type':'application/json'}:{}),...headers},body:body===undefined?undefined:isForm?body:JSON.stringify(body)});}
 const login=await request('/api/login',{method:'POST',body:{password}});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];
 const roomResponse=await request('/api/rooms',{method:'POST',cookie,body:{title:'Synthetic room'}});const room=await roomResponse.json();
 return {system,server,directory,request,cookie,room};
}
test('authentication, same-origin protection, 100 students, ownership, event dedup and room closure',async t=>{
 const f=await fixture(t),{request,cookie,room}=f;
 assert.equal((await request('/api/rooms')).status,401);
 assert.equal((await request('/api/login',{method:'POST',body:{password:'wrong'}})).status,401);
 assert.equal((await request('/api/rooms',{method:'POST',cookie,body:{title:'bad'},headers:{Origin:'https://elsewhere.invalid'}})).status,403);
 const students=Array.from({length:100},(_,i)=>({student_id:`HS${i+1}`,name:`Synthetic student ${i+1}`}));
 const imported=await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students}});assert.equal(imported.status,201);const roster=await imported.json();assert.equal(roster.students.length,100);
 assert.equal((await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'HS101',name:'Extra'}]}})).status,409);
 const sessions=await Promise.all(roster.students.map(async s=>{const response=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:s.access_code}});assert.equal(response.status,200);return response.headers.get('set-cookie').split(';')[0];}));
 const eventReplies=await Promise.all(sessions.map((studentCookie,i)=>request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent(`student-${i}`)]}})));
 assert.ok(eventReplies.every(r=>r.status===200));
 const data=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(data.events.length,100);assert.equal(data.students.length,100);assert.equal(data.students.at(-1).seat_id,'S100');assert.equal(new Set(data.events.map(e=>e.student_id)).size,100);
 assert.equal(data.events.find(e=>e.student_code==='HS1').seat_id,'S01'); // forged client S99 cannot change identity
 assert.equal((await request('/api/rooms',{cookie:sessions[0]})).status,403);
 const other=await(await request('/api/rooms',{method:'POST',cookie,body:{title:'Other'}})).json();
 assert.equal((await request(`/api/rooms/${other.id}`,{cookie:sessions[0]})).status,403);
 assert.equal((await request(`/api/rooms/${other.id}/events`,{cookie:sessions[0],method:'POST',body:{events:[sampleEvent('bad')]}})).status,403);
 const event=data.events.find(e=>e.student_code==='HS1');
 assert.equal((await request(`/api/rooms/${room.id}/events/${event.id}`,{method:'PATCH',cookie:sessions[0],body:{review:'dismissed'}})).status,403);
 await request(`/api/rooms/${room.id}/events/${event.id}`,{method:'PATCH',cookie,body:{review:'dismissed'}});
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),risk:70,duration:10}]}});
 const updated=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(updated.eventCount,100);assert.equal(updated.events.find(e=>e.id===event.id).review,'dismissed');assert.equal(updated.events.find(e=>e.id===event.id).risk,70);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),duration:15,resolved:new Date().toISOString()}]}});
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),duration:2}]}});
 const retryState=await(await request(`/api/rooms/${room.id}`,{cookie})).json();const finalEvent=retryState.events.find(e=>e.id===event.id);assert.equal(finalEvent.payload.duration,15);assert.ok(finalEvent.payload.resolved);
 const studentView=await(await request(`/api/rooms/${room.id}`,{cookie:sessions[0]})).json();assert.equal(studentView.students,undefined);assert.equal(studentView.events,undefined);assert.ok(!JSON.stringify(updated).includes('access_code'));
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[{...sampleEvent('prototype-rule'),rule:'constructor'}]}})).status,400);
 const invalid=await request(`/api/rooms/${other.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'same',name:'A'},{student_id:'same',name:'B'}]}});assert.equal(invalid.status,400);
 assert.equal((await(await request(`/api/rooms/${other.id}`,{cookie})).json()).students.length,0);
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('overscore'),risk:101}]}})).status,400);
 assert.equal((await request(`/api/rooms/${room.id}/cameras`,{method:'POST',cookie,body:{url:'rtsp://127.0.0.1/private'}})).status,400);
 await request(`/api/rooms/${room.id}/close`,{method:'POST',cookie,body:{}});
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[sampleEvent('closed')]}})).status,409);
 assert.equal((await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:roster.students[0].access_code}})).status,401);
});
test('SQLite events and credentials survive application restart',async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-persistence-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 let app=createApp({dataDir:directory,adminPassword:password});app.db.prepare('INSERT INTO rooms(id,code,title,created_at) VALUES(?,?,?,?)').run('persist','PERSIST','Persistence',Date.now());await app.close();
 app=createApp({dataDir:directory});assert.equal(app.db.prepare('SELECT title FROM rooms WHERE id=?').get('persist').title,'Persistence');await app.close();
});
test('video upload uses real FFmpeg, private range serving and limits',async t=>{
 const {request,cookie,room,system,directory}=await fixture(t);
 const source=path.join(directory,'sample.mp4');execFileSync(binaries.ffmpeg,['-nostdin','-v','error','-f','lavfi','-i','color=c=black:s=160x120:d=0.5','-c:v','libx264','-pix_fmt','yuv420p',source]);
 const studentData=await(await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'A',name:'A'},{student_id:'B',name:'B'}]}})).json();
 const tokens=[];for(const s of studentData.students){const response=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:s.access_code}});tokens.push(response.headers.get('set-cookie').split(';')[0]);}
 const body=new FormData();body.append('video',new Blob([readFileSync(source)],{type:'video/mp4'}),'sample.mp4');
 const response=await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie:tokens[0],body});assert.equal(response.status,202);const video=await response.json();await Promise.all([...system.jobs]);
 const ready=await(await request(`/api/videos/${video.id}`,{cookie})).json();assert.equal(ready.status,'ready');
 assert.equal((await request(`/api/videos/${video.id}/content`)).status,401);
 assert.equal((await request(`/api/videos/${video.id}/content`,{cookie:tokens[1]})).status,403);
 const range=await request(`/api/videos/${video.id}/content`,{cookie:tokens[0],headers:{Range:'bytes=0-15'}});assert.equal(range.status,206);assert.equal((await range.arrayBuffer()).byteLength,16);
 const webm=await request(`/api/videos/${video.id}/content?format=webm`,{cookie:tokens[0]});assert.equal(webm.status,200);assert.equal(webm.headers.get('content-type'),'video/webm');assert.deepEqual([...new Uint8Array(await webm.arrayBuffer()).slice(0,4)],[0x1a,0x45,0xdf,0xa3]);
 const bad=new FormData();bad.append('video',new Blob(['not a video'],{type:'video/mp4'}),'fake.mp4');assert.equal((await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie,body:bad})).status,400);
 const huge=new FormData();huge.append('video',new Blob([new Uint8Array(1024*1024+1)],{type:'video/mp4'}),'huge.mp4');assert.equal((await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie,body:huge})).status,413);
 assert.equal((await request(`/api/videos/${video.id}`,{method:'DELETE',cookie:tokens[0]})).status,403);
 assert.equal((await request(`/api/videos/${video.id}`,{method:'DELETE',cookie})).status,200);
 assert.equal((await request(`/api/videos/${video.id}`,{cookie})).status,404);
 assert.ok(!existsSync(path.join(directory,'videos',video.id+'.mp4')));
});
test('RTSP validation requires explicitly configured hosts and rejects other protocols',()=>{
 assert.equal(validateCameraUrl('rtsp://192.0.2.10/live',['192.0.2.10']),'rtsp://192.0.2.10/live');
 assert.throws(()=>validateCameraUrl('http://192.0.2.10/live',['192.0.2.10']));assert.throws(()=>validateCameraUrl('rtsp://example.com/live',['192.0.2.10']));
});
test('server pushes SSE change notifications after a committed event',async t=>{
 const {request,cookie,room}=await fixture(t);const abort=new AbortController();
 const baseResponse=await request(`/api/rooms/${room.id}/stream`,{cookie});
 assert.equal(baseResponse.status,200);assert.match(baseResponse.headers.get('content-type'),/text\/event-stream/);
 const reader=baseResponse.body.getReader();const first=await reader.read();assert.match(new TextDecoder().decode(first.value),/event: change/);
 const next=reader.read();await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('sse-check')]}});
 const received=await Promise.race([next,new Promise((_,reject)=>{const timer=setTimeout(()=>reject(new Error('No SSE change notification')),3000);timer.unref();})]);
 assert.match(new TextDecoder().decode(received.value),/event: change/);await reader.cancel();
});
test('FFmpeg can produce browser HLS segments from synthetic video',()=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-hls-'));
 try{execFileSync(binaries.ffmpeg,['-nostdin','-v','error','-f','lavfi','-i','color=c=black:s=160x120:d=3','-c:v','libx264','-pix_fmt','yuv420p','-g','25','-f','hls','-hls_time','1','-hls_segment_filename',path.join(directory,'segment-%06d.ts'),path.join(directory,'index.m3u8')]);const manifest=readFileSync(path.join(directory,'index.m3u8'),'utf8');assert.match(manifest,/#EXTM3U/);assert.match(manifest,/segment-000000.ts/);assert.ok(existsSync(path.join(directory,'segment-000000.ts')));}finally{rmSync(directory,{recursive:true,force:true});}
});

test('Zalo delivery uses committed server identity, deduplicates uploads, and is admin-only',async t=>{
 const calls=[];let clock=Date.now();
 const f=await fixture(t,{config:{accessToken:'synthetic-oa-token',userId:'synthetic-oa-user',minRisk:40},now:()=>clock,fetchImpl:async(url,options)=>{calls.push({url,options});return Response.json({error:0,data:{message_id:'synthetic'}});}});
 const {request,cookie,room,system}=f;
 const imported=await(await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'A',name:'Server identity',seat_id:'S01'}]}})).json();
 const login=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:imported.students[0].access_code}});const studentCookie=login.headers.get('set-cookie').split(';')[0];
 assert.equal((await request(`/api/rooms/${room.id}/notifications/test`,{method:'POST',cookie:studentCookie,body:{}})).status,403);
 assert.equal((await request(`/api/rooms/${room.id}/notifications/test`,{method:'POST',body:{}})).status,401);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent('zalo-event')]}});await system.notifications.wake();
 assert.equal(calls.length,1);assert.equal(calls[0].url,'https://openapi.zalo.me/v3.0/oa/message/cs');assert.equal(calls[0].options.headers.access_token,'synthetic-oa-token');
 const payload=JSON.parse(calls[0].options.body);assert.equal(payload.recipient.user_id,'synthetic-oa-user');assert.match(payload.message.text,/Server identity \(A\)/);assert.match(payload.message.text,/Chỗ: S01/);assert.ok(!payload.message.text.includes('S99'));
 clock+=10000;
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[{...sampleEvent('zalo-event'),risk:85,duration:8}]}});await system.notifications.wake();assert.equal(calls.length,1);
 const state=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(state.events[0].zalo_status,'sent');assert.equal(state.notifications.sent,1);assert.ok(!JSON.stringify(state).includes('synthetic-oa-token'));assert.ok(!JSON.stringify(state).includes('synthetic-oa-user'));
 const studentView=await(await request(`/api/rooms/${room.id}`,{cookie:studentCookie})).json();assert.equal(studentView.notifications,undefined);
 assert.equal((await request(`/api/rooms/${room.id}/notifications/test`,{method:'POST',cookie,body:{}})).status,202);await system.notifications.wake();assert.equal(calls.length,2);
});
test('Zalo disabled still stores alerts and reports missing configuration',async t=>{
 const {request,cookie,room}=await fixture(t);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('no-zalo')]}});
 const state=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(state.notifications.configured,false);assert.equal(state.events.length,1);assert.equal(state.events[0].zalo_status,null);
 assert.equal((await request(`/api/rooms/${room.id}/notifications/test`,{method:'POST',cookie,body:{}})).status,409);
});
test('transient Zalo failure retries after restart without losing alerts',async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-zalo-restart-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 let clock=Date.now(),calls=0;const config={accessToken:'synthetic-token',userId:'synthetic-user',minRisk:40};
 let system=createApp({dataDir:directory,adminPassword:password,notificationOptions:{config,now:()=>clock,fetchImpl:async()=>{calls++;throw new Error('synthetic-token must never be logged');}}});
 system.db.prepare('INSERT INTO rooms(id,code,title,created_at) VALUES(?,?,?,?)').run('r','R','Restart',clock);
 const insert=system.db.prepare('INSERT INTO events(room_id,source,client_id,seat_id,rule,risk,payload,received_at) VALUES(?,?,?,?,?,?,?,?)');
 insert.run('r','camera','eligible','S01','away',40,JSON.stringify({resolved:null}),clock);
 const event=system.db.prepare('SELECT * FROM events WHERE client_id=?').get('eligible');system.notifications.enqueue(event);await system.notifications.wake();
 let job=system.db.prepare('SELECT * FROM zalo_notifications').get();assert.equal(job.status,'pending');assert.equal(job.attempts,1);assert.ok(!job.error.includes('synthetic-token'));await system.notifications.wake();assert.equal(calls,1);
 await system.close();clock+=30001;
 system=createApp({dataDir:directory,notificationOptions:{config,now:()=>clock,fetchImpl:async()=>{calls++;return Response.json({error:0});}}});
 await system.notifications.wake();job=system.db.prepare('SELECT * FROM zalo_notifications').get();assert.equal(job.status,'sent');assert.equal(job.attempts,2);assert.equal(calls,2);assert.equal(system.db.prepare('SELECT COUNT(*) n FROM events').get().n,1);await system.close();
});
test('Zalo skips low risk/resolved events, bounds retries and sanitizes provider errors',async t=>{
 let clock=Date.now(),mode='timeout';const f=await fixture(t,{config:{accessToken:'synthetic-token',userId:'synthetic-user',minRisk:40},now:()=>clock,fetchImpl:async()=>mode==='timeout'?Promise.reject(new Error('private')):Response.json({error:-124,message:'synthetic-token'})});
 const {request,cookie,room,system}=f;
 for(const event of [{...sampleEvent('low'),risk:30},{...sampleEvent('resolved'),resolved:new Date().toISOString()}])await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[event]}});
 assert.equal(system.db.prepare('SELECT COUNT(*) n FROM zalo_notifications').get().n,0);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('retry')]}});await system.notifications.wake();
 for(let i=0;i<2;i++){clock+=100000;await system.notifications.wake();}
 let job=system.db.prepare('SELECT * FROM zalo_notifications').get();assert.equal(job.status,'failed');assert.equal(job.attempts,3);
 clock+=100000;mode='auth';await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('auth-error')]}});await system.notifications.wake();
 job=system.db.prepare('SELECT * FROM zalo_notifications ORDER BY id DESC').get();assert.equal(job.status,'failed');assert.equal(job.attempts,1);assert.equal(job.error,'Zalo -124');
});

test('sleep observations are stored and queued for Zalo with the correct warning label',async t=>{
 const calls=[];
 const {request,cookie,room,system}=await fixture(t,{config:{accessToken:'synthetic-token',userId:'synthetic-user',minRisk:40},fetchImpl:async(url,options)=>{calls.push(JSON.parse(options.body));return Response.json({error:0});}});
 const event={...sampleEvent('sleep-warning'),rule:'sleep',risk:50,duration:3};
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[event]}})).status,200);await system.notifications.wake();
 const state=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(state.events[0].rule,'sleep');assert.equal(state.events[0].zalo_status,'sent');assert.equal(calls.length,1);assert.match(calls[0].message.text,/nghi ngủ gật/);
});
