import test from 'node:test';
import assert from 'node:assert/strict';
import { enableBrowserAlerts, showBrowserAlert } from './browser-notifications.js';
function fixture(permission='granted') {
 const values=new Map(),calls=[];
 const registration={async showNotification(title,options){calls.push({title,options});}};
 return {calls,browser:{isSecureContext:true,Notification:{permission,async requestPermission(){return permission;}},localStorage:{getItem:key=>values.get(key),setItem:(key,value)=>values.set(key,value)},navigator:{serviceWorker:{async register(url){calls.push(url);return registration;},ready:Promise.resolve(registration),async getRegistration(){return registration;}}}}};
}
test('Android-style notifications use the service worker after explicit opt-in',async()=>{
 const {browser,calls}=fixture();await showBrowserAlert('New','r',browser);assert.equal(calls.length,0);
 assert.equal(await enableBrowserAlerts(browser),'granted');await showBrowserAlert('New','r',browser);
 assert.equal(calls[0],'/notification-sw.js');assert.equal(calls[1].options.tag,'focuslab-r');assert.equal(calls[1].options.body,'New');
});
test('denied permission and insecure contexts do not register or show notifications',async()=>{
 const {browser,calls}=fixture('denied');assert.equal(await enableBrowserAlerts(browser),'denied');await showBrowserAlert('New','r',browser);assert.equal(calls.length,0);
 browser.isSecureContext=false;assert.equal(await enableBrowserAlerts(browser),'unsupported');
});
