// Android Chrome uses ServiceWorkerRegistration.showNotification rather than new Notification.
export async function enableBrowserAlerts(browser = window) {
  if (!browser.isSecureContext || !browser.Notification) return 'unsupported';
  const permission = await browser.Notification.requestPermission();
  if (permission !== 'granted') return permission;
  if (browser.navigator.serviceWorker) {
    await browser.navigator.serviceWorker.register('/notification-sw.js');
    await browser.navigator.serviceWorker.ready;
  }
  browser.localStorage.setItem('focuslab-browser-alerts', 'enabled');
  return 'granted';
}
export async function showBrowserAlert(text, roomId, browser = window) {
  if (browser.localStorage.getItem('focuslab-browser-alerts') !== 'enabled' || browser.Notification?.permission !== 'granted') return;
  const options = { body: text, tag: `focuslab-${roomId}` };
  const registration = await browser.navigator.serviceWorker?.getRegistration('/');
  if (registration) return registration.showNotification('FocusLab · Cảnh báo phòng thi', options);
  const alert = new browser.Notification('FocusLab · Cảnh báo phòng thi', options);
  alert.onclick = () => { browser.focus(); alert.close(); };
  browser.setTimeout(() => alert.close(), 15000);
}
