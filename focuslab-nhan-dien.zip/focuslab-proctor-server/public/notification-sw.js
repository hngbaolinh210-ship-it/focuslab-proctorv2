// No caching and no background push: the open dashboard triggers these notifications.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const dashboard = windows.find(client => new URL(client.url).pathname === '/');
    if (dashboard) return dashboard.focus();
    return self.clients.openWindow(self.registration.scope);
  })());
});
