import './style.css';
import './portal.css';
import './exam.css';
import { api, post, escape } from './api.js';
import { RULES } from './proctoring.js';
import { IntegrityWatch } from './exam-watch.js';

const $ = id => document.getElementById(id);
const AUTOSAVE_MS = 5000, TEXT_MAX = 3000;
let me, paper, questions = [], watch, deadline = null, stops = [], savedAnswers = '{}', frozen = false, atBell = () => {};

function notice(text, error = false) { const box = $('portal-message'); box.textContent = text; box.classList.toggle('error', error); }
function stopTimers() { for (const stop of stops) stop(); stops = []; }
const sumPoints = onlyMcq => questions.reduce((total, q) => total + (!onlyMcq || q.type === 'mcq' ? q.points : 0), 0);
const stored = () => paper.attempt?.answers ?? {};
// The server keeps option indexes as numbers and the form gives strings back, so equality needs one shape.
const fingerprint = answers => JSON.stringify(Object.fromEntries(Object.entries(answers).map(([index, value]) => [index, String(value)])));

function collect() {
  const out = {};
  for (const [index, q] of questions.entries()) {
    const field = q.type === 'mcq' ? document.querySelector(`input[name="q${index}"]:checked`) : $(`answer-${index}`);
    const value = q.type === 'mcq' ? field?.value : field?.value.trim();
    if (value) out[index] = value;
  }
  return out;
}

// The browser cannot prove what a student opened elsewhere; it only proves the paper lost the screen.
// A lost connection must never cost a student the answers they already typed, so the page keeps a local copy too.
const draftKey = () => `focuslab-exam-${paper.id}-${me?.student?.id ?? 'anon'}`;
function writeDraft() { try { localStorage.setItem(draftKey(), JSON.stringify({ at: Date.now(), answers: collect() })); } catch { /* no storage: the server copy is still the one that counts */ } }
function readDraft() {
  try {
    const saved = JSON.parse(localStorage.getItem(draftKey()) ?? 'null');
    return saved && saved.answers && typeof saved.answers === 'object' ? saved : null;
  } catch { return null; }
}
function clearDraft() { try { localStorage.removeItem(draftKey()); } catch { /* nothing to clean */ } }

function applyAnswers(answers) {
  for (const [index, value] of Object.entries(answers)) {
    const question = questions[Number(index)];
    if (!question) continue;
    if (question.type === 'mcq') {
      const choice = document.querySelector(`input[name="q${index}"][value="${String(value)}"]`);
      if (choice) choice.checked = true;
    } else if ($(`answer-${index}`)) $(`answer-${index}`).value = String(value);
  }
}

function offerRestore(draft) {
  const local = Object.keys(draft.answers).length, onServer = Object.keys(stored()).length;
  if (local <= onServer) return;
  const bar = document.createElement('div');
  bar.className = 'exam-offline';
  bar.innerHTML = `<span>Máy tính này còn giữ bản nháp <strong>${local} câu</strong> (lúc ${escape(new Date(draft.at).toLocaleTimeString('vi-VN'))}), máy chủ chỉ có ${onServer} câu.</span><button type="button">Khôi phục bản nháp</button><button type="button" data-dismiss>Bỏ qua</button>`;
  $('content').prepend(bar);
  bar.querySelector('button').onclick = () => { applyAnswers(draft.answers); watch.activity(); paintChips(); void save(); bar.remove(); };
  bar.querySelector('[data-dismiss]').onclick = () => bar.remove();
}

async function report(alert) {
  const rule = RULES[alert.rule], time = new Date().toISOString();
  notice(`Đã báo giám thị: ${rule.label}${alert.question ? ` ở câu ${alert.question}` : ''}${alert.seconds ? ` · ${alert.seconds} giây` : ''}.`);
  try {
    await api(`/api/rooms/${me.roomId}/events`, { method: 'POST', body: JSON.stringify({ events: [{
      clientId: alert.clientId, rule: alert.rule, risk: rule.risk, seatId: me.student.seat_id,
      duration: alert.seconds, time, resolved: time, offset: null }] }) });
  } catch (error) { notice(`Không gửi được cảnh báo (${error.message}). Thời gian rời cửa sổ vẫn lưu cùng bài làm.`, true); }
}

async function save({ keepalive = false } = {}) {
  const answers = collect();
  writeDraft();
  const body = `{"answers":${JSON.stringify(answers)},"tabMs":${Math.round(watch?.awayMs ?? 0)},"tabEvents":${watch?.tabEvents ?? 0},"pasteCount":${watch?.pasteCount ?? 0}}`;
  if (keepalive) { fetch(`/api/exams/${paper.id}/save`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => {}); return; }
  try {
    const result = await api(`/api/exams/${paper.id}/save`, { method: 'POST', body });
    savedAnswers = fingerprint(answers);
    setDeadline(result.remainingSeconds);
    const state = $('save-state');
    if (state) state.textContent = `Đã lưu lúc ${new Date().toLocaleTimeString('vi-VN')} · ${Object.keys(collect()).length}/${questions.length} câu`;
  } catch (error) {
    if (error.status === 409) return freeze(error.message);
    notice(`Mất kết nối với máy chủ (${error.message}). Bài vẫn lưu trên máy này và trang sẽ tự gửi lại khi mạng về.`, true);
  }
}

function setDeadline(seconds) {
  if (!Number.isFinite(seconds)) return;
  deadline = Date.now() + seconds * 1000;
  paintClock();
}

function paintClock() {
  const clock = $('exam-clock');
  if (!clock || deadline === null) return;
  const seconds = Math.max(0, Math.round((deadline - Date.now()) / 1000));
  clock.textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  clock.classList.toggle('urgent', seconds <= 120);
  if (!seconds && !frozen) void atBell();
}

// The bell is the server's clock. This page only stops the pen, then asks the server to grade what is saved.
async function runOut() {
  freeze('Hết thời gian làm bài. Những câu đã lưu vẫn được máy chủ chấm.');
  try { await api(`/api/exams/${paper.id}/submit`, { method: 'POST', body: JSON.stringify({}) }); } catch { /* the server grades the saved work when the board reads it */ }
  await load(paper.id);
}

function freeze(message) {
  if (frozen) return;
  frozen = true;
  stopTimers();
  document.querySelectorAll('#paper input,#paper textarea,#submit').forEach(field => { field.disabled = true; });
  notice(message, true);
}

function paintChips() {
  const done = collect();
  $('exam-chips').innerHTML = questions.map((q, index) => `<a class="chip${done[index] ? ' done' : ''}" href="#q-${index}">${index + 1}</a>`).join('');
  $('exam-count').textContent = `${Object.keys(done).length}/${questions.length} câu đã trả lời`;
}

function renderPaper(remainingSeconds, bell = runOut) {
  atBell = bell;
  const answers = stored();
  $('content').innerHTML = `<div class="exam-bar"><div class="exam-clock-box"><strong id="exam-clock">--:--</strong><span id="save-state">Đang chờ máy chủ…</span></div><div class="exam-progress"><span id="exam-count"></span><div id="exam-chips"></div></div><button id="submit" class="primary">Nộp bài</button></div>
    <section id="paper" class="exam-paper">${questions.map((q, index) => `<article class="exam-q" id="q-${index}" data-index="${index}">
      <h3><span>Câu ${index + 1}</span><small>${q.points} điểm</small></h3>
      <p class="exam-text">${escape(q.text)}</p>
      ${q.type === 'mcq' ? `<div class="exam-options">${q.options.map((option, choice) => `<label><input type="radio" name="q${index}" value="${choice}" ${String(answers[index]) === String(choice) ? 'checked' : ''}/><span>${escape(option)}</span></label>`).join('')}</div>`
        : `<textarea id="answer-${index}" rows="6" maxlength="${TEXT_MAX}" placeholder="${escape(q.prompt || 'Viết câu trả lời của em…')}">${escape(answers[index] ?? '')}</textarea>`}
    </article>`).join('')}</section>
    <p class="portal-note">Tắt trình duyệt không làm mất bài: máy chủ giữ những câu đã lưu và em mở lại trang này để làm tiếp cho tới khi hết giờ.</p>`;

  const sheet = $('paper');
  sheet.addEventListener('input', () => { watch.activity(); paintChips(); });
  sheet.addEventListener('paste', event => {
    const index = Number(event.target.closest('.exam-q')?.dataset.index);
    const alert = watch.paste(Number.isInteger(index) ? index : 0, String(event.clipboardData?.getData('text') ?? '').trim().length);
    if (alert) { void report(alert); void save(); }
  });
  $('submit').onclick = async () => {
    if (frozen || !confirm(`Nộp bài và kết thúc thời gian làm bài? Em đã làm ${Object.keys(collect()).length}/${questions.length} câu.`)) return;
    $('submit').disabled = true;
    try { renderResult(await api(`/api/exams/${paper.id}/submit`, { method: 'POST', body: JSON.stringify({ answers: collect(), tabMs: Math.round(watch?.awayMs ?? 0), tabEvents: watch?.tabEvents ?? 0, pasteCount: watch?.pasteCount ?? 0 }) })); }
    catch (error) {
      $('submit').disabled = false;
      if (error.status === 409) freeze(error.message); else notice(error.message, true);
    }
  };

  savedAnswers = fingerprint(stored());
  paintChips();
  offerRestore(readDraft());
  setDeadline(remainingSeconds);
  if (frozen) return;

  const tick = setInterval(() => { paintClock(); const alert = watch.tick(); if (alert) void report(alert); }, 1000);
  const autosave = setInterval(() => { if (fingerprint(collect()) !== savedAnswers) void save(); else void post('/api/heartbeat', {}); }, AUTOSAVE_MS);
  const onVisibility = () => {
    const alert = watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: !document.hasFocus() });
    if (document.visibilityState !== 'visible') { save({ keepalive: true }); return; }
    if (alert) void report(alert);
    void save();
  };
  const onFocus = () => watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: false });
  const onBlur = () => watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: true });
  const onHide = () => save({ keepalive: true });
  const onOnline = () => { notice(''); void save(); };
  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('focus', onFocus);
  window.addEventListener('blur', onBlur);
  window.addEventListener('pagehide', onHide);
  window.addEventListener('online', onOnline);
  stops = [() => clearInterval(tick), () => clearInterval(autosave), () => document.removeEventListener('visibilitychange', onVisibility),
    () => window.removeEventListener('focus', onFocus), () => window.removeEventListener('blur', onBlur), () => window.removeEventListener('pagehide', onHide),
    () => window.removeEventListener('online', onOnline)];
  if (document.visibilityState !== 'visible' || !document.hasFocus()) onVisibility();
}

function renderReadOnly(message) {
  renderPaper(0, () => {});
  freeze(message);
}

function renderResult(result) {
  const marks = sumPoints(true), total = sumPoints(false);
  stopTimers();
  clearDraft();
  frozen = true;
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">ĐÃ NỘP BÀI</div><h1>${escape(paper.title)}</h1></section>`
    + card('Kết quả', `<p>Trắc nghiệm máy chủ chấm ngay: <strong>${result.score ?? 0} / ${marks}</strong> điểm.${marks < total ? ` Còn ${total - marks} điểm tự luận do giám thị chấm nên điểm cuối cùng sẽ khác.` : ''}</p><p>Giám thị đã nhận được bài làm và danh sách cảnh báo của em.</p><a class="button primary" href="/">Về trang phòng thi</a>`);
  notice('');
}

function showGate() {
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">ĐỀ THI TRÊN MÁY · ${escape(me.student.seat_id)}</div><h1>${escape(paper.title)}</h1><p>${questions.length} câu · ${sumPoints(false)} điểm · ${paper.durationMinutes} phút.</p></section>`
    + card('Trước khi vào làm', `<ul class="exam-rules">
      <li>Đồng hồ chạy ngay khi em bấm bắt đầu và <strong>không tạm dừng</strong>.</li>
      <li>Mỗi câu tự lưu lên máy chủ sau 5 giây. Tắt trang rồi mở lại vẫn còn bài đã lưu.</li>
      <li>Giám thị thấy khi em <strong>rời cửa sổ làm bài</strong> từ 15 giây, khi đáp án <strong>xuất hiện bằng cách dán</strong>, và khi em <strong>ngừng làm</strong> quá 3 phút. Trình duyệt không biết em mở gì ở cửa sổ khác, nên giám thị sẽ kiểm tra lại từng báo.</li>
      <li>Camera giám sát chạy trên thiết bị riêng do giám thị hướng dẫn. Trong lúc làm bài, không mở thêm tab hay ứng dụng khác.</li>
    </ul><button id="begin" class="primary">Bắt đầu làm bài (${paper.durationMinutes} phút)</button><p id="gate-error" class="form-error" role="alert"></p>`);
  $('begin').onclick = async () => {
    const button = $('begin');
    button.disabled = true;
    try { await api(`/api/exams/${paper.id}/start`, { method: 'POST', body: JSON.stringify({}) }); await load(paper.id); }
    catch (error) { button.disabled = false; $('gate-error').textContent = error.message; }
  };
}

async function load(id) {
  stopTimers();
  const data = await api(`/api/exams/${id}/paper`);
  paper = { id, ...data };
  questions = data.questions;
  watch = new IntegrityWatch({ onAlert: report });
  watch.restore({ tabMs: data.attempt?.tabMs, tabEvents: data.attempt?.tabEvents, pasteCount: data.attempt?.pasteCount });
  if (data.attempt) watch.activity();
  frozen = false;
  if (!data.attempt) return showGate();
  if (data.attempt.submittedAt) return renderResult({ score: data.attempt.score });
  if (data.attempt.closed) return renderReadOnly('Đề đã hết thời gian. Những câu đã lưu vẫn được máy chủ chấm.');
  renderPaper(data.attempt.remainingSeconds);
}

function showList(list) {
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">PHÒNG THI CỦA EM</div><h1>Đề thi đã mở.</h1><p>Chọn đề giám thị yêu cầu làm. Mỗi đề có đồng hồ riêng tính theo giờ của máy chủ.</p></section>`
    + list.map(t => card(t.title, `<p>${t.questionCount} câu · ${t.maxPoints} điểm · ${t.durationMinutes} phút.</p><p>${t.submitted ? 'Em đã nộp đề này.'
      : t.started ? `Em đang làm, còn ${Math.ceil(t.remainingSeconds / 60)} phút.` : 'Em chưa bắt đầu.'}</p><a class="button primary" href="/exam?test=${encodeURIComponent(t.id)}">${t.submitted ? 'Xem lại bài đã nộp' : t.started ? 'Tiếp tục làm bài' : 'Vào làm bài'}</a>`)).join('');
}

async function start() {
  try { me = await api('/api/me'); }
  catch (error) { notice(error.status === 401 ? 'Hãy đăng nhập bằng mã tham gia do giám thị cấp.' : error.message, true); $('content').innerHTML = card('Chưa vào được phòng thi', '<p>Mở trang chủ FocusLab, nhập mã phòng và mã tham gia riêng của em rồi vào lại link này.</p><a class="button primary" href="/">Về trang đăng nhập</a>'); return; }
  $('who').textContent = `${me.student.name} · ${me.student.seat_id}`;
  if (me.role !== 'student') { $('content').innerHTML = card('Trang dành cho thí sinh', '<p>Giám thị dùng bảng điều khiển để soạn đề và theo dõi phòng thi.</p><a class="button primary" href="/">Về bảng giám thị</a>'); return; }
  try {
    const list = await api('/api/exams');
    if (!list.length) { $('content').innerHTML = card('Chưa có đề thi', '<p>Giám thị chưa mở đề cho phòng của em. Em hãy giữ trang này và làm theo hướng dẫn trong phòng thi.</p><p><a class="button" href="/monitor?room=' + encodeURIComponent(me.roomId) + '">Mở trang camera giám sát</a></p>'); return; }
    const chosen = list.find(t => t.id === new URLSearchParams(location.search).get('test'));
    if (!chosen && (list.length > 1 || location.search)) return showList(list);
    await load(chosen ? chosen.id : list[0].id);
  } catch (error) { notice(error.message, true); }
}

document.querySelector('#app').innerHTML = `<div class="portal exam"><header><a class="brand" href="/">FocusLab<span class="brand-dot">.</span><small>PROCTOR</small></a><span id="who" class="local-badge">Thí sinh</span></header><div id="portal-message" role="status" aria-live="polite"></div><div id="content"></div><footer>Bài làm lưu trên máy chủ của phòng thi · Giám thị xem lại từng cảnh báo trước khi xử lý</footer></div>`;
start();
