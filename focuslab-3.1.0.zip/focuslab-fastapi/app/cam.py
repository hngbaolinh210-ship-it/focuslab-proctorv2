"""Camera live: ảnh nằm trong RAM của tiến trình, không ghi đĩa, không vào SQLite.

Máy chủ chỉ chuyển ảnh từ máy em học sinh sang máy cô giáo. Mỗi em giữ đúng một khung
mới nhất và khung đó bị bỏ sau vài giây, nên không có bất kỳ bản ghi hình nào lưu lại.
"""
from __future__ import annotations

import threading
import time

FRAME_TTL_S = 8.0
MAX_FRAME_BYTES = 120_000


class CameraBoard:
    """Bảng ảnh đang xem: một phòng chỉ xem được một em mỗi lần."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frames: dict[str, tuple[bytes, float]] = {}
        self._watching: dict[str, str | None] = {}

    def watch(self, room_id: str, student_id: str | None) -> str | None:
        with self._lock:
            if student_id is None:
                self._watching.pop(room_id, None)
                return None
            self._watching[room_id] = student_id
            return student_id

    def watched(self, room_id: str) -> str | None:
        with self._lock:
            return self._watching.get(room_id)

    def wanted(self, room_id: str, student_id: str) -> bool:
        return self.watched(room_id) == student_id

    def put(self, room_id: str, student_id: str, data: bytes) -> bool:
        """Nhận ảnh khi cô đang nhìn em này; những lúc khác báo sai để trình duyệt ngừng gửi."""
        if not data or len(data) > MAX_FRAME_BYTES:
            return False
        with self._lock:
            if self._watching.get(room_id) != student_id:
                return False
            self._frames[student_id] = (data, time.monotonic())
            return True

    def get(self, student_id: str) -> bytes | None:
        with self._lock:
            frame = self._frames.get(student_id)
            if not frame:
                return None
            if time.monotonic() - frame[1] > FRAME_TTL_S:
                self._frames.pop(student_id, None)
                return None
            return frame[0]

    def drop(self, student_id: str) -> None:
        with self._lock:
            self._frames.pop(student_id, None)
            for room, watched in list(self._watching.items()):
                if watched == student_id:
                    self._watching.pop(room, None)

    def forget_room(self, room_id: str) -> None:
        with self._lock:
            watched = self._watching.pop(room_id, None)
            if watched:
                self._frames.pop(watched, None)
