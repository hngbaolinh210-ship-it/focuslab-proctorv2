/* Bảng điều hành của cô: phòng thi, danh sách lớp, soạn đề, theo dõi giờ thi và chấm tự luận. */
import { api, escape, notify, minutes, clock, dateTime } from "/static/app.js";

const el = id => document.getElementById(id);
const LETTERS = "ABCDEFGH";
const POLL_MS = 10000;
const CAM_POLL_MS = 1200;
const CAM_WAIT_MS = 6000;
const ONLINK_MS = 90000;
const TONES = {
  ok: "bg-moss-soft text-moss",
  warn: "bg-amber-100 text-amber-800",
  alert: "bg-red-100 text-red-700",
  done: "bg-slate-200 text-slate-700",
  idle: "bg-slate-100 text-slate-500",
};

let me, rooms = [], roomId = null, room = null, tab = "roster";
let editor = null, detail = null, previous = new Map(), pollTimer;
let camStudent = null, camTimer = null, camUrl = null, camWaited = 0;

async function boot() {
  try {
    me = await api("/api/me");
  } catch {
    el("who").textContent = "Không nối được máy chủ.";
    return;
  }
  if (me.role !== "teacher") return location.replace("/");
  el("who").textContent = me.display_name;
  wire();
  showTab("roster");
  await loadRooms();
}

/* ---------------------------------------------------------------- khung trang */

function wire() {
  el("logout").addEventListener("click", async () => {
    await api("/api/logout", { method: "POST" }).catch(() => {});
    location.replace("/");
  });
  el("new-room").addEventListener("click", createRoom);
  el("copy-code").addEventListener("click", () => navigator.clipboard?.writeText(room.code) && notify(document, `Đã copy mã phòng ${room.code}.`));
  el("toggle-close").addEventListener("click", toggleRoom);
  el("toggle-cam").addEventListener("click", toggleCam);
  el("drop-room").addEventListener("click", dropRoom);
  el("codes-csv").addEventListener("click", () => location.href = `/api/rooms/${roomId}/codes.csv`);
  el("roster-add").addEventListener("click", () => sendRoster("post"));
  el("roster-replace").addEventListener("click", () => sendRoster("put"));
  el("roster-file").addEventListener("change", uploadRoster);
  el("new-exam").addEventListener("click", () => openEditor(blankEditor()));
  el("exam-file").addEventListener("change", uploadExam);
  el("tabs").addEventListener("click", event => {
    const button = event.target.closest("[data-tab]");
    if (button) showTab(button.dataset.tab);
  });
  el("room-list").addEventListener("click", event => {
    const card = event.target.closest("[data-room]");
    if (card) selectRoom(card.dataset.room);
  });
  el("exam-editor").addEventListener("click", editQuestions);
  el("exam-editor").addEventListener("change", switchType);
  el("exam-list").addEventListener("click", examActions);
  el("exam-list").addEventListener("change", saveMarks);
  el("board").addEventListener("click", camActions);
  el("cam-close").addEventListener("click", stopWatch);
  clearInterval(pollTimer);
  pollTimer = setInterval(() => (tab === "board" ? refresh() : loadRooms().catch(() => {})), POLL_MS);
}

function showTab(name) {
  tab = name;
  el("tabs").querySelectorAll("[data-tab]").forEach(button => button.classList.toggle("on", button.dataset.tab === name));
  document.querySelectorAll("[data-panel]").forEach(panel => { panel.hidden = panel.dataset.panel !== name; });
}

async function loadRooms() {
  rooms = await api("/api/rooms");
  el("empty").hidden = rooms.length > 0;
  el("workspace").hidden = rooms.length === 0;
  el("room-list").innerHTML = rooms.map(item => `<button data-room="${item.id}"
      class="rounded-lg border p-3 text-left transition hover:border-moss ${item.id === roomId ? "border-moss bg-moss-soft" : "border-slate-200"}">
      <span class="block text-sm font-bold text-slate-900">${escape(item.title)}</span>
      <span class="block font-mono text-xs text-moss">${escape(item.code)}</span>
      <span class="mt-1 block text-xs text-slate-500">${item.students} học sinh · ${item.exams} đề · ${item.online} em đang online
        ${item.closed ? " · đã đóng" : ""}</span></button>`).join("");
  if (!roomId || !rooms.some(item => item.id === roomId)) selectRoom(rooms[0]?.id);
}

async function selectRoom(id) {
  if (!id) return;
  if (camStudent && id !== roomId) stopWatch();
  roomId = id;
  editor = null;
  detail = null;
  previous = new Map();
  await loadRooms();
  await refresh();
}

async function refresh() {
  if (!roomId) return;
  room = await api(`/api/rooms/${roomId}`);
  paintRoom();
}

async function createRoom() {
  const title = prompt("Tên phòng thi (ví dụ: Lớp 12A1):");
  if (!title) return;
  try {
    const created = await api("/api/rooms", { method: "POST", body: { title } });
    roomId = created.id;
    await loadRooms();
    await refresh();
    notify(document, `Đã tạo phòng ${created.title}. Mã phòng là ${created.code}.`);
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function toggleRoom() {
  await api(`/api/rooms/${roomId}`, { method: "PATCH", body: { closed: !room.closed } });
  await refresh();
}

async function toggleCam() {
  if (room.cam_enabled && !confirm("Tắt camera cho phòng này? Khung xem đang mở sẽ đóng và máy chủ bỏ mọi ảnh đang chờ.")) return;
  try {
    await api(`/api/rooms/${roomId}`, { method: "PATCH", body: { cam_enabled: !room.cam_enabled } });
    if (room.cam_enabled) stopWatch();
    await refresh();
    notify(document, room.cam_enabled
      ? "Đã bật camera. Nhớ báo trước cho các em và phụ huynh rằng phòng thi có giám thị xem hình."
      : "Đã tắt camera cho phòng này.");
  } catch (error) {
    notify(document, error.message, true);
  }
}

/* ---------------------------------------------------------------- khung xem camera */

async function camActions(event) {
  const button = event.target.closest("[data-cam]");
  if (!button) return;
  if (button.dataset.cam === room.cam_watching) return stopWatch();
  try {
    await api(`/api/rooms/${roomId}/cam/watch`, { method: "POST", body: { student_id: button.dataset.cam } });
    camStudent = button.dataset.cam;
    camWaited = 0;
    el("cam-who").textContent = `${button.dataset.who} · đang gửi hình`;
    el("cam-modal").hidden = false;
    camHint("Đang chờ hình từ máy em này…");
    clearInterval(camTimer);
    pullFrame();
    camTimer = setInterval(pullFrame, CAM_POLL_MS);
    paintBoard();
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function stopWatch() {
  clearInterval(camTimer);
  camTimer = null;
  if (camStudent && roomId) await api(`/api/rooms/${roomId}/cam/watch`, { method: "POST", body: { student_id: null } }).catch(() => {});
  camStudent = null;
  el("cam-modal").hidden = true;
  showFrame(null);
  if (room) paintBoard();
}

async function pullFrame() {
  if (!camStudent) return;
  let blob = null;
  try {
    const answer = await fetch(`/api/rooms/${roomId}/cam/${camStudent}`, { credentials: "same-origin", cache: "no-store" });
    if (answer.ok) blob = await answer.blob();
  } catch { /* mất mạng vài giây thì để nguyên khung hình cuối */ }
  if (blob && blob.size) {
    camWaited = 0;
    showFrame(blob);
    return;
  }
  camWaited += CAM_POLL_MS;
  if (camWaited >= CAM_WAIT_MS) camHint("Em này chưa gửi hình — có thể em chưa bấm Cho phép camera, đã tắt camera, hoặc đã nộp bài.");
}

function showFrame(blob) {
  if (camUrl) URL.revokeObjectURL(camUrl);
  camUrl = blob ? URL.createObjectURL(blob) : null;
  el("cam-frame").src = camUrl ?? "";
  el("cam-frame").hidden = !camUrl;
  if (camUrl) el("cam-hint").hidden = true;
}

function camHint(message) {
  el("cam-hint").textContent = message;
  el("cam-hint").hidden = false;
}

async function dropRoom() {
  if (!confirm(`Xóa phòng “${room.title}”? Toàn bộ đề, bài làm và cảnh báo của phòng này sẽ mất theo.`)) return;
  await api(`/api/rooms/${roomId}`, { method: "DELETE" });
  roomId = null;
  await loadRooms();
  notify(document, "Đã xóa phòng.");
}

/* ---------------------------------------------------------------- vẽ phòng */

function paintRoom() {
  el("workspace").hidden = false;
  el("room-title").textContent = room.title;
  el("room-code").textContent = room.code;
  el("room-state").textContent = room.closed ? "Đã đóng, học sinh không vào được" : "Đang mở cho học sinh vào";
  el("room-state").className = `pill ${room.closed ? "bg-slate-200 text-slate-600" : "bg-moss-soft text-moss"}`;
  el("toggle-close").textContent = room.closed ? "Mở lại phòng" : "Đóng phòng";
  el("toggle-cam").textContent = room.cam_enabled ? "Tắt camera của phòng" : "Bật camera cho phòng";
  if (!room.cam_enabled && camStudent) stopWatch();
  const submitted = room.exams.reduce((total, exam) => total + exam.attempts.filter(attempt => attempt.submitted_at).length, 0);
  const away = room.exams.reduce((total, exam) => total + exam.attempts.filter(attempt =>
    statusOf(attempt, previous.get(attempt.id), Date.now()).tone === "alert").length, 0);
  el("counters").innerHTML = counter("Học sinh", room.students.length)
    + counter("Đang vào lớp", room.students.filter(student => Date.now() - student.last_seen < ONLINK_MS).length)
    + counter("Đề đã mở", room.exams.filter(exam => exam.published).length)
    + counter("Em rời cửa sổ", away, away ? "alert" : "");
  paintRoster();
  paintExams();
  paintBoard();
  paintAlerts();
}

const counter = (label, value, tone = "") =>
  `<div class="rounded-lg border border-slate-200 p-3"><p class="text-xs uppercase tracking-wide text-slate-500">${label}</p>
    <p class="text-2xl font-bold ${tone === "alert" ? "text-red-600" : "text-moss"}">${value}</p></div>`;

function paintRoster() {
  el("roster-table").innerHTML = `<thead><tr><th>Chỗ</th><th>Mã học sinh</th><th>Họ và tên</th><th>Mã tham gia</th><th>Vào lớp</th><th></th></tr></thead>
    <tbody>${room.students.map(student => `<tr>
      <td class="font-mono text-xs">${escape(student.seat_id)}</td><td class="font-mono text-xs">${escape(student.student_code)}</td>
      <td>${escape(student.name)}</td>
      <td><code class="rounded bg-moss-soft px-2 py-1 font-mono font-bold text-moss">${escape(student.join_code)}</code></td>
      <td class="text-xs text-slate-500">${student.last_seen ? clock(student.last_seen) : "chưa vào"}</td>
      <td><button class="btn-danger px-2 py-1 text-xs" data-drop-student="${student.id}">Xóa</button></td></tr>`).join("")
      || '<tr><td colspan="6" class="text-sm text-slate-500">Chưa có học sinh. Dán danh sách hoặc tải tệp CSV lên.</td></tr>'}</tbody>`;
  el("roster-table").querySelectorAll("[data-drop-student]").forEach(button =>
    button.addEventListener("click", async () => {
      if (!confirm("Xóa em này khỏi danh sách? Bài làm của em cũng bị xóa.")) return;
      await api(`/api/students/${button.dataset.dropStudent}`, { method: "DELETE" });
      await refresh();
    }));
}

function parseRoster(text) {
  return text.split(/\r?\n/).filter(line => line.trim()).map(line => {
    const [code, ...rest] = line.split(/[,;\t]/);
    return { student_code: code.trim(), name: rest.join(", ").trim() };
  }).filter(item => item.student_code && item.name);
}

async function sendRoster(method) {
  const students = parseRoster(el("roster-paste").value);
  if (!students.length) return notify(document, "Chưa có dòng nào dạng “mã học sinh, họ và tên”.", true);
  if (method === "put" && !confirm(`Thay thế cả danh sách bằng ${students.length} em vừa dán? Danh sách cũ sẽ bị xóa.`)) return;
  try {
    await api(`/api/rooms/${roomId}/students`, { method: method === "put" ? "PUT" : "POST", body: { students } });
    el("roster-paste").value = "";
    await refresh();
    notify(document, `Đã nạp ${students.length} em và cấp mã tham gia.`);
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function uploadRoster(event) {
  const file = event.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  try {
    await api(`/api/rooms/${roomId}/roster`, { method: "POST", form });
    await refresh();
    notify(document, `Đã nạp danh sách từ ${file.name}.`);
  } catch (error) {
    notify(document, error.message, true);
  } finally {
    event.target.value = "";
  }
}

/* ---------------------------------------------------------------- đề thi */

const blankEditor = (exam = null) => ({
  id: exam?.id ?? null,
  title: exam?.title ?? "",
  duration: exam?.duration_minutes ?? 45,
  questions: exam ? exam.questions.map(question => ({ ...question, options: [...(question.options || [])] })) : [blankQuestion()],
});

const blankQuestion = () => ({ type: "mcq", text: "", options: ["", "", "", ""], answer: 0, points: 2 });

function openEditor(next) {
  editor = next;
  el("exam-editor").hidden = false;
  el("exam-editor").innerHTML = `
    <div class="mb-3 grid gap-3 sm:grid-cols-[2fr_1fr]">
      <div><label class="label" for="exam-title">Tên đề</label><input id="exam-title" class="field" maxlength="120"
        value="${escape(editor.title)}" placeholder="Ví dụ: Kiểm tra buổi 5"></div>
      <div><label class="label" for="exam-duration">Thời lượng (phút)</label><input id="exam-duration" class="field" type="number"
        min="5" max="240" value="${editor.duration}"></div>
    </div>
    <details class="mb-3 rounded-lg border border-slate-200 p-3 text-sm">
      <summary class="cursor-pointer font-semibold text-moss">Dán đề từ Word hoặc tệp văn bản để máy tự tách câu</summary>
      <p class="mt-2 text-xs text-slate-500">Một câu là một khối cách nhau một dòng trống, hoặc bắt đầu bằng dòng “Câu 12:” / “12.”.
        Trắc nghiệm: dòng hỏi, các dòng “A. …”, “B. …”, rồi “ĐA: B” và “Điểm: 2”. Tự luận: thêm dòng “Tự luận: hướng dẫn chấm”.</p>
      <textarea id="exam-paste" rows="6" class="field mt-2" placeholder="Câu 1: Chọn đáp án đúng&#10;A. phương án một&#10;B. phương án hai&#10;ĐA: A&#10;Điểm: 2"></textarea>
      <div class="mt-2 flex flex-wrap gap-2">
        <button id="exam-parse" class="btn-primary">Dịch thành câu hỏi</button>
        <button id="exam-add" class="btn-ghost">+ Thêm 1 câu trắng</button>
      </div>
    </details>
    <div id="exam-rows" class="grid gap-3"></div>
    <p id="exam-errors" class="mt-2 text-sm text-red-700" role="alert"></p>
    <div class="mt-3 flex flex-wrap gap-2">
      <button id="exam-save" class="btn-primary">${editor.id ? "Lưu thay đổi" : "Lưu đề (chưa mở cho học sinh)"}</button>
      <button id="exam-cancel" class="btn-ghost">Đóng</button>
      <span id="exam-count" class="self-center text-xs text-slate-500"></span>
    </div>`;
  el("exam-title").focus();
  paintRows();
  el("exam-editor").scrollIntoView({ block: "start", behavior: "smooth" });
}

function rowHtml(question, i) {
  const options = question.type === "mcq"
    ? `<div class="mt-2 grid gap-2">${question.options.map((option, j) => `<div class="flex items-center gap-2">
        <input type="radio" name="key-${i}" value="${j}" ${question.answer === j ? "checked" : ""} title="Đây là đáp án đúng"
          class="h-4 w-4 accent-moss">
        <input data-option="${j}" value="${escape(option)}" class="field" placeholder="${LETTERS[j]}. phương án ${LETTERS[j]}">
        <button data-drop-option="${j}" class="btn-ghost px-2 py-1 text-xs" title="Bỏ phương án">×</button></div>`).join("")}
      ${question.options.length < 8 ? '<button data-add-option class="btn-ghost w-fit px-3 py-1 text-xs">+ Thêm phương án</button>' : ""}
      <p class="text-xs text-slate-500">Chấm tròn đang chọn là đáp án đúng. Máy tự chấm trắc nghiệm, câu tự luận cô chấm.</p></div>`
    : `<input data-field="prompt" class="field mt-2" value="${escape(question.prompt ?? "")}" placeholder="Hướng dẫn chấm, ví dụ: viết khoảng 30 từ">`;
  return `<div data-row="${i}" class="rounded-lg border border-slate-200 p-3">
      <div class="mb-2 flex flex-wrap items-center gap-2">
        <strong class="text-sm text-slate-700">Câu ${i + 1}</strong>
        <select data-field="type" class="field w-auto py-1 text-xs">
          <option value="mcq" ${question.type === "mcq" ? "selected" : ""}>Trắc nghiệm</option>
          <option value="text" ${question.type === "text" ? "selected" : ""}>Tự luận</option></select>
        <label class="flex items-center gap-1 text-xs text-slate-600">Điểm
          <input data-field="points" type="number" min="1" max="20" value="${question.points}" class="field w-16 py-1 text-xs"></label>
        <span class="ml-auto flex gap-1">
          ${i > 0 ? `<button data-up class="btn-ghost px-2 py-1 text-xs">↑</button>` : ""}
          ${i < editor.questions.length - 1 ? `<button data-down class="btn-ghost px-2 py-1 text-xs">↓</button>` : ""}
          <button data-drop-row class="btn-danger px-2 py-1 text-xs">Xóa</button></span>
      </div>
      <textarea data-field="text" rows="2" class="field" placeholder="Nội dung câu hỏi">${escape(question.text)}</textarea>
      ${options}</div>`;
}

function paintRows() {
  el("exam-rows").innerHTML = editor.questions.map(rowHtml).join("");
  el("exam-count").textContent = `${editor.questions.length} câu · ${editor.questions.reduce((total, row) => total + (Number(row.points) || 0), 0)} điểm`;
}

/* Cô giáo có thể đang gõ dở, nên đọc lại màn hình trước khi dựng lại bảng câu. */
function collectRows() {
  return [...el("exam-rows").querySelectorAll("[data-row]")].map((node, i) => {
    const type = node.querySelector("[data-field=type]").value;
    const base = { type, text: node.querySelector("[data-field=text]").value, points: Number(node.querySelector("[data-field=points]").value), index: i };
    if (type === "text") return { ...base, prompt: node.querySelector("[data-field=prompt]")?.value ?? "" };
    const checked = node.querySelector(`input[name="key-${i}"]:checked`);
    return { ...base, options: [...node.querySelectorAll("[data-option]")].map(input => input.value), answer: checked ? Number(checked.value) : 0 };
  });
}

async function editQuestions(event) {
  const button = event.target.closest("button");
  if (!button || !editor) return;
  const row = event.target.closest("[data-row]");
  const i = row ? Number(row.dataset.row) : -1;
  if (button.id === "exam-cancel") { editor = null; el("exam-editor").hidden = true; return; }
  if (button.id === "exam-add") { editor.questions = collectRows(); editor.questions.push(blankQuestion()); return paintRows(); }
  if (button.id === "exam-parse") return parsePaste();
  if (button.id === "exam-save") return saveExam();
  if (i < 0) return;
  editor.questions = collectRows();
  if (button.dataset.up !== undefined || button.dataset.down !== undefined) {
    const to = i + (button.dataset.up !== undefined ? -1 : 1);
    if (editor.questions[to]) [editor.questions[i], editor.questions[to]] = [editor.questions[to], editor.questions[i]];
  } else if (button.dataset.dropRow !== undefined) editor.questions.splice(i, 1);
  else if (button.dataset.addOption !== undefined) editor.questions[i].options.push("");
  else if (button.dataset.dropOption !== undefined) {
    const dropped = Number(button.dataset.dropOption);
    editor.questions[i].options.splice(dropped, 1);
    editor.questions[i].answer = Math.min(editor.questions[i].answer, Math.max(0, editor.questions[i].options.length - 1));
  } else return;
  paintRows();
}

async function parsePaste() {
  try {
    const parsed = await api("/api/papers/parse", { form: new FormData([["text", el("exam-paste").value]]) });
    editor.questions = editor.questions.filter(question => question.text).concat(parsed.questions);
    el("exam-errors").textContent = parsed.notes.join(" · ");
    paintRows();
    notify(document, `Đã dịch ${parsed.questions.length} câu. Cô rà lại đáp án rồi bấm lưu đề.`);
  } catch (error) {
    el("exam-errors").textContent = error.message;
  }
}

async function saveExam() {
  editor.questions = collectRows();
  const body = {
    title: el("exam-title").value.trim(),
    duration_minutes: Number(el("exam-duration").value),
    questions: editor.questions,
  };
  try {
    await api(editor.id ? `/api/exams/${editor.id}` : `/api/rooms/${roomId}/exams`, { method: editor.id ? "PUT" : "POST", body });
    editor = null;
    el("exam-editor").hidden = true;
    await refresh();
    notify(document, "Đã lưu đề. Đề vẫn ở trạng thái chưa mở — bấm “Mở cho học sinh” đúng lúc cả lớp đã vào.");
  } catch (error) {
    el("exam-errors").textContent = error.message;
  }
}

async function uploadExam(event) {
  const file = event.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  form.append("title", file.name.replace(/\.[^.]+$/, ""));
  form.append("duration", "45");
  try {
    const exam = await api(`/api/rooms/${roomId}/exams/import`, { method: "POST", form });
    await refresh();
    notify(document, `Đã nạp ${exam.question_count} câu từ ${file.name}.${exam.notes?.length ? ` Lưu ý: ${exam.notes.join(" · ")}` : ""}`);
  } catch (error) {
    notify(document, error.message, true);
  } finally {
    event.target.value = "";
  }
}

function examCard(exam) {
  const attempts = exam.attempts;
  const submitted = attempts.filter(attempt => attempt.submitted_at).length;
  return `<article class="card p-4" data-exam="${exam.id}">
    <div class="flex flex-wrap items-center justify-between gap-3">
      <div><h4 class="font-bold text-slate-900">${escape(exam.title)}
        <span class="pill ${exam.published ? "bg-moss-soft text-moss" : "bg-slate-100 text-slate-600"}">${exam.published ? "Đang mở" : "Chưa mở"}</span></h4>
        <p class="text-xs text-slate-500">${exam.question_count} câu · ${exam.duration_minutes} phút · ${exam.max_points} điểm ·
          ${attempts.length}/${exam.students} em vào làm · ${submitted} em đã nộp</p></div>
      <div class="flex flex-wrap gap-2">
        <button data-publish="${exam.published ? "false" : "true"}" class="${exam.published ? "btn-ghost" : "btn-primary"} px-3 py-1 text-xs">
          ${exam.published ? "Đóng đề" : "Mở cho học sinh"}</button>
        <button data-edit class="btn-ghost px-3 py-1 text-xs">Sửa đề</button>
        <button data-detail class="btn-ghost px-3 py-1 text-xs">${detail?.id === exam.id ? "Ẩn bài làm" : "Xem bài & chấm"}</button>
        <button data-csv class="btn-ghost px-3 py-1 text-xs">Tải kết quả CSV</button>
        <button data-drop class="btn-danger px-3 py-1 text-xs">Xóa</button>
      </div>
    </div>${detail?.id === exam.id ? detailHtml(exam) : ""}</article>`;
}

function detailHtml(exam) {
  const questions = detail.questions;
  return `<div class="mt-4 grid gap-3 border-t border-slate-200 pt-4">
    ${detail.attempts.map(attempt => `<details class="rounded-lg border border-slate-200 p-3">
      <summary class="cursor-pointer text-sm font-semibold">
        ${escape(attempt.seat_id)} ${escape(attempt.name)} · ${attempt.submitted_at ? `${attempt.score ?? 0}/${exam.max_points} điểm` : "chưa nộp"}
        · rời cửa sổ ${minutes(attempt.tab_ms)} · dán ${attempt.paste_count} lần</summary>
      <ol class="mt-3 grid gap-2 text-sm">
        ${questions.map((question, i) => {
          const value = attempt.answers[String(i)];
          const blank = value === undefined || value === "";
          const shown = blank ? "<em class=\"text-slate-400\">bỏ trống</em>"
            : question.type === "mcq" ? escape(`${LETTERS[Number(value)]}. ${question.options[Number(value)] ?? value}`) : escape(value);
          const verdict = question.type !== "mcq" || blank ? ""
            : Number(value) === question.answer ? ' <span class="pill bg-moss-soft text-moss">đúng</span>' : ' <span class="pill bg-red-100 text-red-700">sai</span>';
          const mark = question.type === "text" && attempt.submitted_at
            ? `<label class="ml-2 inline-flex items-center gap-1 text-xs text-slate-600">Chấm
                <input data-mark="${i}" data-attempt="${attempt.id}" type="number" min="0" max="${question.points}" step="0.25"
                  value="${attempt.marks?.[String(i)] ?? ""}" class="field w-20 py-1 text-xs">/${question.points}đ</label>` : "";
          return `<li><strong>Câu ${i + 1}</strong> (${question.points}đ) — ${shown}${verdict}${mark}</li>`;
        }).join("")}
      </ol></details>`).join("") || '<p class="text-sm text-slate-500">Chưa em nào vào làm đề này.</p>'}</div>`;
}

function paintExams() {
  el("exam-list").innerHTML = room.exams.map(examCard).join("")
    || '<p class="card p-6 text-center text-sm text-slate-500">Chưa có đề nào. Bấm “Soạn đề mới” hoặc tải tệp đề lên.</p>';
}

async function examActions(event) {
  const button = event.target.closest("button");
  if (!button) return;
  const exam = room.exams.find(item => item.id === button.closest("[data-exam]")?.dataset.exam);
  if (!exam) return;
  try {
    if (button.dataset.publish !== undefined) {
      await api(`/api/exams/${exam.id}/publish`, { method: "POST", body: { published: button.dataset.publish === "true" } });
      await refresh();
      return notify(document, button.dataset.publish === "true" ? "Đã mở đề cho lớp." : "Đã đóng đề, học sinh không vào làm được nữa.");
    }
    if (button.dataset.edit !== undefined) return openEditor(blankEditor(await api(`/api/exams/${exam.id}`)));
    if (button.dataset.detail !== undefined) {
      detail = detail?.id === exam.id ? null : { id: exam.id, ...(await api(`/api/exams/${exam.id}/results`)) };
      return paintExams();
    }
    if (button.dataset.csv !== undefined) return openCsv(exam);
    if (button.dataset.drop !== undefined) {
      if (!confirm(`Xóa đề “${exam.title}”? Bài làm và cảnh báo của đề này sẽ bị xóa theo.`)) return;
      await api(`/api/exams/${exam.id}`, { method: "DELETE" });
      detail = null;
      await refresh();
    }
  } catch (error) {
    notify(document, error.message, true);
  }
}

function openCsv(exam) {
  if (!detail || detail.id !== exam.id) return notify(document, "Bấm “Xem bài & chấm” trước để máy chủ gửi kèm đáp án vào tệp.", true);
  location.href = `/api/exams/${exam.id}/results.csv`;
}

async function saveMarks(event) {
  const input = event.target.closest("[data-mark]");
  if (!input) return;
  const marks = {};
  el("exam-list").querySelectorAll(`[data-mark][data-attempt="${input.dataset.attempt}"]`).forEach(cell => {
    if (cell.value !== "") marks[cell.dataset.mark] = Number(cell.value);
  });
  try {
    await api(`/api/attempts/${input.dataset.attempt}/marks`, { method: "PUT", body: { marks } });
    detail = { id: detail.id, ...(await api(`/api/exams/${detail.id}/results`)) };
    paintExams();
    await refresh();
    notify(document, "Đã lưu điểm và cộng vào bài thi.");
  } catch (error) {
    notify(document, error.message, true);
  }
}

/* Đổi một câu từ trắc nghiệm sang tự luận phải vẽ lại thân câu để hiện ô hướng dẫn chấm. */
function switchType(event) {
  const select = event.target.closest("[data-field=type]");
  if (!select || !editor) return;
  editor.questions = collectRows();
  editor.questions[Number(select.closest("[data-row]").dataset.row)].type = select.value;
  paintRows();
}

/* ---------------------------------------------------------------- bảng theo dõi */

function statusOf(attempt, past, now) {
  if (!attempt) return { tone: "idle", label: "Chưa vào làm" };
  if (attempt.submitted_at) return { tone: "done", label: "Đã nộp" };
  const elapsed = past ? Math.max(POLL_MS, now - past.at) : 0;
  const away = past ? Math.max(0, attempt.tab_ms - past.tab_ms) : 0;
  if (away > elapsed * 0.6) return { tone: "alert", label: "Đang rời cửa sổ" };
  if (now - attempt.last_seen > ONLINK_MS) return { tone: "idle", label: "Máy mất kết nối" };
  if (!attempt.answered) return { tone: "warn", label: "Vào làm, chưa trả lời câu nào" };
  return { tone: "ok", label: `Đang làm ${attempt.answered} câu` };
}

const camCell = student => room.cam_enabled ? `<td>
    <button data-cam="${student.id}" data-who="${escape(student.seat_id)} ${escape(student.name)}"
      class="${student.id === room.cam_watching ? "btn-danger" : "btn-ghost"} px-2 py-1 text-xs">
      ${student.id === room.cam_watching ? "Đang soi" : "Xem"}</button></td>` : "";

function paintBoard() {
  const now = Date.now();
  el("board").innerHTML = room.exams.filter(exam => exam.attempts.length || exam.published).map(exam => {
    const bySeat = new Map(exam.attempts.map(attempt => [attempt.student_id, attempt]));
    return `<article class="card overflow-hidden">
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-2">
        <h4 class="font-bold text-slate-900">${escape(exam.title)} <span class="pill bg-slate-100 text-slate-600">${exam.duration_minutes} phút</span></h4>
        <p class="text-xs text-slate-500">${exam.attempts.length}/${exam.students} em vào làm ·
          ${exam.attempts.filter(attempt => attempt.submitted_at).length} em đã nộp</p>
      </div>
      <div class="overflow-x-auto"><table class="table w-full"><thead><tr>
        <th>Chỗ</th><th>Học sinh</th><th>Trạng thái</th><th>Đã làm</th><th>Điểm</th><th>Rời cửa sổ</th><th>Dán bài</th><th>Lưu cuối</th>${room.cam_enabled ? "<th>Camera</th>" : ""}</tr></thead>
        <tbody>${room.students.map(student => {
          const attempt = bySeat.get(student.id);
          const status = statusOf(attempt, previous.get(attempt?.id), now);
          return `<tr><td class="font-mono text-xs">${escape(student.seat_id)}</td>
            <td>${escape(student.name)}<span class="block font-mono text-xs text-slate-400">${escape(student.student_code)}</span></td>
            <td><span class="pill ${TONES[status.tone]}">${status.label}</span></td>
            <td>${attempt ? `${attempt.answered}/${exam.question_count}` : "—"}</td>
            <td>${attempt?.score ?? "—"}</td><td>${attempt ? `${minutes(attempt.tab_ms)} · ${attempt.tab_events} lần` : "—"}</td>
            <td>${attempt?.paste_count ?? 0}</td><td>${attempt ? clock(attempt.last_seen) : "—"}</td>${camCell(student)}</tr>`;
        }).join("")}</tbody></table></div></article>`;
  }).join("") || '<p class="card p-6 text-center text-sm text-slate-500">Chưa có đề nào đang mở cho lớp này.</p>';
  const counters = new Map();
  for (const exam of room.exams) for (const attempt of exam.attempts) counters.set(attempt.id, { tab_ms: attempt.tab_ms, at: now });
  // Chỉ giữ số liệu cũ trong 10 phút: bài đã đóng không được khiến dòng đỏ mãi trên bảng.
  previous = new Map([...[...previous].filter(([id, seen]) => !counters.has(id) && now - seen.at <= 600000), ...counters]);
}

function paintAlerts() {
  const names = new Map(room.students.map(student => [student.id, `${student.seat_id} ${student.name}`]));
  const labels = { tab_left: "Rời cửa sổ làm bài", paste: "Dán bài vào ô trả lời", idle: "Ngừng làm bài" };
  el("alerts").innerHTML = room.events.length
    ? room.events.map(event => `<div class="flex flex-wrap items-center gap-2 px-4 py-2 text-sm">
        <time class="w-40 text-xs text-slate-500">${dateTime(event.created_at)}</time>
        <span class="font-medium">${escape(names.get(event.student_id) ?? "Học sinh đã rời lớp")}</span>
        <span class="pill ${event.risk >= 60 ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-800"}">${labels[event.rule] ?? event.rule}</span>
        ${event.duration ? `<span class="text-xs text-slate-500">${Math.round(event.duration)} giây</span>` : ""}</div>`).join("")
    : '<p class="p-6 text-center text-sm text-slate-500">Chưa có cảnh báo nào trong phòng này.</p>';
}

boot();
