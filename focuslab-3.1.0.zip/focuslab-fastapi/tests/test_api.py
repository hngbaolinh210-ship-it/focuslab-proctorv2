"""Chạy thử trọn luồng: giáo viên lập phòng → tải đề → học sinh vào thi → máy chấm → thầy cô xem kết quả."""
from __future__ import annotations

import io
import os
import re
import tempfile
import time
import unittest

from fastapi.testclient import TestClient

from app import main, papers

PAPER = [
    {"type": "mcq", "text": "Chọn đáp án đúng của 把", "options": ["bǎ", "ba", "bà"], "answer": 0, "points": 2},
    {"type": "mcq", "text": "Chọn đáp án đúng của 放", "options": ["fàng", "páng"], "answer": 1, "points": 3},
    {"type": "text", "text": "Đặt một câu với 放在", "prompt": "khoảng 30 từ", "points": 5},
]


class ApiTest(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.folder.cleanup)
        # một tiến trình duy nhất, nhiều máy truy cập vào — giống phòng thi thật
        self.application = main.create_app(os.path.join(self.folder.name, "thi.db"))
        self.addCleanup(self.application.state.store.close)
        self.client = self.new_client()

    def new_client(self) -> TestClient:
        client = TestClient(self.application)
        client.cookies.clear()
        return client

    def sign_in_teacher(self, client: TestClient | None = None, username="linhtc", password="phongthi2026") -> TestClient:
        client = client or self.client
        response = client.post("/api/teacher/setup", json={"username": username, "password": password, "display_name": "Cô Linh"})
        self.assertEqual(response.status_code, 200, response.text)
        return client

    def make_room(self, students=(("N01", "Nguyễn Văn An"), ("N02", "Trần Bình"))) -> tuple[str, list[dict]]:
        room = self.client.post("/api/rooms", json={"title": "Lớp 12A1"}).json()
        roster = self.client.put(f"/api/rooms/{room['id']}/students",
                                 json={"students": [{"student_code": c, "name": n} for c, n in students]}).json()["students"]
        return room["id"], roster

    def open_exam(self, room_id: str, duration=30, published=True) -> str:
        exam = self.client.post(f"/api/rooms/{room_id}/exams",
                                json={"title": "Kiểm tra buổi 5", "duration_minutes": duration, "questions": PAPER}).json()
        if published:
            self.client.post(f"/api/exams/{exam['id']}/publish", json={"published": True})
        return exam["id"]

    def join(self, roster: list[dict], entry=0, code=None) -> TestClient:
        room = self.client.get("/api/rooms").json()[0]
        student = self.new_client()
        body = {"room_code": room["code"], "student_code": roster[entry]["student_code"],
                "access_code": code or roster[entry]["join_code"]}
        response = student.post("/api/join", json=body)
        self.assertEqual(response.status_code, 200, response.text)
        return student

    # ---------------------------------------------------------------- tài khoản

    def test_first_account_becomes_owner_and_only_first(self):
        me = self.client.get("/api/me").json()
        self.assertIsNone(me["role"])
        self.sign_in_teacher()
        self.assertEqual(self.client.get("/api/me").json()["role"], "teacher")
        self.assertTrue(self.client.get("/api/me").json()["is_owner"])
        # tài khoản thứ hai không tự mở được từ trang đăng nhập
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "khac", "password": "matkhau123"}).status_code, 403)

    def test_login_rejects_wrong_password_and_unknown_user(self):
        self.client.post("/api/teacher/setup", json={"username": "linhtc", "password": "phongthi2026"})
        self.client.post("/api/logout")
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "linhtc", "password": "sai"}).status_code, 401)
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "khongco", "password": "phongthi2026"}).status_code, 401)
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "LINHTC", "password": "phongthi2026"}).status_code, 200)

    def test_login_before_any_account_points_at_setup(self):
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "a", "password": "b"}).status_code, 404)

    def test_owner_can_invite_second_teacher(self):
        self.sign_in_teacher()
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": "thayhung", "password": "daythi2026",
                                                                      "display_name": "Thầy Hùng"}).status_code, 200)
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": "thayhung", "password": "daythi2026"}).status_code, 409)
        other = TestClient(self.client.app)
        other.cookies.clear()
        self.assertEqual(other.post("/api/teacher/login", json={"username": "thayhung", "password": "daythi2026"}).status_code, 200)

    def second_teacher(self, username="thayhung", password="daythi2026") -> TestClient:
        """Thầy cô thường: chỉ thấy phòng do mình lập, khác với tài khoản quản trị đầu tiên."""
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": username, "password": password,
                                                                      "display_name": "Thầy Hùng"}).status_code, 200)
        other = self.new_client()
        self.assertEqual(other.post("/api/teacher/login", json={"username": username, "password": password}).status_code, 200)
        return other

    def test_weak_credentials_are_rejected(self):
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "a", "password": "12345678"}).status_code, 422)
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "linhtc", "password": "ngan"}).status_code, 422)

    def test_api_requires_login(self):
        self.assertEqual(self.client.get("/api/rooms").status_code, 401)
        self.assertEqual(self.client.get("/api/exams").status_code, 401)

    # ---------------------------------------------------------------- phòng và danh sách lớp

    def test_room_code_and_student_codes_are_short(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        room = self.client.get("/api/rooms").json()[0]
        self.assertRegex(room["code"], r"^[A-HJ-KM-Z2-9]{8}$")
        for student in roster:
            self.assertRegex(student["join_code"], r"^[A-HJ-KM-Z2-9]{8}$")
        self.assertEqual(len({s["join_code"] for s in roster}), len(roster))
        self.assertEqual([s["seat_id"] for s in roster], ["S01", "S02"])

    def test_join_accepts_lowercase_and_wrong_caps_lock(self):
        self.sign_in_teacher()
        _, roster = self.make_room()
        student = self.join(roster, code=roster[0]["join_code"].lower())
        self.assertEqual(student.get("/api/me").json()["role"], "student")

    def test_join_rejects_wrong_code_unknown_student_and_closed_room(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        room = self.client.get("/api/rooms").json()[0]
        bad = self.new_client()
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N01",
                                                    "access_code": "SAIMASAI"}).status_code, 401)
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N99",
                                                    "access_code": roster[0]["join_code"]}).status_code, 401)
        self.client.patch(f"/api/rooms/{room_id}", json={"closed": True})
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N01",
                                                    "access_code": roster[0]["join_code"]}).status_code, 403)

    def test_roster_csv_upload_assigns_codes(self):
        self.sign_in_teacher()
        room = self.client.post("/api/rooms", json={"title": "Lớp 11B"}).json()
        data = io.BytesIO("Mã học sinh;Họ và tên\nM01;Phạm Minh\nM02;Lê Hoa\n".encode("utf-8-sig").replace(b";", b","))
        response = self.client.post(f"/api/rooms/{room['id']}/roster", files={"file": ("lop.csv", data, "text/csv")})
        self.assertEqual(response.status_code, 200, response.text)
        students = response.json()["students"]
        self.assertEqual([s["student_code"] for s in students], ["M01", "M02"])
        self.assertEqual(students[0]["name"], "Phạm Minh")

    def test_roster_replaces_previous_list_and_exports_codes(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        self.client.put(f"/api/rooms/{room_id}/students", json={"students": [{"student_code": "K01", "name": "Chỉ Một Em"}]})
        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual([s["student_code"] for s in state["students"]], ["K01"])
        csv = self.client.get(f"/api/rooms/{room_id}/codes.csv")
        self.assertIn("text/csv", csv.headers["content-type"])
        self.assertIn("Chỉ Một Em", csv.text)

    def test_roster_rejects_accented_student_code(self):
        self.sign_in_teacher()
        room = self.client.post("/api/rooms", json={"title": "Lớp 12A2"}).json()
        response = self.client.post(f"/api/rooms/{room['id']}/roster", files={"file": ("a.csv", "mã hs,tên\nNguyễn,An\n".encode(), "text/csv")})
        self.assertEqual(response.status_code, 422)

    def test_delete_room_removes_exams_and_attempts(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}})
        self.assertEqual(self.client.delete(f"/api/rooms/{room_id}").status_code, 200)
        self.assertEqual(self.client.get("/api/rooms").json(), [])

    def test_remove_student_clears_their_attempt(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster, 0).post(f"/api/exams/{exam_id}/start")
        self.join(roster, 1).post(f"/api/exams/{exam_id}/start")
        self.client.delete(f"/api/students/{roster[1]['id']}")
        self.assertEqual(len(self.client.get(f"/api/exams/{exam_id}").json()["attempts"]), 1)

    def test_second_teacher_cannot_touch_another_rooms_data(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        attempt_id = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "2": "Bài làm"}}).json()["id"]
        hung = self.second_teacher()

        self.assertEqual(hung.get("/api/rooms").json(), [])
        for method, url, body in (
            ("GET", f"/api/rooms/{room_id}", None),
            ("PATCH", f"/api/rooms/{room_id}", {"title": "Đổi trộm"}),
            ("PUT", f"/api/rooms/{room_id}/students", {"students": [{"student_code": "Z01", "name": "Em lạ"}]}),
            ("GET", f"/api/rooms/{room_id}/codes.csv", None),
            ("POST", f"/api/rooms/{room_id}/exams", {"title": "Đề lạ", "duration_minutes": 30, "questions": PAPER}),
            ("DELETE", f"/api/students/{roster[0]['id']}", None),
            ("GET", f"/api/exams/{exam_id}", None),
            ("GET", f"/api/exams/{exam_id}/results", None),
            ("GET", f"/api/exams/{exam_id}/results.csv", None),
            ("PUT", f"/api/exams/{exam_id}", {"title": "Sửa trộm", "duration_minutes": 30, "questions": PAPER}),
            ("POST", f"/api/exams/{exam_id}/publish", {"published": False}),
            ("DELETE", f"/api/exams/{exam_id}", None),
            ("PUT", f"/api/attempts/{attempt_id}/marks", {"marks": {"2": 5}}),
            ("POST", f"/api/rooms/{room_id}/cam/watch", {"student_id": roster[0]["id"]}),
            ("GET", f"/api/rooms/{room_id}/cam/{roster[0]['id']}", None),
        ):
            response = hung.request(method, url, json=body)
            self.assertEqual(response.status_code, 404, f"{method} {url} → {response.status_code} {response.text}")

        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual(state["title"], "Lớp 12A1")
        self.assertEqual([s["student_code"] for s in state["students"]], ["N01", "N02"])
        self.assertEqual(self.client.get(f"/api/exams/{exam_id}/results").json()["attempts"][0]["score"], 2)
        # phòng của thầy Hùng thì thầy Hùng dùng vô tư, cô quản trị vẫn thấy để bao quát cả kỳ thi
        hung_room = hung.post("/api/rooms", json={"title": "Lớp 11C"}).json()
        self.assertEqual([room["title"] for room in hung.get("/api/rooms").json()], ["Lớp 11C"])
        self.assertIn(hung_room["id"], [room["id"] for room in self.client.get("/api/rooms").json()])

    # ---------------------------------------------------------------- đề thi

    def test_exam_validation(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 30, "questions": []}).status_code, 422)
        broken = [{**PAPER[0], "answer": 9}]
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 30, "questions": broken}).status_code, 422)
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 2, "questions": PAPER}).status_code, 422)

    def test_hundred_question_paper_is_accepted(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        text = "\n".join(f"Câu {i}: Nội dung {i}?\nA. một\nB. hai\nĐA: A\nĐiểm: 1" for i in range(1, 101))
        questions = papers.parse_text(text)["questions"]
        exam = self.client.post(f"/api/rooms/{room_id}/exams",
                                json={"title": "Đề 100 câu", "duration_minutes": 90, "questions": questions})
        self.assertEqual(exam.status_code, 200, exam.text)
        self.assertEqual(exam.json()["question_count"], 100)
        self.assertEqual(exam.json()["max_points"], 100)

    def test_pdf_docx_csv_txt_import(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        txt = "Câu 1: Hỏi một\nA. a\nB. b\nĐA: A\nĐiểm: 2\n\nCâu 2: Hỏi hai\nA. c\nB. d\nĐA: B\nĐiểm: 2"
        for name, payload, count in (
            ("de.txt", txt.encode(), 2),
            ("de.csv", "question,A,B,answer,points\nHỏi một,a,b,A,2\n".encode(), 1),
        ):
            response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                        files={"file": (name, io.BytesIO(payload), "text/plain")},
                                        data={"title": f"Từ {name}", "duration": "45"})
            self.assertEqual(response.status_code, 200, response.text)
            self.assertEqual(response.json()["question_count"], count)

        import docx

        buffer = io.BytesIO()
        document = docx.Document()
        for line in txt.split("\n"):
            document.add_paragraph(line)
        document.save(buffer)
        buffer.seek(0)
        response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                    files={"file": ("de.docx", buffer, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
                                    data={"title": "Từ Word", "duration": "60"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["question_count"], 2)

    def test_upload_rejects_legacy_doc_and_unknown_type(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        for name, body in (("de.doc", b"doc"), ("de.xlsx", b"xlsx")):
            response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                        files={"file": (name, io.BytesIO(body), "application/octet-stream")})
            self.assertEqual(response.status_code, 422, response.text)

    def test_paste_preview_needs_no_room_and_blocks_students(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        text = "Câu 1: Hỏi một\nA. a\nB. b\nĐA: B"
        parsed = self.client.post("/api/papers/parse", data={"text": text}).json()
        self.assertEqual(parsed["questions"][0]["answer"], 1)
        self.assertEqual(self.client.post("/api/papers/parse", data={"text": "   "}).status_code, 422)
        self.assertEqual(self.join(roster).post("/api/papers/parse", data={"text": text}).status_code, 401)

    def test_exam_locked_once_students_started(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster).post(f"/api/exams/{exam_id}/start")
        response = self.client.put(f"/api/exams/{exam_id}", json={"title": "Sửa đề", "duration_minutes": 30, "questions": PAPER})
        self.assertEqual(response.status_code, 409)

    def test_unpublished_exam_invisible_to_students(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id, published=False)
        student = self.join(roster)
        self.assertEqual(student.get("/api/exams").json(), [])
        self.assertEqual(student.get(f"/api/exams/{exam_id}/paper").status_code, 409)

    def test_other_room_cannot_see_exam(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        exam_id = self.open_exam(room_id)
        other_room = self.client.post("/api/rooms", json={"title": "Lớp khác"}).json()
        other_students = self.client.put(f"/api/rooms/{other_room['id']}/students",
                                         json={"students": [{"student_code": "X01", "name": "Em Khác"}]}).json()["students"]
        room_code = next(room["code"] for room in self.client.get("/api/rooms").json() if room["title"] == "Lớp khác")
        outsider = self.new_client()
        joined = outsider.post("/api/join", json={"room_code": room_code, "student_code": "X01",
                                                 "access_code": other_students[0]["join_code"]})
        self.assertEqual(joined.status_code, 200, joined.text)
        self.assertEqual(outsider.get(f"/api/exams/{exam_id}/paper").status_code, 404)

    # ---------------------------------------------------------------- camera live

    def test_live_camera_only_streams_while_the_teacher_watches(self):
        frame = b"\xff\xd8\xff\xe0" + b"h" * 800
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        first, second = self.join(roster, 0), self.join(roster, 1)
        first.post(f"/api/exams/{exam_id}/start")
        second.post(f"/api/exams/{exam_id}/start")

        # chưa bật camera cho phòng thì chưa xem được em nào
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/cam/watch",
                                          json={"student_id": roster[0]["id"]}).status_code, 409)
        self.assertEqual(first.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})
        room = self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": True}).json()
        self.assertTrue(room["cam_enabled"])
        self.assertIsNone(room["cam_watching"])
        self.assertFalse(first.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).json()["cam_wanted"])

        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/cam/watch",
                                          json={"student_id": roster[1]["id"]}).json()["watching"], roster[1]["id"])

        # cô đang soi em thứ hai: chỉ em đó được gửi hình, em khác im lặng
        self.assertTrue(second.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).json()["cam_wanted"])
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": True})
        self.assertEqual(first.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})
        live = self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}")
        self.assertEqual(live.status_code, 200)
        self.assertEqual(live.content, frame)
        self.assertEqual(live.headers["content-type"], "image/jpeg")
        self.assertIn("no-store", live.headers["cache-control"])
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[0]['id']}").status_code, 404)

        # ảnh rác thì báo về máy chủ, không có chỗ cho ảnh quá lớn hoặc trống
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=b"").status_code, 422)
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=b"x" * (main.cam.MAX_FRAME_BYTES + 1)).status_code, 422)
        other_room = self.client.post("/api/rooms", json={"title": "Lớp khác"}).json()["id"]
        self.client.patch(f"/api/rooms/{other_room}", json={"cam_enabled": True})
        self.assertEqual(self.client.post(f"/api/rooms/{other_room}/cam/watch",
                                          json={"student_id": roster[1]["id"]}).status_code, 422)

        # em tự tắt camera thì khung xem trống, cô không còn nhận hình
        self.assertEqual(second.delete(f"/api/exams/{exam_id}/cam").json(), {"wanted": False})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}").status_code, 404)

        # nộp bài là hết xem — ảnh không nằm lại trên máy chủ
        self.client.post(f"/api/rooms/{room_id}/cam/watch", json={"student_id": roster[1]["id"]})
        second.put(f"/api/exams/{exam_id}/cam", content=frame)
        second.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}").status_code, 404)
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})

        # tắt camera cho phòng: phòng sạch ảnh, bảng của cô hiện cam_watching = None
        self.client.post(f"/api/rooms/{room_id}/cam/watch", json={"student_id": roster[0]["id"]})
        first.put(f"/api/exams/{exam_id}/cam", content=frame)
        closed = self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": False}).json()
        self.assertIsNone(closed["cam_watching"])
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[0]['id']}").status_code, 404)

    # ---------------------------------------------------------------- giờ thi và chấm điểm

    def test_full_exam_flow_and_autosave(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        self.assertEqual(student.get("/api/exams").json()[0]["state"], "chưa vào làm")
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).status_code, 409)
        started = student.post(f"/api/exams/{exam_id}/start").json()
        self.assertEqual(len(started["questions"]), 3)
        self.assertFalse(any("answer" in str(question) for question in started["questions"]))
        self.assertTrue(30 * 60_000 - 3000 <= started["remaining_ms"] <= 30 * 60_000, started["remaining_ms"])
        saved = student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0, "1": 0, "2": "Em đặt câu với 放在."},
                                                                "tab_ms": 4000, "tab_events": 1, "paste_count": 1}).json()
        self.assertEqual(saved["answered"], 3)
        submitted = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "1": 1, "2": "Bài tự luận"}}).json()
        self.assertEqual(submitted["score"], 5)  # chỉ câu 1 đúng (2đ), câu 2 sai, tự luận chờ thầy chấm
        self.assertEqual(student.post(f"/api/exams/{exam_id}/submit", json={"answers": {}}).json()["already"], True)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}}).status_code, 409)
        result = student.get(f"/api/exams/{exam_id}/result").json()
        self.assertEqual(result["answered"], 3)
        self.assertEqual(result["max_points"], 10)

    def test_server_clock_closes_overdue_attempt(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id, duration=5)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0, "1": 1}})
        # đồng hồ chạy trước: đẩy started_at về quá khứ rồi xin giấy thi, máy chủ phải tự chốt điểm
        store = self.client.app.state.store
        store.transact(lambda conn: conn.execute("UPDATE attempts SET started_at = ? WHERE exam_id = ?",
                                                 (int(time.time() * 1000) - 10 * 60_000, exam_id)))
        paper = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertEqual(paper["remaining_ms"], 0)
        self.assertIsNotNone(paper["submitted_at"])
        self.assertEqual(paper["score"], 5)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}}).status_code, 409)
        board = self.client.get(f"/api/exams/{exam_id}/results").json()
        self.assertEqual(board["attempts"][0]["score"], 5)

    def test_grading_ignores_answer_indices_out_of_range(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        saved = student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 9, "7": 1, "x": 2, "1": 1}}).json()
        self.assertEqual(saved["answered"], 1)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/submit", json={"answers": {}}).json()["score"], 3)

    def test_teacher_marks_essay_and_score_updates(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        submitted = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "2": "Bài làm"}}).json()
        attempt_id = submitted["id"]
        self.assertEqual(self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"0": 2}}).status_code, 422)
        marked = self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"2": 4}}).json()
        self.assertEqual(marked["score"], 6)
        self.assertEqual(self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"2": 99}}).json()["score"], 7)

    def test_tab_and_paste_alerts_reach_the_board(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        self.assertEqual(student.post(f"/api/exams/{exam_id}/event", json={"rule": "tab_left", "duration": 12,
                                                                         "client_id": "abc"}).status_code, 200)
        student.post(f"/api/exams/{exam_id}/event", json={"rule": "tab_left", "duration": 12, "client_id": "abc"})
        self.assertEqual(student.post(f"/api/exams/{exam_id}/event", json={"rule": "camera"}).status_code, 422)
        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual(len(state["events"]), 1)
        self.assertEqual(state["events"][0]["rule"], "tab_left")
        self.assertEqual(state["events"][0]["risk"], 70)

    def test_student_cannot_read_the_answer_key_or_others_results(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        self.assertEqual(student.get(f"/api/exams/{exam_id}").status_code, 401)
        self.assertEqual(student.get(f"/api/exams/{exam_id}/results").status_code, 401)
        self.assertEqual(student.get("/api/rooms").status_code, 401)
        paper = student.get(f"/api/exams/{exam_id}/paper")
        self.assertNotIn('"answer"', paper.text)

    def test_results_csv_lists_every_answer(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster).post(f"/api/exams/{exam_id}/start")
        self.client.post(f"/api/exams/{exam_id}/publish", json={"published": True})
        csv = self.client.get(f"/api/exams/{exam_id}/results.csv")
        self.assertEqual(csv.status_code, 200)
        self.assertIn("Câu 1", csv.text)
        self.assertIn("N01", csv.text)

    def test_templates_download(self):
        self.assertEqual(self.client.get("/api/templates/roster.csv").status_code, 200)
        self.assertIn("question", self.client.get("/api/templates/paper.csv").text)

    def test_health_and_pages(self):
        health = self.client.get("/api/health").json()
        self.assertTrue(health["ok"])
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/teacher").status_code, 200)
        self.assertEqual(self.client.get("/exam").status_code, 200)
