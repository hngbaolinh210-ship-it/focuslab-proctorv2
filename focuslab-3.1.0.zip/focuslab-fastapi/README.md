# FocusLab 3.1.0 — nền tảng thi trực tuyến (FastAPI + Tailwind)

Máy chủ Python FastAPI, một tệp SQLite, **không dùng camera**. Giáo viên tạo phòng → nạp danh sách → tải đề
(PDF/Word/CSV) hoặc dán câu hỏi → mở đề. Học sinh vào bằng ba mã, làm bài với lưới câu hỏi bên phải,
máy chấm trắc nghiệm ngay khi nộp.

## Chạy trên máy cô

```
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8099
```

Mở `http://127.0.0.1:8099` — lần chạy đầu bấm **Tạo tài khoản đầu tiên**.

## Kiểm tra trước khi đóng gói

```
.venv\Scripts\python -m unittest discover -s tests      # 48 ca kiểm thử
node chay-thu-e2e.mjs                                   # 68 buoc thi that (can server chay song)
```

Giao diện dùng `static/app.css` đã biên dịch sẵn, **không tải Tailwind từ mạng** trong giờ thi.
Khi sửa `static/input.css` thì build lại:

```
npx @tailwindcss/cli -i static/input.css -o static/app.css --minify
```

## Biến môi trường

| Biến | Mặc định | Dùng khi |
| --- | --- | --- |
| `FOCUSLAB_DB` | `data/focuslab-thi.db` | Railway đặt `/data/focuslab-thi.db` để ghi vào volume |
| `FOCUSLAB_COOKIE_SECURE` | tắt | Bật `=1` khi truy cập qua HTTPS (Railway đã bật sẵn trong Dockerfile) |
| `PORT` | `8000` | Railway tự cấp, Dockerfile dùng `${PORT:-8000}` |

## Cấu trúc

- `app/main.py` — toàn bộ API và ba trang `/`, `/teacher`, `/exam`
- `app/db.py` — sơ đồ SQLite (tự thêm cột mới, không xóa dữ liệu cũ)
- `app/auth.py` — mật khẩu scrypt, mã phòng/mã tham gia 8 ký tự
- `app/papers.py` — dịch đề từ PDF/Word/CSV/TXT/dán văn bản sang câu hỏi
- `static/` — HTML + JS + `app.css` (đã biên dịch)
- `chay-thu-e2e.mjs` — kịch bản chạy thử cả buổi thi bằng HTTP thật

## Quy tắc đã cài đặt

- Một đề tối đa 100 câu, mỗi câu 1–20 điểm; học sinh không bao giờ nhận được đáp án đúng qua API.
- Đồng hồ do máy chủ giữ, cộng 90 giây chịu trễ; quá giờ thì máy chủ tự chốt và chấm, kể cả em quên nộp.
- Đã có em vào làm thì đề bị khóa, sửa phải tạo đề mới.
- Theo dõi chống gian lận chỉ bằng nhật ký: rời thẻ bao nhiêu giây, dán bài mấy lần — không ghi hình.
- Tài khoản quản trị đầu tiên tự tạo; tài khoản thầy cô khác phải do quản trị viên thêm.
