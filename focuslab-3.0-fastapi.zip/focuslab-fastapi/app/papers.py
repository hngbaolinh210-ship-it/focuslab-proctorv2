"""Dịch đề thi thành câu hỏi. Đề có thể đến từ bốn nguồn: dán văn bản, tệp .txt, tệp .csv, hoặc PDF/Word.

Văn bản tiếng Việt trong đề thi có dấu, có bảng và có nhiều kiểu đánh số, nên mọi chỗ so khớp ở đây đều
bỏ dấu trước ("ĐA", "đáp án", "Dap an" đều là "dap an"). Quy tắc tách câu dùng được cho cả bản copy từ
Word lẫn bản trích từ PDF: một dòng bắt đầu bằng "Câu 12:" hoặc "12." mở một câu mới, không cần dòng trống.
"""
from __future__ import annotations

import csv
import io
import re
import unicodedata

LETTERS = "ABCDEFGH"
MAX_QUESTIONS = 100
MAX_TEXT = 4000
MAX_PROMPT = 500
MIN_POINTS, MAX_POINTS = 1, 20
MIN_OPTIONS, MAX_OPTIONS = 2, 8
MAX_UPLOAD_BYTES = 8 * 1024 * 1024


class PaperError(ValueError):
    """Lỗi đề thi: thông điệp tiếng Việt gửi thẳng lên giao diện."""


def plain(text) -> str:
    folded = unicodedata.normalize("NFD", str(text))
    folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
    return folded.lower().replace("đ", "d")


# "Câu 1:", "Câu 3." và "2)" là nhãn câu; "Ca múa…" là câu hỏi tình cờ bắt đầu bằng hai chữ cái đó.
LEADING_LABEL = re.compile(r"^\s*(?:c[aâ]u\s*(?:\d+\s*[:.)-]?|[:.)-])\s*|\d+\s*[.)]\s*)", re.IGNORECASE)
LABEL_NUMBER = re.compile(r"^cau\s*(\d{1,3})(?!\d)")
BARE_NUMBER = re.compile(r"^(\d{1,3})[.)]\s")
OPTION_LINE = re.compile(r"^[a-h][.)]", re.IGNORECASE)
POINTS_LINE = re.compile(r"^diem (\d{1,2})$")
ANSWER_LETTER = re.compile(r"^(?:da|dap an|dap an dung|true|correct) ([a-h])$")
ANSWER_NUMBER = re.compile(r"^(?:da|dap an|dap an dung|true|correct) (\d{1,2})$")
ESSAY_LINE = re.compile(r"^tu luan( .*)?$")


def leading_label(line: str) -> str:
    return LEADING_LABEL.sub("", line, count=1).strip()


def question_number(line: str):
    tag = plain(line)
    found = LABEL_NUMBER.match(tag) or BARE_NUMBER.match(tag)
    return int(found.group(1)) if found else None


def strip_words(line: str, words) -> str:
    parts = line.strip().split()
    used = 0
    while used < len(words) and used < len(parts) and plain(re.sub(r"[:.,;]+$", "", parts[used])) == words[used]:
        used += 1
    # Chỉ bỏ nhãn khi tìm được cả cụm, để một câu hỏi bắt đầu bằng "Tự" giữ nguyên đề bài của nó.
    return " ".join(parts[used:]) if used == len(words) else line.strip()


def blocks_from_text(text: str) -> list[str]:
    blocks: list[str] = []
    current: list[str] = []
    last = 0

    def flush() -> None:
        if current:
            blocks.append("\n".join(current))
            del current[:]

    for raw in str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line:
            flush()
            continue
        number = question_number(line)
        # Số nhỏ hơn số câu trước không được tính là câu mới: phương án đánh 1/2/3/4 hay dòng nối của đề
        # bài phải nằm lại trong câu của nó.
        if number is not None and number > last:
            last = number
            flush()
        current.append(line)
    flush()
    return blocks


def blank_question(kind: str = "mcq") -> dict:
    if kind == "text":
        return {"type": "text", "text": "", "prompt": "", "points": 5}
    return {"type": "mcq", "text": "", "options": ["", "", "", ""], "answer": 0, "points": 2}


def parse_text(text: str) -> dict:
    questions: list[dict] = []
    notes: list[str] = []
    for block in blocks_from_text(text):
        kind, stem, prompt, points, answer_letter = "mcq", "", "", None, None
        slots: dict[int, str] = {}
        seen_text = False
        for raw in block.split("\n"):
            line = raw.strip()
            if not line:
                continue
            tag = re.sub(r"\s+", " ", re.sub(r"[:=.]", " ", plain(line))).strip()
            if OPTION_LINE.match(line):
                slots[LETTERS.index(line[0].upper())] = line[2:].strip()
                continue
            if ESSAY_LINE.match(tag):
                kind, prompt = "text", strip_words(line, ["tu", "luan"])
                continue
            points_line, letter_line, number_line = POINTS_LINE.match(tag), ANSWER_LETTER.match(tag), ANSWER_NUMBER.match(tag)
            if points_line:
                points = int(points_line.group(1))
                continue
            if letter_line:
                answer_letter = letter_line.group(1).upper()
                continue
            if number_line:
                index = int(number_line.group(1)) - 1
                answer_letter = LETTERS[index] if 0 <= index < len(LETTERS) else None
                continue
            if not seen_text:
                stem, seen_text = leading_label(line), True
                continue
            stem = f"{stem}\n{line}"
        if not seen_text or not stem or not re.search(r"\w", stem):
            notes.append(f'Bỏ qua một khối không có nội dung câu hỏi: "{block[:40]}"')
            continue
        if kind == "mcq":
            options = [slots[key] for key in sorted(slots)]
            if len(options) < MIN_OPTIONS:
                kind, prompt = "text", ""
                notes.append(f'Câu "{stem[:30]}" không có phương án A, B nên thành câu tự luận.')
            else:
                marked = slots.get(LETTERS.index(answer_letter), "") if answer_letter and answer_letter in LETTERS else ""
                if marked and marked in options:
                    answer = options.index(marked)
                else:
                    answer = 0
                    reason = f'đáp án {answer_letter} không khớp phương án nào' if answer_letter else 'chưa ghi dòng "ĐA: …"'
                    notes.append(f'Câu "{stem[:30]}": {reason} nên tạm chọn phương án đầu. Kiểm tra lại trước khi mở đề.')
                questions.append({"type": "mcq", "text": stem, "options": options, "answer": answer, "points": points if points is not None else 2})
                continue
        questions.append({"type": "text", "text": stem, "prompt": prompt, "points": points if points is not None else 5})
    return {"questions": questions, "notes": notes}


def _header_key(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", plain(name))


CSV_FIELDS = {
    "text": ("question", "cau", "no dung", "noidung", "debai", "content", "noi dung cau hoi"),
    "type": ("type", "loai", "kind"),
    "prompt": ("prompt", "huong dan", "huongdancham", "huong dan cham", "huongdandancham"),
    "answer": ("answer", "da", "dapan", "dap an", "dapan dung"),
    "points": ("points", "diem", "point", "score"),
}


def parse_csv(data: bytes) -> dict:
    text = decode_text(data)
    lines = text.splitlines()
    first = lines[0] if lines else ""
    # Excel tiếng Việt xuất CSV dùng dấu chấm phẩy; nhận cả hai mà không bắt giáo viên chọn thủ công.
    delimiter = ";" if ";" in first and "," not in first else ","
    rows = [row for row in csv.reader(io.StringIO(text), delimiter=delimiter) if any(str(value).strip() for value in row)]
    if len(rows) < 2:
        raise PaperError("Tệp CSV cần một dòng tiêu đề và ít nhất một dòng câu hỏi. Hãy tải tệp mẫu trong khu soạn đề.")
    header = [_header_key(name) for name in rows[0]]
    columns: dict[str, int] = {}
    for field, aliases in CSV_FIELDS.items():
        for index, name in enumerate(header):
            if name in [_header_key(alias) for alias in aliases]:
                columns[field] = index
                break
    option_columns = [index for index, name in enumerate(header) if re.fullmatch(r"[a-h]", name)]
    if "text" not in columns:
        raise PaperError("Tệp CSV thiếu cột câu hỏi. Tiêu đề cần có: question, A, B, C, D, answer, points.")
    questions, notes = [], []
    for line_no, row in enumerate(rows[1:], start=2):
        def cell(field, default=""):
            index = columns.get(field)
            return str(row[index]).strip() if index is not None and index < len(row) else default
        stem = cell("text")
        if not stem:
            notes.append(f"Dòng {line_no} thiếu nội dung câu hỏi nên được bỏ qua.")
            continue
        kind = plain(cell("type"))
        options = [str(row[index]).strip() for index in option_columns if index < len(row) and str(row[index]).strip()]
        points = re.sub(r"\D", "", cell("points")) or ("5" if kind in ("tu luan", "tuluan", "text", "essay") and not options else "2")
        if not options:
            questions.append({"type": "text", "text": stem, "prompt": cell("prompt"), "points": int(points)})
            continue
        raw_answer = cell("answer").upper()
        if re.fullmatch(r"\d+", raw_answer):
            answer = int(raw_answer) - 1
        elif re.fullmatch(r"[A-H][.)]?", raw_answer or "."):
            answer = LETTERS.index(raw_answer[0])
        else:
            match = next((index for index, option in enumerate(options) if plain(option) == plain(raw_answer)), 0)
            answer = match
        questions.append({"type": "mcq", "text": stem, "options": options, "answer": answer, "points": int(points)})
    return {"questions": questions, "notes": notes}


def decode_text(data: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


def pdf_text(data: bytes) -> str:
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as error:
            raise PaperError("File PDF đang được đặt mật khẩu, máy không đọc được bên trong.") from error
    return "\n\n".join((page.extract_text() or "") for page in reader.pages)


def docx_text(data: bytes) -> str:
    import docx

    document = docx.Document(io.BytesIO(data))
    parts = [paragraph.text for paragraph in document.paragraphs]
    # Bàn trong Word bị tách riêng; mỗi dòng bàn được coi là một câu để bộ tách văn bản xử lý tiếp.
    for table in document.tables:
        for row in table.rows:
            parts.append("\n".join(cell.text for cell in row.cells))
    return "\n".join(parts)


PARSERS = {
    ".txt": lambda data: parse_text(decode_text(data)),
    ".md": lambda data: parse_text(decode_text(data)),
    ".csv": parse_csv,
    ".pdf": lambda data: parse_text(pdf_text(data)),
    ".docx": lambda data: parse_text(docx_text(data)),
}


def parse_upload(filename: str, data: bytes) -> dict:
    extension = "." + re.sub(r"^.*\.", "", str(filename or "")).lower()
    if not data:
        raise PaperError("Tệp rỗng.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise PaperError("Tệp lớn quá 8 MB. Hãy tách đề thành nhiều tệp nhỏ hơn.")
    if extension == ".doc":
        raise PaperError("Word định dạng .doc (2003) không đọc được. Hãy lưu lại thành .docx hoặc .pdf rồi tải lên.")
    parser = PARSERS.get(extension)
    if not parser:
        raise PaperError("Tệp hỗ trợ: .pdf, .docx, .csv, .txt, .md.")
    result = parser(data)
    if not result["questions"]:
        raise PaperError("Máy không tìm thấy câu hỏi nào trong tệp. Với PDF nhiều cột hoặc có ảnh công thức, hãy dùng CSV theo tệp mẫu.")
    return result


def normalize_questions(items) -> list[dict]:
    if not isinstance(items, list) or not items:
        raise PaperError("Đề thi cần ít nhất 1 câu.")
    if len(items) > MAX_QUESTIONS:
        raise PaperError(f"Một đề tối đa {MAX_QUESTIONS} câu, đang có {len(items)} câu.")
    cleaned = []
    for index, item in enumerate(items):
        label = f"Câu {index + 1}"
        if not isinstance(item, dict):
            raise PaperError(f"{label}: thiếu dữ liệu.")
        stem = str(item.get("text") or "").strip()
        if not stem:
            raise PaperError(f"{label}: thiếu nội dung câu hỏi.")
        if len(stem) > MAX_TEXT:
            raise PaperError(f"{label}: nội dung dài quá {MAX_TEXT} ký tự.")
        try:
            points = int(round(float(item.get("points"))))
        except (TypeError, ValueError) as error:
            raise PaperError(f"{label}: điểm cần là số nguyên từ {MIN_POINTS} đến {MAX_POINTS}.") from error
        if not MIN_POINTS <= points <= MAX_POINTS:
            raise PaperError(f"{label}: điểm cần là số nguyên từ {MIN_POINTS} đến {MAX_POINTS}.")
        kind = "mcq" if item.get("type") == "mcq" else "text" if item.get("type") == "text" else None
        if kind is None:
            raise PaperError(f"{label}: chưa chọn loại câu (trắc nghiệm hoặc tự luận).")
        if kind == "text":
            cleaned.append({"type": "text", "text": stem, "prompt": str(item.get("prompt") or "").strip()[:MAX_PROMPT], "points": points})
            continue
        options = [str(option or "").strip() for option in (item.get("options") or [])]
        if not MIN_OPTIONS <= len(options) <= MAX_OPTIONS:
            raise PaperError(f"{label}: trắc nghiệm cần {MIN_OPTIONS}–{MAX_OPTIONS} phương án.")
        if any(not option for option in options):
            raise PaperError(f"{label}: có phương án đang để trống.")
        try:
            answer = int(item.get("answer"))
        except (TypeError, ValueError) as error:
            raise PaperError(f"{label}: đáp án đúng phải là một phương án có trong câu.") from error
        if not 0 <= answer < len(options):
            raise PaperError(f"{label}: đáp án đúng phải là một phương án có trong câu.")
        cleaned.append({"type": "mcq", "text": stem, "options": options, "answer": answer, "points": points})
    return cleaned


def max_points(questions) -> int:
    return sum(question["points"] for question in questions)


def csv_template() -> str:
    rows = [["question", "A", "B", "C", "D", "answer", "points"],
            ["Chọn đáp án đúng: 把 + ?", "S1 + 把 + S2 + V", "S1 + V + 把 + S2", "S2 + 把 + S1 + V", "Không dùng 把", "A", "2"],
            ["Viết một câu với 放在", "", "", "", "", "", "5"]]
    return "\ufeff" + "\r\n".join(",".join(f'"{cell}"' if any(char in cell for char in ',"\r\n') else cell for cell in row) for row in rows) + "\r\n"
