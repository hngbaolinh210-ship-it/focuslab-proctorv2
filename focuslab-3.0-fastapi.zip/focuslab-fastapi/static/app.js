/* Gọi API cùng máy chủ, báo lỗi bằng tiếng Việt và giữ nguyên cookie phiên làm việc. */

export async function api(path, { method, body, form, keepalive = false } = {}) {
  const send = form ?? body;
  const response = await fetch(path, {
    method: method ?? (send ? "POST" : "GET"),
    credentials: "same-origin",
    keepalive,
    headers: form ? undefined : send ? { "content-type": "application/json" } : undefined,
    body: form ?? (send ? JSON.stringify(send) : undefined),
  });
  if (!response.ok) {
    const detail = await response.json().catch(() => ({}));
    const message = typeof detail.detail === "string" ? detail.detail : detail.detail?.[0]?.msg;
    throw new Error(message || `Máy chủ trả lời ${response.status}.`);
  }
  return response.json();
}

export const only = (root, selector) => root.querySelector(selector);

export function escape(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}

export const clock = moment => new Date(moment).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });

export const dateTime = moment => (moment ? new Date(moment).toLocaleString("vi-VN") : "—");

export function minutes(ms) {
  const total = Math.round(ms / 1000);
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

export function countDown(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(total / 3600);
  const rest = `${String(Math.floor(total / 60) % 60).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
  return hours ? `${hours}:${rest}` : rest;
}

let toastTimer;
export function notify(page, message, bad = false) {
  const box = only(page, "toast");
  box.textContent = message;
  box.className = `fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-lg px-4 py-2 text-sm font-medium shadow-lg transition
    ${bad ? "bg-red-700 text-white" : "bg-moss text-white"}`;
  box.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { box.hidden = true; }, bad ? 7000 : 3500);
}
