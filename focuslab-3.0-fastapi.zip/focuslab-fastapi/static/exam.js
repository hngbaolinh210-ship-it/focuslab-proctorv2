/* Trang làm bài của học sinh: đồng hồ do máy chủ giữ, bài tự lưu mỗi 5 giây, bảng câu hỏi bên phải. */
import { api, escape, notify, countDown, clock } from "/static/app.js";

const LETTERS = "ABCDEFGH";
const SAVE_EVERY = 5000;
const el = id => document.getElementById(id);

let me, paper, questions = [], answers = {}, index = 0, remaining = 0;
let tickTimer, saveTimer, wired = false;
let dirty = false, submitted = false;
let tabMs = 0, tabEvents = 0, pasteCount = 0, hiddenAt = 0;

const draftKey = () => `focuslab-de-${paper.id}-${me.student_code}`;
const isAnswered = i => answers[String(i)] !== undefined && answers[String(i)] !== "";
const answeredCount = () => questions.reduce((total, _question, i) => total + (isAnswered(i) ? 1 : 0), 0);

async function boot() {
  try {
    me = await api("/api/me");
  } catch {
    el("loading").textContent = "Không nối được máy chủ. Em tải lại trang sau vài giây nhé.";
    return;
  }
  if (me.role !== "student") return location.replace("/");
  el("loading").hidden = true;
  el("lobby").hidden = false;
  el("leave").addEventListener("click", leave);
  el("back").addEventListener("click", () => show("lobby"));
  el("restore-yes").addEventListener("click", useDraft);
  el("restore-no").addEventListener("click", () => { el("restore").hidden = true; localStorage.removeItem(draftKey()); });
  wireDeskOnce();
  await renderLobby();
  const wanted = new URLSearchParams(location.search).get("de");
  if (wanted) openExam(wanted);
}

function show(name) {
  for (const id of ["lobby", "desk", "finish"]) el(id).hidden = id !== name;
}

async function leave() {
  await api("/api/logout", { method: "POST" }).catch(() => {});
  location.replace("/");
}

async function renderLobby() {
  const exams = await api("/api/exams");
  el("lobby-title").textContent = me.room_title;
  el("lobby-student").textContent = `${me.name} · chỗ ngồi ${me.seat_id}`;
  el("lobby-list").innerHTML = exams.length
    ? exams.map(exam => `<article class="card flex flex-wrap items-center justify-between gap-3 p-4">
        <div>
          <h3 class="font-bold text-slate-900">${escape(exam.title)}</h3>
          <p class="text-xs text-slate-500">${exam.question_count} câu · ${exam.duration_minutes} phút · ${exam.max_points} điểm ·
            <span class="pill ${exam.state === "đã nộp" ? "bg-moss-soft text-moss" : "bg-slate-100 text-slate-600"}">${escape(exam.state)}</span>
            ${exam.score === null || exam.score === undefined ? "" : ` · ${exam.score}/${exam.max_points} điểm`}</p>
        </div>
        ${exam.state === "đã nộp"
          ? `<button class="btn-ghost" data-open="${exam.id}">Xem lại điểm</button>`
          : `<button class="btn-primary" data-open="${exam.id}">${exam.state === "đang làm" ? "Tiếp tục làm bài" : "Bắt đầu làm bài"}</button>`}
      </article>`).join("")
    : '<p class="card p-6 text-center text-sm text-slate-500">Cô giáo chưa mở đề nào cho lớp. Em ngồi tại chỗ, đề mở ra sẽ hiện ở đây.</p>';
  el("lobby-list").querySelectorAll("[data-open]").forEach(button =>
    button.addEventListener("click", () => openExam(button.dataset.open)));
  show("lobby");
  return exams;
}

async function openExam(id) {
  history.replaceState(null, "", `?de=${id}`);
  let sheet;
  try {
    sheet = await api(`/api/exams/${id}/paper`);
  } catch (error) {
    notify(document, error.message, true);
    return renderLobby();
  }
  if (!sheet.started_at) {
    const ready = confirm(`Đề "${sheet.title}" có ${sheet.questions.length} câu, làm trong ${sheet.duration_minutes} phút.\n\n`
      + "Máy chủ bắt đầu tính giờ ngay khi em bấm Bắt đầu và sẽ tự nộp bài khi hết giờ.\nEm đã sẵn sàng chưa?");
    if (!ready) return;
    sheet = await api(`/api/exams/${id}/start`, { method: "POST" });
  }
  paper = sheet;
  questions = sheet.questions;
  answers = { ...sheet.answers };
  tabMs = sheet.tab_ms;
  tabEvents = sheet.tab_events;
  pasteCount = sheet.paste_count;
  submitted = Boolean(sheet.submitted_at);
  if (submitted) return showFinish(sheet.score, sheet.max_points);
  renderDesk();
  show("desk");
  runClock(sheet.remaining_ms);
  startAutosave();
  watchPresence();
  offerDraft();
}

function renderDesk() {
  el("desk-title").textContent = paper.title;
  el("desk-meta").textContent = `${me.room_title} · ${questions.length} câu · ${paper.max_points} điểm`;
  el("track").innerHTML = questions.map(questionPanel).join("");
  el("palette").innerHTML = questions.map((_question, i) =>
    `<button class="palette-cell" data-goto="${i}" title="Đến câu ${i + 1}"><span>${i + 1}</span><span class="tick">✓</span></button>`).join("");
  el("submit").textContent = "Nộp bài";
  paint();
  goTo(0);
}

function questionPanel(question, i) {
  const chosen = answers[String(i)];
  const body = question.type === "mcq"
    ? `<div class="grid gap-2">${question.options.map((option, j) => optionButton(question, i, option, j, chosen)).join("")}</div>`
    : `<textarea data-essay rows="7" class="field" placeholder="Em viết bài làm vào đây…">${escape(answers[String(i)] ?? "")}</textarea>
       ${question.prompt ? `<p class="mt-2 text-xs text-slate-500">Hướng dẫn: ${escape(question.prompt)}</p>` : ""}`;
  return `<section data-question="${i}" class="p-5">
      <p class="mb-4 text-lg leading-relaxed text-slate-800">${escape(question.text)}</p>${body}
    </section>`;
}

const optionButton = (question, i, option, j, chosen) => `<button data-pick="${j}" class="${optionClass(j === chosen)}">
    <span class="grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs
      ${j === chosen ? "border-moss bg-moss text-white" : "border-slate-300 text-slate-600"}">${LETTERS[j]}</span>
    <span>${escape(option)}</span></button>`;

const optionClass = on => `option flex items-start gap-3 rounded-lg border p-3 text-left text-sm transition
  ${on ? "border-moss bg-moss-soft font-semibold text-moss" : "border-slate-300 bg-white hover:border-moss"}`;

/* Một lượt nghe duy nhất cho cả trang: đổi đề, chuyển câu đều không phải gắn lại listener. */
function wireDeskOnce() {
  if (wired) return;
  wired = true;
  el("track").addEventListener("click", event => {
    const button = event.target.closest("[data-pick]");
    if (!button) return;
    pick(Number(button.closest("[data-question]").dataset.question), Number(button.dataset.pick));
  });
  el("track").addEventListener("input", event => {
    if (!event.target.matches("[data-essay]")) return;
    answers[String(event.target.closest("[data-question]").dataset.question)] = event.target.value;
    touch();
  });
  el("track").addEventListener("paste", () => {
    pasteCount += 1;
    flag("paste");
  });
  el("palette").addEventListener("click", event => {
    const cell = event.target.closest("[data-goto]");
    if (cell) goTo(Number(cell.dataset.goto));
  });
  el("prev").addEventListener("click", () => goTo(index - 1));
  el("next").addEventListener("click", () => goTo(index + 1));
  el("submit").addEventListener("click", () => submitNow());
  document.addEventListener("keydown", keys);
}

function paint() {
  el("q-counter").textContent = `Câu ${index + 1} / ${questions.length}`;
  el("q-points").textContent = `${questions[index].points} điểm`;
  el("prev").disabled = index === 0;
  el("next").disabled = index === questions.length - 1;
  const done = answeredCount();
  el("progress").textContent = `Đã làm ${done}/${questions.length} câu · còn ${questions.length - done} câu chưa làm`;
  el("palette").querySelectorAll("[data-goto]").forEach((cell, i) => {
    cell.classList.toggle("done", isAnswered(i));
    cell.classList.toggle("current", i === index);
  });
  el("track").querySelectorAll("[data-question]").forEach(panel => {
    const i = Number(panel.dataset.question);
    if (questions[i].type !== "mcq") return;
    panel.querySelectorAll("[data-pick]").forEach(button => {
      const on = Number(button.dataset.pick) === answers[String(i)];
      button.className = optionClass(on);
      button.firstElementChild.className = `grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs
        ${on ? "border-moss bg-moss text-white" : "border-slate-300 text-slate-600"}`;
    });
  });
}

function goTo(target) {
  index = Math.max(0, Math.min(questions.length - 1, target));
  el("track").style.transform = `translateX(-${index * 100}%)`;
  paint();
}

function keys(event) {
  if (el("desk").hidden || event.target.matches("textarea") || submitted) return;
  if (event.key === "ArrowRight") goTo(index + 1);
  if (event.key === "ArrowLeft") goTo(index - 1);
}

function pick(i, option) {
  answers[String(i)] = option;
  touch();
  paint();
}

function touch() {
  dirty = true;
  localStorage.setItem(draftKey(), JSON.stringify({ answers, saved: Date.now() }));
  paint();
}

const payload = () => ({ answers, tab_ms: tabMs, tab_events: tabEvents, paste_count: pasteCount });

async function save({ keepalive = false } = {}) {
  if (submitted) return;
  dirty = false;
  try {
    const sheet = await api(`/api/exams/${paper.id}/save`, { method: "POST", body: payload(), keepalive });
    remaining = sheet.remaining_ms;
    el("save-state").textContent = `Đã lưu lên máy chủ lúc ${clock(Date.now())}`;
  } catch {
    dirty = true;
    el("save-state").textContent = "Chưa lưu được lên máy chủ. Bài vẫn giữ trên máy này, em kiểm tra mạng nhé.";
  }
}

function startAutosave() {
  clearInterval(saveTimer);
  saveTimer = setInterval(() => { if (dirty) save(); }, SAVE_EVERY);
  window.addEventListener("pagehide", () => { if (dirty) save({ keepalive: true }); });
}

async function flag(rule, duration) {
  try {
    await api(`/api/exams/${paper.id}/event`, { method: "POST", body: { rule, duration, client_id: crypto.randomUUID() } });
  } catch { /* mất một cảnh báo thì cô nhắc bằng lời, đừng làm gián đoạn bài thi */ }
}

function watchPresence() {
  document.addEventListener("visibilitychange", () => {
    if (el("desk").hidden || submitted) return;
    if (document.hidden) {
      hiddenAt = Date.now();
      tabEvents += 1;
      save({ keepalive: true });
    } else if (hiddenAt) {
      const away = Math.round((Date.now() - hiddenAt) / 1000);
      tabMs += away * 1000;
      hiddenAt = 0;
      flag("tab_left", away);
      el("save-state").textContent = `Em rời cửa sổ ${away} giây — cô giáo đã thấy trên bảng theo dõi.`;
    }
  });
}

function offerDraft() {
  const draft = readDraft();
  if (draft && Object.keys(answers).length === 0 && Object.keys(draft.answers).length) el("restore").hidden = false;
}

const readDraft = () => JSON.parse(localStorage.getItem(draftKey()) || "null");

function useDraft() {
  answers = { ...(readDraft()?.answers || {}) };
  el("restore").hidden = true;
  el("track").innerHTML = questions.map(questionPanel).join("");
  dirty = true;
  paint();
}

function runClock(ms) {
  remaining = Math.max(0, ms ?? 0);
  clearInterval(tickTimer);
  paintTimer();
  tickTimer = setInterval(() => {
    remaining = Math.max(0, remaining - 1000);
    paintTimer();
    if (remaining === 0) submitNow({ auto: true });
  }, 1000);
}

function paintTimer() {
  el("timer").textContent = countDown(remaining);
  el("timer").className = `font-mono text-3xl font-bold ${remaining < 300000 ? "text-red-600" : "text-moss"}`;
}

async function submitNow(options = {}) {
  const auto = Boolean(options.auto);
  if (!auto) {
    const left = questions.length - answeredCount();
    if (!confirm(left ? `Em còn ${left} câu chưa làm.\n\nBấm OK để nộp ngay, Cancel để ở lại làm tiếp.` : "Em nộp bài bây giờ nhé?")) return;
  }
  clearInterval(tickTimer);
  clearInterval(saveTimer);
  submitted = true;
  el("submit").disabled = true;
  try {
    const sheet = await api(`/api/exams/${paper.id}/submit`, { method: "POST", body: payload() });
    localStorage.removeItem(draftKey());
    showFinish(sheet.score, sheet.max_points, auto);
  } catch (error) {
    submitted = false;
    notify(document, `${error.message} Em thử nộp lại sau vài giây nhé.`, true);
    runClock(Math.max(remaining, 15000));
  }
}

function showFinish(score, max, auto = false) {
  el("finish-body").textContent = score === null || score === undefined
    ? "Bài của em đã được ghi nhận. Cô giáo sẽ chấm phần tự luận rồi cộng điểm."
    : `Điểm của em: ${score}/${max}.${auto ? " Máy chủ tự nộp khi hết giờ nên bài vẫn được chấm đủ." : ""}`;
  history.replaceState(null, "", location.pathname);
  show("finish");
}

boot();
