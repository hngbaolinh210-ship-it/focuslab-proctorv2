import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import papers


class ParseText(unittest.TestCase):
    def test_vietnamese_paper_with_blank_lines(self):
        result = papers.parse_text("""Câu 1: Chọn đáp án đúng: 把 + ?
A. S1 + 把 + S2 + V
B. S1 + V + 把 + S2
C. S2 + 把 + S1 + V
D. Không dùng 把
ĐA: A
Điểm: 3

2) Câu nào sau đây sai?
A. Sai
B. Đúng hơn
C. Đúng nhất
Đáp án: C

Câu 3: Đặt một câu với chữ 把
Tự luận: viết khoảng 30 từ
Điểm: 5
""")
        questions = result["questions"]
        self.assertEqual([q["type"] for q in questions], ["mcq", "mcq", "text"])
        self.assertEqual(questions[0]["answer"], 0)
        self.assertEqual(questions[0]["points"], 3)
        self.assertEqual(questions[1]["text"], "Câu nào sau đây sai?")
        self.assertEqual(questions[1]["answer"], 2)
        self.assertEqual(questions[2]["prompt"], "viết khoảng 30 từ")
        self.assertEqual(papers.max_points(questions), 10)

    def test_paste_from_word_without_blank_lines(self):
        text = "\n".join(f"Câu {i}: Nội dung câu {i}?\nA. một\nB. hai\nC. ba\nD. bốn\nĐA: B\nĐiểm: 1" for i in range(1, 101))
        questions = papers.parse_text(text)["questions"]
        self.assertEqual(len(questions), 100)
        self.assertEqual(questions[-1]["text"], "Nội dung câu 100?")
        self.assertEqual(questions[0]["options"], ["một", "hai", "ba", "bốn"])
        self.assertEqual(questions[0]["answer"], 1)

    def test_bare_numbering(self):
        questions = papers.parse_text("1. Hỏi một\nA. a\nB. b\nĐA: A\n2) Hỏi hai\nA. c\nB. d\nĐA: B")["questions"]
        self.assertEqual([q["text"] for q in questions], ["Hỏi một", "Hỏi hai"])

    def test_numbers_inside_a_question_stay_inside(self):
        result = papers.parse_text("Câu 37: Tính tổng\nA. một\nB. hai\nĐA: A\nĐiểm: 2\n1. gợi ý thêm\n2,5 là kết quả")
        self.assertEqual(len(result["questions"]), 1)
        self.assertIn("1. gợi ý thêm", result["questions"][0]["text"])

    def test_missing_answer_is_reported_not_guited(self):
        result = papers.parse_text("Câu 1: Hỏi\nA. một\nB. hai\nĐiểm: 2")
        self.assertEqual(result["questions"][0]["answer"], 0)
        self.assertIn('chưa ghi dòng', result["notes"][0])

    def test_wrong_answer_letter_is_reported(self):
        result = papers.parse_text("Câu 1: Hỏi\nA. một\nB. hai\nĐA: D\nĐiểm: 2")
        self.assertIn("không khớp phương án nào", result["notes"][0])

    def test_stem_without_options_becomes_essay(self):
        result = papers.parse_text("Câu 1: Chỉ có một dòng hỏi\nĐiểm: 3")
        self.assertEqual(result["questions"][0]["type"], "text")
        self.assertEqual(result["questions"][0]["points"], 3)
        self.assertEqual(len(result["notes"]), 1)

    def test_page_breaks_and_empty_input(self):
        self.assertEqual(papers.parse_text("")["questions"], [])
        self.assertIn("không có nội dung", papers.parse_text("---\n\n\n")["notes"][0])

    def test_question_starting_with_the_word_ca(self):
        questions = papers.parse_text("Ca múa hôm nay thế nào?\nA. vui\nB. buồn\nĐA: A")["questions"]
        self.assertEqual(questions[0]["text"], "Ca múa hôm nay thế nào?")

    def test_stem_keeps_its_own_line_breaks(self):
        questions = papers.parse_text("Câu 1: Đọc đoạn văn sau:\nHôm nay trời mưa.\nEm thấy gì?")["questions"]
        self.assertEqual(questions[0]["text"], "Đọc đoạn văn sau:\nHôm nay trời mưa.\nEm thấy gì?")


class ParseCsv(unittest.TestCase):
    def test_comma_and_semicolon(self):
        data = 'question,A,B,C,D,answer,points\r\n"Chào ?","A a","B b","C c","D d",B,2\r\n'.encode()
        self.assertEqual(papers.parse_csv(data)["questions"][0]["answer"], 1)
        viet = "question;A;B;answer;points\nHỏi;Một;Hai;C;4\n".encode("utf-8-sig")
        question = papers.parse_csv(viet)["questions"][0]
        self.assertEqual((question["text"], question["answer"], question["points"]), ("Hỏi", 2, 4))

    def test_essay_row_without_options(self):
        data = "question,type,prompt,points\nViết bài,tự luận,60 từ,5\n".encode()
        question = papers.parse_csv(data)["questions"][0]
        self.assertEqual(question["type"], "text")
        self.assertEqual(question["prompt"], "60 từ")

    def test_header_only_is_rejected(self):
        with self.assertRaises(papers.PaperError):
            papers.parse_csv(b"question,A,B\n")


class Normalize(unittest.TestCase):
    good = {"type": "mcq", "text": "Hỏi", "options": ["a", "b"], "answer": 1, "points": 2}

    def test_accepts_a_clean_paper(self):
        self.assertEqual(papers.normalize_questions([self.good])[0]["answer"], 1)

    def test_rejects_bad_rows(self):
        for item, message in [
            ({**self.good, "options": ["", "b"]}, "để trống"),
            ({**self.good, "answer": 5}, "đáp án đúng"),
            ({**self.good, "points": 0}, "số nguyên"),
            ({**self.good, "text": ""}, "thiếu nội dung"),
            ({**self.good, "type": "khác"}, "chưa chọn loại"),
        ]:
            with self.assertRaises(papers.PaperError) as caught:
                papers.normalize_questions([item])
            self.assertIn(message, str(caught.exception))

    def test_rejects_over_100_questions(self):
        with self.assertRaises(papers.PaperError):
            papers.normalize_questions([self.good] * 101)


class Uploads(unittest.TestCase):
    def test_txt_and_unknown_extension(self):
        self.assertEqual(len(papers.parse_upload("de.txt", "Câu 1: Hỏi\nA. a\nB. b\nĐA: A".encode())["questions"]), 1)
        with self.assertRaises(papers.PaperError):
            papers.parse_upload("de.exe", b"MZ")
        with self.assertRaises(papers.PaperError):
            papers.parse_upload("de.doc", b"x")
        with self.assertRaises(papers.PaperError):
            papers.parse_upload("de.pdf", b"")


if __name__ == "__main__":
    unittest.main()
