# FocusLab 3.4.0 — nền tảng thi trực tuyến (FastAPI + Tailwind)

Máy chủ Python FastAPI, một tệp SQLite. Giáo viên tạo phòng → nạp danh sách → tải đề (PDF/Word/CSV)
hoặc dán câu hỏi → mở đề. Học sinh vào bằng ba mã, làm bài với lưới câu hỏi bên phải, máy chấm trắc
nghiệm ngay khi nộp. Một đề là **đề thi** (máy đếm giờ từ lúc em bấm Bắt đầu) hoặc **bài tập về nhà**
(làm trong khoảng cô đặt, không đếm ngược, quá hạn là đóng). Cô giao bài và soạn đề chung một màn hình,
có lọc theo loại và tìm theo tên (gõ không dấu vẫn ra).
**Rời cửa sổ do máy chủ đo**: máy em báo tin mỗi 5 giây và ngừng báo khi bị ẩn, im lặng quá 10 giây là
có một mốc cộng tổng thời gian rời phòng — điện thoại tắt màn hình giữa chừng vẫn hiện, không cần
trình duyệt tự báo (trình duyệt điện thoại hay bị đông băng nên số nó tự khai không dùng được).
Camera là tùy chọn theo từng phòng: máy em
học sinh tự nhận diện bất thường và gửi cho cô **đúng một ảnh bằng chứng**, không quay video, không ghi đĩa.
Cô tải **Tải câu hỏi (.doc)** để in giao bài, kèm bản **có đáp án** chỉ riêng cô mở được.

## Chạy trên máy cô

```
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8099
```

Mở `http://127.0.0.1:8099` — lần chạy đầu bấm **Tạo tài khoản đầu tiên**.

## Kiểm tra trước khi đóng gói

```
.venv\Scripts\python -m unittest discover -s tests   # 77 ca kiểm thử
node chay-thu-phat-hien.mjs                          # 17 buoc thu bo phat hien tren may hoc sinh
node chay-thu-e2e.mjs                                # 135 buoc thi that (can server chay song o 8099, CSDL sach)
```

Giao diện dùng `static/app.css` đã biên dịch sẵn, **không tải Tailwind từ mạng** trong giờ thi.
Khi sửa `static/input.css` thì build lại:

```
npx @tailwindcss/cli -i static/input.css -o static/app.css --minify
```

## Biến môi trường

| Biến | Mặc định | Dùng khi |
| --- | --- | --- |
| `FOCUSLAB_DB` | `data/focuslab-thi.db` | Render/Railway đặt `/data/focuslab-thi.db` để ghi vào volume |
| `FOCUSLAB_BACKUP_URL` | không đặt → tắt sao lưu | **Đường kết nối PostgreSQL của Render**, để dữ liệu sống qua mỗi lần máy chủ khởi động lại |
| `FOCUSLAB_COOKIE_SECURE` | tắt | Bật `=1` khi truy cập qua HTTPS (Dockerfile đã bật sẵn) |
| `PORT` | `8000` | Render/Railway tự cấp, Dockerfile dùng `${PORT:-8000}` |

### Vì sao cần `FOCUSLAB_BACKUP_URL`

Bao miễn phí của Render có **ổ đĩa tạm**: hết phiên là `/data` trắng, phòng thi, danh sách và bài làm
bay theo. `app/vault.py` giải quyết bằng cách sau mỗi lượt ghi, máy chủ xuất toàn bộ SQLite thành một
bản SQL rồi cất vào **một dòng duy nhất** trong PostgreSQL (dịch vụ miễn phí, sống độc lập với web
service). Khi bật máy mà `/data` đang trống, máy chủ tự nạp bản đó về. Không phải chuyển truy vấn sang
PostgreSQL — vẫn SQLite như trước.

Cách lấy trên Render: tạo **PostgreSQL → Free** trong cùng region với web service → mở service đó →
tab **Files** (Docker/Render) → **Connect** → copy **Internal Database URL** → dán vào
Environment của web service với tên `FOCUSLAB_BACKUP_URL`. Đường kết nối có mật khẩu, vì vậy:
**không dán vào chat, không commit lên GitHub**. Kiểm tra bằng `GET /api/health`: thấy
`"backup": "ok 3s"` là sao lưu đang chạy; `"off"` là chưa đặt biến.

Ba trạng thái còn lại khi có sự cố:
- `"chưa nối được nơi giữ dữ liệu: …"` — PostgreSQL đang chết hoặc URL sai, **nhưng `/data` vẫn còn
  CSDL** nên giờ thi vẫn chạy, chỉ là không cất được bản sao. Sửa Environment rồi restart service.
- Máy chủ **không bật được** khi `/data` trắng mà PostgreSQL cũng không nối được — cố ý, để cô thấy
  ngay thay vì mở một hệ thống trống rồi sau này ghi đè lên bản sao lưu thật.
- `"lỗi: …"` — nối được lúc bật máy nhưng lần ghi gần nhất hỏng; luồng sao lưu tự thử lại mỗi 5 giây.

## Cấu trúc

- `app/main.py` — toàn bộ API và ba trang `/`, `/teacher`, `/exam`
- `app/db.py` — sơ đồ SQLite (tự thêm cột mới, không xóa dữ liệu cũ)
- `app/auth.py` — mật khẩu scrypt, mã phòng/mã tham gia 8 ký tự
- `app/papers.py` — dịch đề từ PDF/Word/CSV/TXT/dán văn bản sang câu hỏi
- `app/cam.py` — bảng ảnh trong RAM: khung hình live (8 giây) và ảnh bằng chứng (30 phút), không ghi đĩa
- `app/vault.py` — sao lưu nguyên tệp SQLite sang PostgreSQL, nạp lại khi khởi động
- `static/` — HTML + JS + `app.css` (đã biên dịch)
- `chay-thu-e2e.mjs` — kịch bản chạy thử cả buổi thi bằng HTTP thật
- `chay-thu-phat-hien.mjs` — kịch bản thử bộ phát hiện bằng khung hình giả, đồng hồ giả

## Quy tắc đã cài đặt

- Một đề tối đa 100 câu; điểm mỗi câu 0,25–20 (chấp nhận "0,25 điểm" khi dán và cột điểm thập phân trong CSV).
- Học sinh không bao giờ nhận được đáp án đúng qua API; giấy thi không kèm chữ `"answer"`.
- Đồng hồ do máy chủ giữ, cộng 90 giây chịu trễ; quá giờ thì máy chủ tự chốt và chấm, kể cả em quên nộp.
- Bài tập về nhà (`kind = "baotap"`) bỏ đồng hồ đếm ngược, chỉ theo `open_from`/`open_until`: chưa tới giờ mở
  hoặc đã qua hạn thì máy chủ chặn (409), nhưng em **đã vào làm** vẫn xem lại được bài và bài tự chốt ở hạn nộp.
  Để trống hạn là bài mở vô thời hạn, không bao giờ tự chốt.
- `GET /api/exams/{id}/paper.doc` (thêm `?answers=1` để có đáp án) chỉ thầy cô của phòng đó tải được:
  học sinh 401, thầy cô phòng khác 404.
- Đề chỉ khóa sau khi **có bài nộp**; cô xóa bài của em (hoặc cho cả lớp làm lại) là sửa được tiếp.
- Tên đăng nhập không phân biệt hoa thường, dấu và dấu chấm: `Co.Linh` với `co_linh` là một người, nên
  không tạo được tài khoản trùng. Họ tên hiển thị thì cứ trùng.
- Chống gian lận: nhật ký (rời thẻ, dán bài, idle) + ba dấu hiệu máy em tự nhận ra tại chỗ
  (`cam_dark`, `face_gone`, `object_raised`). Khung hình lấy mỗi 80 ms nên em giơ điện thoại 0,1–0,2 giây vẫn bị;
  `object_raised` còn so màu lạnh của màn hình với màu ấm của áo trắng/ánh đèn nên không nhầm đồng phục.
  Mỗi lần báo chỉ gửi **một** JPEG, giữ 30 phút trên RAM rồi mất.
- Tài khoản quản trị đầu tiên tự tạo; thầy cô khác do quản trị viên thêm trong hộp **Giáo viên & tài khoản**.
- Quyền hạn theo phòng: giám thị chỉ thấy phòng của mình; chỉ chủ tài khoản tải được bản sao lưu `.sql`.
