"""Mật khẩu, token phiên và mã tham gia của học sinh. Chỉ dùng thư viện chuẩn để máy chủ không phải cài thêm gì."""
from __future__ import annotations

import hashlib
import hmac
import secrets
from base64 import urlsafe_b64encode

SCRYPT_PARAMS = {"n": 16384, "r": 8, "p": 1, "maxmem": 64 * 1024 * 1024}

# Bỏ I, L, O, 0, 1 vì giáo viên đọc mã từ tờ giấy in và học sinh gõ lại ngay trước giờ thi.
CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"

SESSION_COOKIE = "focuslab_session"
SESSION_DAYS = 24 * 3600 * 1000


def session_token() -> str:
    return urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _from_alphabet(length: int) -> str:
    return "".join(CODE_ALPHABET[secrets.randbelow(len(CODE_ALPHABET))] for _ in range(length))


def room_code() -> str:
    return _from_alphabet(8)


def access_code() -> str:
    return _from_alphabet(8)


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    key = hashlib.scrypt(password.encode(), salt=salt, dklen=64, **SCRYPT_PARAMS)
    return f"{salt.hex()}:{key.hex()}"


def password_matches(password: str, stored: str) -> bool:
    try:
        salt_hex, key_hex = str(stored).split(":", 1)
        expected = bytes.fromhex(key_hex)
        actual = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), dklen=len(expected), **SCRYPT_PARAMS)
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(expected, actual)
