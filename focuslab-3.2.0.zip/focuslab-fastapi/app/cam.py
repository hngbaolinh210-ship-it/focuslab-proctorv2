"""Camera: ảnh nằm trong RAM của tiến trình, không ghi đĩa, không vào SQLite.

Máy chủ chỉ chuyển ảnh từ máy em học sinh sang máy cô giáo. Khung hình đang xem bị bỏ sau
vài giây; ảnh bằng chứng (một ảnh duy nhất, do máy em tự gửi khi phát hiện bất thường) giữ
30 phút để cô kịp mở xem trong buổi thi, rồi cũng mất. Không có bất kỳ bản ghi hình nào.
"""
from __future__ import annotations

import threading
import time

FRAME_TTL_S = 8.0
EVIDENCE_TTL_S = 30 * 60.0
MAX_FRAME_BYTES = 120_000


class CameraBoard:
    """Bảng ảnh đang xem: một phòng chỉ xem được một em mỗi lần."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frames: dict[str, tuple[bytes, float]] = {}
        self._watching: dict[str, str | None] = {}
        self._evidence: dict[str, tuple[str, bytes, float, float]] = {}

    def watch(self, room_id: str, student_id: str | None) -> str | None:
        with self._lock:
            if student_id is None:
                self._watching.pop(room_id, None)
                return None
            self._watching[room_id] = student_id
            return student_id

    def watched(self, room_id: str) -> str | None:
        with self._lock:
            return self._watching.get(room_id)

    def wanted(self, room_id: str, student_id: str) -> bool:
        return self.watched(room_id) == student_id

    def put(self, room_id: str, student_id: str, data: bytes) -> bool:
        """Nhận ảnh khi cô đang nhìn em này; những lúc khác báo sai để trình duyệt ngừng gửi."""
        if not data or len(data) > MAX_FRAME_BYTES:
            return False
        with self._lock:
            if self._watching.get(room_id) != student_id:
                return False
            self._frames[student_id] = (data, time.monotonic())
            return True

    def get(self, student_id: str) -> bytes | None:
        with self._lock:
            frame = self._frames.get(student_id)
            if not frame:
                return None
            if time.monotonic() - frame[1] > FRAME_TTL_S:
                self._frames.pop(student_id, None)
                return None
            return frame[0]

    def drop_view(self, student_id: str) -> None:
        """Em nộp bài hoặc tự tắt camera: thôi xem hình, còn ảnh bằng chứng vẫn giữ để cô kịp mở."""
        with self._lock:
            self._frames.pop(student_id, None)
            for room, watched in list(self._watching.items()):
                if watched == student_id:
                    self._watching.pop(room, None)

    def drop(self, student_id: str) -> None:
        with self._lock:
            self._frames.pop(student_id, None)
            self._evidence.pop(student_id, None)
            for room, watched in list(self._watching.items()):
                if watched == student_id:
                    self._watching.pop(room, None)

    def forget_room(self, room_id: str) -> None:
        with self._lock:
            watched = self._watching.pop(room_id, None)
            if watched:
                self._frames.pop(watched, None)

    def push_evidence(self, student_id: str, rule: str, data: bytes) -> bool:
        """Nhận một ảnh bằng chứng duy nhất khi máy em báo bất thường; không nhận thêm ảnh nữa."""
        if not data or len(data) > MAX_FRAME_BYTES:
            return False
        with self._lock:
            self._evidence[student_id] = (rule, data, time.monotonic(), time.time())
            return True

    def evidence(self, student_id: str) -> tuple[str, bytes] | None:
        with self._lock:
            item = self._evidence.get(student_id)
            if not item:
                return None
            if time.monotonic() - item[2] > EVIDENCE_TTL_S:
                self._evidence.pop(student_id, None)
                return None
            return item[0], item[1]

    def evidence_list(self, student_ids) -> list[dict]:
        """Danh sách em có ảnh bằng chứng còn hạn, kèm tuổi của ảnh để bảng theo dõi đánh dấu."""
        out = []
        for student_id in student_ids:
            with self._lock:
                item = self._evidence.get(student_id)
                if not item or time.monotonic() - item[2] > EVIDENCE_TTL_S:
                    continue
                out.append({"student_id": student_id, "rule": item[0], "age_ms": int((time.time() - item[3]) * 1000)})
        return out
