"""Giữ hộ dữ liệu qua mỗi lần máy chủ khởi động lại, bằng cách cất nguyên bản CSDL lên PostgreSQL.

Render dịch vụ miễn phí có ổ đĩa tạm: hết phiên là /data trắng, phòng thi và bài làm bay theo.
Thay vì chuyển hết truy vấn sang PostgreSQL, máy chủ vẫn dùng SQLite như trước và sau mỗi lượt ghi
thì xuất toàn bộ bảng thành một bản SQL rồi cất vào một bảng một dòng ở PostgreSQL (miễn phí,
sống độc lập với web service). Dùng bản xuất SQL thay vì sao chép tệp vì bản SQLite của Debian
không bật chế độ đọc tệp trực tiếp.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Callable

TABLE = "focuslab_backup"
FLUSH_EVERY_S = 5.0
RETRY_AFTER_S = 60.0
MAX_BLOB_BYTES = 32 * 1024 * 1024

SCHEMA = f"""
CREATE TABLE IF NOT EXISTS {TABLE} (
  id smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  updated_at bigint NOT NULL,
  blob bytea NOT NULL
);
"""

SAVE_SQL = (f"INSERT INTO {TABLE} (id, updated_at, blob) VALUES (1, %s, %s) "
            "ON CONFLICT (id) DO UPDATE SET updated_at = EXCLUDED.updated_at, blob = EXCLUDED.blob")
LOAD_SQL = f"SELECT blob FROM {TABLE} WHERE id = 1"


def dump(conn: sqlite3.Connection) -> bytes:
    return ("\n".join(conn.iterdump())).encode("utf-8")


def revive(path: str | Path, blob: bytes) -> None:
    file = Path(path)
    file.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(file))
    try:
        conn.executescript(blob.decode("utf-8"))
        conn.commit()
    finally:
        conn.close()


class Vault:
    """Một dòng duy nhất chứa bản xuất mới nhất. Hỏng mạng lúc sao lưu chỉ làm chậm, không mất bài."""

    def __init__(self, conn, snapshot: Callable[[], bytes] | None = None,
                 reopen: Callable[[], Any] | None = None):
        self.conn = conn
        self.reopen = reopen
        self.snapshot = snapshot
        self.conn.execute(SCHEMA)
        self.lock = threading.Lock()
        self.dirty = False
        self.stopped = threading.Event()
        self.updated_at = 0.0
        self.error = ""
        threading.Thread(target=self._loop, name="focuslab-backup", daemon=True).start()

    def restore(self, path: str | Path) -> bool:
        """Dựng lại CSDL từ bản đã cất khi ổ đĩa tạm đang trắng; không đụng vào dữ liệu đang chạy."""
        file = Path(path)
        if file.exists() and file.stat().st_size > 0:
            return False
        row = self.conn.execute(LOAD_SQL).fetchone()
        if not row:
            return False
        revive(file, bytes(row[0]))
        return True

    def note_write(self) -> None:
        self.dirty = True

    def flush(self) -> bool:
        if not self.snapshot:
            return False
        with self.lock:
            data = self.snapshot()
            if len(data) > MAX_BLOB_BYTES:
                self.error = f"bản xuất vượt {MAX_BLOB_BYTES} byte"
                return False
            try:
                self.conn.execute(SAVE_SQL, (int(time.time() * 1000), data))
            except Exception as problem:
                self.error = str(problem).strip() or problem.__class__.__name__
                raise
            self.dirty = False
            self.updated_at = time.time()
            self.error = ""
        return True

    def _loop(self) -> None:
        while not self.stopped.wait(FLUSH_EVERY_S):
            if self.dirty:
                self.guard()

    def guard(self, patient: bool = True) -> bool:
        """Không bao giờ để hỏng hóc làm chết luồng sao lưu: lần ghi sau sẽ thử lại."""
        try:
            return self.flush()
        except Exception:
            pass
        if patient:
            self.stopped.wait(RETRY_AFTER_S)
        try:
            self._reconnect()
            return self.flush()
        except Exception as problem:
            self.error = str(problem).strip() or problem.__class__.__name__
            return False

    def _reconnect(self) -> None:
        if not self.reopen:
            return
        try:
            self.conn.close()
        except Exception:
            pass
        self.conn = self.reopen()
        self.conn.execute(SCHEMA)

    def close(self) -> None:
        self.stopped.set()
        self.guard(patient=False)
        try:
            self.conn.close()
        except Exception:
            pass


def connect_remote(url: str):
    import psycopg

    return psycopg.connect(url, autocommit=True, connect_timeout=10)


def open_vault(url: str | None, path: str | Path, attempts: int = 3,
               wait: float = 4.0) -> tuple[Vault | None, str]:
    """Trả về (nơi giữ dữ liệu, lời cô cần đọc). Không có đường kết nối thì máy chạy như bản chưa có sao lưu.

    Nối không được là hai tình huống khác nhau. Ổ đĩa còn dữ liệu thì cứ cho lớp thi tiếp, chỉ là
    chưa cất bản sao lên được. Ổ đĩa trắng mà cũng không nối được thì báo lỗi ngay từ lúc bật máy:
    thà để cô thấy máy chủ chết còn hơn mở một hệ thống trống rồi sau đó ghi đè bản sao lưu thật.
    """
    if not url:
        return None, ""
    file = Path(path)
    problem: Exception | None = None
    for _ in range(max(1, attempts)):
        try:
            keeper = Vault(connect_remote(url), reopen=lambda: connect_remote(url))
            keeper.restore(file)
            return keeper, ""
        except Exception as error:
            problem = error
            time.sleep(wait)
    if file.exists() and file.stat().st_size:
        detail = str(problem).strip()[:70] or problem.__class__.__name__
        return None, f"chưa nối được nơi giữ dữ liệu: {detail}"
    raise RuntimeError("Không nối được PostgreSQL ghi trong FOCUSLAB_BACKUP_URL mà ổ đĩa tạm lại đang trắng. "
                       "Kiểm tra lại đường kết nối và region của hai dịch vụ trên Render.") from problem
