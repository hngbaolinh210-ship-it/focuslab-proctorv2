/* Trang cổng: học sinh vào phòng thi, cô giáo đăng nhập vào bảng điều hành. */
import { api } from "/static/app.js";

const el = id => document.getElementById(id);

async function boot() {
  const me = await api("/api/me").catch(() => ({ role: null }));
  if (me.role === "teacher") return location.replace("/teacher");
  if (me.role === "student") return location.replace("/exam");

  el("join-form").addEventListener("submit", async event => {
    event.preventDefault();
    el("join-error").textContent = "";
    try {
      await api("/api/join", {
        method: "POST",
        body: { room_code: el("room_code").value, student_code: el("student_code").value, access_code: el("access_code").value },
      });
      location.replace("/exam");
    } catch (error) {
      el("join-error").textContent = error.message;
    }
  });

  el("setup-toggle").addEventListener("click", () => {
    el("setup-fields").hidden = !el("setup-fields").hidden;
    el("login-button").textContent = el("setup-fields").hidden ? "Đăng nhập" : "Tạo tài khoản và vào";
  });

  el("login-form").addEventListener("submit", async event => {
    event.preventDefault();
    const body = { username: el("username").value, password: el("password").value, display_name: el("display_name").value };
    const creating = !el("setup-fields").hidden;
    el("login-error").textContent = "";
    try {
      await api(creating ? "/api/teacher/setup" : "/api/teacher/login", { method: "POST", body });
      location.replace("/teacher");
    } catch (error) {
      // Máy chủ báo 404 khi chưa có tài khoản nào: bật sẵn ô tạo tài khoản để cô khỏi tìm.
      if (error.message.includes("Tạo tài khoản đầu tiên") && el("setup-fields").hidden) el("setup-toggle").click();
      el("login-error").textContent = error.message;
    }
  });
}

boot();
