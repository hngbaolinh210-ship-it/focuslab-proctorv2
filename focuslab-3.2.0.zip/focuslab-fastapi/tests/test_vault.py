"""Thử chỗ giữ dữ liệu: máy chủ khởi động lại với ổ đĩa trắng vẫn còn nguyên phòng thi và bài làm."""
from __future__ import annotations

import os
import sqlite3
import tempfile
import unittest

from app import db, main, vault


class FakeRemote:
    """Thay PostgreSQL bằng SQLite trong bộ nhớ; chỉ khác chỗ đánh dấu tham số và kiểu dữ liệu."""

    def __init__(self):
        self.conn = sqlite3.connect(":memory:")
        script = vault.SCHEMA.replace("smallint", "INTEGER").replace("bigint", "INTEGER").replace("bytea", "BLOB")
        self.conn.executescript(script)
        self.offline = False

    def execute(self, sql, args=()):
        if self.offline:
            raise ConnectionError("mất mạng với nơi giữ dữ liệu")
        return self.conn.execute(sql.replace("%s", "?"), args)

    def close(self):
        pass  # SQLite in-memory dùng chung cho cả phiên test, không được đóng giữa chừng


class VaultTest(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.folder.cleanup)
        self.path = os.path.join(self.folder.name, "thi.db")
        self.remote = FakeRemote()

    def open_store(self) -> tuple[main.Store, vault.Vault]:
        keeper = vault.Vault(self.remote)
        keeper.restore(self.path)
        store = main.Store(self.path, vault=keeper)
        self.addCleanup(keeper.close)
        return store, keeper

    def add_room(self, store: main.Store, title: str) -> None:
        def write(conn) -> None:
            conn.execute("INSERT INTO rooms (id, code, title, owner_id, created_at) VALUES (?,?,?,?,?)",
                         (db.new_id(), title[:8].ljust(8, "X"), title, "t1", db.now()))

        store.transact(write)

    def titles(self) -> list[str]:
        conn = db.connect(self.path)
        try:
            return [row["title"] for row in conn.execute("SELECT title FROM rooms ORDER BY created_at")]
        finally:
            conn.close()

    def test_a_wiped_disk_is_rebuilt_from_the_remote_copy(self):
        store, keeper = self.open_store()
        self.add_room(store, "Lớp 12A1")
        self.add_room(store, "Lớp 11B")
        store.close()
        self.assertGreater(keeper.updated_at, 0)

        for suffix in ("", "-wal", "-shm"):  # Render dựng lại container: /data trắng hoàn toàn
            try:
                os.remove(self.path + suffix)
            except FileNotFoundError:
                pass
        self.assertFalse(os.path.exists(self.path))  # đừng mở CSDL ở đây, sẽ tạo lại tệp rỗng

        again, _ = self.open_store()
        self.assertEqual(self.titles(), ["Lớp 12A1", "Lớp 11B"])
        again.close()

    def test_restore_leaves_a_database_that_already_has_data_alone(self):
        store, _ = self.open_store()
        self.add_room(store, "Lớp 12A1")
        store.close()

        stranger = vault.Vault(self.remote)
        self.assertFalse(stranger.restore(self.path))
        self.assertEqual(self.titles(), ["Lớp 12A1"])
        stranger.close()

    def test_a_failed_backup_leaves_the_exam_running_and_is_retried(self):
        store, keeper = self.open_store()
        self.add_room(store, "Lớp 12A1")

        self.remote.offline = True
        self.assertFalse(keeper.guard(patient=False))
        self.assertTrue(keeper.error)
        self.add_room(store, "Lớp 11B")  # mất mạng sao lưu thì học sinh vẫn làm bài bình thường

        self.remote.offline = False
        self.assertTrue(keeper.guard(patient=False))
        self.assertEqual(keeper.error, "")
        store.close()
        self.assertEqual(self.titles(), ["Lớp 12A1", "Lớp 11B"])


class NoConnectionTest(unittest.TestCase):
    """Nơi giữ dữ liệu đang chết: máy có được phép bật hay không tùy ổ đĩa còn dữ liệu hay không."""

    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.folder.cleanup)
        self.path = os.path.join(self.folder.name, "thi.db")
        self.real_connect = vault.connect_remote
        vault.connect_remote = lambda url: (_ for _ in ()).throw(ConnectionError("khong noi duoc"))
        self.addCleanup(setattr, vault, "connect_remote", self.real_connect)

    def open(self):
        return vault.open_vault("postgres://example/focuslab", self.path, attempts=2, wait=0)

    def test_an_exam_with_data_on_disk_may_continue(self):
        db.connect(self.path).close()  # ổ đĩa còn nguyên CSDL của buổi thi trước
        keeper, note = self.open()
        self.assertIsNone(keeper)
        self.assertIn("chưa nối được nơi giữ dữ liệu", note)

    def test_the_health_page_shows_the_broken_backup(self):
        from fastapi.testclient import TestClient

        db.connect(self.path).close()
        keeper, note = self.open()
        real_vault = vault.open_vault
        vault.open_vault = lambda url, path: (keeper, note)
        self.addCleanup(setattr, vault, "open_vault", real_vault)
        with TestClient(main.create_app(self.path)) as client:
            self.assertIn("chưa nối được nơi giữ dữ liệu", client.get("/api/health").json()["backup"])

    def test_a_blank_disk_and_a_dead_vault_refuses_to_start(self):
        with self.assertRaises(RuntimeError) as caught:
            self.open()
        self.assertIn("FOCUSLAB_BACKUP_URL", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
