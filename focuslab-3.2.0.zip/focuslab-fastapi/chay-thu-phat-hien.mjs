/* Chạy thử bộ tự phát hiện trên máy học sinh (measurement + analyze + raise) mà không cần camera thật:
   đưa từng khung hình giả vào, đồng hồ giả chạy nhanh, xem máy có báo đúng dấu hiệu và báo MỘT ảnh hay không.
   Cách dùng:  node chay-thu-phat-hien.mjs  */

import { readFile } from "node:fs/promises";

const source = await readFile(new URL("./static/exam.js", import.meta.url), "utf8");
const start = source.indexOf("const skinPixel");
const end = source.indexOf("async function sendFrame");
if (start < 0 || end < 0) throw new Error("Không tìm thấy đoạn mã tự phát hiện trong static/exam.js.");
const code = source.slice(start, end);

// ---------------------------------------------------------------- khung hình giả
// Mỗi khung hình là một mảng RGB: vụng về nhưng đủ để thử ba công thức màu.
function frame(painter) {
  const width = 96, height = 72;
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const [r, g, b] = painter(x, y, width, height);
      const p = (y * width + x) * 4;
      data[p] = r; data[p + 1] = g; data[p + 2] = b; data[p + 3] = 255;
    }
  }
  return { data, width, height };
}

const SKIN = [200, 150, 120];
const WALL = [90, 100, 110];
const DARK = [8, 8, 8];
const SCREEN = [245, 248, 252];

// Em ngồi đúng tư thế: mặt (màu da) choán nửa trên, nửa dưới là áo và bàn tối màu.
const seated = (x, y, w, h) => (y < h * 0.5 && x > w * 0.25 && x < w * 0.75 ? SKIN : WALL);
// Em giơ điện thoại sáng lên gần mặt: vẫn thấy da, nhưng vùng giữa dưới có mảng sáng lớn.
const phoneUp = (x, y, w, h) => (y > h * 0.45 && x > w * 0.3 && x < w * 0.7 ? SCREEN : seated(x, y, w, h));
// Em rời khỏi khung hình: chỉ còn tường và áo, không một điểm màu da.
const nobody = (x, y, w, h) => (y < h * 0.5 ? WALL : [60, 70, 80]);
// Camera bị che hoặc tắt đèn.
const covered = () => DARK;

// ---------------------------------------------------------------- môi trường giả
let now = 1_000_000;
const alerts = [];
const timers = new Map();

const sandbox = {
  HOLD: { cam_dark: 5000, face_gone: 9000, object_raised: 1500 },
  COOLDOWN_MS: 90000,
  scan: null,
  holdSince: {},
  lastAlert: {},
  camStream: { active: true },
  submitted: false,
  paper: { id: "de-1" },
  el: () => ({ videoWidth: 480, videoHeight: 360 }),
  notify: () => {},
  crypto: { randomUUID: () => `id-${alerts.length}` },
  jpegOf: async () => new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]),
  document: {
    hidden: false,
    createElement: () => ({
      width: 0, height: 0,
      getContext: () => ({
        drawImage: (_video, _dx, _dy, w, h) => { sandbox.__size = [w, h]; },
        getImageData: () => sandbox.__pixels,
      }),
    }),
  },
  fetch: async (url) => { alerts.push(url); return { ok: true, json: async () => ({}) }; },
};

const results = [];
const step = (label, ok, extra = "") => {
  results.push({ label, ok, extra });
  console.log(`${ok ? "OK  " : "FAIL"} ${label}${extra ? ` — ${extra}` : ""}`);
};

function run(code, globals) {
  const names = Object.keys(globals);
  const body = `${code}
    return { measure, analyze, raise, state: () => ({ holdSince, lastAlert }) };`;
  // eslint-disable-next-line no-new-func
  return new Function(...names, body)(...names.map(name => globals[name]));
}

// Date.now và setInterval trong đoạn mã dùng đồng hồ thật, nên cho nó một Date giả.
const RealDate = Date;
class FakeDate extends RealDate {
  constructor(...args) {
    super(args.length ? args[0] : now);
  }
  static now() {
    return now;
  }
}
const api = run(code, { ...sandbox, document: sandbox.document, Date: FakeDate, notify: sandbox.notify,
  crypto: sandbox.crypto, fetch: sandbox.fetch, jpegOf: sandbox.jpegOf, el: sandbox.el,
  HOLD: sandbox.HOLD, COOLDOWN_MS: sandbox.COOLDOWN_MS });

// raise() là hàm bất đồng bộ: phải để các lời gọi fetch kịp chạy rồi mới đếm số ảnh gửi lên.
const flush = () => new Promise(resolve => setImmediate(resolve));

async function show(painter) {
  sandbox.__pixels = frame(painter);
  now += 600;              // mỗi lần phân tích cách nhau đúng WATCH_EVERY
  api.analyze();
  await flush();
}

const sent = () => alerts.length;
const rule = (i) => (alerts[i] ?? "").match(/rule=([a-z_]+)/)?.[1] ?? "";

// 1. Ngồi đúng tư thế thì im lặng — đây là điều quan trọng nhất, không được báo nhiễu.
for (let i = 0; i < 40; i++) await show(seated);
step("Em ngồi làm bài bình thường: 24 giây phân tích, không báo gì", sent() === 0, `${sent()} ảnh gửi lên`);

// 2. Giơ màn hình sáng lên gần mặt: phải bắt được sau khoảng 1,5 giây, tính từ khung hình đầu tiên thấy dấu hiệu.
for (let i = 0; i < 4; i++) await show(phoneUp);
step("Em giơ điện thoại lên gần mặt: máy báo sau ~1,8 giây", sent() === 1 && rule(0) === "object_raised", alerts[0] ?? "");

// 3. Cùng một dấu hiệu liên tiếp không được biến thành bão cảnh báo.
for (let i = 0; i < 40; i++) await show(phoneUp);
step("Vẫn giơ điện thoại thêm 24 giây nữa: không thành bão, vẫn đúng 1 ảnh", sent() === 1, `${sent()} ảnh`);
now += 90_000;
for (let i = 0; i < 5; i++) await show(phoneUp);
step("Hết 90 giây chờ mà em vẫn giơ: gửi thêm đúng 1 ảnh nữa", sent() === 2 && rule(1) === "object_raised", `${sent()} ảnh`);

// 4. Rời khỏi khung hình: phải chờ đủ 9 giây, không báo vì một cái quay đầu.
now += 90_000;             // hết thời gian chờ của dấu hiệu trước
for (let i = 0; i < 10; i++) await show(nobody);
step("Em rời khỏi khung hình 6 giây: chưa báo", sent() === 2, `${sent()} ảnh`);
for (let i = 0; i < 8; i++) await show(nobody);
step("Em không đứng trước camera 10 giây: báo face_gone", sent() === 3 && rule(2) === "face_gone", alerts[2] ?? "");

// 5. Che camera: báo cam_dark chứ không phải face_gone.
now += 90_000;
for (let i = 0; i < 12; i++) await show(covered);
step("Camera bị che: báo cam_dark, không báo nhầm mất mặt",
  sent() === 4 && rule(3) === "cam_dark", alerts[3] ?? "");

// 6. Một cái quay đầu nhanh hoặc ngồi sai tư thế không thành cảnh báo.
now += 90_000;
await show(nobody);
await show(seated);
await show(seated);
await show(nobody);
step("Quay đầu 2 lần trong 1,2 giây: không báo", sent() === 4, `${sent()} ảnh`);

// 7. Ảnh gửi lên là JPEG do canvas vẽ lại, kèm client_id riêng để máy chủ chống trùng.
step("Mỗi lần báo gửi đúng một ảnh, có client_id riêng",
  alerts.every(url => /client_id=id-\d+/.test(url)) && new Set(alerts).size === alerts.length);

// 8. Máy mất mạng thì dấu hiệu vẫn được tính, không làm trang làm bài crash.
sandbox.fetch = async () => { throw new Error("mất mạng"); };
const quiet = run(code, { ...sandbox, Date: FakeDate });
now += 90_000;
let crashed = false;
try {
  for (let i = 0; i < 12; i++) { sandbox.__pixels = frame(covered); now += 600; quiet.analyze(); }
  await flush();
} catch { crashed = true; }
step("Mất mạng giữa giờ: máy chỉ thôi gửi ảnh, trang làm bài không lỗi", !crashed);

// 9. measure() phải trả về ba con số hợp lệ cho khung hình trắng đen.
sandbox.__pixels = frame(seated);
const stats = api.measure({ videoWidth: 480, videoHeight: 360 });
step("Đo khung hình trả về tỉ lệ phần thập phân (không phải số pixel thô)",
  stats && 0 <= stats.skin && stats.skin <= 1 && 0 <= stats.bright && stats.bright <= 1 && typeof stats.dark === "boolean",
  JSON.stringify(stats));

const failed = results.filter(result => !result.ok);
console.log(`\n${failed.length ? failed.length + " bước Hỏng" : "Toàn bộ " + results.length + " bước đạt."}`);
for (const failure of failed) console.log(`  FAIL: ${failure.label} ${failure.extra}`);
process.exit(failed.length ? 1 : 0);
