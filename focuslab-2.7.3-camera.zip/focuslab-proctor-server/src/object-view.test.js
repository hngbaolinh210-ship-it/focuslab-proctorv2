import test from 'node:test';
import assert from 'node:assert/strict';
import {objectRegion,projectObjects,forbiddenObjects,objectsAreFresh} from './object-view.js';
import {assignToSeats} from './proctoring.js';
test('center scan maps detections back into the correct full-frame seat',()=>{
 const raw=[{classId:67,box:{x:.8,y:.2,width:.1,height:.1}}];
 const projected=projectObjects(raw,objectRegion('center'));
 const seats=[{id:'left',region:{x:0,y:0,width:.5,height:1}},{id:'right',region:{x:.5,y:0,width:.5,height:1}}];
 const result=assignToSeats(seats,[],projected);
 assert.equal(result.assigned.get('left').objects.length,0);assert.equal(result.assigned.get('right').objects.length,1);
 assert.equal(projected[0].box.x,.65);assert.equal(projected[0].box.width,.05);
 assert.deepEqual(projectObjects(raw,objectRegion('full')),raw);
});
test('allowed books remain visible while excluded from risk input',()=>{
 const objects=[{classId:73},{classId:67}];
 assert.deepEqual(forbiddenObjects(objects,true),[{classId:67}]);
 assert.deepEqual(forbiddenObjects(objects,false),objects);assert.equal(objects.length,2);
});
test('slow inference must not become a fresh live observation on completion',()=>{
 assert.equal(objectsAreFresh(100,3100),true);assert.equal(objectsAreFresh(100,3101),false);
 assert.equal(objectsAreFresh(-Infinity,5000),false);assert.equal(objectsAreFresh(200,100),false);
});
