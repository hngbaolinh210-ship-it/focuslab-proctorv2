export function objectRegion(mode) {
  return mode === 'center' ? {x: .25, y: .25, width: .5, height: .5} : {x: 0, y: 0, width: 1, height: 1};
}
export function projectObjects(objects, region) {
  return objects.map(object => ({...object, box: {
    x: region.x + object.box.x * region.width,
    y: region.y + object.box.y * region.height,
    width: object.box.width * region.width,
    height: object.box.height * region.height,
  }}));
}
export function forbiddenObjects(objects, allowBooks) {
  return allowBooks ? objects.filter(object => object.classId !== 73) : objects;
}
export function objectsAreFresh(capturedAt, now) {
  return Number.isFinite(capturedAt) && now >= capturedAt && now - capturedAt <= 3000;
}
