# FocusLab Proctor 2.4 — thiết bị, phòng thi và máy chủ

Ứng dụng hỗ trợ giám sát trên trình duyệt, với máy chủ Node.js 24, SQLite, MediaPipe và YOLO11n. Một phòng có tối đa **100 học sinh trong danh sách**; hỗ trợ thí sinh dùng thiết bị riêng và camera phòng thi.

## Mở trên Windows

1. Cài **Node.js 24 LTS** từ https://nodejs.org.
2. Dừng cửa sổ FocusLab cũ bằng Ctrl+C. Giải nén **toàn bộ** ZIP vào thư mục mới.
3. Nhấp đúp `start-windows.cmd`. Lần đầu cần Internet để tải thư viện và FFmpeg.
4. Lần đầu, nhập mật khẩu giám thị **từ 12 đến 200 ký tự** rồi Enter. Khi gõ sẽ hiện dấu `*`. Nếu quá ngắn, ứng dụng cho nhập lại. Ghi nhớ mật khẩu này.
5. Website tự mở tại http://localhost:5173. Chọn **Đăng nhập giám thị**.
6. Giữ cửa sổ lệnh mở. Lần sau file mở nhanh dùng lại dependencies nếu lockfile không đổi.

Chạy bằng Terminal:

```sh
npm ci
npm run setup
npm run dev
```

Đừng mở file `.cmd` ngay trong ZIP hoặc kéo riêng nó ra ngoài. Nếu báo thiếu `package-lock.json`, giải nén lại toàn bộ. Node thấp hơn 24 không hỗ trợ cấu hình máy chủ này.

## Tài khoản giám thị riêng (2.5)

Mỗi giám thị có một tên đăng nhập và một mật khẩu. Trước đây toàn trường dùng chung một mật khẩu, nên không thể biết ai đã xem hoặc bỏ qua cảnh báo nào, và mọi cảnh báo chỉ đi tới một điện thoại duy nhất.

- Giám thị tự tạo tài khoản tại trang đăng nhập bằng **mã đăng ký** do chủ máy chủ cấp (`PROCTOR_INVITE_CODE`). Tên đăng nhập duy nhất, mật khẩu từ 12 ký tự.
- Sau khi đăng nhập, giám thị chỉ thấy phòng được phân công cho mình. Tài khoản quản trị (mật khẩu chung của máy chủ) vẫn thấy mọi phòng.
- Tài khoản quản trị tích giám thị vào mục **Phân công giám thị** trong từng phòng. Giám thị tự tạo phòng thì được gán ngay cho chính mình.
- Cảnh báo Web Push chỉ bắn tới điện thoại của giám thị được gán phòng, cộng với mọi thiết bị của tài khoản quản trị.

## Đổi mật khẩu giám thị (2.4)

1. Đăng nhập giám thị, bấm **Đổi mật khẩu** ở đầu trang.
2. Nhập mật khẩu hiện tại, mật khẩu mới và nhập lại mật khẩu mới (12–200 ký tự).
3. Bấm **Lưu mật khẩu mới**, rồi đăng nhập lại bằng mật khẩu mới.

Tất cả phiên giám thị đang đăng nhập sẽ bị đăng xuất. Phiên học sinh, phòng thi, danh sách, video và cảnh báo được giữ nguyên. Sau khi nâng cấp lên 2.4, giám thị cần đăng nhập lại một lần.

Mật khẩu được băm và lưu trong `DATA_DIR`; trên Railway, giữ volume **/data** để mật khẩu mới tồn tại sau khi khởi động hoặc triển khai lại. `ADMIN_PASSWORD` chỉ dùng tạo tài khoản ban đầu: thay biến này không ghi đè mật khẩu đã lưu. Tính năng yêu cầu mật khẩu hiện tại; chưa có chức năng khôi phục khi quên mật khẩu.

## Tạo phòng và nhập danh sách

- Đăng nhập giám thị, tạo phòng rồi chọn phòng đó.
- Tải CSV mẫu từ giao diện. Các cột là `student_id,name,seat_id`; UTF-8, tối đa 100 dòng/phòng.
- `student_id`: chữ/số/gạch dưới/gạch ngang, tối đa 40 ký tự. `name`: tối đa 120 ký tự. `seat_id`: S01…S100; có thể để trống để đánh số tự động.
- Nhập CSV rồi **tải danh sách mã tham gia ngay**. Mã ngẫu nhiên chỉ trả về trong lần cấp này; máy chủ chỉ lưu mã băm. Giữ tệp mã riêng tư và chuyển đúng mã cho từng học sinh.
- Danh sách không được thêm trùng mã/chỗ, tổng không vượt 100. Muốn làm lại toàn bộ danh sách, tạo phòng mới.
- Học sinh mở link `/join?room=MÃ_PHÒNG`, nhập mã tham gia riêng. Tên/chỗ được tự lấy từ danh sách, không cần gõ/gán tên trong trang phân tích.

**Danh tính không được nhận diện bằng khuôn mặt.** Mã tham gia gắn phiên với tài khoản được cấp. Trong phòng thi tập trung, dữ liệu gắn theo vị trí đã khai báo trong sơ đồ chỗ ngồi; giám thị xác minh người ngồi đúng chỗ. Không có so sánh ảnh thẻ/embedding hoặc kết luận thi hộ.

## Các nguồn hình ảnh

### Điện thoại, laptop, webcam USB

Trong trang quản lý, chọn **Mở camera phòng thi**; học sinh dùng **Mở camera & bắt đầu**. Chọn camera trước, sau hoặc webcam từ danh sách nguồn rồi bật camera. Danh sách thiết bị có tên đầy đủ sau khi cấp quyền.

Mỗi học sinh từ xa dùng một trình duyệt/thiết bị và mã riêng. Giám thị giữ trang quản lý mở để xem thông báo. Trong phòng thi tập trung, có thể chọn các vùng thuộc camera hiện tại từ danh sách rồi **Áp dụng vùng**. Các camera khác có thể mở trang phân tích ở thiết bị hoặc tab riêng và chọn tập chỗ khác.

Chỉnh vùng bao gồm thí sinh và bàn; tránh chồng lấn. Các vùng lấy nhãn từ danh sách, không cần ghép khuôn mặt với tên thủ công. Khi mỗi vùng có đúng một khuôn mặt và các thí sinh nhìn thẳng, bấm **Hiệu chỉnh & bắt đầu**. Góc chuẩn lưu riêng cho từng vùng.

Camera trên điện thoại từ xa cần **HTTPS**, quyền camera, WebGL và trình duyệt tương đối mới (Chrome/Edge hoặc Safari hiện đại). Địa chỉ HTTP mạng nội bộ như `http://192.168.x.x:5173` không đáp ứng điều kiện camera của phần lớn trình duyệt. “Truy cập trên nhiều thiết bị” không có nghĩa mọi trình duyệt cũ/thiết bị yếu đều phân tích được.

### Chế độ điện thoại và giảm giật (2.1)

- **Chế độ xử lý → Tự động** chọn cấu hình nhẹ cho Android/iPhone/tablet cảm ứng: camera ưu tiên 640×480, tối đa 24 fps; dữ liệu mặt được thu nhỏ theo đúng tỷ lệ, không phải mọi khung hình camera đều chạy AI. Có thể chọn **Nhẹ** hoặc **Tiêu chuẩn** trước khi bật nguồn. Chế độ tiêu chuẩn giữ ảnh lớn hơn cho camera nhiều chỗ.
- MediaPipe ưu tiên GPU; nếu không khởi tạo được GPU sẽ dùng CPU. YOLO WASM dùng worker để suy luận không chặn luồng giao diện. Dòng tốc độ hiển thị thời gian xử lý mặt, không phải phép đo độ chính xác.
- Trên điện thoại của giám thị, phòng **nhiều hơn 4 chỗ** yêu cầu chọn các chỗ thuộc camera rồi **Áp dụng vùng từ danh sách**. Danh sách vẫn tối đa 100; không tự giả định một camera điện thoại nhìn đủ mọi chỗ. Phiên học sinh theo mã riêng tự có một vùng.
- Camera hiện hình trong lúc tải mô hình. Khi đã có mặt hợp lệ, phải bấm **Hiệu chỉnh & bắt đầu** để ghi sự kiện. Nếu chưa thấy mặt, thử camera trước, ánh sáng rõ và khoảng cách gần; giữ điện thoại cố định.
- Nếu YOLO tải lỗi, camera/quy tắc khuôn mặt tiếp tục chạy và giao diện thông báo rõ cảnh báo vật thể không hoạt động. Có thể tải lại trang để thử YOLO, hoặc tắt lựa chọn vật thể trước khi bật lại.
- Nếu vẫn giật, thử chế độ Nhẹ và tắt nhận diện vật thể để so sánh. Khi tắt, các quy tắc điện thoại/sách/cúi đầu kèm vật thể không hoạt động. Không giảm ngưỡng tùy tiện để tăng số cảnh báo.

Đã kiểm tra worker suy luận trên WASM thật và giao diện vẫn cập nhật trong môi trường trình duyệt thử; việc nhận diện mặt/GPU trên Android thật và độ chính xác trong điều kiện sử dụng cần thử lại trên điện thoại. Thay đổi này không bổ sung mô hình nhận diện mới hoặc xác minh danh tính.

### Camera không bật: đọc nhãn trên nút (2.7.3)

Nút bật camera giờ tự mô tả lý do bị khoá, thay vì chỉ mờ đi mà không nói gì:

- **Bật camera** — bấm được, camera sẽ mở.
- **Chưa kết nối được máy chủ** — link mở ra không gọi được API phòng thi (đường dẫn cũ, mất phiên, hoặc máy chủ đang khởi động lại). Mở **Trang quản lý → vào phòng → Mở camera phòng thi** rồi thử lại.
- **Chọn chỗ ngồi của bạn trước** — thiết bị cảm ứng đang mang vai trò giám thị cho phòng trên 4 chỗ. Tick đúng các chỗ camera này thấy, bấm **Áp dụng vùng từ danh sách**.
- **Đang giám sát** — phiên đã chạy; bấm **Dừng** trước khi đổi nguồn hoặc số vùng.

Dòng lỗi màu đỏ nêu rõ nguyên nhân kỹ thuật: `NotAllowedError` (từ chối quyền / mở link trong Facebook, Zalo → chọn “Mở trong Chrome”), `NotFoundError` (chưa cắm webcam), `NotReadableError` (app khác đang giữ camera), `OverconstrainedError` (chọn lại camera trong danh sách), `AbortError` (tab khác của cùng trang). Sau khi cấp quyền phải **tải lại trang (F5)**.

### Video có sẵn

- **Video trên thiết bị** trong trang phân tích: chọn file, phát trực tiếp, không gửi tệp lên server.
- **Tải lên máy chủ** trong trang quản lý/thí sinh: nhận MP4/MOV/WebM tối đa 500 MB, 2 giờ, độ phân giải tối đa 4K. Server xác thực người gửi và tạo MP4 H.264/AAC tối đa chiều ngang 1280 và WebM VP8/Opus tối đa chiều ngang 960. Trình duyệt thiếu H.264 sẽ dùng WebM; giới hạn lưu trữ tính cả hai bản.
- Mỗi máy chủ hiện xử lý tối đa 2 video cùng lúc; chờ xử lý xong rồi mở **Video & phân tích**. Dung lượng video lưu mặc định tối đa 5 GB; giám thị có thể xóa video cũ.
- Video chỉ chủ sở hữu và giám thị được xem; hỗ trợ HTTP Range để tua. Khi phân tích, các mốc thời gian quy tắc dùng thời gian video; khi tua, phiên phân tích hiện tại kết thúc và cần hiệu chỉnh lại. Tạm dừng video không bị coi là mất camera.
- Đóng trang trong lúc server đã nhận và xử lý video không dừng tác vụ server. Video/sự kiện lưu qua các lần khởi động lại.

### Camera IP / CCTV (RTSP)

Camera RTSP không chạy trực tiếp trong trình duyệt. Máy chủ dùng FFmpeg chuyển thành HLS; trình duyệt dùng HLS.js hoặc trình phát HLS có sẵn của Safari.

1. Máy chủ phải truy cập được mạng của camera. Với camera trong mạng trường, dùng máy chủ trong mạng đó, VPN/site-to-site, hoặc hạ tầng camera phù hợp. VPS trên Internet không tự truy cập được IP riêng của trường.
2. Cấu hình biến môi trường `CAMERA_HOSTS` chứa hostname/IP được phép, cách nhau bằng dấu phẩy, ví dụ `192.168.1.20,192.168.1.21`.
3. Tại trang giám thị nhập tên camera và URL `rtsp://…` (hoặc `rtsps://…`) do camera cung cấp. Không chia sẻ URL chứa mật khẩu.
4. Đợi luồng khởi động, mở phân tích. Tối đa 4 luồng IP đang chuyển đổi trên máy chủ trong cấu hình này. Dừng luồng từ bảng quản lý khi dùng xong.
5. Luồng RTSP không được lưu bền vững; sau khi khởi động lại máy chủ cần kết nối lại. URL camera chỉ nằm trong bộ nhớ tiến trình, không gửi lại cho trình duyệt khác/ghi vào DB.

Nếu camera chỉ có giao thức riêng của hãng/ONVIF và chưa có URL RTSP, cần lấy URL từ tài liệu hãng. Bridge đã có, nhưng từng camera thật cần kiểm chứng codec, tài khoản, mạng và hiệu năng.

## Cảnh báo về máy chủ

Trình phân tích gửi các quan sát mỗi khoảng 4 giây. Server gắn học sinh theo phiên đăng nhập hoặc `seat_id` từ sơ đồ phòng, lưu SQLite và phát thông báo SSE tới giám thị. Trang quản lý tự kết nối lại và làm mới dự phòng. Giám thị đánh dấu sự kiện đã xem/cần trao đổi; học sinh không được sửa đánh giá hoặc đọc dữ liệu phòng khác.

Sự kiện có khóa để gửi lại không tạo bản sao. Khi mất mạng, trang giữ hàng đợi cục bộ và báo số sự kiện chờ gửi; tối đa 5.000 sự kiện chờ. Giữ trang mở/khôi phục kết nối để gửi tiếp, xuất CSV tại thiết bị nếu cần giữ bản riêng. Dữ liệu máy chủ là **báo cáo từ thiết bị**, không phải bằng chứng chống sửa đổi trên máy thí sinh. Chưa có trình duyệt khóa thi hoặc kiểm tra toàn vẹn thiết bị.

Bảng server hiển thị/xuất 300 sự kiện gần nhất; DB giữ toàn bộ (tối đa 50.000 sự kiện/phòng). CSV tại trang phân tích có toàn bộ phiên tại thiết bị. Đóng phòng ngừng nhận sự kiện mới và mã tham gia; dữ liệu cũ vẫn xem được.

## Quy tắc điểm

| Quan sát | Điều kiện mặc định | Điểm |
|---|---|---|
| Quay đầu | `abs(yaw)>22°` liên tục ≥2,2 giây | +40 |
| Nhắm mắt kéo dài | hai mắt `EAR<0,21` liên tục ≥2 giây | +50 |
| Có mặt nhưng không đo được mắt (che mặt, úp mặt, quay hẳn bên) | một mặt trong vùng, điểm mắt không hợp lệ ≥2 giây | +60 |
| Mở miệng | `MAR>0.45` liên tục ≥1,8 giây | +30 |
| Điện thoại/sách không được phép | Trong cùng vùng ≥1 giây | +60 |
| Vùng trắng mới xuất hiện (nghi giấy in) | Trong cùng vùng ≥2,5 giây, không có trong nền đã ghi lúc chỉnh vùng | +55 |
| Không thấy khuôn mặt trong vùng | Liên tục ≥2,5 giây | +65 |
| Nhiều mặt trong cùng vùng | ≥0,7 giây | +65 |
| Cúi đầu và vật thể | `pitch<-18°` cùng vật thể ≥1 giây | Điểm tối thiểu 85 |

Cộng các quy tắc đang hoạt động, tối đa 100; tổ hợp cúi đầu/vật thể đặt sàn 85 để tránh cộng vật thể hai lần. 40–69: cần xem lại; từ 70: ưu tiên cao. Đây không phải xác suất hoặc kết luận gian lận. MAR không xác định lời nói. Cảnh báo do mất mặt có thể là che khuất/ánh sáng. Giám thị cần kiểm tra bối cảnh trước khi xử lý.

Khoảng cách giữa hai lần suy luận trên 2,5 giây đặt lại bộ đếm của các quy tắc cần quan sát liên tục (quay đầu, nhắm mắt, mở miệng, vật thể, che mặt). Bộ đếm "không thấy mặt" **không** bị đặt lại, vì máy yếu hoặc khung hình trễ không được biến thành miễn cảnh báo.

YOLO11n COCO chỉ dùng `cell phone` và `book`. Mô hình này **không có lớp "giấy"**, nên giấy in được xử lý bằng một bộ dò riêng, không cần mô hình:

- Khung hình chia thành lưới 24×18 ô. Một ô là "trắng" khi sáng (max ≥ 68%), gần trung tính về màu (chênh lệch kênh ≤ 26%, min ≥ 60%) và ≥70% điểm ảnh trong ô đạt.
- Trong giai đoạn chỉnh vùng (trước khi bấm “Hiệu chỉnh & bắt đầu”), mọi ô trắng được ghi vào **nền**. Sau khi bắt đầu, chỉ cụm ô trắng **không có trong nền** mới được tính.
- Cụm ô nối cạnh nhau được gom lại; phải có ≥6 ô mới, ≥50% cụm là ô mới và diện tích ≥1,2% khung hình. Ngưỡng nhỏ này loại phản chiếu đèn và vệt sáng.
- Cụm đạt thành một vật thể `kind:'paper'` → quy tắc `paper` (+55, mức "cần xem lại", không bao giờ chạm mức ưu tiên cao 85 của tổ hợp cúi đầu + vật thể).
- Giấy đã nằm sẵn trên bàn trước khi bắt đầu **không** bị báo. Ánh sáng đổi mạnh, áo trắng, tường trắng khi camera quay đều thành vùng mới → chỉ là tín hiệu để giám thị nhìn lại, không phải bằng chứng.
- Tắt bằng mục **Dò vùng trắng mới xuất hiện** trong Cấu hình phiên thi. Nếu trình duyệt chặn đọc ảnh (canvas lệch nguồn), bộ dò tự tắt và ghi rõ lý do; các quy tắc khác vẫn chạy.

Kết quả vật thể quá 3 giây không được sử dụng, kể cả kết quả vùng trắng.

## Giới hạn 100 học sinh

100 là giới hạn danh sách/API và số vùng có thể cấu hình. Đã kiểm tra 100 phiên học sinh giả lập cùng gửi sự kiện. **Chưa kiểm tra 100 luồng video trực tiếp hoặc 100 mặt trong một khung hình**. Tốc độ phụ thuộc camera, kích thước khuôn mặt và CPU/GPU. Một camera xa không đủ chi tiết để đo mắt/miệng của cả hội trường. Chia vùng cho nhiều camera/thiết bị, thử tải thực tế trước khi dùng.

Hiện phân tích AI chạy ở trình duyệt, giám thị phải giữ trang phân tích mở. Server lưu cảnh báo, video và chuyển đổi RTSP/video; server chưa tự chạy nhận diện khuôn mặt/YOLO nếu không có trình duyệt phân tích. Khi ẩn trang camera, phiên dừng. Mỗi phiên tối đa 2 giờ.

## Đưa lên Internet qua HTTPS

Bản ZIP không tự có đường link công khai. Bạn cần tài khoản hosting hoặc VPS. Có cấu hình `render.yaml` cho Render với Node 24 và ổ đĩa bền vững; dịch vụ/ổ đĩa này có chi phí theo bảng giá của Render.

1. Đưa mã nguồn (không có `data/`, mật khẩu, `node_modules/`) lên repository Git của bạn.
2. Trên Render, tạo **Blueprint** từ repository chứa `render.yaml`.
3. Nhập `ADMIN_PASSWORD` riêng ít nhất 12 ký tự khi được hỏi. Mật khẩu chỉ dùng tạo quản trị lần đầu và được băm vào ổ đĩa.
4. Build: `npm ci && npm run build`. Start: `npm start`. Health: `/api/health`.
5. Khi deploy xong, dùng địa chỉ HTTPS Render cấp để đăng nhập, tạo phòng, gửi link và mã tham gia cho học sinh.
6. Nếu dùng camera IP, thiết lập mạng tới camera và `CAMERA_HOSTS` trước; đây là việc riêng với khả năng mở website công khai.

Có thể triển khai trên VPS Node 24, reverse proxy HTTPS (Nginx/Caddy), ổ đĩa bền vững. Chạy build rồi `npm start`; cấu hình `PORT`, `DATA_DIR`, `COOKIE_SECURE=true`, `TRUST_PROXY=true` khi chỉ có một proxy tin cậy. Không đưa cổng backend trực tiếp ra Internet khi bật trust proxy. Xem `.env.example`; các giá trị phải được đặt trong môi trường shell/hosting (ứng dụng không tự đọc `.env`).

Sao lưu thư mục `DATA_DIR`: DB/SQLite WAL, hash quản trị, video. Không công khai thư mục dữ liệu, không đưa vào Git/ZIP. Để SQLite nhất quán, dừng server trước khi sao lưu toàn bộ hoặc dùng công cụ SQLite backup. Cấu hình này dành cho một instance máy chủ; không dùng nhiều replica cùng một file SQLite.

### Railway khi repository đang chứa ZIP

Nếu đã tải ZIP nguồn lên GitHub, có thể dùng `deploy/railway-zip.Dockerfile` thay cho thao tác tải từng thư mục:

1. Đặt cấu hình đó ở thư mục gốc GitHub với tên chính xác **`Dockerfile`**, cạnh **một** ZIP nguồn FocusLab Proctor 2. ZIP cần chứa thư mục `focuslab-proctor-server`; tên ZIP có hậu tố ` (1)` vẫn được hỗ trợ.
2. Railway tự nhận Dockerfile, giải nén, cài dependencies và build. Nếu đã cấu hình lệnh build/start riêng, dùng lại lệnh mặc định của Dockerfile.
3. Trong **Variables**, đặt `ADMIN_PASSWORD` riêng từ 12 đến 200 ký tự. Không ghi mật khẩu vào Dockerfile hoặc GitHub.
4. Thêm **Volume** gắn với service, Mount Path là **`/data`**. Đây là nơi giữ SQLite, mật khẩu băm và video qua các lần deploy.
5. Triển khai, đợi service chạy; trong **Settings → Networking → Generate Domain**, chọn cổng **5173** để lấy link HTTPS. Nếu đã đặt `PORT` riêng, chọn đúng cổng đó.

Dockerfile dùng Node 24.14.1, `DATA_DIR=/data`, cookie HTTPS và một proxy tin cậy. Chỉ triển khai sau proxy của hosting, dùng một instance cho ổ SQLite. Railway có phí theo gói/dung lượng; kiểm tra hạn mức ổ đĩa trước khi tải video. Cấu hình này không tự tạo volume, mật khẩu hoặc tên miền. Khi cập nhật app, thay ZIP nguồn rồi triển khai lại.

## Phát triển và kiểm tra

```sh
npm test
npm run build
npm start
```

- `server/app.mjs`: API, session HTTP-only, quyền truy cập, danh sách/sự kiện/video.
- `server/media.mjs`: FFmpeg/FFprobe, bridge RTSP → HLS.
- `src/portal.js`: đăng nhập, danh sách, bảng giám thị và tải video.
- `src/main.js`: camera/nguồn video và phân tích tại thiết bị.
- `src/monitor-sync.js`: hàng đợi gửi cảnh báo.
- `src/proctoring.js`, `src/yolo.js`: quy tắc, hình học và ONNX.

Đã kiểm thử API/giới hạn 100/đúng quyền/CSV/quy tắc, FFmpeg với video tổng hợp, SSE và build. Webcam/điện thoại/camera IP thật và độ chính xác mô hình trong phòng thi cần kiểm tra trên thiết bị thật. File mở nhanh Windows phiên bản mới chưa được thực thi trong sandbox Linux. Chưa triển khai lên hosting Internet.

## Mô hình và giấy phép

Face Landmarker float16 v1 từ https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task (MediaPipe Apache-2.0).

YOLO11n ONNX từ https://huggingface.co/giangndm/yolo11-onnx tại revision `8b180c762d5cf217886d16e64403508042207e4d`, tệp `yolo11n_640.onnx` (Ultralytics YOLO11, AGPL-3.0); SHA-256 `71b891f38f484175c65b0277612e0305789bad9bd88b4e2def7609f18a23836f`. Ultralytics AGPL-3.0; bản phân phối mã nguồn dùng AGPL-3.0, thư viện bên thứ ba giữ giấy phép riêng. Xem `LICENSE` và `licenses/`.

WASM được tạo lại khi `npm ci` qua `postinstall`; chạy `npm run prepare:assets` nếu đã bỏ qua script. FFmpeg/FFprobe được lấy theo hệ điều hành từ package dependencies; có thể cấu hình `FFMPEG_PATH`, `FFPROBE_PATH` để dùng binary đã cài trên máy chủ.

## Cảnh báo tới điện thoại giám thị (Web Push)

Cảnh báo luôn được lưu trên máy chủ và cập nhật trang giám thị qua SSE. Ngoài ra máy chủ đẩy **Web Push** tới điện thoại đã đăng ký, nên giám thị nhận cảnh báo **kể cả khi đã tắt trình duyệt**.

### Chủ máy chủ bật đăng ký tài khoản

1. Trên Railway → service → **Variables**, thêm `PROCTOR_INVITE_CODE` là một mã nội bộ từ 8 ký tự trở lên. Không dùng mã dễ đoán, không đưa mã lên GitHub hay nhóm chat.
2. Triển khai lại. Khi biến này trống, nút tạo tài khoản tự ẩn và API đăng ký trả lời "máy chủ chưa bật đăng ký".
3. Gửi mã cho từng giám thị qua kênh riêng. Mỗi người tự đặt mật khẩu của mình (12–200 ký tự); máy chủ chỉ lưu mật khẩu đã băm.

### Giám thị nhận cảnh báo trên điện thoại

1. Đăng nhập bằng **tên đăng nhập và mật khẩu riêng** của mình. Không dùng mật khẩu chung của máy chủ.
2. iPhone: mở link, chọn **Thêm vào MH chủ** (Add to Home Screen), rồi mở FocusLab từ biểu tượng đó. Android Chrome: mở link và bấm **Bật thông báo điện thoại**.
3. Bấm **Cho phép** khi trình duyệt hỏi quyền, rồi bấm **Kiểm tra thông báo** để nhận một tin thử.
4. Mở phòng thi được giao, tích tên mình vào mục **Phân công giám thị** rồi bấm lưu. Cảnh báo của phòng đó chỉ đẩy tới điện thoại của những người được tích; tài khoản quản trị nhận cảnh báo của mọi phòng.

Khóa VAPID tự tạo trong `DATA_DIR/vapid.json` khi khởi động lần đầu và giữ nguyên qua các lần triển khai, miễn là volume `/data` còn. Chỉ đặt `PUSH_VAPID_PUBLIC_KEY` và `PUSH_VAPID_PRIVATE_KEY` khi `DATA_DIR` không phải volume. Ngưỡng gửi là `PUSH_MIN_RISK` (mặc định 40/100) và `PUSH_COOLDOWN_SECONDS` (mặc định 60 giây cho cùng một chỗ ngồi và cùng một quy tắc).

Máy chủ chỉ chấp nhận endpoint HTTPS công khai, và một thiết bị chỉ tự hủy đăng ký của chính nó. Bản này **không còn gửi tin Zalo Official Account**: bảng `zalo_notifications` cũ vẫn nằm trong `/data` nhưng không được dùng tới. Muốn dùng lại Zalo thì phải tích hợp lại từ đầu.
## Nhận diện sách và điện thoại (2.3)

Mô hình YOLO11n thay YOLOv8n, ngưỡng mặc định 30%. Độ tin cậy mô hình không phải xác suất gian lận. Sách được phép vẫn hiện khung nhận diện nhưng không tính cảnh báo vật thể.

Nếu vật thể nhỏ, chọn **Vật thể nhỏ: phóng vùng giữa 2×** trước khi hiệu chỉnh; đặt sách/điện thoại vào khung vàng. Chế độ này chỉ quét giữa ảnh, không dùng để giám sát toàn phòng. Không thêm lượt suy luận nên không nhân đôi tải máy.

Mở **Ảnh AI vừa phân tích** để xem đúng ảnh và khung vật thể mà mô hình đã xử lý. Kết quả chậm hơn 3 giây vẫn xem được ở đây, nhưng không được dùng để gán cảnh báo trực tiếp cho thí sinh. Khung này không tải ảnh lên máy chủ.

Đã thử trực tiếp mô hình ONNX với ảnh COCO128 có sách/điện thoại và ảnh đối chứng. Có cải thiện trên một số ảnh; vẫn bỏ sót vật thể nhỏ, bị che và góc lạ. Đây không phải kiểm định độ chính xác phòng thi hay Android thật. Cần kiểm tra trên camera thực tế trước khi sử dụng.

### Nhắm mắt kéo dài / nghi ngủ gật

Mặc định hai mắt có EAR dưới 0,21 liên tục 2 giây tạo cảnh báo **Nhắm mắt kéo dài (nghi ngủ gật)**, trọng số 50. Có thanh chỉnh EAR và cột EAR theo chỗ ngồi. Chớp mắt ngắn, một mắt nhắm, nhiều mặt trong một vùng hoặc gián đoạn xử lý không được cộng thành thời gian nhắm mắt liên tục. Khi mở mắt, sự kiện kết thúc. Quy tắc này theo dõi mắt, không xác nhận một người thực sự đang ngủ.

Vì nhắm mắt chỉ đo được khi nhìn rõ hai mắt, thí sinh úp mặt, quay hẳn sang bên hoặc che mặt bằng tay/vở sẽ làm mất điểm mắt và **không** tạo cảnh báo nhắm mắt. Hai trường hợp đó do quy tắc khác phủ: còn khuôn mặt trong vùng nhưng không đo được mắt ≥2 giây → **Có mặt nhưng không đo được mắt** (+60); mặt rời hẳn khỏi vùng ≥2,5 giây → **Không thấy khuôn mặt tại chỗ** (+65).

Cảnh báo nhắm mắt được lưu/gửi về máy chủ giống các quy tắc khác; nếu đạt `PUSH_MIN_RISK` thì được đẩy tới điện thoại của giám thị được gán phòng. Sách mặc định bị cảnh báo sau1,5giây quan sát hợp lệ trong cùng vùng; chỉ miễn cảnh báo khi giám thị chủ động chọn **Đề thi mở sách: bỏ cảnh báo sách**. Cần bấm **Hiệu chỉnh & bắt đầu** để ghi và gửi sự kiện.
