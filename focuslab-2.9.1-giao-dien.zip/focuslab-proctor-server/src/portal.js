import './style.css';
import './portal.css';
import Papa from 'papaparse';
import { enablePhonePush } from './browser-notifications.js';
import { api,post,escape,download } from './api.js';
import { RULES,csvCell } from './proctoring.js';
import { mountExamBoard } from './exam-board.js';
const $=id=>document.getElementById(id);
let me,roomId,stream,roomState,previousCount=null;
let processing=new Set(),refreshTimer,examBoard,seatFilter=null;
function scheduleRefresh(){if(refreshTimer)return;refreshTimer=setTimeout(()=>{refreshTimer=null;refreshRoom().catch(e=>notify(e.message,true));},800);}
const savedRoom=()=>sessionStorage.getItem('focuslab-room');
function notify(text,error=false){$('portal-message').textContent=text;$('portal-message').classList.toggle('error',error);}
const EYE_OPEN='<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.6 12S5.4 5.3 12 5.3 22.4 12 22.4 12 18.6 18.7 12 18.7 1.6 12 1.6 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>';
const EYE_CLOSED=`${EYE_OPEN}<path d="M3.4 20.6 20.6 3.4"/>`;
function paintToggle(input,button,hidden){
 button.innerHTML=hidden?EYE_OPEN:EYE_CLOSED;
 const label=hidden?'Hiện mật khẩu':'Ẩn mật khẩu';
 button.title=label;button.setAttribute('aria-label',label);button.setAttribute('aria-pressed',String(!hidden));
}
function mountPasswordToggles(root=document){
 root.querySelectorAll('input').forEach(input=>{
  if(input.dataset.toggle||input.type!=='password')return;
  input.dataset.toggle='1';
  const field=document.createElement('span');field.className='pw-field';
  input.parentNode.insertBefore(field,input);field.append(input);
  const button=document.createElement('button');button.type='button';button.className='pw-toggle';
  paintToggle(input,button,true);
  button.onclick=()=>{const hidden=input.type==='password';input.type=hidden?'text':'password';paintToggle(input,button,hidden);input.focus({preventScroll:true});};
  field.append(button);
 });
}
function hideSecrets(root){
 root.querySelectorAll('input[data-toggle]').forEach(input=>{input.type='password';paintToggle(input,input.parentNode.querySelector('.pw-toggle'),true);});
}
async function submitForm(formId,errorId,busyText,work){
 const form=$(formId),error=$(errorId),button=form.querySelector('button');
 error.textContent='';error.classList.remove('error');
 const label=button.textContent;button.disabled=true;button.textContent=busyText;
 try{await work();}
 catch(e){
  error.textContent=e.message||'Máy chủ không phản hồi. Kiểm tra mạng rồi thử lại.';
  error.classList.add('error');
  notify(e.message,true);
  error.scrollIntoView({block:'center',behavior:'smooth'});
 }
 finally{button.disabled=false;button.textContent=label;}
}
document.querySelector('#app').innerHTML=`<div class="portal"><header><a class="brand" href="/">FocusLab<span class="brand-dot">.</span><small>PROCTOR</small></a><div><span id="admin-badge" class="local-badge" hidden></span> <a href="/monitor" class="text-link">Phân tích tại thiết bị</a> <button id="change-password" hidden>Đổi mật khẩu</button> <button id="logout" hidden>Đăng xuất</button></div></header><div id="portal-message" role="status" aria-live="polite"></div><div id="content"></div><dialog id="password-dialog" aria-labelledby="password-title"><form id="password-form"><h2 id="password-title">Đổi mật khẩu giám thị</h2><p>Mật khẩu mới từ 12 đến 200 ký tự. Đổi xong, mọi phiên giám thị cần đăng nhập lại.</p><label>Mật khẩu hiện tại<input id="current-password" type="password" autocomplete="current-password" required maxlength="200"/></label><label>Mật khẩu mới<input id="new-password" type="password" autocomplete="new-password" required minlength="12" maxlength="200"/></label><label>Nhập lại mật khẩu mới<input id="confirm-password" type="password" autocomplete="new-password" required minlength="12" maxlength="200"/></label><p id="password-message" role="alert"></p><div><button id="save-password" class="primary">Lưu mật khẩu mới</button> <button id="cancel-password" type="button">Hủy</button></div></form></dialog><footer>Giám sát bằng tín hiệu quan sát · Giám thị xác minh bối cảnh trước khi xử lý</footer></div>`;
mountPasswordToggles();
async function showLogin(){
 const signup=await api('/api/proctor-signup').catch(()=>({enabled:false}));
 $('content').innerHTML=`<section class="welcome"><div class="eyebrow">MÁY TÍNH · ĐIỆN THOẠI · CAMERA PHÒNG THI</div><h1>Một phòng thi.<br>Kết nối nhiều thiết bị.</h1><p>Quản lý tối đa 100 học sinh mỗi phòng, nhận cảnh báo đẩy về điện thoại và xem video trên trình duyệt.</p></section><div class="login-grid"><form id="admin-login" class="portal-card"><h2>Dành cho giám thị</h2><p>Đăng nhập bằng tài khoản riêng của bạn. Bỏ trống tên đăng nhập nếu bạn dùng mật khẩu chủ máy chủ.</p><label>Tên đăng nhập<input id="login-username" autocomplete="username" maxlength="32"/></label><label>Mật khẩu<input type="password" id="admin-password" autocomplete="current-password" required maxlength="200"/></label><button class="primary">Đăng nhập giám thị</button><p id="login-error" class="form-error" role="alert"></p>${signup.enabled?'<p><a href="#dang-ky" id="open-signup">Chưa có tài khoản? Tạo mới</a></p>':'<p>Máy chủ chưa bật tự đăng ký. Hãy liên hệ quản trị viên.</p>'}</form><form id="proctor-signup-form" class="portal-card" hidden><h2>Tạo tài khoản giám thị</h2><p>Mỗi giám thị một mật khẩu riêng. Cảnh báo chỉ bắn tới điện thoại của giám thị được gán phòng.</p><label>Tên đăng nhập (không dấu cách)<input id="signup-username" required maxlength="32" autocomplete="username"/></label><label>Họ và tên<input id="signup-display" required maxlength="120" autocomplete="name"/></label><label>Mật khẩu (ít nhất 12 ký tự)<input id="signup-password" type="password" required maxlength="200" autocomplete="new-password"/></label><label>Mã đăng ký<input id="signup-code" type="password" required maxlength="100" autocomplete="off"/></label><button class="primary">Tạo tài khoản & đăng nhập</button><p id="signup-error" class="form-error" role="alert"></p><p><a href="#dang-nhap" id="back-to-login">← Đã có tài khoản? Đăng nhập</a></p></form><form id="student-join" class="portal-card"><h2>Tham gia phiên thi</h2><p>Nhập mã do giám thị cấp. Tên của bạn được lấy từ danh sách phòng thi.</p><label>Mã phòng<input id="room-code" required value="${escape(new URLSearchParams(location.search).get('room')||'')}" autocomplete="off"/></label><label>Mã tham gia riêng<input id="access-code" type="password" required autocomplete="off"/></label><button class="primary">Tham gia</button><p id="join-error" class="form-error" role="alert"></p></form></div><p class="portal-note">Camera điện thoại cần website HTTPS. Mã tham gia gắn phiên với danh sách, không xác minh danh tính bằng khuôn mặt.</p>`;
 mountPasswordToggles($('content'));
 function showSignup(){
  $('admin-login').hidden=true;$('student-join').hidden=true;$('proctor-signup-form').hidden=false;
  $('content').querySelector('.login-grid').classList.add('single');
  $('signup-username').focus();$('proctor-signup-form').scrollIntoView({block:'center',behavior:'smooth'});
 }
 function showLoginForm(){
  $('admin-login').hidden=false;$('student-join').hidden=false;$('proctor-signup-form').hidden=true;
  $('content').querySelector('.login-grid').classList.remove('single');
  $('login-username').focus();$('admin-login').scrollIntoView({block:'center',behavior:'smooth'});
 }
 $('open-signup')?.addEventListener('click',event=>{event.preventDefault();showSignup();});
 $('back-to-login')?.addEventListener('click',event=>{event.preventDefault();showLoginForm();});
 $('admin-login').onsubmit=event=>{event.preventDefault();const username=$('login-username').value.trim();void submitForm('admin-login','login-error','Đang đăng nhập…',async()=>{await post('/api/login',username?{username,password:$('admin-password').value}:{password:$('admin-password').value});await initialize();});};
 $('proctor-signup-form').onsubmit=event=>{event.preventDefault();void submitForm('proctor-signup-form','signup-error','Đang tạo tài khoản…',async()=>{const password=$('signup-password').value;if(password.length<12)throw new Error(`Mật khẩu cần ít nhất 12 ký tự, bạn mới gõ ${password.length} ký tự.`);await post('/api/proctors/register',{username:$('signup-username').value,displayName:$('signup-display').value,password,inviteCode:$('signup-code').value});await initialize();});};
 $('student-join').onsubmit=event=>{event.preventDefault();void submitForm('student-join','join-error','Đang vào phòng…',async()=>{await post('/api/join',{roomCode:$('room-code').value,accessCode:$('access-code').value});await initialize();});};
}
async function initialize(){
 try{me=await api('/api/me');}catch(e){if(e.status===401){await showLogin();return;}notify('Không kết nối được máy chủ. Hãy chạy npm run dev rồi mở lại trang.',true);return;}
 $('logout').hidden=false;$('change-password').hidden=me.role==='student';
 $('admin-badge').hidden=false;$('admin-badge').textContent=me.role==='student'?me.student.name:me.proctor?.display_name||'Chủ máy chủ';notify(`Đã đăng nhập${me.proctor?` · ${me.proctor.display_name}`:' · tài khoản chủ máy chủ'}.`);
 if(me.role==='student')await showStudent();else await showAdmin();
}
async function showAdmin(){
 const rooms=await api('/api/rooms');
 $('content').innerHTML=`<section class="page-heading"><div><div class="eyebrow">BẢNG ĐIỀU KHIỂN GIÁM THỊ</div><h1>Quản lý phòng thi.</h1><p>Cảnh báo gửi từ thiết bị và nguồn camera được lưu tại máy chủ.</p></div></section><section class="portal-card room-selector"><label>Chọn phòng<select id="room-select"><option value="">Chọn phòng…</option>${rooms.map(r=>`<option value="${r.id}">${escape(r.title)} · ${r.student_count}/100${r.closed?' · Đã đóng':''}</option>`).join('')}</select></label><form id="new-room"><label>Tên phòng mới<input id="room-title" required maxlength="120" placeholder="Ví dụ: Lớp 10A — Toán"/></label><button class="primary">Tạo phòng</button></form></section><div id="room-content"></div>`;
 $('new-room').onsubmit=async e=>{e.preventDefault();try{const room=await post('/api/rooms',{title:$('room-title').value});sessionStorage.setItem('focuslab-room',room.id);await showAdmin();}catch(error){notify(error.message,true);}};
 $('room-select').onchange=()=>openRoom($('room-select').value);
 const selected=rooms.find(r=>r.id===savedRoom())??rooms[0];if(selected){$('room-select').value=selected.id;await openRoom(selected.id);}
}
async function openRoom(id){
 stream?.close();roomId=id;previousCount=null;seatFilter=null;examBoard=null;if(!id){$('room-content').innerHTML='';return;}sessionStorage.setItem('focuslab-room',id);
 $('room-content').innerHTML=`<section class="dash-head"><div><div class="eyebrow">BẢNG ĐIỀU KHIỂN GIÁM THỊ</div><h1>Quản lý phòng thi: <span id="room-name"></span></h1><p>Mã phòng <code id="room-code">…</code> · <span id="room-status" class="live-pill">Đang mở</span> · Cảnh báo từ camera và thiết bị được ghi nhận theo thời gian thực.</p></div><div class="dash-actions"><a class="button primary" href="/">+ Tạo phòng mới</a><button id="close-room" class="danger">Đóng phòng thi</button></div></section><div class="portal-stats" id="room-stats"></div><section class="portal-card" id="exam-panel"></section><div class="portal-grid"><section class="portal-card"><div class="section-head"><h2>Danh sách học sinh</h2><button id="sample-roster" class="mini">Tải CSV mẫu</button></div><p>CSV: <code>student_id,name,seat_id</code>. Cột chỗ ngồi có thể bỏ trống để tự đánh S01…S100.</p><form id="import-roster"><label class="drop-zone"><input id="roster-file" type="file" accept=".csv,text/csv" required/><span>Kéo thả tệp CSV vào đây hoặc <b>Chọn tệp</b></span><small>Chấp nhận định dạng .csv, tối đa 100 học sinh</small></label><button class="primary block">Nhập danh sách & cấp mã</button></form><div id="credentials" hidden><p>Hãy tải mã và gửi riêng cho từng học sinh. Mã chỉ hiện trong lần cấp này.</p><button id="download-codes">Tải danh sách mã tham gia</button></div><p id="join-link"></p></section><section class="portal-card"><div class="section-head"><h2>Nguồn giám sát & Camera IP</h2></div><p>Một thiết bị phân tích camera phòng thi; học sinh từ xa dùng mã riêng trên điện thoại/máy tính.</p><div class="dash-actions"><a id="room-monitor" class="button primary">📷 Mở camera phòng thi</a><a class="button outline" href="#add-camera">🔗 Kết nối Camera IP</a></div><form id="add-camera"><h3>Camera IP / CCTV</h3><input id="camera-name" maxlength="100" placeholder="Tên camera (ví dụ: Camera cửa lớp)"/><input id="camera-url" type="password" required placeholder="URL RTSP (rtsp://…)" autocomplete="off"/><small>Host camera cần được khai báo trong CAMERA_HOSTS, và máy chủ phải truy cập được camera.</small><button class="outline">Kết nối camera IP</button></form><div id="camera-list"></div></section></div><section class="portal-card" id="proctor-panel" hidden><h2>Giám thị phụ trách phòng</h2><p>Cảnh báo của phòng này chỉ đẩy tới điện thoại của giám thị được tick ở đây, cộng với điện thoại của chủ máy chủ.</p><div id="proctor-list"></div><button id="save-proctors" class="primary">Lưu phân công</button></section><section class="portal-card"><div class="section-head"><h2>Học sinh trong phòng thi</h2><span>Trạng thái theo kết nối thiết bị, cập nhật thời gian thực</span></div><div class="scroll-table"><table><thead><tr><th>Mã HS</th><th>Họ và tên</th><th>Chỗ ngồi</th><th>Trạng thái kết nối</th><th>Thao tác</th></tr></thead><tbody id="student-list"></tbody></table></div></section><section class="portal-card"><div class="section-head"><h2 id="server-events-title">Cảnh báo máy chủ</h2><button id="export-server-events" class="mini">Xuất 300 sự kiện đang hiển thị</button></div><p id="event-note"></p><div class="dash-actions"><button id="enable-push">Bật thông báo điện thoại</button><button id="test-push">Gửi thông báo thử</button></div><p id="notification-status" role="status"></p><small>Bấm một lần trên mỗi điện thoại rồi chọn Cho phép. Sau đó máy chủ tự đẩy cảnh báo, kể cả khi bạn tắt trang.</small><div class="scroll-table"><table><thead><tr><th>Nhận lúc</th><th>Học sinh / vùng</th><th>Quan sát</th><th>Chỉ số</th><th>Điện thoại</th><th>Giám thị xem lại</th></tr></thead><tbody id="server-events"></tbody></table></div></section><section class="portal-card"><div class="section-head"><h2>Video đã tải lên</h2></div><form id="video-upload"><label>Video MP4, MOV hoặc WebM (≤500 MB, ≤2 giờ)<input id="upload-file" type="file" accept="video/mp4,video/quicktime,video/webm,.mov" required/></label><button class="primary">Tải lên máy chủ</button><span id="upload-status"></span></form><div id="video-list" class="media-grid"></div></section>`;
 $('room-monitor').href=`/monitor?room=${id}`;
 examBoard=mountExamBoard($('exam-panel'),{roomId:id,notify});
 $('sample-roster').onclick=()=>download('danh-sach-mau.csv','\uFEFFstudent_id,name,seat_id\r\nHS001,Học sinh mẫu 1,S01\r\nHS002,Học sinh mẫu 2,S02');
 // Kéo thả chỉ là cách chọn tệp khác: vẫn dùng đúng input#roster-file và cùng một luồng xử lý CSV.
 const drop=$('import-roster').querySelector('.drop-zone');
 drop.ondragover=event=>{event.preventDefault();drop.classList.add('over');};
 drop.ondragleave=()=>drop.classList.remove('over');
 drop.ondrop=event=>{event.preventDefault();drop.classList.remove('over');const files=event.dataTransfer?.files;if(!files?.length)return;$('roster-file').files=files;notify(`Đã chọn ${files[0].name}. Bấm "Nhập danh sách & cấp mã".`);};
 $('student-list').onclick=event=>{
  const code=event.target.dataset.detail;
  if(!code)return;
  seatFilter=seatFilter===code?null:code;
  $('server-events-title').scrollIntoView({block:'center',behavior:'smooth'});
  refreshRoom().catch(error=>notify(error.message,true));
 };
 $('import-roster').onsubmit=e=>{e.preventDefault();const file=$('roster-file').files[0];if(file.size>1024*1024){notify('CSV tối đa 1 MB.',true);return;}Papa.parse(file,{header:true,skipEmptyLines:'greedy',transformHeader:h=>h.trim().replace(/^\uFEFF/,''),complete:async result=>{try{if(result.errors.length)throw new Error('CSV có lỗi định dạng. Hãy dùng tệp mẫu.');const data=await post(`/api/rooms/${roomId}/students`,{students:result.data});$('credentials').hidden=false;$('download-codes').onclick=()=>download('ma-tham-gia.csv','\uFEFF'+[['room_code','student_id','name','seat_id','access_code'],...data.students.map(s=>[data.roomCode,s.student_id,s.name,s.seat_id,s.access_code])].map(r=>r.map(csvCell).join(',')).join('\r\n'));notify(`Đã thêm ${data.students.length} học sinh. Tải mã tham gia ngay.`);await refreshRoom();}catch(error){notify(error.message,true);}}});};
 $('add-camera').onsubmit=async e=>{e.preventDefault();try{await post(`/api/rooms/${roomId}/cameras`,{name:$('camera-name').value,url:$('camera-url').value});$('camera-url').value='';await refreshRoom();notify('Đang kết nối camera. Đợi vài giây rồi mở luồng phân tích.');}catch(error){notify(error.message,true);}};
 $('close-room').onclick=async()=>{if(!confirm('Đóng phòng sẽ ngừng nhận cảnh báo mới và mã tham gia. Tiếp tục?'))return;try{await post(`/api/rooms/${roomId}/close`,{});await refreshRoom();}catch(e){notify(e.message,true);}};
 $('video-upload').onsubmit=e=>{e.preventDefault();uploadVideo($('upload-file').files[0],roomId);};
 $('server-events').onchange=async e=>{if(!e.target.dataset.event)return;try{await api(`/api/rooms/${roomId}/events/${e.target.dataset.event}`,{method:'PATCH',body:JSON.stringify({review:e.target.value})});}catch(error){notify(error.message,true);}};
 $('server-events').onclick=async e=>{const clipId=e.target.dataset?.clip;if(!clipId)return;if(!confirm('Xoá clip này khỏi máy chủ? Không lấy lại được.'))return;try{await api(`/api/clips/${clipId}`,{method:'DELETE'});notify('Đã xoá clip.');await refreshRoom();}catch(error){notify(error.message,true);}};
 $('export-server-events').onclick=()=>download('canh-bao-may-chu.csv','\uFEFF'+[['received_at','student_id','name','seat_id','observation','risk','review'],...(roomState?.events??[]).filter(e=>!seatFilter||e.student_code===seatFilter).map(e=>[new Date(e.received_at).toISOString(),e.student_code??'',e.name??'',e.seat_id,RULES[e.rule]?.label??e.rule,e.risk,e.review])].map(row=>row.map(csvCell).join(',')).join('\r\n'));
 $('enable-push').onclick=async()=>{const button=$('enable-push');button.disabled=true;try{
   const result=await enablePhonePush(window,{getKey:async()=>(await api('/api/push')).publicKey,save:subscription=>post('/api/push/subscription',{...subscription,label:String(navigator.userAgent).slice(0,60)})});
   notify(result==='granted'?'Đã bật. Điện thoại này sẽ nhận cảnh báo kể cả khi bạn tắt trang.':result==='unsupported'?'Trình duyệt này chưa hỗ trợ thông báo đẩy. Trên iPhone cần thêm website ra màn hình chủ rồi bật trong ứng dụng FocusLab.':result==='denied'?'Bạn chưa cho phép thông báo. Cảnh báo vẫn được lưu trên máy chủ.':'Máy chủ chưa cung cấp khóa thông báo, chủ máy cần khởi động lại dịch vụ.');
   await refreshRoom();
  }catch(error){notify(error.message,true);}finally{button.disabled=false;}};
 $('test-push').onclick=async()=>{const button=$('test-push');button.disabled=true;try{const result=await post('/api/push/test',{});notify(`Đã đẩy ${result.sent}/${result.total} thông báo thử tới điện thoại của tài khoản này.`);}catch(error){notify(error.message,true);}finally{await refreshRoom();button.disabled=false;}};
 if(me.role==='admin'){
   $('proctor-panel').hidden=false;
   const [all,assigned]=await Promise.all([api('/api/proctors'),api(`/api/rooms/${id}/proctors`)]).catch(()=>[[],[]]);
   const chosen=new Set(assigned.map(p=>p.id));
   $('proctor-list').innerHTML=all.length?all.map(p=>`<label><input type="checkbox" data-proctor="${escape(p.id)}" ${chosen.has(p.id)?'checked':''}/> ${escape(p.display_name)} <small>@${escape(p.username)} · ${p.room_count} phòng</small></label>`).join('<br>'):'<p>Chưa có giám thị nào. Hãy đặt PROCTOR_INVITE_CODE rồi gửi mã đó cho từng người để họ tự tạo tài khoản.</p>';
   $('save-proctors').onclick=async()=>{try{await api(`/api/rooms/${id}/proctors`,{method:'PUT',body:JSON.stringify({proctorIds:[...document.querySelectorAll('[data-proctor]:checked')].map(input=>input.dataset.proctor)})});notify('Đã lưu phân công. Cảnh báo phòng này chỉ đẩy tới điện thoại của giám thị được tick.');}catch(error){notify(error.message,true);}};
 }
 await refreshRoom();stream=new EventSource(`/api/rooms/${roomId}/stream`);stream.addEventListener('change',scheduleRefresh);stream.onerror=async()=>{if(!me||roomId!==id)return;try{await api('/api/me');if(me&&roomId===id)notify('Kết nối thông báo đang thử lại; dữ liệu vẫn được lưu trên máy chủ.',true);}catch(error){if(error.status===401&&me?.role!=='student')endSession('Phiên giám thị đã hết hiệu lực. Hãy đăng nhập lại.');else if(me&&roomId===id)notify('Không kết nối được luồng thông báo. Đang thử lại.',true);}};
}
async function refreshRoom(){
 const requested=roomId;if(!requested||!['admin','proctor'].includes(me?.role))return;const data=await api(`/api/rooms/${requested}`);if(requested!==roomId)return;roomState=data;
 $('room-name').textContent=data.room.title;$('room-code').textContent=data.room.code;
 $('room-status').textContent=data.room.closed?'Đã đóng':'Đang mở';$('room-status').classList.toggle('closed',!!data.room.closed);$('close-room').disabled=!!data.room.closed;
 $('join-link').textContent=`Link tham gia: ${location.origin}/join?room=${data.room.code}`;
 const live=data.students.filter(s=>Date.now()-s.last_seen<90000).length;
 $('room-stats').innerHTML=`<article><div><span>Học sinh trong danh sách</span><strong>${data.students.length}<em>/100</em></strong></div><i class="stat-icon mint">👥</i></article><article><div><span>Thiết bị kết nối gần đây</span><strong>${live}</strong></div><i class="stat-icon amber">💻</i></article><article><div><span>Sự kiện / Vi phạm</span><strong class="danger">${data.eventCount}</strong></div><i class="stat-icon rose">🚨</i></article>`;
 $('student-list').innerHTML=data.students.map(s=>{const online=Date.now()-s.last_seen<90000;return `<tr><td>${escape(s.student_code)}</td><td>${escape(s.name)}</td><td>${escape(s.seat_id)}</td><td><span class="badge ${online?'on':'off'}">${online?'🟢 Đang kết nối':'🔴 Ngoại tuyến'}</span></td><td><button class="link" data-detail="${escape(s.student_code)}">${seatFilter===s.student_code?'Bỏ lọc cảnh báo':'Chi tiết'}</button></td></tr>`;}).join('');
 // One clip per event id: the device names the clip with the same client id it used for the event.
 const clipsByEvent=new Map((data.clips??[]).map(clip=>[clip.event_id,clip]));
 const shown=seatFilter?data.events.filter(e=>e.student_code===seatFilter):data.events;
 if(!document.activeElement?.matches('[data-event]'))$('server-events').innerHTML=(shown.length?shown.map(e=>`<tr><td>${new Date(e.received_at).toLocaleTimeString('vi-VN')}</td><td>${escape(e.name||e.seat_id)}<small>${escape(e.student_code||'Vùng chưa gán danh sách')}</small></td><td>${escape(RULES[e.rule]?.label)}${e.payload.offset!==null?`<small>Mốc video: ${e.payload.offset.toFixed(1)}s</small>`:''}${(()=>{const clip=clipsByEvent.get(e.id);if(!clip)return '';return `<a href="/api/clips/${encodeURIComponent(clip.id)}/content" download>Tải clip ${(Math.round(clip.size/1048576*10)/10)} MB</a><button data-clip="${encodeURIComponent(clip.id)}">Xoá clip</button><small>Clip tự xoá ${new Date(clip.expires_at).toLocaleDateString('vi-VN')}</small>`;})()}</td><td>${e.risk}/100</td><td>${escape(({pending:'Đang chờ đẩy',sending:'Đang đẩy',sent:`Đã đẩy ${e.push_delivered}/${e.push_devices} máy`,failed:'Không đẩy được'})[e.push_status]||'Không xếp hàng')} ${e.push_error?`<small>${escape(e.push_error)}</small>`:''}</td><td><select data-event="${e.id}">${[['pending','Chưa xem'],['dismissed','Không cần xử lý'],['followup','Cần trao đổi']].map(([v,label])=>`<option value="${v}" ${e.review===v?'selected':''}>${label}</option>`).join('')}</select></td></tr>`).join(''):'<tr><td colspan="6" class="empty-row">Chưa có cảnh báo nào theo bộ lọc này.</td></tr>');
 $('event-note').textContent=seatFilter?`Đang lọc theo học sinh ${seatFilter}: ${shown.length}/${data.events.length} cảnh báo hiển thị trong bảng. Bấm "Bỏ lọc cảnh báo" ở bảng học sinh để xem tất cả.`:`Hiển thị ${data.events.length}/${data.eventCount} sự kiện gần nhất. Đây là báo cáo do thiết bị gửi, cần giám thị xác minh.`;
 const n=data.notifications;$('test-push').disabled=!n.devices;$('notification-status').textContent=n.devices?`Điện thoại nhận cảnh báo phòng này: ${n.devices} máy · Đẩy từ ${n.minRisk}/100 · Lặp lại sớm nhất sau ${n.cooldownSeconds}s · Đã đẩy ${n.sent} · Lỗi ${n.failed}.`:'Chưa có điện thoại nào đăng ký. Mở trang này trên điện thoại của giám thị rồi bấm Bật thông báo điện thoại.';
 $('camera-list').innerHTML=data.cameras.map(c=>`<div class="media-item"><strong>${escape(c.name)}</strong><span>${escape(c.status)}</span><a href="/monitor?room=${roomId}&camera=${c.id}">Mở phân tích</a><button data-stop-camera="${c.id}">Dừng luồng IP</button></div>`).join('');
 $('video-list').innerHTML=data.videos.map(v=>`<div class="media-item"><strong>${escape(v.name)}</strong><span>${v.status==='ready'?'Sẵn sàng':v.status==='processing'?'Đang chuyển đổi':'Lỗi xử lý'}</span>${v.error?`<small>${escape(v.error)}</small>`:''}${v.status==='ready'?`<a href="/monitor?room=${roomId}&video=${v.id}">Mở video & phân tích</a>`:''}<button data-delete-video="${v.id}" ${v.status==='processing'?'disabled':''}>Xóa video</button></div>`).join('');
 // The paper board reads a second endpoint, so its failure must never blank the proctoring panel above it.
 try{await examBoard?.refresh(data);}catch(error){notify(`Không tải được bảng đề thi: ${error.message}`,true);}
 if(previousCount!==null&&data.eventCount>previousCount){notify(`Có ${data.eventCount-previousCount} cảnh báo mới. Mở bảng để kiểm tra.`);} previousCount=data.eventCount;
}
async function showStudent(){
 roomId=me.roomId;const data=await api(`/api/rooms/${roomId}`);
 $('content').innerHTML=`<section class="welcome"><div class="eyebrow">THIẾT BỊ CỦA THÍ SINH</div><h1>Xin chào, ${escape(me.student.name)}.</h1><p>${escape(data.room.title)} · Mã ${escape(me.student.student_code)} · ${escape(me.student.seat_id)}</p></section><div class="portal-grid"><section class="portal-card"><h2>Bài thi trên máy</h2><p>Mở đề thi đang chạy trên thiết bị này và giữ nguyên cửa sổ đó tới khi hết giờ. Bài tự lưu từng câu, tắt trang mở lại vẫn còn.</p><a class="button primary" href="/exam">Vào làm bài</a><p><small>Đây là cửa sổ làm bài. Giám thị thấy khi em rời cửa sổ này, dán bài hoặc ngừng làm; camera giám sát chạy trên thiết bị kia.</small></p></section><section class="portal-card"><h2>Camera của bạn</h2><p>Chọn camera trước/sau hoặc webcam USB trong trang phân tích. Cảnh báo sẽ gửi về máy chủ của phòng thi.</p><a class="button primary" href="/monitor?room=${roomId}">Mở camera & bắt đầu</a><p>Giữ trang phân tích mở trong suốt phiên.</p></section></div><section class="portal-card"><h2>Nộp video</h2><form id="video-upload"><label>Chọn video (MP4/MOV/WebM, ≤500 MB, ≤2 giờ)<input type="file" id="upload-file" accept="video/*" required/></label><button class="primary">Tải lên máy chủ</button><p id="upload-status"></p></form><div id="own-video"></div></section>`;
 $('video-upload').onsubmit=e=>{e.preventDefault();uploadVideo($('upload-file').files[0],roomId);};post('/api/heartbeat',{}).catch(()=>{});
}
async function uploadVideo(file,id){
 if(!file)return;if(file.size>500*1024*1024){notify('Video tối đa 500 MB.',true);return;}
 const button=$('video-upload').querySelector('button');button.disabled=true;$('upload-status').textContent='Đang tải lên…';
 try{const body=new FormData();body.append('video',file);const video=await api(`/api/rooms/${id}/videos`,{method:'POST',body});$('upload-status').textContent='Máy chủ đã nhận video; đang chuyển định dạng cho trình duyệt.';processing.add(video.id);if(me.role!=='student')await refreshRoom();}catch(error){$('upload-status').textContent=error.message;}finally{button.disabled=false;}
}
$('content').addEventListener('click',async e=>{try{if(e.target.dataset.deleteVideo){if(!confirm('Xóa video khỏi máy chủ?'))return;await api(`/api/videos/${e.target.dataset.deleteVideo}`,{method:'DELETE'});await refreshRoom();}if(e.target.dataset.stopCamera){await api(`/api/cameras/${e.target.dataset.stopCamera}`,{method:'DELETE'});await refreshRoom();}}catch(error){notify(error.message,true);}});
function endSession(message){
 stream?.close();stream=null;clearTimeout(refreshTimer);refreshTimer=null;
 roomId=null;roomState=null;previousCount=null;me=null;examBoard=null;
 $('password-dialog').close();$('password-form').reset();$('password-message').textContent='';
 $('change-password').hidden=true;$('logout').hidden=true;$('admin-badge').hidden=true;
 showLogin();notify(message);
}
$('change-password').onclick=()=>{$('password-form').reset();$('password-message').textContent='';$('password-dialog').showModal();};
$('cancel-password').onclick=()=>{$('password-dialog').close();$('password-form').reset();};
$('password-dialog').addEventListener('cancel',event=>{if($('save-password').disabled)event.preventDefault();});
$('password-dialog').addEventListener('close',()=>{$('password-form').reset();hideSecrets($('password-form'));$('password-message').textContent='';});
$('password-form').onsubmit=async event=>{
 event.preventDefault();const currentPassword=$('current-password').value,newPassword=$('new-password').value,confirmPassword=$('confirm-password').value;
 if(newPassword!==confirmPassword){$('password-message').textContent='Hai lần nhập mật khẩu mới chưa khớp.';return;}
 const button=$('save-password');if(button.disabled)return;button.disabled=true;$('cancel-password').disabled=true;$('password-message').textContent='Đang lưu…';
 try{await post(me.role==='proctor'?'/api/proctors/password':'/api/admin/password',{currentPassword,newPassword,confirmPassword});endSession('Đã đổi mật khẩu. Hãy đăng nhập bằng mật khẩu mới.');}
 catch(error){$('password-message').textContent=error.message;}
 finally{button.disabled=false;$('cancel-password').disabled=false;}
};
$('logout').onclick=async()=>{await post('/api/logout',{});location.href='/';};
setInterval(async()=>{if(!me)return;try{if(me.role!=='student'&&roomId)await refreshRoom();else await post('/api/heartbeat',{});for(const id of processing){const v=await api(`/api/videos/${id}`);if(v.status!=='processing'){processing.delete(id);$('upload-status').textContent=v.status==='ready'?'Video đã sẵn sàng.':v.error;if(me.role==='student'&&v.status==='ready')$('own-video').innerHTML=`<a href="/monitor?room=${roomId}&video=${id}">Mở video & phân tích</a>`;}}}catch(error){if(error.status===401&&me?.role!=='student')endSession('Phiên giám thị đã hết hiệu lực. Hãy đăng nhập lại.');}},10000);
window.addEventListener('pagehide',()=>stream?.close());
initialize().catch(error=>notify(error.message,true));
