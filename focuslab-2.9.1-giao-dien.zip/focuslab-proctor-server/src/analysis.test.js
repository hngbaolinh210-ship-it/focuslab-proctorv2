import test from 'node:test';
import assert from 'node:assert/strict';
import { ear, pose, classify, angleDifference } from './analysis.js';
test('EAR accounts for image aspect ratio and degenerate eye width', () => {
 const eye = [{x:0,y:.5},{x:.25,y:.3},{x:.75,y:.3},{x:1,y:.5},{x:.75,y:.7},{x:.25,y:.7}];
 assert.ok(Math.abs(ear(eye,[0,1,2,3,4,5],200,100)-.2)<1e-9);
 assert.equal(ear(Array(6).fill({x:0,y:0}),[0,1,2,3,4,5],200,100),null);
});
test('short blink is ignored; sustained closure and head turn are flagged', () => {
 assert.equal(classify(.1,0,0,.2,25,799).score,100);
 assert.equal(classify(.1,0,0,.2,25,800).score,10);
 assert.equal(classify(.3,0,26,.2,25,0).score,40);
 assert.equal(classify(.3,-21,0,.2,25,0).score,40);
 assert.equal(classify(null,0,0,.2,25,0).score,null);
});
test('pose uses column-major rotation and calibration wraps angles', () => {
 assert.equal(pose(null),null);
 const identity = [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
 assert.equal(Math.abs(pose(identity).yaw),0);
 assert.equal(pose(identity).pitch,0);
 assert.equal(angleDifference(-179,179),2);
 const a=Math.PI/6;
 assert.ok(Math.abs(pose([Math.cos(a),0,-Math.sin(a),0,0,1,0,0,Math.sin(a),0,Math.cos(a),0,0,0,0,1]).yaw-30)<1e-9);
});

test('eye openness rejects missing/degenerate landmarks and preserves pixel aspect ratio',async()=>{
 const {eyeOpenness,LEFT_EYE,RIGHT_EYE}=await import('./analysis.js');
 assert.equal(eyeOpenness([],640,480),null);
 const points=Array.from({length:478},()=>({x:.5,y:.5}));assert.equal(eyeOpenness(points,640,480),null);
 for(const indices of [LEFT_EYE,RIGHT_EYE])[[.3,.5],[.4,.45],[.6,.45],[.7,.5],[.6,.55],[.4,.55]].forEach(([x,y],i)=>points[indices[i]]={x,y});
 const eyes=eyeOpenness(points,200,100);assert.ok(Math.abs(eyes.average-.125)<1e-9);
 points[LEFT_EYE[0]].x=NaN;assert.equal(eyeOpenness(points,200,100),null);
});
