export const PAPER_LABEL = 'Vùng trắng mới xuất hiện (nghi giấy in)';
export const PAPER_GRID = { cols: 24, rows: 18 };
const PAPER_DEFAULTS = { ...PAPER_GRID, brightness: .68, tint: .60, saturation: .26, fill: .70, step: 2, minCells: 6, freshRatio: .5, minArea: .012 };

// Paper is bright, weakly coloured and uniform, so it is separable from a room
// background by colour alone. Which of those cells are *new* decides the alert.
export function paperCells(pixels, width, height, options = {}) {
  const { cols, rows, brightness, tint, saturation, fill, step } = { ...PAPER_DEFAULTS, ...options };
  const found = new Set();
  if (!(width > 0 && height > 0) || !pixels) return found;
  for (let row = 0; row < rows; row++) {
    const yFrom = Math.floor(row * height / rows), yTo = Math.floor((row + 1) * height / rows);
    for (let col = 0; col < cols; col++) {
      const xFrom = Math.floor(col * width / cols), xTo = Math.floor((col + 1) * width / cols);
      let total = 0, white = 0;
      for (let y = yFrom; y < yTo; y += step) for (let x = xFrom; x < xTo; x += step) {
        const i = (y * width + x) * 4;
        if (i + 3 >= pixels.length || pixels[i + 3] < 200) continue;
        const max = Math.max(pixels[i], pixels[i + 1], pixels[i + 2]);
        const min = Math.min(pixels[i], pixels[i + 1], pixels[i + 2]);
        total++;
        if (max / 255 >= brightness && min / 255 >= tint && (max - min) / Math.max(1, max) <= saturation) white++;
      }
      if (total >= 4 && white / total >= fill) found.add(row * cols + col);
    }
  }
  return found;
}

export function paperBlobs(cells, cols = PAPER_GRID.cols, rows = PAPER_GRID.rows) {
  const seen = new Set(), blobs = [];
  for (const start of cells) {
    if (seen.has(start)) continue;
    seen.add(start);
    const stack = [start], group = [];
    while (stack.length) {
      const cell = stack.pop();
      group.push(cell);
      const col = cell % cols, row = (cell - col) / cols;
      for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const c = col + dc, r = row + dr;
        if (c < 0 || r < 0 || c >= cols || r >= rows) continue;
        const next = r * cols + c;
        if (cells.has(next) && !seen.has(next)) { seen.add(next); stack.push(next); }
      }
    }
    const colsIn = group.map(cell => cell % cols), rowsIn = group.map(cell => Math.floor(cell / cols));
    const minCol = Math.min(...colsIn), maxCol = Math.max(...colsIn), minRow = Math.min(...rowsIn), maxRow = Math.max(...rowsIn);
    blobs.push({ cells: group, box: { x: minCol / cols, y: minRow / rows, width: (maxCol + 1 - minCol) / cols, height: (maxRow + 1 - minRow) / rows } });
  }
  return blobs;
}

export function paperDetections(pixels, width, height, baseline = new Set(), options = {}) {
  const settings = { ...PAPER_DEFAULTS, ...options };
  const cells = paperCells(pixels, width, height, settings);
  const boxes = [];
  for (const blob of paperBlobs(cells, settings.cols, settings.rows)) {
    const fresh = blob.cells.filter(cell => !baseline.has(cell)).length;
    const area = blob.box.width * blob.box.height;
    if (fresh < settings.minCells || fresh / blob.cells.length < settings.freshRatio || area < settings.minArea) continue;
    boxes.push({ label: PAPER_LABEL, score: Number((fresh / blob.cells.length).toFixed(3)), kind: 'paper', box: blob.box });
  }
  return { cells, boxes };
}
