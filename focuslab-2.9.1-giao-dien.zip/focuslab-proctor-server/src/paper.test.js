import test from 'node:test';
import assert from 'node:assert/strict';
import { paperCells, paperBlobs, paperDetections, PAPER_LABEL, PAPER_GRID } from './paper.js';

const W = 240, H = 180;
function frame(draw) {
  const pixels = new Uint8ClampedArray(W * H * 4);
  for (let i = 0; i < W * H; i++) { pixels[i * 4 + 3] = 255; draw(i % W, (i - i % W) / W, pixels, i); }
  return pixels;
}
const paint = (r, g, b, inside) => (x, y, pixels, i) => {
  if (!inside || inside(x, y)) { pixels[i * 4] = r; pixels[i * 4 + 1] = g; pixels[i * 4 + 2] = b; }
};

test('a bright colourless rectangle is paper, a dark desk is not', () => {
  const desk = paperCells(frame(paint(70, 72, 76)), W, H);
  assert.equal(desk.size, 0);
  const sheet = paperCells(frame(paint(255, 255, 255, (x, y) => x > 60 && x < 180 && y > 60 && y < 150)), W, H);
  assert.ok(sheet.size >= 20, `expected a wide sheet, got ${sheet.size} cells`);
});

test('warm lamp light and coloured shirts are rejected by tint and saturation', () => {
  const warm = paperCells(frame(paint(250, 214, 150)), W, H);
  assert.equal(warm.size, 0);
  const blue = paperCells(frame(paint(150, 170, 250)), W, H);
  assert.equal(blue.size, 0);
});

test('blobs merge across touching cells and keep a normalised box', () => {
  const cells = new Set([0, 1, PAPER_GRID.cols, PAPER_GRID.cols + 1]);
  const [blob] = paperBlobs(cells);
  assert.equal(blob.cells.length, 4);
  assert.deepEqual(blob.box, { x: 0, y: 0, width: 2 / PAPER_GRID.cols, height: 2 / PAPER_GRID.rows });
});

test('only cells absent from the recorded background raise a detection', () => {
  const pixels = frame(paint(255, 255, 255, (x, y) => x > 60 && x < 180 && y > 60 && y < 150));
  const background = paperCells(pixels, W, H);
  assert.equal(paperDetections(pixels, W, H, background).boxes.length, 0);
  const wall = new Set([...background].filter(cell => Math.floor(cell / PAPER_GRID.cols) < 6));
  const result = paperDetections(pixels, W, H, wall);
  assert.equal(result.boxes.length, 1);
  assert.equal(result.boxes[0].label, PAPER_LABEL);
  assert.equal(result.boxes[0].kind, 'paper');
  assert.ok(result.boxes[0].score > 0 && result.boxes[0].score <= 1);
});

test('a speck of glare is too small to accuse anyone', () => {
  const glare = frame(paint(255, 255, 255, (x, y) => x > 100 && x < 112 && y > 80 && y < 92));
  assert.equal(paperDetections(glare, W, H, new Set()).boxes.length, 0);
});

test('an empty or unreadable frame never produces boxes', () => {
  assert.equal(paperCells(null, 0, 0).size, 0);
  assert.equal(paperDetections(new Uint8ClampedArray(0), 0, 0).boxes.length, 0);
});

test('a classroom scene: white wall becomes background, a sheet placed later is reported', () => {
  const scene = (...layers) => frame((x, y, pixels, i) => {
    for (const [color, inside] of layers) if (inside(x, y)) { const [r, g, b] = color; pixels[i * 4] = r; pixels[i * 4 + 1] = g; pixels[i * 4 + 2] = b; }
  });
  const wall = (x, y) => y < 34, desk = (x, y) => !wall(x, y), shirt = (x, y) => x > 180 && x < 240 && y > 40 && y < 120;
  const before = scene([[250, 250, 246], wall], [[122, 84, 52], desk], [[58, 92, 162], shirt]);
  const baseline = paperCells(before, W, H);
  assert.ok(baseline.size > 0, 'the wall should read as white so it can be excluded');
  const after = scene([[250, 250, 246], wall], [[122, 84, 52], desk], [[58, 92, 162], shirt], [[247, 246, 242], (x, y) => x > 40 && x < 150 && y > 90 && y < 170]);
  const { boxes } = paperDetections(after, W, H, baseline);
  assert.equal(boxes.length, 1);
  assert.ok(boxes[0].box.y > 0.2, 'the alert must point at the sheet, not the wall');
  assert.ok(boxes[0].box.width * boxes[0].box.height < 0.5);
  assert.equal(paperDetections(before, W, H, baseline).boxes.length, 0);
});
