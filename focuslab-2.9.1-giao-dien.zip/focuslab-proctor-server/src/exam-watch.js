// A browser can prove that a student left the exam window. It can never prove what they opened somewhere else,
// so every signal below is phrased as an observation for the invigilator to verify, never as a verdict.

export const TAB_ALERT_MS = 15000;
export const PASTE_MIN_CHARS = 25;
export const IDLE_ALERT_MS = 180000;

export class IntegrityWatch {
  #hidden = false;
  #blurred = false;
  #awaySince = null;
  #awayTotal = 0;
  #lastActivity;
  #idleSince = null;

  constructor({ now = () => Date.now(), onAlert = () => {} } = {}) {
    this.now = now;
    this.onAlert = onAlert;
    this.#lastActivity = now();
    this.tabEvents = 0;
    this.pasteCount = 0;
  }

  get awayMs() { return this.#awayTotal + (this.#awaySince === null ? 0 : Math.max(0, this.now() - this.#awaySince)); }

  // A reload must continue the numbering, otherwise "tab-2" of the new page overwrites the old row on the server.
  restore({ tabMs = 0, tabEvents = 0, pasteCount = 0 } = {}) {
    this.#awayTotal = Math.max(0, Math.round(Number(tabMs) || 0));
    this.tabEvents = Math.max(this.tabEvents, Math.round(Number(tabEvents) || 0));
    this.pasteCount = Math.max(this.pasteCount, Math.round(Number(pasteCount) || 0));
  }

  setVisible({ hidden = false, blurred = false } = {}) {
    this.#hidden = hidden;
    this.#blurred = blurred;
    const away = this.#hidden || this.#blurred;
    if (away && this.#awaySince === null) { this.#awaySince = this.now(); return null; }
    if (away || this.#awaySince === null) return null;
    const ms = Math.max(0, this.now() - this.#awaySince);
    this.#awayTotal += ms;
    this.#awaySince = null;
    this.#lastActivity = Math.max(this.#lastActivity, this.now());
    this.tabEvents += 1;
    if (ms < TAB_ALERT_MS) return null;
    return this.#alert('tab', 'tab_left', this.tabEvents, Math.round(ms / 1000), {});
  }

  activity(at = this.now()) {
    this.#lastActivity = Math.max(this.#lastActivity, at);
    this.#idleSince = null;
  }

  paste(questionIndex, pastedChars) {
    this.activity();
    if (pastedChars < PASTE_MIN_CHARS) return null;
    this.pasteCount += 1;
    return this.#alert('paste', 'paste', this.pasteCount, pastedChars, { question: questionIndex + 1, chars: pastedChars });
  }

  // Called on the page timer: a student who stops typing while the window is open is a different case from one who left.
  tick(at = this.now()) {
    if (this.#awaySince !== null) return null;
    if (at - this.#lastActivity < IDLE_ALERT_MS) return null;
    if (this.#idleSince === this.#lastActivity) return null;
    this.#idleSince = this.#lastActivity;
    return this.#alert('idle', 'idle', this.#lastActivity, Math.round((at - this.#lastActivity) / 1000), {
      minutes: Math.floor((at - this.#lastActivity) / 60000),
    });
  }

  // The client id is what makes a re-send harmless on the server: the same absence can only ever become one row.
  #alert(prefix, rule, index, seconds, payload) {
    const alert = { clientId: `${prefix}-${index}`, rule, seconds, ...payload };
    this.onAlert(alert);
    return alert;
  }
}
