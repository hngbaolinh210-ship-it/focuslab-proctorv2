import { api, escape, download } from './api.js';
import { RULES, csvCell } from './proctoring.js';
import { LETTERS, blankQuestion, parsePaperText, questionsFromRows, rowsFromQuestions, validateRows } from './exam-author.js';

const $ = (root, id) => root.querySelector(`#${id}`);
export const ONLINK_MS = 90000;
export const POLL_GAP_MS = 10000;

// Live presence cannot come from lastSeen alone: a hidden tab still saves about once a minute, so the board
// compares the away counter between two polls instead of trusting the heartbeat.
export function statusOf(attempt, previous, now) {
  if (!attempt) return { tone: 'idle', label: 'Chưa vào làm' };
  if (attempt.submittedAt) return { tone: 'done', label: 'Đã nộp' };
  const elapsed = previous ? Math.max(POLL_GAP_MS, now - previous.at) : 0;
  const awayDelta = previous ? Math.max(0, attempt.tabMs - previous.tabMs) : 0;
  if (awayDelta > elapsed * 0.6) return { tone: 'alert', label: 'Đang rời cửa sổ làm bài' };
  if (now - attempt.lastSeen > ONLINK_MS) return { tone: 'idle', label: 'Thiết bị mất kết nối' };
  if (!attempt.answered) return { tone: 'warn', label: 'Vào làm nhưng chưa trả lời câu nào' };
  return { tone: 'ok', label: `Đang làm ${attempt.answered} câu` };
}

const minutes = ms => `${Math.floor(ms / 60000)}′${String(Math.round(ms / 1000) % 60).padStart(2, '0')}″`;
const clock = at => new Date(at).toLocaleTimeString('vi-VN');

// Staff-only panel: every route it calls is guarded by the same `staff` middleware, so the edit buttons
// never need a second client-side role check.
export function mountExamBoard(root, { roomId, notify }) {
  let tests = [], roster = [], events = [], rows = [], editing = null, detail = null;
  let previous = new Map();

  root.innerHTML = `<h2>Đề thi trên máy &amp; bảng làm bài</h2>
    <p>Giám thị dán đề, mở cho phòng thi và thấy ngay em nào đang làm, em nào rời cửa sổ, em nào chưa vào. Cảnh báo rời cửa sổ, dán bài và ngừng làm cũng chảy vào bảng "Cảnh báo máy chủ" và điện thoại như camera.</p>
    <div class="section-head"><button id="exam-new" class="primary">Soạn đề mới</button><span id="exam-hint"></span></div>
    <section id="exam-editor" class="exam-editor" hidden></section>
    <div id="exam-tests"></div>`;

  function editorHtml() {
    return `<h3>${editing ? 'Sửa đề' : 'Đề mới'}</h3>
      <div class="exam-fields"><label>Tên đề<input id="exam-title" maxlength="120" placeholder="Ví dụ: Kiểm tra buổi 5"/></label>
      <label>Thời lượng (phút)<input id="exam-duration" type="number" min="5" max="240" value="30"/></label></div>
      <label>Dán đề vào đây rồi bấm dịch<em>Mỗi câu một khối, cách nhau một dòng trống. Trắc nghiệm: dòng hỏi, các dòng "A. …", "B. …", rồi "ĐA: B" và "Điểm: 2". Tự luận: thêm dòng "Tự luận: hướng dẫn chấm".</em>
        <textarea id="exam-paste" rows="7" placeholder="Câu 1: Chọn đáp án đúng&#10;A. phương án một&#10;B. phương án hai&#10;ĐA: A&#10;Điểm: 2"></textarea></label>
      <div class="exam-paste-actions"><button id="exam-parse" class="primary">Dịch thành câu hỏi</button><button id="exam-add">Thêm 1 câu trắng</button></div>
      <div id="exam-rows"></div>
      <p id="exam-errors" class="form-error" role="alert"></p>
      <div class="exam-paste-actions"><button id="exam-save" class="primary">Lưu đề (chưa mở cho thí sinh)</button><button id="exam-cancel">Đóng</button></div>`;
  }

  function rowHtml(row, index) {
    const options = row.type === 'mcq' ? `<div class="exam-options-editor">
      ${row.options.map((option, choice) => `<div class="exam-option"><input type="radio" name="key-${index}" value="${choice}" ${row.answer === choice ? 'checked' : ''} title="Đáp án đúng"/>
        <input data-option="${choice}" value="${escape(option)}" placeholder="${LETTERS[choice]}. Phương án ${LETTERS[choice]}"/><button data-drop-option="${choice}" title="Bỏ phương án">×</button></div>`).join('')}
      ${row.options.length < 8 ? '<button data-add-option>Thêm phương án</button>' : ''}
      <small>Bấm chấm tròn để chỉ định đáp án đúng. Máy chủ tự chấm phần trắc nghiệm; câu tự luận giám thị chấm.</small></div>` : '';
    return `<div class="exam-row" data-row="${index}">
      <div class="exam-row-top"><strong>Câu ${index + 1}</strong>
        <select data-field="type"><option value="mcq" ${row.type === 'mcq' ? 'selected' : ''}>Trắc nghiệm</option><option value="text" ${row.type === 'text' ? 'selected' : ''}>Tự luận</option></select>
        <label class="exam-points">Điểm<input type="number" data-field="points" min="1" max="20" value="${row.points}"/></label>
        <span class="exam-row-tools">${index > 0 ? '<button data-up title="Lên trên">↑</button>' : ''}${index < rows.length - 1 ? '<button data-down title="Xuống dưới">↓</button>' : ''}<button data-drop-row>Xóa câu</button></span></div>
      <textarea data-field="text" rows="2" placeholder="Nội dung câu hỏi">${escape(row.text)}</textarea>
      ${row.type === 'text' ? `<input data-field="prompt" value="${escape(row.prompt ?? '')}" placeholder="Hướng dẫn chấm, ví dụ: viết khoảng 30 từ"/>` : options}
    </div>`;
  }

  function paintRows() {
    $(root, 'exam-rows').innerHTML = rows.map(rowHtml).join('') || '<p>Chưa có câu nào. Dán đề hoặc bấm "Thêm 1 câu trắng".</p>';
    $(root, 'exam-hint').textContent = `${rows.length} câu · ${rows.reduce((total, row) => total + (Number(row.points) || 0), 0)} điểm`;
  }

  // The teacher may have typed into the form since the last repaint, so read the DOM back before rebuilding it.
  function collectRows() {
    return [...$(root, 'exam-rows').querySelectorAll('.exam-row')].map((element, index) => {
      const type = element.querySelector('[data-field=type]').value;
      const base = { type, text: element.querySelector('[data-field=text]').value, points: element.querySelector('[data-field=points]').value, index };
      if (type === 'text') return { ...base, prompt: element.querySelector('[data-field=prompt]')?.value ?? '' };
      const checked = element.querySelector(`input[name="key-${index}"]:checked`);
      return { ...base, options: [...element.querySelectorAll('[data-option]')].map(input => input.value), answer: checked ? Number(checked.value) : 0 };
    });
  }

  function openEditor(nextRows, test = null) {
    rows = nextRows;
    editing = test?.id ?? null;
    const editor = $(root, 'exam-editor');
    editor.hidden = false;
    editor.innerHTML = editorHtml();
    if (test) {
      $(root, 'exam-title').value = test.title;
      $(root, 'exam-duration').value = test.durationMinutes;
    }
    paintRows();
    editor.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }

  function closeEditor() {
    rows = [];
    editing = null;
    $(root, 'exam-editor').hidden = true;
    $(root, 'exam-editor').innerHTML = '';
    $(root, 'exam-hint').textContent = '';
  }

  async function savePaper() {
    rows = collectRows();
    const errors = validateRows(rows);
    $(root, 'exam-errors').textContent = errors.map(error => error.message).join(' · ');
    if (errors.length) return;
    const body = { title: $(root, 'exam-title').value.trim(), durationMinutes: Number($(root, 'exam-duration').value), questions: questionsFromRows(rows) };
    try {
      if (editing) await api(`/api/tests/${editing}`, { method: 'PUT', body: JSON.stringify(body) });
      else await api(`/api/rooms/${roomId}/tests`, { method: 'POST', body: JSON.stringify(body) });
      notify('Đã lưu đề. Đề vẫn ở trạng thái chưa mở — bấm "Mở cho thí sinh" khi cả phòng đã vào làm.');
      closeEditor();
      await refresh();
    } catch (error) { $(root, 'exam-errors').textContent = error.message; }
  }

  const actionsHtml = test => `<button data-publish>${test.published ? 'Đóng đề' : 'Mở cho thí sinh'}</button><button data-edit>Sửa đề</button><button data-remove>Xóa</button>
    <button data-detail>${detail?.id === test.id ? 'Ẩn bài làm' : 'Xem bài làm từng em'}</button><button data-csv>Tải kết quả CSV</button>`;

  function testsHtml() {
    if (!tests.length) return '<p class="exam-empty">Chưa có đề nào cho phòng này. Bấm "Soạn đề mới" để dán đề vào.</p>';
    const now = Date.now();
    return tests.map(test => {
      const attempts = test.attempts ?? [];
      const bySeat = new Map(attempts.map(attempt => [attempt.seatId, attempt]));
      const away = attempts.filter(attempt => statusOf(attempt, previous.get(attempt.id), now).tone === 'alert').length;
      const submitted = attempts.filter(attempt => attempt.submittedAt).length;
      return `<article class="exam-test" data-test="${test.id}">
        <div class="section-head"><h3>${escape(test.title)} <span class="pill ${test.published ? 'live' : ''}">${test.published ? 'Đang mở cho thí sinh' : 'Chưa mở'}</span></h3>
          <div class="exam-actions">${actionsHtml(test)}</div></div>
        <p><strong>${attempts.length}/${test.students}</strong> em đã vào làm · <strong>${submitted}</strong> em đã nộp · <strong>${away}</strong> em đang rời cửa sổ. ${test.durationMinutes} phút · ${test.questionCount} câu · ${test.maxPoints} điểm.</p>
        <div class="scroll-table"><table><thead><tr><th>Chỗ</th><th>Học sinh</th><th>Trạng thái</th><th>Đã làm</th><th>Điểm TC</th><th>Rời cửa sổ</th><th>Dán bài</th><th>Lưu cuối</th></tr></thead><tbody>
          ${roster.map(student => {
            const attempt = bySeat.get(student.seat_id);
            const status = statusOf(attempt, previous.get(attempt?.id), now);
            return `<tr class="tone-${status.tone}"><td>${escape(student.seat_id)}</td><td>${escape(student.name)}<small>${escape(student.student_code)}</small></td>
              <td><span class="exam-status ${status.tone}">${status.label}</span></td>
              <td>${attempt ? `${attempt.answered}/${test.questionCount}` : '—'}</td><td>${attempt?.score ?? '—'}</td>
              <td>${attempt ? `${minutes(attempt.tabMs)} · ${attempt.tabEvents} lần` : '—'}</td><td>${attempt?.pasteCount ?? 0}</td>
              <td>${attempt ? clock(attempt.lastSeen) : '—'}</td></tr>`;
          }).join('')}</tbody></table></div>
        ${detail?.id === test.id ? detailHtml(test) : ''}</article>`;
    }).join('');
  }

  // The audit trail the teacher needs as evidence already lives in the events table, so the board filters it
  // by seat instead of asking the server for a second log.
  function auditHtml(seatId) {
    const flagged = events.filter(event => event.seat_id === seatId);
    if (!flagged.length) return '<p class="exam-none">Không có cảnh báo nào cho em này.</p>';
    return `<h5>Nhật ký cảnh báo · ${flagged.length} mốc</h5><ul class="exam-audit">${flagged.map(event => `<li>
      <time>${new Date(event.received_at).toLocaleString('vi-VN')}</time> ${escape(RULES[event.rule]?.label ?? event.rule)}
      <span class="exam-status ${event.risk >= 60 ? 'alert' : event.risk >= 40 ? 'warn' : 'ok'}">${event.risk}/100</span>
      ${event.payload?.duration ? `<small>${Math.round(event.payload.duration)} giây</small>` : ''}</li>`).join('')}</ul>`;
  }

  function detailHtml(test) {
    return `<div class="exam-detail"><h4>Bài làm từng em · ${escape(test.title)}</h4>${detail.attempts.map(attempt => `<details>
      <summary><strong>${escape(attempt.seatId)} ${escape(attempt.name)}</strong> · ${attempt.submittedAt ? `${attempt.score ?? 0}/${attempt.maxPoints ?? 0} điểm` : 'chưa nộp'} · rời cửa sổ ${minutes(attempt.tabMs)} · dán ${attempt.pasteCount} lần</summary>
      <ol class="exam-answer-list">${detail.questions.map((question, index) => {
        const value = attempt.answers[index];
        const blank = value === undefined || value === '';
        const shown = blank ? '<em>bỏ trống</em>' : question.type === 'mcq' ? escape(`${LETTERS[Number(value)] ?? '?'}. ${question.options[Number(value)] ?? value}`) : escape(value);
        const verdict = question.type !== 'mcq' || blank ? '' : Number(value) === question.answer ? ' <b class="exam-right">đúng</b>' : ' <b class="exam-wrong">sai</b>';
        return `<li><strong>Câu ${index + 1}</strong> (${question.points}đ) ${shown}${verdict}</li>`;
      }).join('')}</ol>${auditHtml(attempt.seatId)}</details>`).join('') || '<p>Chưa em nào vào làm đề này.</p>'}</div>`;
  }

  async function loadDetail(testId) {
    const [paper, results] = await Promise.all([api(`/api/tests/${testId}`), api(`/api/tests/${testId}/results`)]);
    detail = { id: testId, questions: paper.questions, attempts: results.attempts };
  }

  function exportCsv(test) {
    if (!detail || detail.id !== test.id) throw new Error('Bấm "Xem bài làm từng em" trước để máy chủ gửi kèm đáp án.');
    const header = ['seat_id', 'student_code', 'name', 'started_at', 'submitted_at', 'score', 'max_points', 'answered', 'away_seconds', 'tab_events', 'paste_count'];
    const keys = detail.questions.map((question, index) => `Câu ${index + 1}${question.type === 'mcq' ? ` (đáp án ${LETTERS[question.answer]})` : ''} (${question.points}đ)`);
    const lines = detail.attempts.map(attempt => [
      attempt.seatId, attempt.studentCode, attempt.name,
      attempt.startedAt ? new Date(attempt.startedAt).toISOString() : '', attempt.submittedAt ? new Date(attempt.submittedAt).toISOString() : '',
      attempt.score ?? '', attempt.maxPoints ?? '', Object.keys(attempt.answers).length, Math.round(attempt.tabMs / 1000), attempt.tabEvents, attempt.pasteCount,
      ...detail.questions.map((question, index) => {
        const value = attempt.answers[index];
        if (value === undefined || value === '') return '';
        return question.type === 'mcq' ? `${LETTERS[Number(value)] ?? value}. ${question.options[Number(value)] ?? ''}` : value;
      })]);
    download(`ket-qua-${test.title.replace(/[\\/:*?"'<>|]+/g, '-').slice(0, 60)}.csv`,
      `\uFEFF${[[...header, ...keys], ...lines].map(row => row.map(csvCell).join(',')).join('\r\n')}`);
  }

  root.addEventListener('click', async event => {
    const target = event.target.closest('button');
    if (!target) return;
    const card = target.closest('[data-test]');
    const test = card ? tests.find(item => item.id === card.dataset.test) : null;
    const rowElement = target.closest('[data-row]');
    const rowIndex = rowElement ? Number(rowElement.dataset.row) : -1;
    try {
      if (target.id === 'exam-new') return openEditor([blankQuestion()]);
      if (target.id === 'exam-cancel') return closeEditor();
      if (target.id === 'exam-add') { rows = collectRows(); rows.push(blankQuestion()); return paintRows(); }
      if (target.id === 'exam-parse') {
        const parsed = parsePaperText($(root, 'exam-paste').value);
        rows = collectRows().concat(parsed.rows);
        $(root, 'exam-errors').textContent = parsed.notes.join(' · ');
        return paintRows();
      }
      if (target.id === 'exam-save') return savePaper();
      if (rowIndex >= 0) {
        rows = collectRows();
        if (target.matches('[data-up],[data-down]')) {
          const to = rowIndex + (target.matches('[data-up]') ? -1 : 1);
          if (rows[to]) [rows[rowIndex], rows[to]] = [rows[to], rows[rowIndex]];
          paintRows();
          return;
        }
        if (target.matches('[data-drop-row]')) { rows.splice(rowIndex, 1); return paintRows(); }
        if (target.matches('[data-add-option]')) { rows[rowIndex].options.push(''); return paintRows(); }
        if (target.matches('[data-drop-option]')) {
          const row = rows[rowIndex], dropped = Number(target.dataset.dropOption);
          row.options.splice(dropped, 1);
          row.answer = Math.min(row.answer, Math.max(0, row.options.length - 1));
          return paintRows();
        }
      }
      if (!test) return;
      if (target.matches('[data-publish]')) {
        await api(`/api/tests/${test.id}/publish`, { method: 'POST', body: JSON.stringify({}) });
        notify(test.published ? 'Đã đóng đề. Thí sinh không vào làm được nữa.' : 'Đã mở đề cho thí sinh trong phòng này.');
        return refresh();
      }
      if (target.matches('[data-edit]')) return openEditor(rowsFromQuestions((await api(`/api/tests/${test.id}`)).questions), test);
      if (target.matches('[data-remove]')) {
        if (!confirm(`Xóa đề "${test.title}"? Bài làm và cảnh báo của đề này sẽ bị xóa theo.`)) return;
        await api(`/api/tests/${test.id}`, { method: 'DELETE' });
        if (detail?.id === test.id) detail = null;
        notify('Đã xóa đề.');
        return refresh();
      }
      if (target.matches('[data-detail]')) {
        if (detail?.id === test.id) { detail = null; return paintTests(); }
        await loadDetail(test.id);
        return paintTests();
      }
      if (target.matches('[data-csv]')) return exportCsv(test);
    } catch (error) { notify(error.message, true); }
  });

  // A <select> never reaches the click handler, and switching a question to tự luận must repaint its body.
  root.addEventListener('change', event => {
    const select = event.target.closest('[data-field=type]');
    if (!select) return;
    rows = collectRows();
    rows[Number(select.closest('[data-row]').dataset.row)].type = select.value;
    paintRows();
  });

  function paintTests() { $(root, 'exam-tests').innerHTML = testsHtml(); }

  async function refresh(room) {
    roster = room?.students ?? roster;
    events = room?.events ?? events;
    tests = await api(`/api/rooms/${roomId}/tests`);
    if (detail && !tests.some(test => test.id === detail.id)) detail = null;
    const now = Date.now();
    const counters = new Map();
    for (const test of tests) for (const attempt of test.attempts ?? []) counters.set(attempt.id, { tabMs: attempt.tabMs, at: now });
    // Keep the older readings only until the trend they belong to goes stale, otherwise a closed attempt
    // would keep the row red forever.
    previous = new Map([...[...previous].filter(([id, seen]) => !counters.has(id) && now - seen.at <= 10 * 60000), ...counters]);
    paintTests();
  }

  return { refresh };
}
