if (location.pathname === '/monitor') await import('./main.js');
else if (location.pathname === '/exam') await import('./exam.js');
else await import('./portal.js');
