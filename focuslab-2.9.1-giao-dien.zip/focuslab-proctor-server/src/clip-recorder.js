export const CLIP_BUFFER_MS = 45000;
export const CLIP_AFTER_MS = 10000;
export const CLIP_MIN_RISK = 50;
export const CLIP_GAP_MS = 30000;
export const CLIP_MAX_BYTES = 25 * 1024 * 1024;

export function pickClipMime(supported) {
  for (const type of ['video/webm;codecs=vp8', 'video/webm', 'video/mp4']) if (supported(type)) return type;
  return null;
}
// A rolling in-memory buffer only: frames older than the window are dropped, so an
// unattended camera never accumulates video and nothing reaches the server unless an
// alert crosses CLIP_MIN_RISK.
export class ClipRecorder {
  constructor({factory, stream, mimeType, onUpload, now = () => Date.now(), bufferMs = CLIP_BUFFER_MS,
    afterMs = CLIP_AFTER_MS, gapMs = CLIP_GAP_MS, maxBytes = CLIP_MAX_BYTES, timesliceMs = 1000}) {
    Object.assign(this, {factory, stream, mimeType, onUpload, now, bufferMs, afterMs, gapMs, maxBytes, timesliceMs});
    this.chunks = []; this.active = null; this.recorder = null; this.lastCaptureAt = -Infinity;
  }
  // Accepts the camera MediaStream, or the <video> element for IP camera and file sources,
  // where the only way to reach frames is the element's own capture stream.
  static forBrowser(source, options = {}) {
    const Recorder = options.Recorder ?? globalThis.MediaRecorder;
    const stream = typeof source?.getVideoTracks === 'function' ? source
      : source?.captureStream?.() ?? source?.mozCaptureStream?.() ?? null;
    if (!Recorder || typeof stream?.getVideoTracks !== 'function') return null;
    const mimeType = pickClipMime(type => Recorder.isTypeSupported?.(type) ?? false);
    if (!mimeType) return null;
    return new ClipRecorder({...options, stream, mimeType, factory: (src, type) => new Recorder(src, {mimeType: type})});
  }
  get armed() { return this.active !== null; }
  start() {
    if (this.recorder || !this.factory || !this.stream) return false;
    this.recorder = this.factory(this.stream, this.mimeType);
    this.recorder.ondataavailable = event => this.push(event.data, this.now());
    this.recorder.start(this.timesliceMs);
    return true;
  }
  push(data, at) {
    if (!data || !data.size) return;
    this.chunks.push({blob: data, at});
    while (at - this.chunks[0].at > this.bufferMs) this.chunks.shift();
  }
  capture(event, at = this.now()) {
    if (this.active || !this.chunks.length || at - this.lastCaptureAt < this.gapMs) return false;
    this.lastCaptureAt = at;
    this.active = {event, head: this.chunks.slice(), deadline: at + this.afterMs};
    return true;
  }
  // Called from the analysis loop; assembles the clip once the post-alert window closes.
  tick(at = this.now()) {
    if (!this.active || at < this.active.deadline) return null;
    const {event, head} = this.active; this.active = null;
    const parts = [...head, ...this.chunks.filter(chunk => !head.includes(chunk))].map(chunk => chunk.blob);
    const bytes = parts.reduce((total, blob) => total + blob.size, 0);
    if (!parts.length) return null;
    const clip = {event, bytes};
    if (bytes > this.maxBytes) clip.error = 'QUA_LARGE';
    else clip.blob = new Blob(parts, {type: this.mimeType.split(';')[0]});
    this.onUpload(clip);
    return clip;
  }
  stop() {
    this.recorder?.stop();
    this.recorder = null; this.chunks = []; this.active = null;
  }
}
