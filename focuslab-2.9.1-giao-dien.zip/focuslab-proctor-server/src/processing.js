export function mobileDevice(navigatorInfo = {}, coarsePointer = false) {
  return /Android|iPhone|iPad|iPod/i.test(navigatorInfo.userAgent || '') ||
    (coarsePointer && Number(navigatorInfo.maxTouchPoints) > 0);
}

export function processingProfile(mode, mobile, seatCount) {
  const lightweight = mode === 'light' || (mode === 'auto' && mobile);
  return {
    lightweight,
    width: lightweight ? 640 : 1280,
    height: lightweight ? 480 : 720,
    frameRate: lightweight ? 24 : 30,
    analysisSide: lightweight ? 640 : 1280,
    frameInterval: lightweight ? 250 : 200,
    maxFaces: Math.min(100, Math.max(1, Number(seatCount) || 1) + 1),
  };
}

// Preserve source aspect ratio so normalized landmarks and seat regions agree.
export function fitFrame(width, height, maxSide) {
  if (!(width > 0 && height > 0 && maxSide > 0)) return null;
  const scale = Math.min(1, maxSide / Math.max(width, height));
  return {width: Math.max(1, Math.round(width * scale)), height: Math.max(1, Math.round(height * scale))};
}
