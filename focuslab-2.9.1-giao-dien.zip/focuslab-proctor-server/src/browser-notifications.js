const base64UrlToBytes = value => {
  const binary = atob(String(value).replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(String(value).length / 4) * 4, '='));
  return Uint8Array.from(binary, character => character.charCodeAt(0));
};
// Web Push wakes the phone through the browser's push service, so alerts arrive with every tab closed.
export async function enablePhonePush(browser = window, { getKey = async () => '', save = async () => {} } = {}) {
  if (!browser.isSecureContext || !browser.Notification || !browser.navigator?.serviceWorker || !browser.PushManager) return 'unsupported';
  const permission = await browser.Notification.requestPermission();
  if (permission !== 'granted') return permission;
  const registration = await browser.navigator.serviceWorker.register('/notification-sw.js');
  await (browser.navigator.serviceWorker.ready ?? Promise.resolve(registration));
  const publicKey = await getKey();
  if (!publicKey) return 'no-key';
  const manager = registration.pushManager;
  const subscription = (await manager.getSubscription?.()) ?? await manager.subscribe({ userVisibleOnly: true, applicationServerKey: base64UrlToBytes(publicKey) });
  if (!subscription) return 'no-subscription';
  await save(subscription.toJSON?.() ?? subscription);
  browser.localStorage.setItem('focuslab-phone-push', 'enabled');
  return 'granted';
}
