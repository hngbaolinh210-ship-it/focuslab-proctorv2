import test from 'node:test';
import assert from 'node:assert/strict';
import {mobileDevice, processingProfile, fitFrame} from './processing.js';
import {mouthAspectRatio} from './proctoring.js';

test('automatic light mode recognizes Android and touch tablets; desktop can opt in',()=>{
  assert.equal(mobileDevice({userAgent:'Mozilla/5.0 (Linux; Android 14)',maxTouchPoints:5}),true);
  assert.equal(mobileDevice({userAgent:'Macintosh',maxTouchPoints:5},true),true);
  assert.equal(mobileDevice({userAgent:'Windows NT',maxTouchPoints:0},false),false);
  assert.equal(processingProfile('light',false,1).lightweight,true);
  assert.equal(processingProfile('standard',true,1).lightweight,false);
});

test('light mode does not silently drop classroom seats or disable the extra-face rule',()=>{
  const one=processingProfile('auto',true,1);
  assert.equal(one.maxFaces,2);
  assert.ok(one.width<=640&&one.height<=480);
  const hundred=processingProfile('auto',true,100);
  assert.equal(hundred.maxFaces,100);
  assert.equal(processingProfile('standard',false,3).maxFaces,4);
});

test('resized portrait/landscape frames retain mouth geometry and do not upscale',()=>{
  const points=Array.from({length:468},()=>({x:0,y:0}));
  points[78]={x:.3,y:.5};points[308]={x:.7,y:.5};points[13]={x:.5,y:.45};points[14]={x:.5,y:.55};
  for(const [width,height] of [[1920,1080],[1080,1920]]){
    const resized=fitFrame(width,height,640);
    assert.ok(Math.max(resized.width,resized.height)<=640);
    assert.equal(mouthAspectRatio(points,width,height),mouthAspectRatio(points,resized.width,resized.height));
  }
  assert.deepEqual(fitFrame(320,240,640),{width:320,height:240});
  assert.equal(fitFrame(0,720,640),null);
});
