// Teachers write exam papers as text, not as JSON. This turns a pasted Vietnamese paper into editor rows and
// back, and validates with the same limits the server applies, so a save is never rejected for a surprise reason.

export const MAX_QUESTIONS = 100;
export const MAX_TEXT = 4000;
export const LETTERS = 'ABCDEFGH';

// Marker words are matched with the accents removed, so "ĐA", "Đáp án", "dap an" and "đáp án đúng" all work.
// Đ has no accent to strip, so the case fold has to happen before the letters are compared.
const plain = value => String(value ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/đ/g, 'd');
// "Câu 1:", "Câu 3." and "2)" are labels; "Ca múa…" is a question that simply starts with those letters.
const leadingNumber = line => line.replace(/^\s*(?:c[aâ]u\s*(?:\d+\s*[:.)-]?|[:.)-])\s*|\d+\s*[.)]\s*)/i, '').trim();
// Removing a marker word by accent-insensitive tokens keeps the rest of the line exactly as typed, which a
// regex on "tự luận" cannot do: ự and ậ are their own code points, not ư/â plus a modifier.
const stripWords = (line, words) => {
  const parts = line.trim().split(/\s+/);
  let used = 0;
  while (used < words.length && used < parts.length && plain(parts[used].replace(/[:.,;]+$/, '')) === words[used]) used += 1;
  // Only drop the marker when the whole phrase was found, so a question starting with "Tự" keeps its wording.
  return used === words.length ? parts.slice(used).join(' ') : line.trim();
};

export const blankQuestion = (type = 'mcq') => type === 'text'
  ? { type: 'text', text: '', prompt: '', points: 5 }
  : { type: 'mcq', text: '', options: ['', '', '', ''], answer: 0, points: 2 };

export function rowsFromQuestions(questions) {
  return questions.map(q => q.type === 'mcq'
    ? { type: 'mcq', text: q.text, options: [...q.options], answer: q.answer, points: q.points }
    : { type: 'text', text: q.text, prompt: q.prompt ?? '', points: q.points });
}

export function questionsFromRows(rows) {
  return rows.map(row => row.type === 'mcq'
    ? { type: 'mcq', text: String(row.text ?? '').trim(), options: (row.options ?? []).map(o => String(o).trim()), answer: Number(row.answer), points: Number(row.points) }
    : { type: 'text', text: String(row.text ?? '').trim(), prompt: String(row.prompt ?? '').trim(), points: Number(row.points) });
}

export function validateRows(rows) {
  const errors = [];
  if (!rows.length) errors.push({ index: -1, message: 'Đề thi cần ít nhất 1 câu.' });
  if (rows.length > MAX_QUESTIONS) errors.push({ index: -1, message: `Một đề tối đa ${MAX_QUESTIONS} câu.` });
  rows.forEach((row, index) => {
    const label = `Câu ${index + 1}`;
    const text = String(row.text ?? '').trim();
    if (!text) errors.push({ index, message: `${label}: thiếu nội dung câu hỏi.` });
    else if (text.length > MAX_TEXT) errors.push({ index, message: `${label}: nội dung dài quá ${MAX_TEXT} ký tự.` });
    const points = Math.round(Number(row.points));
    if (!Number.isInteger(points) || points < 1 || points > 20) errors.push({ index, message: `${label}: điểm cần là số nguyên từ 1 đến 20.` });
    if (row.type !== 'mcq' && row.type !== 'text') errors.push({ index, message: `${label}: chưa chọn loại câu.` });
    if (row.type === 'mcq') {
      const options = (row.options ?? []).map(o => String(o ?? '').trim());
      if (options.length < 2) errors.push({ index, message: `${label}: trắc nghiệm cần ít nhất 2 phương án.` });
      if (options.length > 8) errors.push({ index, message: `${label}: tối đa 8 phương án.` });
      if (options.some(o => !o)) errors.push({ index, message: `${label}: có phương án đang để trống.` });
      const answer = Number(row.answer);
      if (!Number.isInteger(answer) || answer < 0 || answer >= options.length) errors.push({ index, message: `${label}: đáp án đúng phải là một phương án có trong câu.` });
    }
  });
  return errors;
}

export function parsePaperText(input) {
  const rows = [], notes = [];
  for (const block of String(input ?? '').split(/\n\s*\n/).map(b => b.trim()).filter(Boolean)) {
    const row = blankQuestion();
    const slots = [];
    let answerLetter = null, seenText = false;
    for (const raw of block.split('\n')) {
      const line = raw.trim();
      if (!line) continue;
      const tag = plain(line).replace(/[:=.]/g, ' ').replace(/\s+/g, ' ').trim();
      const points = /^diem (\d{1,2})$/.exec(tag), letter = /^(?:da|dap an|dap an dung|true|correct) ([a-h])$/.exec(tag),
        numbered = /^(?:da|dap an|dap an dung|true|correct) (\d\d?)$/.exec(tag);
      if (/^[a-h][.)]/i.test(line)) { slots[LETTERS.indexOf(line[0].toUpperCase())] = line.slice(2).trim(); continue; }
      if (/^tu luan( .*)?$/.test(tag)) { row.type = 'text'; row.prompt = stripWords(line, ['tu', 'luan']); continue; }
      if (points) { row.points = Number(points[1]); continue; }
      if (letter) { answerLetter = letter[1].toUpperCase(); continue; }
      if (numbered) { answerLetter = LETTERS[Number(numbered[1]) - 1] ?? null; continue; }
      if (!seenText) { row.text = leadingNumber(line); seenText = true; continue; }
      row.text = `${row.text}\n${line}`;
    }
    // A pasted Word paper keeps its page breaks ("---", "==="), which are not questions.
    if (!seenText || !row.text || !/[\p{L}\p{N}]/u.test(row.text)) { notes.push(`Bỏ qua một khối không có nội dung câu hỏi: "${block.slice(0, 40)}"`); continue; }
    if (row.type === 'mcq') {
      row.options = slots.filter(slot => slot);
      if (row.options.length < 2) {
        row.type = 'text';
        row.prompt = '';
        notes.push(`Câu "${row.text.slice(0, 30)}" không có phương án A, B nên thành câu tự luận.`);
      } else {
        const letterIndex = answerLetter === null ? -1 : LETTERS.indexOf(answerLetter);
        const marked = letterIndex >= 0 ? slots[letterIndex] : '';
        if (marked && row.options.includes(marked)) row.answer = row.options.indexOf(marked);
        else notes.push(`Câu "${row.text.slice(0, 30)}": ${answerLetter ? `đáp án ${answerLetter} không khớp phương án nào` : 'chưa ghi dòng "ĐA: …"'} nên tạm chọn phương án đầu. Kiểm tra lại trước khi mở đề.`);
      }
    }
    // One canonical shape per type, so an editor row never carries an empty option list from the wrong template.
    rows.push(row.type === 'mcq'
      ? { type: 'mcq', text: row.text, options: row.options, answer: row.answer, points: row.points }
      : { type: 'text', text: row.text, prompt: row.prompt, points: row.points });
  }
  return { rows, notes };
}

export function paperTextFromRows(rows) {
  return rows.map(row => row.type === 'mcq'
    ? [`Câu: ${row.text}`, ...row.options.map((o, i) => `${LETTERS[i]}. ${o}`), `ĐA: ${LETTERS[row.answer] ?? 'A'}`, `Điểm: ${row.points}`].join('\n')
    : [`Câu: ${row.text}`, `Tự luận${row.prompt ? `: ${row.prompt}` : ''}`, `Điểm: ${row.points}`].join('\n')).join('\n\n');
}
