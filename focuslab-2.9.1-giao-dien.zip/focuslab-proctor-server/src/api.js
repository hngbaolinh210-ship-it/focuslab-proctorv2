export async function api(url,options={}) {
  const response=await fetch(url,{credentials:'same-origin',...options,headers:options.body instanceof FormData?options.headers:{'Content-Type':'application/json',...options.headers}});
  const data=await response.json().catch(()=>({error:'Máy chủ trả về dữ liệu không hợp lệ.'}));
  if(!response.ok){const error=new Error(data.error||'Yêu cầu thất bại.');error.status=response.status;throw error;}return data;
}
export const post=(url,data)=>api(url,{method:'POST',body:JSON.stringify(data)});
export async function sendBlob(url,blob) {
  const response=await fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':blob.type||'application/octet-stream'},body:blob});
  if(response.ok)return response.json();
  const data=await response.json().catch(()=>({error:'Máy chủ trả về dữ liệu không hợp lệ.'}));
  const error=new Error(data.error||'Không gửi được clip.');error.status=response.status;throw error;
}
export const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function download(name,text,type='text/csv;charset=utf-8;') {const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
