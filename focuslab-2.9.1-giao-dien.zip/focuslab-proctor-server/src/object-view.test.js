import test from 'node:test';
import assert from 'node:assert/strict';
import {objectRegion,projectObjects,forbiddenObjects,objectsAreFresh,padRegion,scanTargets,scanWindowMs,collectScans} from './object-view.js';
import {assignToSeats, makeSeats} from './proctoring.js';
test('center scan maps detections back into the correct full-frame seat',()=>{
 const raw=[{classId:67,box:{x:.8,y:.2,width:.1,height:.1}}];
 const projected=projectObjects(raw,objectRegion('center'));
 const seats=[{id:'left',region:{x:0,y:0,width:.5,height:1}},{id:'right',region:{x:.5,y:0,width:.5,height:1}}];
 const result=assignToSeats(seats,[],projected);
 assert.equal(result.assigned.get('left').objects.length,0);assert.equal(result.assigned.get('right').objects.length,1);
 assert.equal(projected[0].box.x,.65);assert.equal(projected[0].box.width,.05);
 assert.deepEqual(projectObjects(raw,objectRegion('full')),raw);
});
test('allowed books remain visible while excluded from risk input',()=>{
 const objects=[{classId:73},{classId:67}];
 assert.deepEqual(forbiddenObjects(objects,true),[{classId:67}]);
 assert.deepEqual(forbiddenObjects(objects,false),objects);assert.equal(objects.length,2);
});
test('slow inference must not become a fresh live observation on completion',()=>{
 assert.equal(objectsAreFresh(100,3100),true);assert.equal(objectsAreFresh(100,3101),false);
 assert.equal(objectsAreFresh(-Infinity,5000),false);assert.equal(objectsAreFresh(200,100),false);
});
test('seat crops stay inside the frame and keep the desk area',()=>{
 const crop=padRegion({x:.5,y:.5,width:.2,height:.2},.12);
 assert.ok(Math.abs(crop.width-.224)<1e-9&&Math.abs(crop.height-.224)<1e-9);
 assert.ok(Math.abs(crop.x-.488)<1e-9&&Math.abs(crop.y-.488)<1e-9);
 const edge=padRegion({x:0,y:.8,width:.4,height:.4},.12);
 assert.equal(edge.x,0);assert.equal(edge.width,edge.height);
 assert.ok(edge.y+edge.height<=1&&edge.y<=.8&&edge.width>.4);
 assert.deepEqual(padRegion({x:0,y:0,width:1,height:1}),{x:0,y:0,width:1,height:1});
});
test('rotation scans each seat crop once then the whole frame',()=>{
 const seats=makeSeats(3);const targets=scanTargets(seats);
 assert.deepEqual(targets.map(t=>t.key),['S01','S02','S03','full']);
 assert.deepEqual(targets[3].region,{x:0,y:0,width:1,height:1});
 assert.equal(targets[0].region.width,seats[0].region.width*1.12);
 assert.equal(scanTargets(makeSeats(30)).length,13);
});
test('a result stays usable until that target is scanned again',()=>{
 assert.equal(scanWindowMs(1),3000);assert.equal(scanWindowMs(5),6500);
 const scans=new Map([['S01',{capturedAt:1000,objects:[{label:'Điện thoại'}]}],['full',{capturedAt:5800,objects:[{label:'Sách'}]}]]);
 assert.deepEqual(collectScans(scans,6000,scanWindowMs(5)),[{label:'Điện thoại'},{label:'Sách'}]);
 assert.deepEqual(collectScans(scans,6000,3000),[{label:'Sách'}]);
 assert.deepEqual([...scans.keys()],['full']);
 assert.deepEqual(collectScans(new Map([['S01',{capturedAt:7000,objects:[{label:'Sách'}]}]]),6000,3000),[]);
});
