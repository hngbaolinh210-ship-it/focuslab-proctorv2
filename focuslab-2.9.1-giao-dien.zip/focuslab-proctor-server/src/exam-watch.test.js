import test from 'node:test';
import assert from 'node:assert/strict';
import { IntegrityWatch, TAB_ALERT_MS, PASTE_MIN_CHARS, IDLE_ALERT_MS } from './exam-watch.js';

const clock = () => { let now = 1_000_000; return { now: () => now, advance: ms => { now += ms; return now; } }; };
const watch = () => { const t = clock(), alerts = [], w = new IntegrityWatch({ now: t.now, onAlert: a => alerts.push(a) }); return { t, w, alerts }; };

test('a short alt-tab is counted but never announced', () => {
  const { t, w, alerts } = watch();
  assert.equal(w.setVisible({ blurred: true }), null);
  t.advance(4000);
  assert.equal(w.awayMs, 4000, 'time away is still reported to the server');
  assert.equal(w.setVisible({}), null);
  assert.equal(w.tabEvents, 1);
  assert.deepEqual(alerts, []);
});

test('leaving the exam window is announced once, with a stable id', () => {
  const { t, w, alerts } = watch();
  w.setVisible({ hidden: true });
  t.advance(TAB_ALERT_MS + 6000);
  assert.equal(w.awayMs, TAB_ALERT_MS + 6000);
  const alert = w.setVisible({});
  assert.equal(alert.rule, 'tab_left');
  assert.equal(alert.clientId, 'tab-1');
  assert.equal(alert.seconds, Math.round((TAB_ALERT_MS + 6000) / 1000));
  assert.equal(alerts.length, 1);
  // A second absence becomes a second row, never an edit of the first one.
  w.setVisible({ hidden: true });
  t.advance(40000);
  assert.equal(w.setVisible({}).clientId, 'tab-2');
  assert.equal(alerts.length, 2);
});

test('both ways of losing the window count as one absence', () => {
  const { t, w, alerts } = watch();
  w.setVisible({ blurred: true });
  w.setVisible({ blurred: true, hidden: true });
  t.advance(20000);
  w.setVisible({ hidden: true });
  assert.equal(w.awayMs, 20000, 'overlapping signals must not double-count the same absence');
  assert.equal(w.setVisible({}).clientId, 'tab-1');
  assert.equal(alerts.length, 1);
});

test('bulk paste is a signal, typing is not', () => {
  const { w, alerts } = watch();
  assert.equal(w.paste(0, 3), null, 'a couple of characters is a normal edit');
  assert.equal(w.paste(0, PASTE_MIN_CHARS - 1), null);
  const alert = w.paste(2, 180);
  assert.equal(alert.rule, 'paste');
  assert.equal(alert.question, 3, 'the invigilator needs the question number, not the text');
  assert.equal(alert.clientId, 'paste-1');
  assert.equal(w.paste(2, 90).clientId, 'paste-2');
  assert.equal(alerts.length, 2);
  assert.equal(w.pasteCount, 2);
});

test('silence at the desk is announced once per idle period', () => {
  const { t, w, alerts } = watch();
  assert.equal(w.tick(t.now()), null);
  t.advance(IDLE_ALERT_MS + 1000);
  const first = w.tick(t.now());
  assert.equal(first.rule, 'idle');
  assert.equal(first.minutes, 3);
  assert.equal(w.tick(t.now()), null, 'the same silence is not pushed again every minute');
  assert.equal(w.tick(t.now() + 60000), null);
  // While the student is away the page already says why nothing is happening.
  w.setVisible({ hidden: true });
  t.advance(IDLE_ALERT_MS);
  assert.equal(w.tick(t.now()), null);
  assert.equal(alerts.filter(a => a.rule === 'idle').length, 1);
  assert.equal(alerts.length, 1);
});

test('a reload continues the same absence numbering', () => {
  const { t, w } = watch();
  w.restore({ tabMs: 70000, tabEvents: 4, pasteCount: 2 });
  assert.equal(w.awayMs, 70000);
  w.setVisible({ hidden: true });
  t.advance(30000);
  assert.equal(w.awayMs, 100000, 'time already stored on the server is not counted twice');
  assert.equal(w.setVisible({}).clientId, 'tab-5', 'the fifth absence stays the fifth');
  assert.equal(w.paste(0, 40).clientId, 'paste-3');
  // The server value is the one that gets restored, so a fresh page opens where the old one left off.
  const fresh = new IntegrityWatch({ now: t.now });
  fresh.restore({ tabMs: 100000, tabEvents: 5, pasteCount: 3 });
  fresh.setVisible({ hidden: true });
  t.advance(20000);
  assert.equal(fresh.awayMs, 120000);
  assert.equal(fresh.setVisible({}).clientId, 'tab-6');
});

test('coming back restarts the idle clock', () => {
  const { t, w, alerts } = watch();
  t.advance(IDLE_ALERT_MS - 1000);
  w.activity(t.now());
  t.advance(IDLE_ALERT_MS - 1000);
  assert.equal(w.tick(t.now()), null, 'only two minutes have passed since the last keystroke');
  t.advance(2000);
  assert.equal(w.tick(t.now()).rule, 'idle');
  assert.equal(alerts.length, 1);
});
