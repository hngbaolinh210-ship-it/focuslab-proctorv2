import test from 'node:test';
import assert from 'node:assert/strict';
import { POLL_GAP_MS, ONLINK_MS, statusOf } from './exam-board.js';

const NOW = 1_700_000_000_000;
const attempt = (fields = {}) => ({ id: 'a1', submittedAt: null, lastSeen: NOW - 5000, answered: 4, tabMs: 20000, ...fields });
const seen = (tabMs, ago) => ({ tabMs, at: NOW - ago });

test('the board tells apart "never came" from "submitted"', () => {
  assert.equal(statusOf(null, undefined, NOW).tone, 'idle');
  assert.equal(statusOf(attempt({ submittedAt: NOW - 60000 }), undefined, NOW).tone, 'done');
});

test('a first poll cannot call anyone absent', () => {
  // Without an earlier reading there is no trend, and a red row the teacher acts on must be a real one.
  const status = statusOf(attempt({ tabMs: 400000 }), undefined, NOW);
  assert.notEqual(status.tone, 'alert');
});

test('the away counter growing across most of the gap turns the row red', () => {
  const status = statusOf(attempt({ tabMs: 26000 }), seen(5000, POLL_GAP_MS), NOW);
  assert.equal(status.tone, 'alert');
  assert.match(status.label, /rời cửa sổ/);
  // A student who left once long ago and is back to typing stays green.
  assert.equal(statusOf(attempt({ tabMs: 26000 }), seen(26000, POLL_GAP_MS), NOW).tone, 'ok');
});

test('silence is an offline device, not a cheating student', () => {
  const status = statusOf(attempt({ lastSeen: NOW - ONLINK_MS - 1 }), seen(20000, POLL_GAP_MS), NOW);
  assert.equal(status.tone, 'idle');
  assert.match(status.label, /mất kết nối/);
});

test('opened the paper but typed nothing is worth a second look', () => {
  assert.equal(statusOf(attempt({ answered: 0 }), seen(20000, POLL_GAP_MS), NOW).tone, 'warn');
});
