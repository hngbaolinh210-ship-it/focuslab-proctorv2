import test from 'node:test';
import assert from 'node:assert/strict';
import { enablePhonePush } from './browser-notifications.js';

function fixture({ permission = 'granted', secure = true, pushManager = true, existing = null } = {}) {
  const values = new Map(), calls = [], saved = [];
  const manager = pushManager ? {
    async getSubscription() { calls.push(['getSubscription']); return existing; },
    async subscribe(options) { calls.push(['subscribe', options]); return { toJSON: () => ({ endpoint: 'https://push.example.com/p/synthetic', keys: { p256dh: 'Bsynthetic', auth: 'c3ludGhldGlj' } }) }; },
  } : undefined;
  const registration = { pushManager: manager };
  const browser = {
    isSecureContext: secure,
    PushManager: pushManager ? {} : undefined,
    Notification: { permission, async requestPermission() { return permission; } },
    localStorage: { getItem: key => values.get(key), setItem: (key, value) => values.set(key, value) },
    navigator: { serviceWorker: { async register(url) { calls.push(['register', url]); return registration; }, ready: Promise.resolve(registration) } },
  };
  const options = { getKey: async () => 'BH9A7cQ_zl4rN2VRi2zbNE6AOFg8cEVSsIdt60b5n6-WMKRwyrsHD51EfNSR7wel_FH_--p1TlOpAozVT3hBvzI', save: async body => { saved.push(body); } };
  return { browser, options, calls, saved, values };
}

test('a supervisor phone is subscribed once and registered with the server', async () => {
  const { browser, options, calls, saved, values } = fixture();
  assert.equal(await enablePhonePush(browser, options), 'granted');
  assert.deepEqual(calls.map(call => call[0]), ['register', 'getSubscription', 'subscribe']);
  const subscribe = calls[2][1];
  assert.equal(subscribe.userVisibleOnly, true);
  assert.ok(subscribe.applicationServerKey instanceof Uint8Array);
  assert.deepEqual(saved, [{ endpoint: 'https://push.example.com/p/synthetic', keys: { p256dh: 'Bsynthetic', auth: 'c3ludGhldGlj' } }]);
  assert.equal(values.get('focuslab-phone-push'), 'enabled');
});
test('an existing subscription is re-registered instead of creating a second device', async () => {
  const existing = { toJSON: () => ({ endpoint: 'https://push.example.com/p/old', keys: { p256dh: 'Bold', auth: 'b2xk' } }) };
  const { browser, options, calls, saved } = fixture({ existing });
  assert.equal(await enablePhonePush(browser, options), 'granted');
  assert.deepEqual(calls.map(call => call[0]), ['register', 'getSubscription']);
  assert.equal(saved[0].endpoint, 'https://push.example.com/p/old');
});
test('refused permission and unsupported browsers never contact the server', async () => {
  const denied = fixture({ permission: 'denied' });
  assert.equal(await enablePhonePush(denied.browser, denied.options), 'denied');
  assert.deepEqual(denied.calls, []);
  const insecure = fixture({ secure: false });
  assert.equal(await enablePhonePush(insecure.browser, insecure.options), 'unsupported');
  const noManager = fixture({ pushManager: false });
  assert.equal(await enablePhonePush(noManager.browser, noManager.options), 'unsupported');
  assert.deepEqual(noManager.saved, []);
});
test('a server without a VAPID key stops before subscribing', async () => {
  const { browser, calls, saved } = fixture();
  assert.equal(await enablePhonePush(browser, { getKey: async () => '', save: async () => {} }), 'no-key');
  assert.deepEqual(calls.map(call => call[0]), ['register']);
  assert.deepEqual(saved, []);
});
