import './style.css';
import './portal.css';
import './exam.css';
import { api, post, escape } from './api.js';
import { RULES } from './proctoring.js';
import { IntegrityWatch } from './exam-watch.js';

const $ = id => document.getElementById(id);
const AUTOSAVE_MS = 5000, TEXT_MAX = 3000;
let me, paper, questions = [], watch, deadline = null, stops = [], savedAnswers = '{}', frozen = false, atBell = () => {}, current = 0, answersStore = {}, camera = null;

function notice(text, error = false) { const box = $('portal-message'); box.textContent = text; box.classList.toggle('error', error); }
function stopTimers() { for (const stop of stops) stop(); stops = []; }
const sumPoints = onlyMcq => questions.reduce((total, q) => total + (!onlyMcq || q.type === 'mcq' ? q.points : 0), 0);
const stored = () => paper.attempt?.answers ?? {};
// The server keeps option indexes as numbers and the form gives strings back, so equality needs one shape.
const fingerprint = answers => JSON.stringify(Object.fromEntries(Object.entries(answers).map(([index, value]) => [index, String(value)])));

// Trang làm bài hiển thị từng câu một, nên câu trả lời phải nằm trong bộ nhớ của trang, không nằm trong ô nhập.
// Lần đọc nào cũng gom ô đang hiển thị vào store trước, vì vậy không bao giờ mất chữ em vừa gõ khi sang câu khác.
function flush() {
  const q = questions[current];
  if (!q || !$('paper')) return;
  const value = q.type === 'mcq' ? document.querySelector(`input[name="q${current}"]:checked`)?.value : $(`answer-${current}`)?.value.trim();
  if (value) answersStore[current] = value; else delete answersStore[current];
}
function collect() {
  flush();
  return answersStore;
}

// The browser cannot prove what a student opened elsewhere; it only proves the paper lost the screen.
// A lost connection must never cost a student the answers they already typed, so the page keeps a local copy too.
const draftKey = () => `focuslab-exam-${paper.id}-${me?.student?.id ?? 'anon'}`;
function writeDraft() { try { localStorage.setItem(draftKey(), JSON.stringify({ at: Date.now(), answers: collect() })); } catch { /* no storage: the server copy is still the one that counts */ } }
function readDraft() {
  try {
    const saved = JSON.parse(localStorage.getItem(draftKey()) ?? 'null');
    return saved && saved.answers && typeof saved.answers === 'object' ? saved : null;
  } catch { return null; }
}
function clearDraft() { try { localStorage.removeItem(draftKey()); } catch { /* nothing to clean */ } }

function applyAnswers(from) {
  flush();
  answersStore = { ...answersStore, ...Object.fromEntries(Object.entries(from).filter(([index]) => questions[Number(index)])) };
  renderQuestion();
  paintNav();
}

function offerRestore(draft) {
  const local = Object.keys(draft.answers).length, onServer = Object.keys(stored()).length;
  if (local <= onServer) return;
  const bar = document.createElement('div');
  bar.className = 'exam-offline';
  bar.innerHTML = `<span>Máy tính này còn giữ bản nháp <strong>${local} câu</strong> (lúc ${escape(new Date(draft.at).toLocaleTimeString('vi-VN'))}), máy chủ chỉ có ${onServer} câu.</span><button type="button">Khôi phục bản nháp</button><button type="button" data-dismiss>Bỏ qua</button>`;
  $('content').prepend(bar);
  bar.querySelector('button').onclick = () => { applyAnswers(draft.answers); watch.activity(); void save(); bar.remove(); };
  bar.querySelector('[data-dismiss]').onclick = () => bar.remove();
}

async function report(alert) {
  const rule = RULES[alert.rule], time = new Date().toISOString();
  notice(`Đã báo giám thị: ${rule.label}${alert.question ? ` ở câu ${alert.question}` : ''}${alert.seconds ? ` · ${alert.seconds} giây` : ''}.`);
  try {
    await api(`/api/rooms/${me.roomId}/events`, { method: 'POST', body: JSON.stringify({ events: [{
      clientId: alert.clientId, rule: alert.rule, risk: rule.risk, seatId: me.student.seat_id,
      duration: alert.seconds, time, resolved: time, offset: null }] }) });
  } catch (error) { notice(`Không gửi được cảnh báo (${error.message}). Thời gian rời cửa sổ vẫn lưu cùng bài làm.`, true); }
}

async function save({ keepalive = false } = {}) {
  const answers = collect();
  writeDraft();
  const body = `{"answers":${JSON.stringify(answers)},"tabMs":${Math.round(watch?.awayMs ?? 0)},"tabEvents":${watch?.tabEvents ?? 0},"pasteCount":${watch?.pasteCount ?? 0}}`;
  if (keepalive) { fetch(`/api/exams/${paper.id}/save`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => {}); return; }
  try {
    const result = await api(`/api/exams/${paper.id}/save`, { method: 'POST', body });
    savedAnswers = fingerprint(answers);
    setDeadline(result.remainingSeconds);
    const state = $('save-state');
    if (state) state.textContent = `Đã lưu lúc ${new Date().toLocaleTimeString('vi-VN')} · ${Object.keys(collect()).length}/${questions.length} câu`;
  } catch (error) {
    if (error.status === 409) return freeze(error.message);
    notice(`Mất kết nối với máy chủ (${error.message}). Bài vẫn lưu trên máy này và trang sẽ tự gửi lại khi mạng về.`, true);
  }
}

function setDeadline(seconds) {
  if (!Number.isFinite(seconds)) return;
  deadline = Date.now() + seconds * 1000;
  paintClock();
}

function paintClock() {
  const clock = $('exam-clock');
  if (!clock || deadline === null) return;
  const seconds = Math.max(0, Math.round((deadline - Date.now()) / 1000));
  clock.textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  clock.classList.toggle('urgent', seconds <= 120);
  if (!seconds && !frozen) void atBell();
}

// The bell is the server's clock. This page only stops the pen, then asks the server to grade what is saved.
async function runOut() {
  freeze('Hết thời gian làm bài. Những câu đã lưu vẫn được máy chủ chấm.');
  try { await api(`/api/exams/${paper.id}/submit`, { method: 'POST', body: JSON.stringify({}) }); } catch { /* the server grades the saved work when the board reads it */ }
  await load(paper.id);
}

function freeze(message) {
  if (frozen) return;
  frozen = true;
  stopTimers();
  document.querySelectorAll('#paper input,#paper textarea,#submit').forEach(field => { field.disabled = true; });
  notice(message, true);
}

// Lưới câu hỏi bên phải: xanh có dấu tích = đã trả lời, đỏ = chưa làm, khoanh đậm = câu đang hiển thị.
function paintNav() {
  const done = collect();
  $('exam-chips').innerHTML = questions.map((q, index) => {
    const state = index === current ? 'current' : done[index] ? 'done' : 'todo';
    const label = state === 'current' ? 'đang làm' : done[index] ? 'đã trả lời' : 'chưa làm';
    return `<button type="button" class="chip ${state}" data-index="${index}" title="Câu ${index + 1} · ${label}">${index + 1}${done[index] ? ' ✓' : ''}</button>`;
  }).join('');
  const answered = Object.keys(done).length;
  $('exam-count').textContent = `Đã làm: ${answered}/${questions.length}`;
  $('exam-nav-note').textContent = answered === questions.length ? 'Em đã trả lời đủ tất cả câu.' : `Còn ${questions.length - answered} câu màu đỏ chưa làm.`;
  const step = $('exam-count-step');
  if (step) step.textContent = `${current + 1} / ${questions.length}`;
}

function renderQuestion() {
  const q = questions[current], value = answersStore[current], lock = frozen ? ' disabled' : '';
  $('paper').innerHTML = `<div class="exam-pane-head"><span>Câu hỏi ${current + 1} / ${questions.length}</span><small>${q.points} điểm · ${q.type === 'mcq' ? 'Trắc nghiệm' : 'Tự luận'}</small></div>
    <h2 class="exam-text">${escape(q.text)}</h2>
    ${q.type === 'mcq' ? `<div class="exam-options">${q.options.map((option, choice) => `<label><input type="radio" name="q${current}" value="${choice}" ${String(value) === String(choice) ? 'checked' : ''}${lock}/><span>${escape(option)}</span></label>`).join('')}</div>`
      : `<textarea id="answer-${current}" rows="8" maxlength="${TEXT_MAX}" placeholder="${escape(q.prompt || 'Viết câu trả lời của em…')}"${lock}>${escape(value ?? '')}</textarea>`}
    <div class="exam-step"><button id="prev" class="secondary"${current === 0 || frozen ? ' disabled' : ''}>‹ Câu trước</button><span id="exam-count-step"></span><button id="next"${current === questions.length - 1 || frozen ? ' disabled' : ''}>Câu tiếp ›</button></div>`;
  $('prev').onclick = () => goTo(current - 1);
  $('next').onclick = () => goTo(current + 1);
}

function goTo(index) {
  if (!Number.isInteger(index) || index < 0 || index >= questions.length) return;
  flush();
  current = index;
  renderQuestion();
  paintNav();
  if (!frozen) watch.activity();
}

// Camera ở đây chỉ để em tự kiểm tra: ảnh không rời khỏi máy, và giám thị vẫn xem bằng thiết bị phân tích riêng.
async function toggleCamera() {
  const button = $('cam-toggle'), state = $('cam-state'), video = $('cam-view');
  if (camera) {
    camera.getTracks().forEach(track => track.stop());
    camera = null;
    video.srcObject = null;
    video.hidden = true;
    $('cam-empty').hidden = false;
    button.textContent = 'Tự kiểm tra camera';
    state.textContent = '';
    return;
  }
  button.disabled = true;
  state.textContent = 'Đang xin phép dùng camera…';
  try {
    camera = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
    video.srcObject = camera;
    video.hidden = false;
    $('cam-empty').hidden = true;
    void video.play();
    stops.push(() => camera?.getTracks().forEach(track => track.stop()));
    state.textContent = 'Ảnh này chỉ hiện trên máy em, giám thị không xem được từ đây. Nếu trang phân tích chạy trên cùng máy này, tắt camera kiểm tra để trang đó dùng camera.';
    button.textContent = 'Tắt camera kiểm tra';
  } catch (error) {
    state.textContent = `Không bật được camera trên máy này (${error.name}). ${({ NotAllowedError: 'Hãy cho phép dùng camera trong trình duyệt rồi bấm lại.', NotReadableError: 'Camera đang bị ứng dụng hoặc tab khác giữ.', NotFoundError: 'Máy này chưa có camera.', SecurityError: 'Trang phải mở bằng HTTPS thì trình duyệt mới xin được camera.' })[error.name] || error.message}`;
  } finally {
    button.disabled = false;
  }
}

function renderPaper(remainingSeconds, bell = runOut) {
  atBell = bell;
  current = 0;
  answersStore = { ...stored() };
  $('content').innerHTML = `<div class="exam-bar"><div class="exam-id"><span class="exam-subject">${escape(paper.title)}</span><span class="exam-seat">${escape(me.student.seat_id)}</span></div><div class="exam-clock-box"><span aria-hidden="true">⏰</span><span id="exam-clock">--:--</span><span id="save-state">Đang chờ máy chủ…</span></div><button id="submit" class="primary">Nộp bài thi</button></div>
    <div class="exam-layout">
      <section id="paper" class="exam-pane"></section>
      <aside class="exam-side">
        <div class="exam-cam"><video id="cam-view" playsinline muted hidden></video><div id="cam-empty"><strong>Camera giám sát</strong><p>Giám thị thấy em qua trang phân tích ở thiết bị riêng do giám thị hướng dẫn. Bấm nút dưới để tự kiểm tra camera của máy này.</p></div>
          <div class="exam-cam-tools"><button id="cam-toggle">Tự kiểm tra camera</button><a href="/monitor?room=${encodeURIComponent(me.roomId)}">Mở trang camera giám sát</a></div>
          <p id="cam-state" role="status"></p></div>
        <div class="exam-palette"><h3><span>Danh sách câu hỏi</span><span id="exam-count"></span></h3><div id="exam-legend"><i class="dot done"></i>Đã làm<i class="dot todo"></i>Chưa làm</div><div id="exam-chips"></div><p id="exam-nav-note"></p></div>
      </aside>
    </div>
    <p class="portal-note">Tắt trình duyệt không làm mất bài: máy chủ giữ những câu đã lưu và em mở lại trang này để làm tiếp cho tới khi hết giờ.</p>`;
  renderQuestion();

  const sheet = $('paper');
  sheet.addEventListener('input', () => { watch.activity(); flush(); paintNav(); });
  sheet.addEventListener('paste', event => {
    const alert = watch.paste(current, String(event.clipboardData?.getData('text') ?? '').trim().length);
    if (alert) { void report(alert); void save(); }
  });
  $('exam-chips').addEventListener('click', event => {
    const index = Number(event.target.closest('button[data-index]')?.dataset.index);
    if (Number.isInteger(index)) goTo(index);
  });
  $('cam-toggle').onclick = () => void toggleCamera();
  $('submit').onclick = async () => {
    if (frozen || !confirm(`Nộp bài và kết thúc thời gian làm bài? Em đã làm ${Object.keys(collect()).length}/${questions.length} câu.`)) return;
    $('submit').disabled = true;
    try { renderResult(await api(`/api/exams/${paper.id}/submit`, { method: 'POST', body: JSON.stringify({ answers: collect(), tabMs: Math.round(watch?.awayMs ?? 0), tabEvents: watch?.tabEvents ?? 0, pasteCount: watch?.pasteCount ?? 0 }) })); }
    catch (error) {
      $('submit').disabled = false;
      if (error.status === 409) freeze(error.message); else notice(error.message, true);
    }
  };

  savedAnswers = fingerprint(answersStore);
  paintNav();
  offerRestore(readDraft());
  setDeadline(remainingSeconds);
  if (frozen) return;

  const tick = setInterval(() => { paintClock(); const alert = watch.tick(); if (alert) void report(alert); }, 1000);
  const autosave = setInterval(() => { if (fingerprint(collect()) !== savedAnswers) void save(); else void post('/api/heartbeat', {}); }, AUTOSAVE_MS);
  const onVisibility = () => {
    const alert = watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: !document.hasFocus() });
    if (document.visibilityState !== 'visible') { save({ keepalive: true }); return; }
    if (alert) void report(alert);
    void save();
  };
  const onFocus = () => watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: false });
  const onBlur = () => watch.setVisible({ hidden: document.visibilityState !== 'visible', blurred: true });
  const onHide = () => save({ keepalive: true });
  const onOnline = () => { notice(''); void save(); };
  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('focus', onFocus);
  window.addEventListener('blur', onBlur);
  window.addEventListener('pagehide', onHide);
  window.addEventListener('online', onOnline);
  stops = [() => clearInterval(tick), () => clearInterval(autosave), () => document.removeEventListener('visibilitychange', onVisibility),
    () => window.removeEventListener('focus', onFocus), () => window.removeEventListener('blur', onBlur), () => window.removeEventListener('pagehide', onHide),
    () => window.removeEventListener('online', onOnline)];
  if (document.visibilityState !== 'visible' || !document.hasFocus()) onVisibility();
}

function renderReadOnly(message) {
  renderPaper(0, () => {});
  freeze(message);
}

function renderResult(result) {
  const marks = sumPoints(true), total = sumPoints(false);
  stopTimers();
  clearDraft();
  frozen = true;
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">ĐÃ NỘP BÀI</div><h1>${escape(paper.title)}</h1></section>`
    + card('Kết quả', `<p>Trắc nghiệm máy chủ chấm ngay: <strong>${result.score ?? 0} / ${marks}</strong> điểm.${marks < total ? ` Còn ${total - marks} điểm tự luận do giám thị chấm nên điểm cuối cùng sẽ khác.` : ''}</p><p>Giám thị đã nhận được bài làm và danh sách cảnh báo của em.</p><a class="button primary" href="/">Về trang phòng thi</a>`);
  notice('');
}

function showGate() {
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">ĐỀ THI TRÊN MÁY · ${escape(me.student.seat_id)}</div><h1>${escape(paper.title)}</h1><p>${questions.length} câu · ${sumPoints(false)} điểm · ${paper.durationMinutes} phút.</p></section>`
    + card('Trước khi vào làm', `<ul class="exam-rules">
      <li>Đồng hồ chạy ngay khi em bấm bắt đầu và <strong>không tạm dừng</strong>.</li>
      <li>Mỗi câu tự lưu lên máy chủ sau 5 giây. Tắt trang rồi mở lại vẫn còn bài đã lưu.</li>
      <li>Giám thị thấy khi em <strong>rời cửa sổ làm bài</strong> từ 15 giây, khi đáp án <strong>xuất hiện bằng cách dán</strong>, và khi em <strong>ngừng làm</strong> quá 3 phút. Trình duyệt không biết em mở gì ở cửa sổ khác, nên giám thị sẽ kiểm tra lại từng báo.</li>
      <li>Camera giám sát chạy trên thiết bị riêng do giám thị hướng dẫn. Trong lúc làm bài, không mở thêm tab hay ứng dụng khác.</li>
    </ul><button id="begin" class="primary">Bắt đầu làm bài (${paper.durationMinutes} phút)</button><p id="gate-error" class="form-error" role="alert"></p>`);
  $('begin').onclick = async () => {
    const button = $('begin');
    button.disabled = true;
    try { await api(`/api/exams/${paper.id}/start`, { method: 'POST', body: JSON.stringify({}) }); await load(paper.id); }
    catch (error) { button.disabled = false; $('gate-error').textContent = error.message; }
  };
}

async function load(id) {
  stopTimers();
  const data = await api(`/api/exams/${id}/paper`);
  paper = { id, ...data };
  questions = data.questions;
  watch = new IntegrityWatch({ onAlert: report });
  watch.restore({ tabMs: data.attempt?.tabMs, tabEvents: data.attempt?.tabEvents, pasteCount: data.attempt?.pasteCount });
  if (data.attempt) watch.activity();
  frozen = false;
  if (!data.attempt) return showGate();
  if (data.attempt.submittedAt) return renderResult({ score: data.attempt.score });
  if (data.attempt.closed) return renderReadOnly('Đề đã hết thời gian. Những câu đã lưu vẫn được máy chủ chấm.');
  renderPaper(data.attempt.remainingSeconds);
}

function showList(list) {
  $('content').innerHTML = `<section class="welcome"><div class="eyebrow">PHÒNG THI CỦA EM</div><h1>Đề thi đã mở.</h1><p>Chọn đề giám thị yêu cầu làm. Mỗi đề có đồng hồ riêng tính theo giờ của máy chủ.</p></section>`
    + list.map(t => card(t.title, `<p>${t.questionCount} câu · ${t.maxPoints} điểm · ${t.durationMinutes} phút.</p><p>${t.submitted ? 'Em đã nộp đề này.'
      : t.started ? `Em đang làm, còn ${Math.ceil(t.remainingSeconds / 60)} phút.` : 'Em chưa bắt đầu.'}</p><a class="button primary" href="/exam?test=${encodeURIComponent(t.id)}">${t.submitted ? 'Xem lại bài đã nộp' : t.started ? 'Tiếp tục làm bài' : 'Vào làm bài'}</a>`)).join('');
}

async function start() {
  try { me = await api('/api/me'); }
  catch (error) { notice(error.status === 401 ? 'Hãy đăng nhập bằng mã tham gia do giám thị cấp.' : error.message, true); $('content').innerHTML = card('Chưa vào được phòng thi', '<p>Mở trang chủ FocusLab, nhập mã phòng và mã tham gia riêng của em rồi vào lại link này.</p><a class="button primary" href="/">Về trang đăng nhập</a>'); return; }
  $('who').textContent = `${me.student.name} · ${me.student.seat_id}`;
  if (me.role !== 'student') { $('content').innerHTML = card('Trang dành cho thí sinh', '<p>Giám thị dùng bảng điều khiển để soạn đề và theo dõi phòng thi.</p><a class="button primary" href="/">Về bảng giám thị</a>'); return; }
  try {
    const list = await api('/api/exams');
    if (!list.length) { $('content').innerHTML = card('Chưa có đề thi', '<p>Giám thị chưa mở đề cho phòng của em. Em hãy giữ trang này và làm theo hướng dẫn trong phòng thi.</p><p><a class="button" href="/monitor?room=' + encodeURIComponent(me.roomId) + '">Mở trang camera giám sát</a></p>'); return; }
    const chosen = list.find(t => t.id === new URLSearchParams(location.search).get('test'));
    if (!chosen && (list.length > 1 || location.search)) return showList(list);
    await load(chosen ? chosen.id : list[0].id);
  } catch (error) { notice(error.message, true); }
}

document.querySelector('#app').innerHTML = `<div class="portal exam"><header><a class="brand" href="/">FocusLab<span class="brand-dot">.</span><small>EXAM</small></a><span id="who" class="local-badge">Thí sinh</span></header><div id="portal-message" role="status" aria-live="polite"></div><div id="content"></div><footer>Bài làm lưu trên máy chủ của phòng thi · Giám thị xem lại từng cảnh báo trước khi xử lý</footer></div>`;
start();
