import test from 'node:test';
import assert from 'node:assert/strict';
import {pickClipMime, ClipRecorder} from './clip-recorder.js';

class FakeRecorder {
  constructor() { this.stopped = false; }
  set ondataavailable(handler) { this.handler = handler; }
  start(timeslice) { this.timeslice = timeslice; }
  emit(data) { this.handler?.({data}); }
  stop() { this.stopped = true; }
}
// Drives a recorder with a fake clock: one 1000-byte chunk per simulated second.
function harness(options = {}) {
  const recorder = new FakeRecorder();
  const uploaded = [];
  let clock = 0;
  const clips = new ClipRecorder({
    factory: () => recorder, stream: {}, mimeType: 'video/webm',
    now: () => clock, onUpload: meta => uploaded.push(meta), ...options,
  });
  clips.start();
  return {
    clips, recorder, uploaded,
    second() { clock += 1000; recorder.emit({size: 1000, type: 'video/webm'}); },
    jump(ms) { clock += ms; },
  };
}

test('only formats the browser really records are offered', () => {
  assert.equal(pickClipMime(() => false), null);
  assert.equal(pickClipMime(type => type === 'video/mp4'), 'video/mp4');
  assert.equal(pickClipMime(type => type.startsWith('video/webm')), 'video/webm;codecs=vp8');
});
test('the camera stream is used directly, a video element is asked for its own', () => {
  const tracks = {getVideoTracks: () => [{kind: 'video'}]};
  const Recorder = class {
    static isTypeSupported(type) { return type === 'video/webm'; }
    constructor(stream) { this.stream = stream; }
    start() {} stop() {}
  };
  assert.equal(ClipRecorder.forBrowser(tracks, {Recorder}).stream, tracks);
  assert.equal(ClipRecorder.forBrowser({captureStream: () => tracks}, {Recorder}).stream, tracks);
  assert.equal(ClipRecorder.forBrowser({mozCaptureStream: () => tracks}, {Recorder}).stream, tracks);
  assert.equal(ClipRecorder.forBrowser({}, {Recorder}), null);
  assert.equal(ClipRecorder.forBrowser(tracks, {Recorder: undefined}), null, 'no MediaRecorder means no clip');
  assert.equal(ClipRecorder.forBrowser(tracks, {Recorder: class { static isTypeSupported() { return false; } }}), null);
});
test('rolling buffer keeps only the seconds before the alert', () => {
  const h = harness({bufferMs: 5000});
  for (let i = 0; i < 9; i++) h.second();
  assert.equal(h.clips.chunks.length, 6);
  assert.equal(h.clips.armed, false);
});
test('alert freezes the buffer, waits out the after-window, then uploads once', () => {
  const h = harness();
  for (let i = 0; i < 35; i++) h.second();
  assert.equal(h.clips.capture({id: 7, seatId: 'S01', rule: 'object', risk: 60}), true);
  assert.equal(h.clips.armed, true);
  for (let i = 0; i < 9; i++) { h.second(); assert.equal(h.clips.tick(), null, 'inside the 10 second window'); }
  h.second();
  const clip = h.clips.tick();
  assert.equal(clip.event.seatId, 'S01');
  assert.equal(clip.bytes, 45000, '35 buffered seconds plus 10 recorded after the alert');
  assert.equal(h.clips.armed, false);
  assert.equal(h.clips.tick(), null, 'one clip per alert');
  assert.equal(h.uploaded.length, 1);
});
test('a second alert must wait out the cooldown', () => {
  const h = harness();
  h.second();
  assert.equal(h.clips.capture({id: 1}), true);
  h.clips.active = null;
  assert.equal(h.clips.capture({id: 2}), false);
  h.jump(30000);
  assert.equal(h.clips.capture({id: 3}), true);
});
test('an alert before any recorded frame is skipped instead of sending an empty clip', () => {
  const clips = new ClipRecorder({factory: () => new FakeRecorder(), stream: {}, mimeType: 'video/webm', now: () => 0, onUpload: () => { throw new Error('must not upload'); }});
  clips.start();
  assert.equal(clips.capture({id: 1}), false);
  assert.equal(clips.armed, false);
});
test('oversized clips are dropped with a reason, not uploaded', () => {
  const h = harness({maxBytes: 20000});
  for (let i = 0; i < 40; i++) h.second();
  h.clips.capture({id: 9});
  h.clips.active.deadline = 0;
  const result = h.clips.tick();
  assert.equal(result.bytes, 40000);
  assert.equal(h.uploaded[0].error, 'QUA_LARGE');
  assert.equal(h.clips.armed, false);
});
test('stop clears the buffer so a restarted camera cannot reuse old frames', () => {
  const h = harness();
  h.second(); h.second();
  h.clips.capture({id: 4});
  h.clips.stop();
  assert.deepEqual(h.clips.chunks, []);
  assert.equal(h.clips.armed, false);
  assert.equal(h.clips.active, null);
  assert.equal(h.recorder.stopped, true);
});
