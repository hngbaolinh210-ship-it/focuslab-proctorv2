export function objectRegion(mode) {
  return mode === 'center' ? {x: .25, y: .25, width: .5, height: .5} : {x: 0, y: 0, width: 1, height: 1};
}
export function padRegion(region, amount = .12) {
  const width = Math.min(1, region.width * (1 + amount)), height = Math.min(1, region.height * (1 + amount));
  return {
    x: Math.max(0, Math.min(1 - width, region.x - (width - region.width) / 2)),
    y: Math.max(0, Math.min(1 - height, region.y - (height - region.height) / 2)),
    width, height,
  };
}
// One 640px inference per target: seat crops are scanned in turn, then the whole
// frame, so objects outside every region still reach the proctor. Past the crop
// budget a seat falls back to the full-frame pass rather than a rotating window
// that would leave every result minutes old.
export function scanTargets(seats, maxCrops = 12) {
  return [...seats.slice(0, maxCrops).map(seat => ({key: seat.id, region: padRegion(seat.region)})), {key: 'full', region: objectRegion('full')}];
}
export function scanWindowMs(targetCount, intervalMs = 1000) {
  return Math.max(3000, Math.max(1, targetCount) * intervalMs + 1500);
}
export function collectScans(scans, now, windowMs) {
  const fresh = [];
  for (const [key, scan] of scans) {
    if (!Number.isFinite(scan.capturedAt) || now < scan.capturedAt || now - scan.capturedAt > windowMs) scans.delete(key);
    else fresh.push(...scan.objects);
  }
  return fresh;
}

export function projectObjects(objects, region) {
  return objects.map(object => ({...object, box: {
    x: region.x + object.box.x * region.width,
    y: region.y + object.box.y * region.height,
    width: object.box.width * region.width,
    height: object.box.height * region.height,
  }}));
}
export function forbiddenObjects(objects, allowBooks) {
  return allowBooks ? objects.filter(object => object.classId !== 73) : objects;
}
export function objectsAreFresh(capturedAt, now) {
  return Number.isFinite(capturedAt) && now >= capturedAt && now - capturedAt <= 3000;
}
