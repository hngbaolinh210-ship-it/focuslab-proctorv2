import test from 'node:test';
import assert from 'node:assert/strict';
import { LETTERS, blankQuestion, rowsFromQuestions, questionsFromRows, validateRows, parsePaperText, paperTextFromRows } from './exam-author.js';

test('a pasted Vietnamese paper becomes editable rows', () => {
  const { rows, notes } = parsePaperText(`Câu 1: Chọn đáp án đúng: 把 + ?
A. S1 + 把 + S2 + V
B. S1 + V + 把 + S2
C. S2 + 把 + S1 + V
D. Không dùng 把
ĐA: A
Điểm: 3

2) Câu nào sau đây sai?
A. Sai
B. Đúng hơn
C. Đúng nhất
Đáp án: C

Câu 3: Đặt một câu với chữ 把
Tự luận: viết khoảng 30 từ
Điểm: 5
`);
  assert.deepEqual(notes, []);
  assert.equal(rows.length, 3);
  assert.deepEqual(rows[0], { type: 'mcq', text: 'Chọn đáp án đúng: 把 + ?', options: ['S1 + 把 + S2 + V', 'S1 + V + 把 + S2', 'S2 + 把 + S1 + V', 'Không dùng 把'], answer: 0, points: 3 });
  assert.deepEqual(rows[1], { type: 'mcq', text: 'Câu nào sau đây sai?', options: ['Sai', 'Đúng hơn', 'Đúng nhất'], answer: 2, points: 2 });
  assert.deepEqual(rows[2], { type: 'text', text: 'Đặt một câu với chữ 把', prompt: 'viết khoảng 30 từ', points: 5 });
});

test('the answer key is the row that survives a round trip', () => {
  const questions = [
    { type: 'mcq', text: 'Em chọn phương án nào?', options: ['Một', 'Hai', 'Ba'], answer: 2, points: 1 },
    { type: 'text', text: 'Giải thích vì sao.', prompt: 'Không quá 10 dòng', points: 4 },
  ];
  const parsed = parsePaperText(paperTextFromRows(rowsFromQuestions(questions)));
  assert.deepEqual(parsed.notes, []);
  assert.deepEqual(questionsFromRows(parsed.rows), questions);

  // The teacher may edit options in place, so indexes must follow the letters, not the order typed.
  const reordered = parsePaperText('Câu 1: Hỏi gì đó\nC. phương án C\nA. phương án A\nB. phương án B\nĐA: B\nĐiểm: 2');
  assert.deepEqual(reordered.rows[0].options, ['phương án A', 'phương án B', 'phương án C']);
  assert.equal(reordered.rows[0].answer, 1);
});

test('a marker that does not name an option is reported, never guessed silently', () => {
  const missing = parsePaperText('Câu 1: Hỏi\nA. một\nB. hai\nĐiểm: 2');
  assert.equal(missing.rows[0].answer, 0);
  assert.match(missing.notes[0], /chưa ghi dòng "ĐA: …"/);

  const wrong = parsePaperText('Câu 1: Hỏi\nA. một\nB. hai\nĐA: D\nĐiểm: 2');
  assert.equal(wrong.rows[0].answer, 0);
  assert.match(wrong.notes[0], /đáp án D không khớp phương án nào/);

  const numeric = parsePaperText('Câu 1: Hỏi\nA. một\nB. hai\nĐáp án đúng: 2');
  assert.equal(numeric.rows[0].answer, 1);
  assert.deepEqual(numeric.notes, []);
});

test('a block without options falls back to an essay question', () => {
  const { rows, notes } = parsePaperText('Câu 1: Chỉ có một dòng hỏi\nĐiểm: 3');
  assert.equal(rows[0].type, 'text');
  assert.equal(rows[0].points, 3);
  assert.equal(notes.length, 1);
  assert.deepEqual(parsePaperText('').rows, []);
  assert.match(parsePaperText('---\n\n\n').notes[0], /không có nội dung/);
});

test('validation mirrors the server limits', () => {
  assert.deepEqual(validateRows([]), [{ index: -1, message: 'Đề thi cần ít nhất 1 câu.' }]);
  const good = { type: 'mcq', text: 'Hỏi', options: ['a', 'b'], answer: 1, points: 2 };
  assert.deepEqual(validateRows([good]), []);
  assert.deepEqual(validateRows([{ ...good, options: ['', 'b'] }]), [{ index: 0, message: 'Câu 1: có phương án đang để trống.' }]);
  assert.deepEqual(validateRows([{ ...good, options: ['a', 'b'], answer: 2 }]), [{ index: 0, message: 'Câu 1: đáp án đúng phải là một phương án có trong câu.' }]);
  assert.deepEqual(validateRows([{ ...good, points: 0 }]), [{ index: 0, message: 'Câu 1: điểm cần là số nguyên từ 1 đến 20.' }]);
  assert.deepEqual(validateRows([{ ...good, text: '' }]), [{ index: 0, message: 'Câu 1: thiếu nội dung câu hỏi.' }]);
  assert.deepEqual(validateRows([{ type: 'text', text: 'Viết bài', prompt: '', points: 5 }]), []);
  assert.equal(validateRows(Array.from({ length: 101 }, () => good))[0].index, -1);
  assert.deepEqual(blankQuestion('text'), { type: 'text', text: '', prompt: '', points: 5 });
  assert.equal(LETTERS.length, 8);
});

test('question text keeps its own line breaks and its bullet-looking lines stay questions', () => {
  const parsed = parsePaperText('Câu 1: Đọc đoạn văn sau:\nHôm nay trời mưa.\nEm thấy gì?');
  assert.equal(parsed.rows[0].text, 'Đọc đoạn văn sau:\nHôm nay trời mưa.\nEm thấy gì?');
  // A stem with no A/B options cannot be graded automatically, so it is announced instead of guessed.
  assert.equal(parsed.rows[0].type, 'text');
  assert.match(parsed.notes[0], /không có phương án A, B/);
  const startsWithCa = parsePaperText('Ca múa hôm nay thế nào?\nA. vui\nB. buồn\nĐA: A');
  assert.equal(startsWithCa.rows[0].text, 'Ca múa hôm nay thế nào?');
});
