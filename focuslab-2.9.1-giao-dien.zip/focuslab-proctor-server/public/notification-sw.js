// Background push: the phone's push service wakes this worker even when every tab is closed.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { body: event.data?.text() }; }
  const title = data.title || 'FocusLab · Cảnh báo phòng thi';
  const options = {
    body: data.body || 'Có cảnh báo mới cần giám thị kiểm tra.',
    tag: data.tag || 'focuslab-alert',
    icon: '/icons/focuslab-1024.png',
    badge: '/icons/focuslab-1024.png',
    timestamp: Date.now(),
    data: { url: data.url || '/' },
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = new URL(event.notification.data?.url || '/', self.location).pathname;
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const existing = windows.find(client => new URL(client.url).pathname === target)
      ?? windows.find(client => new URL(client.url).pathname === '/');
    if (existing) return existing.focus();
    return self.clients.openWindow(target);
  })());
});
