import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync, openSync, closeSync, fsyncSync, renameSync, unlinkSync } from 'node:fs';
import path from 'node:path';
export const token = () => randomBytes(24).toString('base64url');
export const digest = value => createHash('sha256').update(value).digest('hex');
export function passwordHash(password) {
  const salt=randomBytes(16).toString('hex');
  return `${salt}:${scryptSync(password,salt,64).toString('hex')}`;
}
export function passwordMatches(password, stored) {
  const [salt,hash]=stored.split(':');const expected=Buffer.from(hash,'hex');const actual=scryptSync(password,salt,64);
  return expected.length===actual.length&&timingSafeEqual(expected,actual);
}
export function initializeAdmin(dataDir,password) {
  mkdirSync(dataDir,{recursive:true,mode:0o700});const file=path.join(dataDir,'admin.json');
  if(existsSync(file))return JSON.parse(readFileSync(file,'utf8')).passwordHash;
  if(typeof password!=='string'||password.length<12)throw new Error('Chạy npm run setup để tạo mật khẩu giám thị từ 12 ký tự.');
  const hash=passwordHash(password);writeFileSync(file,JSON.stringify({passwordHash:hash}),{mode:0o600,flag:'wx'});return hash;
}

export function replaceAdminPassword(dataDir, password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 200) throw new Error('PASSWORD_LENGTH');
  const hash = passwordHash(password);
  const target = path.join(dataDir,'admin.json');
  const temporary = path.join(dataDir,`.admin-${token()}.tmp`);
  let fd;
  try {
    fd = openSync(temporary,'wx',0o600);
    writeFileSync(fd,JSON.stringify({passwordHash:hash}));
    fsyncSync(fd);closeSync(fd);fd=undefined;
    // Replace only after the new file is fully written. A failed write leaves the old password intact.
    renameSync(temporary,target);
    return hash;
  } finally {
    if (fd !== undefined) closeSync(fd);
    if (existsSync(temporary)) unlinkSync(temporary);
  }
}
