import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync,rmSync,readFileSync,existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import {createApp} from './app.mjs';
import {binaries,validateCameraUrl} from './media.mjs';
const password='synthetic-test-password-only';
const sampleEvent=id=>({clientId:id,seatId:'S99',rule:'away',risk:40,time:new Date().toISOString(),resolved:null,duration:3,offset:null});
const device=(name='phone')=>({endpoint:`https://push.example.com/push/${name}`,keys:{p256dh:'B'+'y'.repeat(86),auth:'a'.repeat(22)},label:name});
async function fixture(t, pushOptions={}, appOptions={}){
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-test-'));const system=createApp({dataDir:directory,adminPassword:password,cameraHosts:['192.0.2.10'],maxUploadBytes:1024*1024,pushOptions:{sendImpl:async()=>{throw new Error('no device should receive')},...pushOptions},...appOptions});
 const server=system.app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));const base=`http://127.0.0.1:${server.address().port}`;
 t.after(async()=>{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await system.close();rmSync(directory,{recursive:true,force:true,maxRetries:10,retryDelay:100});});
 async function request(route,{cookie,body,method='GET',headers={}}={}){const isForm=body instanceof FormData;return fetch(base+route,{method,headers:{...(cookie?{Cookie:cookie}:{}),...(!isForm&&body!==undefined?{'Content-Type':'application/json'}:{}),...headers},body:body===undefined?undefined:isForm?body:JSON.stringify(body)});}
 const login=await request('/api/login',{method:'POST',body:{password}});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];
 const roomResponse=await request('/api/rooms',{method:'POST',cookie,body:{title:'Synthetic room'}});const room=await roomResponse.json();
 return {system,server,directory,request,cookie,room};
}
test('authentication, same-origin protection, 100 students, ownership, event dedup and room closure',async t=>{
 const f=await fixture(t),{request,cookie,room}=f;
 assert.equal((await request('/api/rooms')).status,401);
 assert.equal((await request('/api/login',{method:'POST',body:{password:'wrong'}})).status,401);
 assert.equal((await request('/api/rooms',{method:'POST',cookie,body:{title:'bad'},headers:{Origin:'https://elsewhere.invalid'}})).status,403);
 const students=Array.from({length:100},(_,i)=>({student_id:`HS${i+1}`,name:`Synthetic student ${i+1}`}));
 const imported=await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students}});assert.equal(imported.status,201);const roster=await imported.json();assert.equal(roster.students.length,100);
 assert.equal((await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'HS101',name:'Extra'}]}})).status,409);
 const sessions=await Promise.all(roster.students.map(async s=>{const response=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:s.access_code}});assert.equal(response.status,200);return response.headers.get('set-cookie').split(';')[0];}));
 const eventReplies=await Promise.all(sessions.map((studentCookie,i)=>request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent(`student-${i}`)]}})));
 assert.ok(eventReplies.every(r=>r.status===200));
 const data=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(data.events.length,100);assert.equal(data.students.length,100);assert.equal(data.students.at(-1).seat_id,'S100');assert.equal(new Set(data.events.map(e=>e.student_id)).size,100);
 assert.equal(data.events.find(e=>e.student_code==='HS1').seat_id,'S01'); // forged client S99 cannot change identity
 assert.equal((await request('/api/rooms',{cookie:sessions[0]})).status,403);
 const other=await(await request('/api/rooms',{method:'POST',cookie,body:{title:'Other'}})).json();
 assert.equal((await request(`/api/rooms/${other.id}`,{cookie:sessions[0]})).status,403);
 assert.equal((await request(`/api/rooms/${other.id}/events`,{cookie:sessions[0],method:'POST',body:{events:[sampleEvent('bad')]}})).status,403);
 const event=data.events.find(e=>e.student_code==='HS1');
 assert.equal((await request(`/api/rooms/${room.id}/events/${event.id}`,{method:'PATCH',cookie:sessions[0],body:{review:'dismissed'}})).status,403);
 await request(`/api/rooms/${room.id}/events/${event.id}`,{method:'PATCH',cookie,body:{review:'dismissed'}});
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),risk:70,duration:10}]}});
 const updated=await(await request(`/api/rooms/${room.id}`,{cookie})).json();assert.equal(updated.eventCount,100);assert.equal(updated.events.find(e=>e.id===event.id).review,'dismissed');assert.equal(updated.events.find(e=>e.id===event.id).risk,70);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),duration:15,resolved:new Date().toISOString()}]}});
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('student-0'),duration:2}]}});
 const retryState=await(await request(`/api/rooms/${room.id}`,{cookie})).json();const finalEvent=retryState.events.find(e=>e.id===event.id);assert.equal(finalEvent.payload.duration,15);assert.ok(finalEvent.payload.resolved);
 const studentView=await(await request(`/api/rooms/${room.id}`,{cookie:sessions[0]})).json();assert.equal(studentView.students,undefined);assert.equal(studentView.events,undefined);assert.ok(!JSON.stringify(updated).includes('access_code'));
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[{...sampleEvent('prototype-rule'),rule:'constructor'}]}})).status,400);
 const invalid=await request(`/api/rooms/${other.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'same',name:'A'},{student_id:'same',name:'B'}]}});assert.equal(invalid.status,400);
 assert.equal((await(await request(`/api/rooms/${other.id}`,{cookie})).json()).students.length,0);
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[{...sampleEvent('overscore'),risk:101}]}})).status,400);
 assert.equal((await request(`/api/rooms/${room.id}/cameras`,{method:'POST',cookie,body:{url:'rtsp://127.0.0.1/private'}})).status,400);
 await request(`/api/rooms/${room.id}/close`,{method:'POST',cookie,body:{}});
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:sessions[0],body:{events:[sampleEvent('closed')]}})).status,409);
 assert.equal((await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:roster.students[0].access_code}})).status,401);
});
test('SQLite events and credentials survive application restart',async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-persistence-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 let app=createApp({dataDir:directory,adminPassword:password});app.db.prepare('INSERT INTO rooms(id,code,title,created_at) VALUES(?,?,?,?)').run('persist','PERSIST','Persistence',Date.now());await app.close();
 app=createApp({dataDir:directory});assert.equal(app.db.prepare('SELECT title FROM rooms WHERE id=?').get('persist').title,'Persistence');await app.close();
});
test('video upload uses real FFmpeg, private range serving and limits',async t=>{
 const {request,cookie,room,system,directory}=await fixture(t);
 const source=path.join(directory,'sample.mp4');execFileSync(binaries.ffmpeg,['-nostdin','-v','error','-f','lavfi','-i','color=c=black:s=160x120:d=0.5','-c:v','libx264','-pix_fmt','yuv420p',source]);
 const studentData=await(await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'A',name:'A'},{student_id:'B',name:'B'}]}})).json();
 const tokens=[];for(const s of studentData.students){const response=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:s.access_code}});tokens.push(response.headers.get('set-cookie').split(';')[0]);}
 const body=new FormData();body.append('video',new Blob([readFileSync(source)],{type:'video/mp4'}),'sample.mp4');
 const response=await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie:tokens[0],body});assert.equal(response.status,202);const video=await response.json();await Promise.all([...system.jobs]);
 const ready=await(await request(`/api/videos/${video.id}`,{cookie})).json();assert.equal(ready.status,'ready');
 assert.equal((await request(`/api/videos/${video.id}/content`)).status,401);
 assert.equal((await request(`/api/videos/${video.id}/content`,{cookie:tokens[1]})).status,403);
 const range=await request(`/api/videos/${video.id}/content`,{cookie:tokens[0],headers:{Range:'bytes=0-15'}});assert.equal(range.status,206);assert.equal((await range.arrayBuffer()).byteLength,16);
 const webm=await request(`/api/videos/${video.id}/content?format=webm`,{cookie:tokens[0]});assert.equal(webm.status,200);assert.equal(webm.headers.get('content-type'),'video/webm');assert.deepEqual([...new Uint8Array(await webm.arrayBuffer()).slice(0,4)],[0x1a,0x45,0xdf,0xa3]);
 const bad=new FormData();bad.append('video',new Blob(['not a video'],{type:'video/mp4'}),'fake.mp4');assert.equal((await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie,body:bad})).status,400);
 const huge=new FormData();huge.append('video',new Blob([new Uint8Array(1024*1024+1)],{type:'video/mp4'}),'huge.mp4');assert.equal((await request(`/api/rooms/${room.id}/videos`,{method:'POST',cookie,body:huge})).status,413);
 assert.equal((await request(`/api/videos/${video.id}`,{method:'DELETE',cookie:tokens[0]})).status,403);
 assert.equal((await request(`/api/videos/${video.id}`,{method:'DELETE',cookie})).status,200);
 assert.equal((await request(`/api/videos/${video.id}`,{cookie})).status,404);
 assert.ok(!existsSync(path.join(directory,'videos',video.id+'.mp4')));
});
test('RTSP validation requires explicitly configured hosts and rejects other protocols',()=>{
 assert.equal(validateCameraUrl('rtsp://192.0.2.10/live',['192.0.2.10']),'rtsp://192.0.2.10/live');
 assert.throws(()=>validateCameraUrl('http://192.0.2.10/live',['192.0.2.10']));assert.throws(()=>validateCameraUrl('rtsp://example.com/live',['192.0.2.10']));
});
test('server pushes SSE change notifications after a committed event',async t=>{
 const {request,cookie,room}=await fixture(t);const abort=new AbortController();
 const baseResponse=await request(`/api/rooms/${room.id}/stream`,{cookie});
 assert.equal(baseResponse.status,200);assert.match(baseResponse.headers.get('content-type'),/text\/event-stream/);
 const reader=baseResponse.body.getReader();const first=await reader.read();assert.match(new TextDecoder().decode(first.value),/event: change/);
 const next=reader.read();await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('sse-check')]}});
 const received=await Promise.race([next,new Promise((_,reject)=>{const timer=setTimeout(()=>reject(new Error('No SSE change notification')),3000);timer.unref();})]);
 assert.match(new TextDecoder().decode(received.value),/event: change/);await reader.cancel();
});
test('FFmpeg can produce browser HLS segments from synthetic video',()=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-hls-'));
 try{execFileSync(binaries.ffmpeg,['-nostdin','-v','error','-f','lavfi','-i','color=c=black:s=160x120:d=3','-c:v','libx264','-pix_fmt','yuv420p','-g','25','-f','hls','-hls_time','1','-hls_segment_filename',path.join(directory,'segment-%06d.ts'),path.join(directory,'index.m3u8')]);const manifest=readFileSync(path.join(directory,'index.m3u8'),'utf8');assert.match(manifest,/#EXTM3U/);assert.match(manifest,/segment-000000.ts/);assert.ok(existsSync(path.join(directory,'segment-000000.ts')));}finally{rmSync(directory,{recursive:true,force:true});}
});

test('phone push follows server identity, dedupes events and hides device secrets',async t=>{
 const calls=[];let clock=Date.now();
 const f=await fixture(t,{now:()=>clock,sendImpl:async(subscription,payload)=>{calls.push({subscription,payload:JSON.parse(payload)});return{statusCode:201};}});
 const {request,cookie,room,system}=f;
 const imported=await(await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'A',name:'Server identity',seat_id:'S01'}]}})).json();
 const studentLogin=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:imported.students[0].access_code}});const studentCookie=studentLogin.headers.get('set-cookie').split(';')[0];
 assert.equal((await request('/api/push')).status,401);
 assert.equal((await request('/api/push',{cookie:studentCookie})).status,403);
 assert.equal((await request('/api/push/subscription',{method:'POST',cookie:studentCookie,body:device('steal')})).status,403);
 const subscribed=await request('/api/push/subscription',{method:'POST',cookie,body:device('admin-phone')});assert.equal(subscribed.status,201);
 const listed=await(await request('/api/push',{cookie})).json();assert.equal(listed.devices.length,1);assert.ok(listed.publicKey);
 assert.ok(!JSON.stringify(listed).includes('push.example.com'));assert.ok(!JSON.stringify(listed).includes('p256dh'));
 assert.equal((await request('/api/push/subscription',{method:'POST',cookie,body:{endpoint:'http://push.example.com/insecure',keys:device().keys}})).status,400);
 assert.equal((await request('/api/push/subscription',{method:'POST',cookie,body:{endpoint:'https://192.168.1.9/push',keys:device().keys}})).status,400);
 assert.equal((await request('/api/push/subscription',{method:'POST',cookie,body:{endpoint:'https://push.example.com/push/no-keys'}})).status,400);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent('push-event')]}});await system.notifications.wake();
 assert.equal(calls.length,1);assert.match(calls[0].payload.body,/Server identity \(A\)/);assert.match(calls[0].payload.body,/chỗ S01/);assert.ok(!calls[0].payload.body.includes('S99'));
 assert.equal(calls[0].subscription.endpoint,'https://push.example.com/push/admin-phone');
 clock+=10000;
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[{...sampleEvent('push-event'),risk:85,duration:8}]}});await system.notifications.wake();assert.equal(calls.length,1);
 const state=await(await request(`/api/rooms/${room.id}`,{cookie})).json();
 assert.equal(state.events[0].push_status,'sent');assert.equal(state.events[0].push_delivered,1);assert.equal(state.notifications.sent,1);
 const studentView=await(await request(`/api/rooms/${room.id}`,{cookie:studentCookie})).json();assert.equal(studentView.notifications,undefined);
 clock+=10000;
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[{...sampleEvent('same-seat-repeat'),seatId:'S01'}]}});await system.notifications.wake();
 assert.equal(calls.length,1,'cooldown suppresses a repeated warning for the same seat and rule');
 clock+=100000;
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[{...sampleEvent('after-cooldown'),seatId:'S01'}]}});await system.notifications.wake();assert.equal(calls.length,2);
 const tested=await request('/api/push/test',{method:'POST',cookie,body:{}});assert.equal(tested.status,202);assert.equal((await tested.json()).sent,1);
});
test('push is silent until a phone is registered, then retries and bounds attempts',async t=>{
 let clock=Date.now(),mode='retry',calls=0;
 const f=await fixture(t,{now:()=>clock,sendImpl:async()=>{calls++;if(mode==='retry'){throw Object.assign(new Error('máy chủ đẩy trả 503'),{retry:true});}throw Object.assign(new Error('private detail '+mode),{gone:true});}});
 const {request,cookie,room,system}=f;
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('no-device')]}});await system.notifications.wake();
 assert.equal(system.db.prepare('SELECT COUNT(*) n FROM push_notifications').get().n,0);
 assert.equal((await request('/api/push/test',{method:'POST',cookie,body:{}})).status,409);
 await request('/api/push/subscription',{method:'POST',cookie,body:device('retry-phone')});
 for(const event of [{...sampleEvent('low'),risk:30},{...sampleEvent('resolved'),resolved:new Date().toISOString()}])await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[event]}});
 assert.equal(system.db.prepare('SELECT COUNT(*) n FROM push_notifications').get().n,0);
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[sampleEvent('retry')]}});
 for(let i=0;i<3;i++){clock+=100000;await system.notifications.wake();}
 let job=system.db.prepare('SELECT * FROM push_notifications').get();assert.equal(job.status,'failed');assert.equal(job.attempts,3);assert.ok(!job.error.includes('private detail'));
 clock+=100000;mode='gone';
 await request('/api/push/subscription',{method:'POST',cookie,body:device('gone-phone')});
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[{...sampleEvent('gone-event'),seatId:'S03'}]}});await system.notifications.wake();
 job=system.db.prepare('SELECT * FROM push_notifications ORDER BY id DESC').get();assert.equal(job.status,'failed');assert.equal(job.delivered,0);
 assert.equal(system.db.prepare('SELECT COUNT(*) n FROM push_subscriptions').get().n,0,'dead devices are unregistered');
});
test('a push interrupted by a restart is retried without losing the alert',async t=>{
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-push-restart-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 let clock=Date.now(),calls=0;
 let system=createApp({dataDir:directory,adminPassword:password,pushOptions:{now:()=>clock,sendImpl:async()=>{calls++;throw new Error('đường truyền bị cắt');}}});
 system.db.prepare('INSERT INTO rooms(id,code,title,created_at) VALUES(?,?,?,?)').run('r','R','Restart',clock);
 system.db.prepare('INSERT INTO push_subscriptions(endpoint,p256dh,auth,label,created_at) VALUES(?,?,?,?,?)').run('https://push.example.com/push/restarted','key','auth','phone',clock);
 const event={id:1,room_id:'r',seat_id:'S01',rule:'away',risk:40,received_at:clock,payload:JSON.stringify({resolved:null})};
 system.db.prepare('INSERT INTO events(id,room_id,source,client_id,seat_id,rule,risk,payload,received_at) VALUES(?,?,?,?,?,?,?,?,?)').run(event.id,'r','camera','eligible','S01','away',40,event.payload,clock);
 system.notifications.enqueue(system.db.prepare('SELECT * FROM events WHERE id=?').get(1));
 system.db.prepare("UPDATE push_notifications SET status='sending'").run();
 await system.close();clock+=30001;
 calls=0;
 system=createApp({dataDir:directory,adminPassword:password,pushOptions:{now:()=>clock,sendImpl:async()=>{calls++;return{statusCode:201};}}});
 await system.notifications.wake();
 const job=system.db.prepare('SELECT * FROM push_notifications').get();assert.equal(job.status,'sent');assert.equal(calls,1);
 await system.close();
});
test('each supervisor only pushes to their own rooms and devices',async t=>{
 const calls=[];let clock=Date.now();
 const f=await fixture(t,{now:()=>clock,sendImpl:async(subscription,payload)=>{calls.push({endpoint:subscription.endpoint,payload:JSON.parse(payload)});return{statusCode:201};}},{proctorInviteCode:'synthetic-invite-code'});
 const {request,cookie,room,system}=f;
 const registration=await request('/api/proctors/register',{method:'POST',body:{username:'linh',displayName:'Thầy Linh',password:'synthetic-proctor-password',inviteCode:'synthetic-invite-code'}});
 assert.equal(registration.status,201);const proctorCookie=registration.headers.get('set-cookie').split(';')[0];
 const other=await(await request('/api/rooms',{method:'POST',body:{title:'Phòng của giám thị'},cookie:proctorCookie})).json();
 assert.equal((await request('/api/rooms',{cookie:proctorCookie})).status,200);
 assert.ok((await(await request('/api/rooms',{cookie:proctorCookie})).json()).every(r=>r.id===other.id));
 assert.equal((await request('/api/rooms',{method:'POST',cookie:proctorCookie,body:{title:'Phòng khác'}})).status,201);
 const proctorDevice=await request('/api/push/subscription',{method:'POST',cookie:proctorCookie,body:device('proctor-phone')});assert.equal(proctorDevice.status,201);
 assert.equal((await request('/api/push/subscription',{method:'POST',cookie,body:device('admin-phone')})).status,201);
 const roster=await(await request(`/api/rooms/${other.id}/students`,{method:'POST',cookie:proctorCookie,body:{students:[{student_id:'B',name:'Học sinh B',seat_id:'S01'}]}})).json();
 const studentLogin=await request('/api/join',{method:'POST',body:{roomCode:other.code,accessCode:roster.students[0].access_code}});const studentCookie=studentLogin.headers.get('set-cookie').split(';')[0];
 await request(`/api/rooms/${other.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent('proctor-room')]}});await system.notifications.wake();
 assert.deepEqual(calls.map(call=>call.endpoint).sort(),['https://push.example.com/push/admin-phone','https://push.example.com/push/proctor-phone'].sort());
 const adminList=await(await request('/api/rooms',{cookie})).json();assert.equal(adminList.length,3);
 // A room with no assigned supervisor pages only the admin device, never another supervisor's phone.
 calls.length=0;clock+=100000;
 const unassigned=await(await request('/api/rooms',{method:'POST',cookie,body:{title:'Phòng trống'}})).json();
 const unassignedRoster=await(await request(`/api/rooms/${unassigned.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'C',name:'Học sinh C',seat_id:'S01'}]}})).json();
 const unassignedLogin=await request('/api/join',{method:'POST',body:{roomCode:unassigned.code,accessCode:unassignedRoster.students[0].access_code}});
 await request(`/api/rooms/${unassigned.id}/events`,{method:'POST',cookie:unassignedLogin.headers.get('set-cookie').split(';')[0],body:{events:[{...sampleEvent('other-room'),seatId:'S01'}]}});
 await system.notifications.wake();
 assert.deepEqual(calls.map(call=>call.endpoint),['https://push.example.com/push/admin-phone']);
 const adminDeviceId=(await(await request('/api/push',{cookie})).json()).devices[0].id;
 assert.equal((await request('/api/push/subscription',{method:'DELETE',cookie:proctorCookie,body:{id:adminDeviceId}})).status,404);
 const ownId=(await(await request('/api/push',{cookie:proctorCookie})).json()).devices[0].id;
 assert.equal((await request('/api/push/subscription',{method:'DELETE',cookie:proctorCookie,body:{id:ownId}})).status,200);
 assert.equal((await(await request('/api/push',{cookie})).json()).devices.length,1,'the admin device survives another account unregistering its own phone');
});
test('sleep observations push the correct Vietnamese warning label',async t=>{
 const calls=[];
 const {request,cookie,room,system}=await fixture(t,{sendImpl:async(_sub,payload)=>{calls.push(JSON.parse(payload));return{statusCode:201};}});
 await request('/api/push/subscription',{method:'POST',cookie,body:device('label-phone')});
 const event={...sampleEvent('sleep-warning'),rule:'sleep',risk:50,duration:3};
 assert.equal((await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie,body:{events:[event]}})).status,200);await system.notifications.wake();
 const state=await(await request(`/api/rooms/${room.id}`,{cookie})).json();
 assert.equal(state.events[0].rule,'sleep');assert.equal(state.events[0].push_status,'sent');assert.equal(calls.length,1);assert.match(calls[0].body,/ngủ gật/);
});

test('password change requires admin/current password, revokes all admin sessions and preserves student data',async t=>{
 const {request,cookie,room,system,directory}=await fixture(t);
 const nextPassword='synthetic-new-password-only';
 const body={currentPassword:password,newPassword:nextPassword,confirmPassword:nextPassword};
 const secondLogin=await request('/api/login',{method:'POST',body:{password}});const secondCookie=secondLogin.headers.get('set-cookie').split(';')[0];
 const oldSession=system.db.prepare("SELECT * FROM sessions WHERE role='admin' LIMIT 1").get();
 const roster=await(await request(`/api/rooms/${room.id}/students`,{method:'POST',cookie,body:{students:[{student_id:'P1',name:'Synthetic password student'}]}})).json();
 const studentLogin=await request('/api/join',{method:'POST',body:{roomCode:room.code,accessCode:roster.students[0].access_code}});const studentCookie=studentLogin.headers.get('set-cookie').split(';')[0];
 await request(`/api/rooms/${room.id}/events`,{method:'POST',cookie:studentCookie,body:{events:[sampleEvent('keep-after-password')]}});
 const initialFile=readFileSync(path.join(directory,'admin.json'),'utf8');
 assert.equal((await request('/api/admin/password',{method:'POST',body})).status,401);
 assert.equal((await request('/api/admin/password',{method:'POST',cookie:studentCookie,body})).status,403);
 assert.equal((await request('/api/admin/password',{method:'POST',cookie,body,headers:{Origin:'https://elsewhere.invalid'}})).status,403);
 for(const invalid of [{...body,currentPassword:'wrong'},{...body,newPassword:'short',confirmPassword:'short'},{...body,newPassword:'x'.repeat(201),confirmPassword:'x'.repeat(201)},{...body,confirmPassword:'does-not-match'},{currentPassword:password,newPassword:password,confirmPassword:password}]){
  assert.ok([400,401].includes((await request('/api/admin/password',{method:'POST',cookie,body:invalid})).status));
 }
 assert.equal(readFileSync(path.join(directory,'admin.json'),'utf8'),initialFile);
 const stream=await request(`/api/rooms/${room.id}/stream`,{cookie:secondCookie});const reader=stream.body.getReader();await reader.read();
 const changed=await request('/api/admin/password',{method:'POST',cookie,body});assert.equal(changed.status,200);assert.match(changed.headers.get('set-cookie'),/focuslab_session=;/);
 const ended=await reader.read();assert.equal(ended.done,true);
 assert.equal((await request('/api/me',{cookie})).status,401);assert.equal((await request('/api/me',{cookie:secondCookie})).status,401);
 assert.equal((await request('/api/me',{cookie:studentCookie})).status,200);
 assert.equal((await request('/api/login',{method:'POST',body:{password}})).status,401);
 const newLogin=await request('/api/login',{method:'POST',body:{password:nextPassword}});assert.equal(newLogin.status,200);const newCookie=newLogin.headers.get('set-cookie').split(';')[0];
 const state=await(await request(`/api/rooms/${room.id}`,{cookie:newCookie})).json();assert.equal(state.students.length,1);assert.equal(state.eventCount,1);assert.equal(state.room.code,room.code);
 assert.ok(!readFileSync(path.join(directory,'admin.json'),'utf8').includes(nextPassword));
 // Simulate a crash after file replacement but before session deletion.
 system.db.prepare('INSERT INTO sessions(hash,role,student_id,room_id,expires,admin_version) VALUES(?,?,?,?,?,?)').run(oldSession.hash,oldSession.role,oldSession.student_id,oldSession.room_id,oldSession.expires,oldSession.admin_version);
 assert.equal((await request('/api/me',{cookie})).status,401);
 const restart=createApp({dataDir:directory,adminPassword:password});
 const server=restart.app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
 // Windows keeps a byte lock on an open SQLite file, so release the restart instance before the temp folder is removed.
 const stopRestart=async()=>{server.closeAllConnections();await new Promise(resolve=>{try{server.close(resolve);}catch{resolve();}});try{await restart.close();}catch{}};
 t.after(stopRestart);
 const base=`http://127.0.0.1:${server.address().port}`;
 assert.equal((await fetch(base+'/api/me',{headers:{Cookie:cookie}})).status,401);
 assert.equal((await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:nextPassword})})).status,200);
 assert.equal((await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password})})).status,401);
 await stopRestart();
});
test('password change attempts are rate limited without changing credentials',async t=>{
 const {request,cookie,directory}=await fixture(t),before=readFileSync(path.join(directory,'admin.json'),'utf8');
 for(let i=0;i<10;i++)assert.equal((await request('/api/admin/password',{method:'POST',cookie,body:{currentPassword:'wrong',newPassword:'synthetic-next-password',confirmPassword:'synthetic-next-password'}})).status,401);
 assert.equal((await request('/api/admin/password',{method:'POST',cookie,body:{currentPassword:password,newPassword:'synthetic-next-password',confirmPassword:'synthetic-next-password'}})).status,429);
 assert.equal(readFileSync(path.join(directory,'admin.json'),'utf8'),before);
});
test('legacy session schema upgrades without discarding students; old admin sessions require login',async t=>{
 const {DatabaseSync}=await import('node:sqlite');const {digest}=await import('./auth.mjs');
 const directory=mkdtempSync(path.join(tmpdir(),'focuslab-session-upgrade-'));const db=new DatabaseSync(path.join(directory,'focuslab.sqlite'));
 db.exec('CREATE TABLE sessions(hash TEXT PRIMARY KEY,role TEXT,student_id TEXT,room_id TEXT,expires INTEGER)');
 for(const role of ['student','admin'])db.prepare('INSERT INTO sessions VALUES(?,?,?,?,?)').run(digest('legacy-'+role),role,null,null,Date.now()+60000);db.close();
 const system=createApp({dataDir:directory,adminPassword:password});const server=system.app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));t.after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));await system.close();rmSync(directory,{recursive:true,force:true});});
 const base=`http://127.0.0.1:${server.address().port}`;
 assert.equal((await fetch(base+'/api/me',{headers:{Cookie:'focuslab_session=legacy-student'}})).status,200);
 assert.equal((await fetch(base+'/api/me',{headers:{Cookie:'focuslab_session=legacy-admin'}})).status,401);
 assert.equal(system.db.prepare('SELECT COUNT(*) n FROM sessions').get().n,2);
});
