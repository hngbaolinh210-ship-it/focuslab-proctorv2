import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { isPublicPushEndpoint, loadVapidKeys, pushConfig } from './push.mjs';

test('only public https push endpoints are accepted', () => {
  for (const valid of ['https://fcm.googleapis.com/fcm/send/abc', 'https://updates.push.services.mozilla.com/wpush/v2/abc']) {
    assert.equal(isPublicPushEndpoint(valid), true, valid);
  }
  for (const invalid of ['', 'not a url', 'http://push.example.com/p', 'https://user:pass@push.example.com/p',
    'https://localhost:8443/push', 'https://127.0.0.1/push', 'https://10.1.2.3/push', 'https://192.168.0.9/push',
    'https://172.16.4.4/push', 'https://169.254.1.1/push', 'https://[fd00::1]/push', 'https://[fe80::1]/push',
    'https://internal/push', 'https://printer.local/push', `https://push.example.com/${'a'.repeat(2000)}`]) {
    assert.equal(isPublicPushEndpoint(invalid), false, invalid);
  }
});
test('VAPID keys are created once, stored privately, and reused after restart', t => {
  const directory = mkdtempSync(path.join(tmpdir(), 'focuslab-vapid-')); t.after(() => rmSync(directory, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }));
  let generated = 0;
  const first = loadVapidKeys(directory, {}, () => { generated++; return { publicKey: 'synthetic-public', privateKey: 'synthetic-private' }; });
  const second = loadVapidKeys(directory, {}, () => { generated++; return { publicKey: 'other', privateKey: 'other' }; });
  assert.deepEqual(first, { publicKey: 'synthetic-public', privateKey: 'synthetic-private' });
  assert.deepEqual(second, first);
  assert.equal(generated, 1);
  assert.equal(readFileSync(path.join(directory, 'vapid.json'), 'utf8').includes('synthetic-private'), true);
  assert.deepEqual(loadVapidKeys(directory, { PUSH_VAPID_PUBLIC_KEY: 'env-public', PUSH_VAPID_PRIVATE_KEY: 'env-private' }), { publicKey: 'env-public', privateKey: 'env-private' });
});
test('push thresholds fall back when the environment is wrong', () => {
  assert.deepEqual(pushConfig({}), { minRisk: 40, cooldownSeconds: 60, subject: 'mailto:admin@focuslab.app' });
  assert.deepEqual(pushConfig({ PUSH_MIN_RISK: '75', PUSH_COOLDOWN_SECONDS: '0' }), { minRisk: 75, cooldownSeconds: 0, subject: 'mailto:admin@focuslab.app' });
  assert.equal(pushConfig({ PUSH_MIN_RISK: '900', PUSH_COOLDOWN_SECONDS: '-5' }).minRisk, 40);
  assert.equal(pushConfig({ PUSH_COOLDOWN_SECONDS: '9000' }).cooldownSeconds, 60);
  assert.equal(pushConfig({ PUSH_SUBJECT: 'mailto:owner@truong.edu.vn' }).subject, 'mailto:owner@truong.edu.vn');
  assert.equal(pushConfig({ PUSH_SUBJECT: 'https://evil.example.com' }).subject, 'mailto:admin@focuslab.app');
});
