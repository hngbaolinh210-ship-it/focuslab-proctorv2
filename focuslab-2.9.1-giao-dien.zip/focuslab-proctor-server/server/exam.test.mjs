import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from './app.mjs';

const password = 'synthetic-test-password-only';
const DAY = 86400000;

async function fixture(t, appOptions = {}) {
  const directory = mkdtempSync(path.join(tmpdir(), 'focuslab-exam-'));
  const system = createApp({ dataDir: directory, adminPassword: password, ...appOptions });
  const server = system.app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await system.close(); rmSync(directory, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }); });
  async function request(route, { cookie, body, method = 'GET' } = {}) {
    const response = await fetch(base + route, { method, headers: { ...(cookie ? { Cookie: cookie } : {}), ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, data: await response.json().catch(() => null), cookie: response.headers.get('set-cookie')?.split(';')[0] };
  }
  const admin = await request('/api/login', { method: 'POST', body: { password } });
  const room = (await request('/api/rooms', { method: 'POST', cookie: admin.cookie, body: { title: 'Exam room' } })).data;
  const other = (await request('/api/rooms', { method: 'POST', cookie: admin.cookie, body: { title: 'Other room' } })).data;
  const roster = (await request(`/api/rooms/${room.id}/students`, { method: 'POST', cookie: admin.cookie, body: { students: [{ student_id: 'HS1', name: 'An' }, { student_id: 'HS2', name: 'Binh' }] } })).data;
  const otherRoster = (await request(`/api/rooms/${other.id}/students`, { method: 'POST', cookie: admin.cookie, body: { students: [{ student_id: 'HS9', name: 'Cuong' }] } })).data;
  const join = async list => Promise.all(list.students.map(async s => ({ ...s, cookie: (await request('/api/join', { method: 'POST', body: { roomCode: list.roomCode ?? room.code, accessCode: s.access_code } })).cookie })));
  const students = await join({ students: roster.students });
  const outsiders = await join({ students: otherRoster.students, roomCode: other.code });
  const paper = [
    { type: 'mcq', text: 'Chọn đáp án đúng: 把 + ?', options: ['S1 + 把 + S2 + V', 'S1 + V + 把 + S2'], answer: 0, points: 3 },
    { type: 'mcq', text: 'Câu nào sai?', options: ['A', 'B', 'C'], answer: 2, points: 2 },
    { type: 'text', text: 'Đặt một câu với chữ 把', prompt: 'Viết khoảng 30 từ', points: 5 },
  ];
  const created = await request(`/api/rooms/${room.id}/tests`, { method: 'POST', cookie: admin.cookie, body: { title: 'Kiểm tra buổi 5', durationMinutes: 30, questions: paper } });
  const testId = created.data.id;
  await request(`/api/tests/${testId}/publish`, { method: 'POST', cookie: admin.cookie, body: {} });
  return { system, request, admin: admin.cookie, room, other, students, outsiders, testId };
}

test('a published paper reaches its students without the answer key', async t => {
  const f = await fixture(t);
  const { request, admin, students, testId } = f;
  assert.equal((await request('/api/rooms/whatever/tests')).status, 401);
  assert.equal((await request(`/api/tests/${testId}/publish`, { method: 'POST', cookie: students[0].cookie, body: {} })).status, 403);

  const list = await request('/api/exams', { cookie: students[0].cookie });
  assert.equal(list.status, 200);
  assert.deepEqual(list.data.map(e => [e.title, e.questionCount, e.maxPoints]), [['Kiểm tra buổi 5', 3, 10]]);

  const paper = await request(`/api/exams/${testId}/paper`, { cookie: students[0].cookie });
  assert.equal(paper.status, 200);
  assert.equal(paper.data.attempt, null);
  assert.equal(JSON.stringify(paper.data.questions).includes('"answer"'), false, 'the paper must not carry the answer key');
  assert.equal(JSON.stringify(paper.data.questions).includes('Câu nào sai?'), true);

  assert.equal((await request(`/api/exams/${testId}/paper`, { cookie: f.outsiders[0].cookie })).status, 403);
  assert.equal((await request(`/api/tests/${testId}/results`, { cookie: students[0].cookie })).status, 403);
  assert.equal((await request(`/api/exams/${testId}/paper`, { cookie: admin })).status, 403, 'staff does not sit the paper');

  // The editor needs the key; only a staff cookie may see it.
  const editable = await request(`/api/tests/${testId}`, { cookie: admin });
  assert.equal(editable.status, 200);
  assert.deepEqual(editable.data.questions.map(q => q.answer), [0, 2, undefined]);
  assert.equal(editable.data.maxPoints, 10);
  assert.equal((await request(`/api/tests/${testId}`, { cookie: students[0].cookie })).status, 403, 'a student can never read the answer key');
  assert.equal((await request(`/api/tests/${testId}`, { cookie: f.outsiders[0].cookie })).status, 403);

  const broken = await request(`/api/rooms/${f.room.id}/tests`, { method: 'POST', cookie: admin, body: { title: 'Lỗi', durationMinutes: 30, questions: [{ type: 'mcq', text: 'hỏi', options: ['a', 'b'], points: 1 }] } });
  assert.equal(broken.status, 400);
  assert.equal((await request(`/api/rooms/${f.room.id}/tests`, { method: 'POST', cookie: admin, body: { title: 'Lỗi', durationMinutes: 3, questions: paper } })).status, 400);
});

test('answers are saved, frozen on submit and graded on the server', async t => {
  const f = await fixture(t);
  const { request, students, testId } = f;
  const [an, binh] = students;

  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: '1' } } })).status, 409, 'no start yet');
  assert.equal((await request(`/api/tests/${testId}`, { method: 'PUT', cookie: f.admin, body: { durationMinutes: 40, questions: [] } })).status, 400, 'an empty paper is rejected before anything is frozen');
  assert.equal((await request(`/api/exams/${testId}/start`, { method: 'POST', cookie: an.cookie, body: {} })).status, 201);
  assert.equal((await request(`/api/exams/${testId}/start`, { method: 'POST', cookie: an.cookie, body: {} })).status, 200);

  const saved = await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: 0, 1: 2, 2: '  我把书放在桌子上。  ' }, tabMs: 45000, tabEvents: 3, pasteCount: 1 } });
  assert.equal(saved.status, 200);
  assert.ok(saved.data.remainingSeconds > 29 * 60);

  // A tampered tab cannot erase the trail of leaving the room.
  const lower = await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: 0 }, tabMs: 1000, tabEvents: 0, pasteCount: 0 } });
  assert.equal(lower.data.saved, 45000);
  assert.equal(lower.data.tabEvents, 3);

  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 99: 'x' } } })).status, 400);
  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 1: 9 } } })).status, 400, 'option index outside the paper');

  const submitted = await request(`/api/exams/${testId}/submit`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: 0, 1: 1, 2: 'Tôi đã sửa câu trả lời.' } } });
  assert.equal(submitted.status, 200);
  // câu 1 đúng (+3), câu 2 chọn sai (0), tự luận không tự chấm -> 3/10
  assert.deepEqual({ score: submitted.data.score, maxPoints: submitted.data.maxPoints }, { score: 3, maxPoints: 10 });

  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: 1 } } })).status, 409);
  assert.equal((await request(`/api/exams/${testId}/submit`, { method: 'POST', cookie: an.cookie, body: {} })).data.already, true);

  const mine = await request(`/api/exams/${testId}/paper`, { cookie: an.cookie });
  assert.equal(mine.data.attempt.closed, true);
  assert.equal(mine.data.attempt.answers[2], 'Tôi đã sửa câu trả lời.');

  const board = await request(`/api/rooms/${f.room.id}/tests`, { cookie: f.admin });
  const row = board.data[0].attempts.find(a => a.studentCode === 'HS1');
  assert.equal(row.score, 3);
  assert.equal(row.tabMs, 45000);
  assert.equal(board.data[0].attempts.find(a => a.studentCode === 'HS2'), undefined, 'Binh never opened the paper');

  await request(`/api/exams/${testId}/start`, { method: 'POST', cookie: binh.cookie, body: {} });
  await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: binh.cookie, body: { answers: { 0: 0 } } });
  const results = await request(`/api/tests/${testId}/results`, { cookie: f.admin });
  assert.deepEqual(results.data.attempts.map(a => [a.studentCode, a.score, Object.keys(a.answers).length]), [['HS1', 3, 3], ['HS2', null, 1]]);

  assert.equal((await request(`/api/tests/${testId}`, { method: 'PUT', cookie: f.admin, body: { durationMinutes: 40 } })).status, 409, 'no editing once something is submitted');
});

test('a bare submit grades the saved work instead of rejecting the student', async t => {
  const f = await fixture(t);
  const { request, students, testId, admin } = f;
  const an = students[0];
  await request(`/api/exams/${testId}/start`, { method: 'POST', cookie: an.cookie, body: {} });
  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: an.cookie, body: { answers: { 0: 0, 1: 2 }, tabMs: 90000, tabEvents: 2, pasteCount: 1 } })).status, 200);
  // The page's bell posts nothing but the route; a 400 there would leave a student staring at an unsubmitted paper.
  const bell = await request(`/api/exams/${testId}/submit`, { method: 'POST', cookie: an.cookie, body: {} });
  assert.equal(bell.status, 200);
  assert.deepEqual({ score: bell.data.score, maxPoints: bell.data.maxPoints, graded: bell.data.graded }, { score: 5, maxPoints: 10, graded: 'submitted' });
  const results = await request(`/api/tests/${testId}/results`, { cookie: admin });
  const attempt = results.data.attempts.find(a => a.seatId === 'S01');
  assert.deepEqual({ tabMs: attempt.tabMs, tabEvents: attempt.tabEvents, pasteCount: attempt.pasteCount }, { tabMs: 90000, tabEvents: 2, pasteCount: 1 }, 'the saved integrity counters travel with the submission');
});

test('the clock is owned by the server: a late tab still gets its saved work graded', async t => {
  const f = await fixture(t);
  const { system, request, students, testId, admin } = f;
  await request(`/api/exams/${testId}/start`, { method: 'POST', cookie: students[1].cookie, body: {} });
  await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: students[1].cookie, body: { answers: { 0: 0, 1: 2 } } });

  const attempt = system.db.prepare('SELECT * FROM attempts WHERE test_id=? AND student_id=?').get(testId, students[1].id);
  // Past the 30-minute paper and its 90-second grace window: the bell has rung on the server clock.
  system.db.prepare('UPDATE attempts SET started_at=? WHERE id=?').run(Date.now() - 32 * 60000, attempt.id);

  assert.equal((await request(`/api/exams/${testId}/save`, { method: 'POST', cookie: students[1].cookie, body: { answers: { 0: 1 } } })).status, 409, 'the bell froze the paper');
  // late answers in the submit body must be ignored, not graded
  const late = await request(`/api/exams/${testId}/submit`, { method: 'POST', cookie: students[1].cookie, body: { answers: { 0: 1, 1: 1 } } });
  assert.equal(late.status, 200);
  assert.equal(late.data.score, 5, 'graded from what was saved before the deadline');
  assert.equal(late.data.graded, 'auto');

  const reloaded = await request(`/api/exams/${testId}/paper`, { cookie: students[1].cookie });
  assert.equal(reloaded.data.attempt.remainingSeconds, 0);
  assert.equal(reloaded.data.attempt.answers[0], 0);

  await request(`/api/tests/${testId}/publish`, { method: 'POST', cookie: admin, body: {} });
  assert.equal((await request(`/api/exams/${testId}/paper`, { cookie: students[1].cookie })).status, 409, 'unpublished again closes the door');

  // Integrity warnings travel on the alert road he already uses: the same events route, board and push.
  const now = new Date().toISOString();
  const alert = await request(`/api/rooms/${f.room.id}/events`, { method: 'POST', cookie: students[1].cookie, body: { events: [
    { clientId: 'tab-1', rule: 'tab_left', risk: 70, seatId: 'S02', duration: 40, time: now, resolved: null, offset: null },
    { clientId: 'paste-1', rule: 'paste', risk: 60, seatId: 'S02', duration: 1, time: now, resolved: now, offset: null },
  ] } });
  assert.equal(alert.status, 200);
  const board = await request(`/api/rooms/${f.room.id}`, { cookie: admin });
  const flagged = board.data.events.filter(e => ['tab_left', 'paste'].includes(e.rule));
  assert.deepEqual(flagged.map(e => [e.seat_id, e.rule, e.risk]), [['S02', 'paste', 60], ['S02', 'tab_left', 70]]);
  assert.deepEqual(flagged.map(e => e.student_id), [students[1].id, students[1].id], 'the warning names the student who left the paper');

  const rules = (await import('../src/proctoring.js')).RULES;
  assert.ok(rules.tab_left.risk >= 70 && rules.paste.risk >= 50 && rules.idle.risk >= 30, 'exam integrity rules must be alert-worthy');
});
