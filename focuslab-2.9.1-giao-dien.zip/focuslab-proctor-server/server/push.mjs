import webpush from 'web-push';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { RULES } from '../src/proctoring.js';

const PRIVATE_ADDRESS = /(^|\.)(localhost|internal|local)$/i;

// A push endpoint is a URL this server POSTs to, so it must never point at a private host.
export function isPublicPushEndpoint(value) {
  if (typeof value !== 'string' || !value || value.length > 2000) return false;
  let url;
  try { url = new URL(value); } catch { return false; }
  if (url.protocol !== 'https:' || url.username || url.password) return false;
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (PRIVATE_ADDRESS.test(host)) return false;
  if (/^0\./.test(host) || host === '127.0.0.1' || host === '::1') return false;
  if (/^10\./.test(host) || /^192\.168\./.test(host)) return false;
  if (/^169\.254\./.test(host)) return false;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(host)) return false;
  if (host.includes(':') && /^(f[cd]|fe[89ab])/i.test(host)) return false; // IPv6 unique-local and link-local
  return true;
}

export function loadVapidKeys(dataDir, env = process.env, generate = webpush.generateVAPIDKeys) {
  const configuredPublic = env.PUSH_VAPID_PUBLIC_KEY?.trim();
  const configuredPrivate = env.PUSH_VAPID_PRIVATE_KEY?.trim();
  if (configuredPublic && configuredPrivate) return { publicKey: configuredPublic, privateKey: configuredPrivate };
  const file = path.join(dataDir, 'vapid.json');
  if (existsSync(file)) {
    const stored = JSON.parse(readFileSync(file, 'utf8'));
    if (stored.publicKey && stored.privateKey) return { publicKey: stored.publicKey, privateKey: stored.privateKey };
  }
  const keys = generate();
  writeFileSync(file, JSON.stringify({ publicKey: keys.publicKey, privateKey: keys.privateKey }), { mode: 0o600, flag: 'wx' });
  return { publicKey: keys.publicKey, privateKey: keys.privateKey };
}

export function pushConfig(env = process.env) {
  const number = (value, fallback, min, max) => {
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
  };
  const subject = env.PUSH_SUBJECT?.trim();
  return {
    minRisk: number(env.PUSH_MIN_RISK, 40, 0, 100),
    cooldownSeconds: number(env.PUSH_COOLDOWN_SECONDS, 60, 0, 3600),
    subject: /^mailto:.{3,120}$/.test(subject) ? subject : 'mailto:admin@focuslab.app',
  };
}

// One persisted job per event, delivered to every phone registered by the supervisors of that room.
export function createPush(db, {
  dataDir, env = process.env, config = pushConfig(env), keys = loadVapidKeys(dataDir, env),
  sendImpl = defaultSend, now = Date.now, onChange = () => {}
} = {}) {
  db.exec(`CREATE TABLE IF NOT EXISTS push_subscriptions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, endpoint TEXT UNIQUE NOT NULL,
    p256dh TEXT NOT NULL, auth TEXT NOT NULL, proctor_id TEXT REFERENCES proctors(id),
    label TEXT, created_at INTEGER NOT NULL, last_sent INTEGER);
  CREATE TABLE IF NOT EXISTS push_notifications(
    id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER UNIQUE REFERENCES events(id),
    room_id TEXT REFERENCES rooms(id), seat_id TEXT, rule TEXT, title TEXT NOT NULL, body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0,
    devices INTEGER NOT NULL DEFAULT 0, delivered INTEGER NOT NULL DEFAULT 0,
    next_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, error TEXT);
  CREATE INDEX IF NOT EXISTS push_pending ON push_notifications(status,next_at);
  CREATE INDEX IF NOT EXISTS push_room ON push_notifications(room_id,seat_id,rule,status,id);`);
  db.prepare("UPDATE push_notifications SET status='pending' WHERE status='sending'").run();
  webpush.setVapidDetails(config.subject, keys.publicKey, keys.privateKey);
  let stopped = false, running = null, nextSendAt = 0;

  function devices(roomId) {
    const adminDevices = db.prepare('SELECT * FROM push_subscriptions WHERE proctor_id IS NULL').all();
    const staffDevices = db.prepare(`SELECT p.* FROM push_subscriptions p JOIN room_proctors rp ON rp.proctor_id=p.proctor_id
      WHERE rp.room_id=? AND p.proctor_id IS NOT NULL`).all(roomId);
    return [...adminDevices, ...staffDevices];
  }

  function subscribe({ endpoint, keys: k, proctorId = null, label = null }) {
    if (!isPublicPushEndpoint(endpoint)) throw new Error('ENDPOINT');
    if (typeof k?.p256dh !== 'string' || typeof k.auth !== 'string' || !k.p256dh || !k.auth || k.p256dh.length > 200 || k.auth.length > 100) throw new Error('KEYS');
    const at = now();
    db.prepare(`INSERT INTO push_subscriptions(endpoint,p256dh,auth,proctor_id,label,created_at) VALUES(?,?,?,?,?,?)
      ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth,proctor_id=excluded.proctor_id,label=excluded.label`)
      .run(endpoint, k.p256dh, k.auth, proctorId, String(label ?? '').slice(0, 60) || null, at);
    return db.prepare('SELECT id,endpoint,label,created_at FROM push_subscriptions WHERE endpoint=?').get(endpoint);
  }

  // A device may unregister itself, but never remove another supervisor's phone.
  function unsubscribe(id, identity) {
    const owner = identity?.role === 'admin' ? 'proctor_id IS NULL' : 'proctor_id=?';
    const args = identity?.role === 'admin' ? [] : [identity?.proctor_id];
    return db.prepare(`DELETE FROM push_subscriptions WHERE id=? AND ${owner}`).run(Number(id), ...args).changes > 0;
  }

  function describe(event) {
    const room = db.prepare('SELECT title FROM rooms WHERE id=?').get(event.room_id);
    const student = event.student_id && db.prepare('SELECT name,student_code FROM students WHERE id=?').get(event.student_id);
    return {
      title: `FocusLab · Phòng ${room?.title ?? event.room_id}`,
      body: `${student ? student.name + ' (' + student.student_code + ')' : event.seat_id} · chỗ ${event.seat_id}\n`
        + `${RULES[event.rule]?.label ?? event.rule} · rủi ro ${event.risk}/100\n`
        + `Lúc ${new Date(event.received_at).toLocaleString('vi-VN')}`,
    };
  }

  function suppressed(roomId, seatId, rule) {
    if (!config.cooldownSeconds) return false;
    const last = db.prepare(`SELECT updated_at FROM push_notifications WHERE room_id=? AND seat_id=? AND rule=? AND status='sent' ORDER BY id DESC LIMIT 1`)
      .get(roomId, seatId, rule);
    return Boolean(last) && now() - last.updated_at < config.cooldownSeconds * 1000;
  }

  function enqueue(event) {
    if (event.risk < config.minRisk || JSON.parse(event.payload).resolved !== null) return;
    if (!devices(event.room_id).length) return;
    if (suppressed(event.room_id, event.seat_id, event.rule)) return;
    const { title, body } = describe(event);
    db.prepare(`INSERT OR IGNORE INTO push_notifications(event_id,room_id,seat_id,rule,title,body,next_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?)`).run(event.id, event.room_id, event.seat_id, event.rule, title, body.slice(0, 900), now(), now());
  }

  function status(roomId) {
    const counts = { pending: 0, sending: 0, sent: 0, failed: 0 };
    for (const row of db.prepare('SELECT status,COUNT(*) n FROM push_notifications WHERE room_id=? GROUP BY status').all(roomId)) counts[row.status] = (counts[row.status] ?? 0) + row.n;
    const devicesInRoom = devices(roomId).length;
    return { minRisk: config.minRisk, cooldownSeconds: config.cooldownSeconds, devices: devicesInRoom, ...counts };
  }

  async function processOne() {
    if (stopped || now() < nextSendAt) return;
    const job = db.prepare("SELECT * FROM push_notifications WHERE status='pending' AND next_at<=? ORDER BY id LIMIT 1").get(now());
    if (!job) return;
    const targets = devices(job.room_id);
    if (!targets.length) {
      db.prepare("UPDATE push_notifications SET status='failed',devices=0,error='Chưa có điện thoại nào đăng ký nhận thông báo.' WHERE id=?").run(job.id);
      nextSendAt = now() + 1000;
      onChange(job.room_id);
      return;
    }
    const payload = JSON.stringify({ title: job.title, body: job.body, tag: `focuslab-${job.room_id}` });
    db.prepare("UPDATE push_notifications SET status='sending',devices=?,updated_at=? WHERE id=?").run(targets.length, now(), job.id);
    const settled = await Promise.all(targets.map(async target => {
      try {
        const outcome = await sendImpl({ endpoint: target.endpoint, keys: { p256dh: target.p256dh, auth: target.auth } }, payload);
        return { target, ...outcome };
      } catch (error) {
        return { target, error: error?.message ?? 'Lỗi gửi', retry: Boolean(error?.retry), gone: Boolean(error?.gone) };
      }
    }));
    const delivered = settled.filter(entry => !entry.error).length;
    for (const entry of settled.filter(item => item.gone)) db.prepare('DELETE FROM push_subscriptions WHERE endpoint=?').run(entry.target.endpoint);
    const failures = settled.filter(entry => entry.error);
    const attempts = job.attempts + 1;
    const error = failures.length ? String(failures[0].error).slice(0, 200) : null;
    const state = delivered ? 'sent' : failures.every(entry => entry.retry) && attempts < 3 ? 'pending' : 'failed';
    if (state === 'sent') db.prepare("UPDATE push_notifications SET status='sent',delivered=?,devices=?,error=?,updated_at=? WHERE id=?")
      .run(delivered, settled.length, error, now(), job.id);
    else db.prepare('UPDATE push_notifications SET status=?,attempts=?,delivered=?,devices=?,next_at=?,updated_at=?,error=? WHERE id=?')
      .run(state, attempts, delivered, settled.length, now() + 30000 * attempts, now(), error, job.id);
    const at = now();
    for (const entry of settled.filter(item => !item.error)) db.prepare('UPDATE push_subscriptions SET last_sent=? WHERE endpoint=?').run(at, entry.target.endpoint);
    nextSendAt = now() + 1500;
    onChange(job.room_id);
  }

  function wake() {
    if (stopped) return Promise.resolve();
    if (!running) running = processOne().finally(() => { running = null; });
    return running;
  }

  // Test message goes to the requesting account's own phones only, so it cannot ring the whole team.
  async function testMessage(identity) {
    const rows = identity?.role === 'admin'
      ? db.prepare('SELECT * FROM push_subscriptions WHERE proctor_id IS NULL').all()
      : db.prepare('SELECT * FROM push_subscriptions WHERE proctor_id=?').all(identity?.proctor_id ?? '');
    if (!rows.length) return { sent: 0, error: 'Điện thoại này chưa đăng ký nhận thông báo. Hãy bấm Bật thông báo điện thoại.' };
    const payload = JSON.stringify({ title: 'FocusLab · Kiểm tra thông báo', body: 'Tin thử. Từ giờ cảnh báo phòng thi sẽ hiện ở đây, kể cả khi tắt web.', tag: 'focuslab-test' });
    const outcomes = await Promise.all(rows.map(async row => {
      try { return await sendImpl({ endpoint: row.endpoint, keys: { p256dh: row.p256dh, auth: row.auth } }, payload); }
      catch (error) { return { error: error?.message ?? 'Lỗi gửi', gone: Boolean(error?.gone) }; }
    }));
    for (const [index, outcome] of outcomes.entries()) if (outcome.gone) db.prepare('DELETE FROM push_subscriptions WHERE endpoint=?').run(rows[index].endpoint);
    const sent = outcomes.filter(outcome => !outcome.error).length;
    return { sent, total: rows.length, error: sent ? null : String(outcomes[0]?.error ?? 'Không gửi được').slice(0, 200) };
  }

  const timer = setInterval(wake, 2000); timer.unref();
  return {
    publicKey: keys.publicKey, config, devices, subscribe, unsubscribe, enqueue, status, wake, testMessage,
    async close() { stopped = true; clearInterval(timer); await running; }
  };
}

// Push services answer 201; 404/410 mean the device is gone, 429/5xx are worth retrying.
export async function defaultSend(subscription, payload) {
  const response = await webpush.sendNotification(subscription, payload, { TTL: 60, urgency: 'high', timeout: 10000 });
  if (response.statusCode >= 200 && response.statusCode < 300) return { statusCode: response.statusCode };
  const error = new Error(`Máy chủ đẩy trả ${response.statusCode}`);
  error.retry = response.statusCode === 429 || response.statusCode >= 500;
  error.gone = response.statusCode === 404 || response.statusCode === 410;
  throw error;
}
