import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, existsSync, readdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from './app.mjs';

const password = 'synthetic-test-password-only';
const EBML = Buffer.from([0x1a, 0x45, 0xdf, 0xa3]);
const FTYP = Buffer.concat([Buffer.alloc(4), Buffer.from('ftyp')]);
const DAY = 86400000;

function clipBody(size = 4096, mp4 = false) {
  const head = mp4 ? FTYP : EBML;
  return Buffer.concat([head, Buffer.alloc(Math.max(0, size - head.length), 0x20)]);
}
const alertEvent = clientId => ({ clientId, seatId: 'S01', rule: 'object', risk: 60, time: new Date().toISOString(), resolved: null, duration: 5, offset: null });

async function fixture(t, appOptions = {}) {
  const directory = mkdtempSync(path.join(tmpdir(), 'focuslab-clips-'));
  const system = createApp({ dataDir: directory, adminPassword: password, pushOptions: { sendImpl: async () => { throw new Error('no device should receive'); } }, ...appOptions });
  const server = system.app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await system.close(); rmSync(directory, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }); });

  async function request(route, { cookie, body, method = 'GET', headers = {} } = {}) {
    return fetch(base + route, { method, headers: { ...(cookie ? { Cookie: cookie } : {}), ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
  }
  async function upload(route, bytes, { cookie, contentType = 'video/webm' } = {}) {
    return fetch(base + route, { method: 'POST', headers: { ...(cookie ? { Cookie: cookie } : {}), 'Content-Type': contentType }, body: bytes });
  }
  const login = await request('/api/login', { method: 'POST', body: { password } });
  assert.equal(login.status, 200);
  const cookie = login.headers.get('set-cookie').split(';')[0];
  const room = await (await request('/api/rooms', { method: 'POST', cookie, body: { title: 'Clip room' } })).json();
  const roster = await (await request(`/api/rooms/${room.id}/students`, { method: 'POST', cookie, body: { students: [{ student_id: 'HS1', name: 'Student one' }, { student_id: 'HS2', name: 'Student two' }] } })).json();
  const students = [];
  for (const s of roster.students) {
    const joined = await request('/api/join', { method: 'POST', body: { roomCode: room.code, accessCode: s.access_code } });
    assert.equal(joined.status, 200);
    students.push({ ...s, cookie: joined.headers.get('set-cookie').split(';')[0] });
  }
  const clipFiles = () => readdirSync(path.join(directory, 'clips'));
  return { system, directory, request, upload, cookie, room, students, clipFiles, clipRoute: (clientId, { seat = 'S01', rule = 'object', risk = 60 } = {}) => `/api/rooms/${room.id}/clips?clientId=${clientId}&seat=${seat}&rule=${rule}&risk=${risk}` };
}

test('a clip is stored, linked to its alert, listed for staff and downloadable by its owner', async t => {
  const f = await fixture(t);
  const [hs1, hs2] = f.students;
  const bytes = clipBody();

  assert.equal((await f.upload(f.clipRoute('unsigned'), bytes)).status, 401);

  await (await f.request(`/api/rooms/${f.room.id}/events`, { method: 'POST', cookie: hs1.cookie, body: { events: [alertEvent('clip-1')] } })).json();
  const eventId = f.system.db.prepare('SELECT id FROM events WHERE room_id=? AND client_id=?').get(f.room.id, 'clip-1').id;

  const saved = await f.upload(f.clipRoute('clip-1'), bytes, { cookie: hs1.cookie });
  assert.equal(saved.status, 201);
  const { id, size } = await saved.json();
  assert.equal(size, bytes.length);
  assert.deepEqual(f.clipFiles(), [`${id}.webm`]);
  assert.deepEqual(readFileSync(path.join(f.directory, 'clips', `${id}.webm`)), bytes);

  const duplicate = await f.upload(f.clipRoute('clip-1'), bytes, { cookie: hs1.cookie });
  assert.equal(duplicate.status, 200);
  assert.equal((await duplicate.json()).duplicate, true);
  assert.equal(f.system.db.prepare('SELECT COUNT(*) n FROM clips').get().n, 1);

  const staffView = await (await f.request(`/api/rooms/${f.room.id}`, { cookie: f.cookie })).json();
  const listed = staffView.clips.find(clip => clip.id === id);
  assert.equal(listed.event_id, eventId);
  assert.equal(listed.seat_id, 'S01');
  assert.equal(listed.rule, 'object');
  assert.equal(listed.mime, 'video/webm');
  assert.equal(listed.expires_at - listed.created_at, 7 * DAY);

  const own = await f.request(`/api/clips/${id}/content`, { cookie: hs1.cookie });
  assert.equal(own.status, 200);
  assert.equal(own.headers.get('content-type'), 'video/webm');
  assert.match(own.headers.get('content-disposition'), /^attachment; filename="[0-9a-f-]+\.webm"$/);
  assert.deepEqual(Buffer.from(await own.arrayBuffer()), bytes);
  assert.equal((await f.request(`/api/clips/${id}/content`, { cookie: hs2.cookie })).status, 403);
  assert.equal((await f.request(`/api/clips/${id}`, { method: 'DELETE', cookie: hs1.cookie })).status, 403);

  assert.equal((await f.request(`/api/clips/${id}`, { method: 'DELETE', cookie: f.cookie })).status, 200);
  assert.equal(f.system.db.prepare('SELECT COUNT(*) n FROM clips').get().n, 0);
  assert.deepEqual(f.clipFiles(), []);
});

test('clip uploads are validated before anything touches the disk', async t => {
  const f = await fixture(t);
  const [hs1] = f.students;
  const other = await (await f.request('/api/rooms', { method: 'POST', cookie: f.cookie, body: { title: 'Other room' } })).json();

  assert.equal((await f.upload(`/api/rooms/${other.id}/clips?clientId=x&seat=S01&rule=object&risk=60`, clipBody(), { cookie: hs1.cookie })).status, 403);
  assert.equal((await f.upload(f.clipRoute('clip-proto', { rule: 'constructor' }), clipBody(), { cookie: hs1.cookie })).status, 400);
  assert.equal((await f.upload(f.clipRoute('clip-risk', { risk: 101 }), clipBody(), { cookie: hs1.cookie })).status, 400);
  assert.equal((await f.upload(f.clipRoute('../escape'), clipBody(), { cookie: hs1.cookie })).status, 400);
  assert.equal((await f.upload(f.clipRoute('clip-short'), clipBody(1024), { cookie: hs1.cookie })).status, 400);
  assert.equal((await f.upload(f.clipRoute('clip-text'), Buffer.alloc(4096, 0x41), { cookie: hs1.cookie })).status, 400);
  assert.equal((await f.upload(f.clipRoute('clip-empty'), Buffer.alloc(0), { cookie: hs1.cookie })).status, 400);
  assert.deepEqual(f.clipFiles(), []);
  assert.equal(f.system.db.prepare('SELECT COUNT(*) n FROM clips').get().n, 0);

  const mp4 = await f.upload(f.clipRoute('clip-mp4'), clipBody(4096, true), { cookie: hs1.cookie, contentType: 'video/mp4' });
  assert.equal(mp4.status, 201);
  const { id } = await mp4.json();
  assert.equal((await (await f.request(`/api/rooms/${f.room.id}`, { cookie: f.cookie })).json()).clips.find(clip => clip.id === id).mime, 'video/mp4');
  assert.deepEqual(f.clipFiles(), [`${id}.mp4`]);
});

test('an oversized clip is refused with 413 and the browser still gets the answer', async t => {
  const f = await fixture(t, { maxClipUploadBytes: 4096 });
  const [hs1] = f.students;
  const refused = await f.upload(f.clipRoute('clip-large'), clipBody(64 * 1024), { cookie: hs1.cookie });
  assert.equal(refused.status, 413);
  assert.ok((await refused.json()).error);
  assert.deepEqual(f.clipFiles(), []);
});

test('the clip volume keeps the newest evidence and drops the oldest', async t => {
  const f = await fixture(t, { maxClipStoreBytes: 8192 });
  const [hs1] = f.students;
  const ids = [];
  for (const clientId of ['clip-1', 'clip-2', 'clip-3']) {
    const response = await f.upload(f.clipRoute(clientId), clipBody(), { cookie: hs1.cookie });
    assert.equal(response.status, 201);
    ids.push((await response.json()).id);
  }
  const remaining = f.system.db.prepare('SELECT client_id FROM clips ORDER BY created_at ASC, rowid ASC').all();
  assert.deepEqual(remaining.map(row => row.client_id), ['clip-2', 'clip-3']);
  assert.equal(existsSync(path.join(f.directory, 'clips', `${ids[0]}.webm`)), false);
  assert.deepEqual(f.clipFiles().sort(), [`${ids[1]}.webm`, `${ids[2]}.webm`].sort());
});

test('clips expire on their own and the retention window follows configuration', async t => {
  const short = await fixture(t, { clipRetentionDays: 1 });
  const [student] = short.students;
  const created = await (await short.upload(short.clipRoute('clip-age'), clipBody(), { cookie: student.cookie })).json();
  const row = short.system.db.prepare('SELECT * FROM clips WHERE id=?').get(created.id);
  assert.equal(row.expires_at - row.created_at, DAY);

  short.system.db.prepare('UPDATE clips SET expires_at=? WHERE id=?').run(Date.now() - 1000, created.id);
  const expired = await short.request(`/api/clips/${created.id}/content`, { cookie: student.cookie });
  assert.equal(expired.status, 410);
  assert.equal(short.system.db.prepare('SELECT COUNT(*) n FROM clips').get().n, 0);
  assert.deepEqual(short.clipFiles(), []);

  assert.equal((await short.request(`/api/clips/${created.id}/content`, { cookie: short.cookie })).status, 404);
});
