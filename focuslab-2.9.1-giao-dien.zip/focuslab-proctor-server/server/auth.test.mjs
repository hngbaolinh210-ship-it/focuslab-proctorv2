import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync,readdirSync,statSync,mkdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {initializeAdmin,replaceAdminPassword,passwordMatches} from './auth.mjs';
test('atomic password replacement persists a private hash and leaves no temporary file',t=>{
 const dir=mkdtempSync(path.join(tmpdir(),'focuslab-auth-'));t.after(()=>rmSync(dir,{recursive:true,force:true}));
 initializeAdmin(dir,'synthetic-old-password');const hash=replaceAdminPassword(dir,'synthetic-new-password');
 assert.equal(passwordMatches('synthetic-new-password',hash),true);assert.equal(passwordMatches('synthetic-old-password',hash),false);
 assert.equal(initializeAdmin(dir,'synthetic-old-password'),hash);// POSIX file modes do not exist on Windows, so only assert them where they are honoured.
 if(process.platform!=='win32')assert.equal(statSync(path.join(dir,'admin.json')).mode&0o777,0o600);
 assert.deepEqual(readdirSync(dir),['admin.json']);const stored=readFileSync(path.join(dir,'admin.json'),'utf8');assert.ok(!stored.includes('synthetic-new-password'));
 for(const invalid of ['short','x'.repeat(201),null])assert.throws(()=>replaceAdminPassword(dir,invalid));assert.equal(readFileSync(path.join(dir,'admin.json'),'utf8'),stored);
});
test('failed replacement preserves its target and cleans up the temporary secret file',t=>{
 const dir=mkdtempSync(path.join(tmpdir(),'focuslab-auth-fail-'));t.after(()=>rmSync(dir,{recursive:true,force:true}));mkdirSync(path.join(dir,'admin.json'));
 assert.throws(()=>replaceAdminPassword(dir,'synthetic-new-password'));assert.deepEqual(readdirSync(dir),['admin.json']);assert.equal(statSync(path.join(dir,'admin.json')).isDirectory(),true);
});
