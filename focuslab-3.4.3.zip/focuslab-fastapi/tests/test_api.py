"""Chạy thử trọn luồng: giáo viên lập phòng → tải đề → học sinh vào thi → máy chấm → thầy cô xem kết quả."""
from __future__ import annotations

import io
import os
import re
import tempfile
import time
import unittest

from fastapi.testclient import TestClient

from app import main, papers

PAPER = [
    {"type": "mcq", "text": "Chọn đáp án đúng của 把", "options": ["bǎ", "ba", "bà"], "answer": 0, "points": 2},
    {"type": "mcq", "text": "Chọn đáp án đúng của 放", "options": ["fàng", "páng"], "answer": 1, "points": 3},
    {"type": "text", "text": "Đặt một câu với 放在", "prompt": "khoảng 30 từ", "points": 5},
]


class ApiTest(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.folder.cleanup)
        # một tiến trình duy nhất, nhiều máy truy cập vào — giống phòng thi thật
        self.application = main.create_app(os.path.join(self.folder.name, "thi.db"))
        self.addCleanup(self.application.state.store.close)
        self.client = self.new_client()

    def new_client(self) -> TestClient:
        client = TestClient(self.application)
        client.cookies.clear()
        return client

    def sign_in_teacher(self, client: TestClient | None = None, username="linhtc", password="phongthi2026") -> TestClient:
        client = client or self.client
        response = client.post("/api/teacher/setup", json={"username": username, "password": password, "display_name": "Cô Linh"})
        self.assertEqual(response.status_code, 200, response.text)
        return client

    def make_room(self, students=(("N01", "Nguyễn Văn An"), ("N02", "Trần Bình"))) -> tuple[str, list[dict]]:
        room = self.client.post("/api/rooms", json={"title": "Lớp 12A1"}).json()
        roster = self.client.put(f"/api/rooms/{room['id']}/students",
                                 json={"students": [{"student_code": c, "name": n} for c, n in students]}).json()["students"]
        return room["id"], roster

    def open_exam(self, room_id: str, duration=30, published=True) -> str:
        exam = self.client.post(f"/api/rooms/{room_id}/exams",
                                json={"title": "Kiểm tra buổi 5", "duration_minutes": duration, "questions": PAPER}).json()
        if published:
            self.client.post(f"/api/exams/{exam['id']}/publish", json={"published": True})
        return exam["id"]

    def open_homework(self, room_id: str, until=None, opens=None, duration=240) -> str:
        exam = self.client.post(f"/api/rooms/{room_id}/exams",
                                json={"title": "Bài tập buổi 6", "duration_minutes": duration, "questions": PAPER,
                                      "kind": "baotap", "open_from": opens, "open_until": until}).json()
        self.client.post(f"/api/exams/{exam['id']}/publish", json={"published": True})
        return exam["id"]

    def join(self, roster: list[dict], entry=0, code=None, student=None) -> TestClient:
        room = self.client.get("/api/rooms").json()[0]
        learner = self.new_client()
        body = {"room_code": room["code"], "student_code": student or roster[entry]["student_code"],
                "access_code": code or roster[entry]["join_code"]}
        response = learner.post("/api/join", json=body)
        self.assertEqual(response.status_code, 200, response.text)
        return learner

    # ---------------------------------------------------------------- tài khoản

    def test_first_account_becomes_owner_and_only_first(self):
        me = self.client.get("/api/me").json()
        self.assertIsNone(me["role"])
        self.sign_in_teacher()
        self.assertEqual(self.client.get("/api/me").json()["role"], "teacher")
        self.assertTrue(self.client.get("/api/me").json()["is_owner"])
        # tài khoản thứ hai không tự mở được từ trang đăng nhập
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "khac", "password": "matkhau123"}).status_code, 403)

    def test_login_rejects_wrong_password_and_unknown_user(self):
        self.client.post("/api/teacher/setup", json={"username": "linhtc", "password": "phongthi2026"})
        self.client.post("/api/logout")
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "linhtc", "password": "sai"}).status_code, 401)
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "khongco", "password": "phongthi2026"}).status_code, 401)
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "LINHTC", "password": "phongthi2026"}).status_code, 200)

    def test_login_before_any_account_points_at_setup(self):
        self.assertEqual(self.client.post("/api/teacher/login", json={"username": "a", "password": "b"}).status_code, 404)

    def test_repeated_wrong_password_locks_that_machine(self):
        self.sign_in_teacher()
        wrong = {"username": "linhtc", "password": "sai"}
        for _ in range(main.LOGIN_MAX_FAILS - 1):
            self.assertEqual(self.client.post("/api/teacher/login", json=wrong).status_code, 401)
        self.assertEqual(self.client.post("/api/teacher/login", json=wrong).status_code, 429)
        # đã khóa thì gõ đúng mật khẩu cũng phải chờ, nhưng tài khoản khác không liên lụy
        self.assertEqual(self.client.post("/api/teacher/login",
                                         json={"username": "linhtc", "password": "phongthi2026"}).status_code, 429)

    def test_correct_password_clears_the_lock_counter(self):
        self.sign_in_teacher()
        wrong = {"username": "linhtc", "password": "sai"}
        for _ in range(main.LOGIN_MAX_FAILS - 2):
            self.client.post("/api/teacher/login", json=wrong)
        self.assertEqual(self.client.post("/api/teacher/login",
                                          json={"username": "linhtc", "password": "phongthi2026"}).status_code, 200)
        for _ in range(main.LOGIN_MAX_FAILS - 1):
            self.assertEqual(self.client.post("/api/teacher/login", json=wrong).status_code, 401)

    def test_api_shape_is_not_public(self):
        """Máy chủ công khai không được liệt kê toàn bộ đường đi của API."""
        for url in ("/openapi.json", "/docs", "/redoc"):
            self.assertEqual(self.client.get(url).status_code, 404, url)

    def test_owner_can_invite_second_teacher(self):
        self.sign_in_teacher()
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": "thayhung", "password": "daythi2026",
                                                                      "display_name": "Thầy Hùng"}).status_code, 200)
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": "thayhung", "password": "daythi2026"}).status_code, 409)
        other = TestClient(self.client.app)
        other.cookies.clear()
        self.assertEqual(other.post("/api/teacher/login", json={"username": "thayhung", "password": "daythi2026"}).status_code, 200)

    def test_invite_ignores_case_and_accents_in_the_login_name_only(self):
        """Cô gõ "Cô Linh" hay "co linh" cho tên đăng nhập đều bị chặn, nhưng hai thầy cô trùng họ tên thì vẫn tạo được."""
        self.sign_in_teacher()
        for name in ("LINHTC", "linh.tc", "LinhTC"):
            taken = self.client.post("/api/teacher/invite", json={"username": name, "password": "daythi2026"})
            self.assertEqual(taken.status_code, 409, taken.text)
            self.assertIn("trùng với tài khoản đã có", taken.json()["detail"])
        second = self.client.post("/api/teacher/invite", json={"username": "co.linh.b", "password": "daythi2026",
                                                              "display_name": "Cô Linh"})
        self.assertEqual(second.status_code, 200, second.text)
        self.assertEqual(self.client.post("/api/teacher/invite",
                                          json={"username": "Cô Linh", "password": "daythi2026"}).status_code, 422)

    def test_owner_lists_teachers_and_downloads_the_backup(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        helper = self.second_teacher()
        self.assertEqual(helper.get("/api/teachers").status_code, 403)
        self.assertEqual(helper.get("/api/backup").status_code, 403)
        names = {row["username"] for row in self.client.get("/api/teachers").json()["teachers"]}
        self.assertEqual(names, {"linhtc", "thayhung"})
        dump = self.client.get("/api/backup")
        self.assertEqual(dump.status_code, 200, dump.text)
        self.assertIn("Lớp 12A1", dump.text)
        self.assertIn("CREATE TABLE", dump.text)
        self.assertIn("focuslab-", dump.headers["content-disposition"])

    def second_teacher(self, username="thayhung", password="daythi2026") -> TestClient:
        """Thầy cô thường: chỉ thấy phòng do mình lập, khác với tài khoản quản trị đầu tiên."""
        self.assertEqual(self.client.post("/api/teacher/invite", json={"username": username, "password": password,
                                                                      "display_name": "Thầy Hùng"}).status_code, 200)
        other = self.new_client()
        self.assertEqual(other.post("/api/teacher/login", json={"username": username, "password": password}).status_code, 200)
        return other

    def test_weak_credentials_are_rejected(self):
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "a", "password": "12345678"}).status_code, 422)
        self.assertEqual(self.client.post("/api/teacher/setup", json={"username": "linhtc", "password": "ngan"}).status_code, 422)

    def test_api_requires_login(self):
        self.assertEqual(self.client.get("/api/rooms").status_code, 401)
        self.assertEqual(self.client.get("/api/exams").status_code, 401)

    # ---------------------------------------------------------------- phòng và danh sách lớp

    def test_room_code_and_student_codes_are_short(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        room = self.client.get("/api/rooms").json()[0]
        self.assertRegex(room["code"], r"^[A-HJ-KM-Z2-9]{8}$")
        for student in roster:
            self.assertRegex(student["join_code"], r"^[A-HJ-KM-Z2-9]{8}$")
        self.assertEqual(len({s["join_code"] for s in roster}), len(roster))
        self.assertEqual([s["seat_id"] for s in roster], ["S01", "S02"])

    def test_join_accepts_lowercase_and_wrong_caps_lock(self):
        self.sign_in_teacher()
        _, roster = self.make_room()
        student = self.join(roster, code=roster[0]["join_code"].lower())
        self.assertEqual(student.get("/api/me").json()["role"], "student")

    def test_join_accepts_lowercase_student_code(self):
        """Cô in giấy ghi N01, em gõ n01 — không được bắt em gõ lại vì hoa thường."""
        self.sign_in_teacher()
        _, roster = self.make_room()
        student = self.join(roster, student=roster[0]["student_code"].lower())
        self.assertEqual(student.get("/api/me").json()["name"], roster[0]["name"])

    def test_join_rejects_wrong_code_unknown_student_and_closed_room(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        room = self.client.get("/api/rooms").json()[0]
        bad = self.new_client()
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N01",
                                                    "access_code": "SAIMASAI"}).status_code, 401)
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N99",
                                                    "access_code": roster[0]["join_code"]}).status_code, 401)
        self.client.patch(f"/api/rooms/{room_id}", json={"closed": True})
        self.assertEqual(bad.post("/api/join", json={"room_code": room["code"], "student_code": "N01",
                                                    "access_code": roster[0]["join_code"]}).status_code, 403)

    def test_roster_csv_upload_assigns_codes(self):
        self.sign_in_teacher()
        room = self.client.post("/api/rooms", json={"title": "Lớp 11B"}).json()
        data = io.BytesIO("Mã học sinh;Họ và tên\nM01;Phạm Minh\nM02;Lê Hoa\n".encode("utf-8-sig").replace(b";", b","))
        response = self.client.post(f"/api/rooms/{room['id']}/roster", files={"file": ("lop.csv", data, "text/csv")})
        self.assertEqual(response.status_code, 200, response.text)
        students = response.json()["students"]
        self.assertEqual([s["student_code"] for s in students], ["M01", "M02"])
        self.assertEqual(students[0]["name"], "Phạm Minh")

    def test_roster_replaces_previous_list_and_exports_codes(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        self.client.put(f"/api/rooms/{room_id}/students", json={"students": [{"student_code": "K01", "name": "Chỉ Một Em"}]})
        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual([s["student_code"] for s in state["students"]], ["K01"])
        csv = self.client.get(f"/api/rooms/{room_id}/codes.csv")
        self.assertIn("text/csv", csv.headers["content-type"])
        self.assertIn("Chỉ Một Em", csv.text)

    def test_roster_rejects_accented_student_code(self):
        self.sign_in_teacher()
        room = self.client.post("/api/rooms", json={"title": "Lớp 12A2"}).json()
        response = self.client.post(f"/api/rooms/{room['id']}/roster", files={"file": ("a.csv", "mã hs,tên\nNguyễn,An\n".encode(), "text/csv")})
        self.assertEqual(response.status_code, 422)

    def test_delete_room_removes_exams_and_attempts(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}})
        self.assertEqual(self.client.delete(f"/api/rooms/{room_id}").status_code, 200)
        self.assertEqual(self.client.get("/api/rooms").json(), [])

    def test_remove_student_clears_their_attempt(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster, 0).post(f"/api/exams/{exam_id}/start")
        self.join(roster, 1).post(f"/api/exams/{exam_id}/start")
        self.client.delete(f"/api/students/{roster[1]['id']}")
        self.assertEqual(len(self.client.get(f"/api/exams/{exam_id}").json()["attempts"]), 1)

    def test_second_teacher_cannot_touch_another_rooms_data(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        attempt_id = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "2": "Bài làm"}}).json()["id"]
        hung = self.second_teacher()

        self.assertEqual(hung.get("/api/rooms").json(), [])
        for method, url, body in (
            ("GET", f"/api/rooms/{room_id}", None),
            ("PATCH", f"/api/rooms/{room_id}", {"title": "Đổi trộm"}),
            ("PUT", f"/api/rooms/{room_id}/students", {"students": [{"student_code": "Z01", "name": "Em lạ"}]}),
            ("GET", f"/api/rooms/{room_id}/codes.csv", None),
            ("POST", f"/api/rooms/{room_id}/exams", {"title": "Đề lạ", "duration_minutes": 30, "questions": PAPER}),
            ("DELETE", f"/api/students/{roster[0]['id']}", None),
            ("GET", f"/api/exams/{exam_id}", None),
            ("GET", f"/api/exams/{exam_id}/results", None),
            ("GET", f"/api/exams/{exam_id}/results.csv", None),
            ("PUT", f"/api/exams/{exam_id}", {"title": "Sửa trộm", "duration_minutes": 30, "questions": PAPER}),
            ("POST", f"/api/exams/{exam_id}/publish", {"published": False}),
            ("DELETE", f"/api/exams/{exam_id}", None),
            ("PUT", f"/api/attempts/{attempt_id}/marks", {"marks": {"2": 5}}),
            ("POST", f"/api/rooms/{room_id}/cam/watch", {"student_id": roster[0]["id"]}),
            ("GET", f"/api/rooms/{room_id}/cam/{roster[0]['id']}", None),
        ):
            response = hung.request(method, url, json=body)
            self.assertEqual(response.status_code, 404, f"{method} {url} → {response.status_code} {response.text}")

        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual(state["title"], "Lớp 12A1")
        self.assertEqual([s["student_code"] for s in state["students"]], ["N01", "N02"])
        self.assertEqual(self.client.get(f"/api/exams/{exam_id}/results").json()["attempts"][0]["score"], 2)
        # phòng của thầy Hùng thì thầy Hùng dùng vô tư, cô quản trị vẫn thấy để bao quát cả kỳ thi
        hung_room = hung.post("/api/rooms", json={"title": "Lớp 11C"}).json()
        self.assertEqual([room["title"] for room in hung.get("/api/rooms").json()], ["Lớp 11C"])
        self.assertIn(hung_room["id"], [room["id"] for room in self.client.get("/api/rooms").json()])

    # ---------------------------------------------------------------- đề thi

    def test_exam_validation(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 30, "questions": []}).status_code, 422)
        broken = [{**PAPER[0], "answer": 9}]
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 30, "questions": broken}).status_code, 422)
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/exams",
                                          json={"title": "Đề", "duration_minutes": 2, "questions": PAPER}).status_code, 422)

    def test_hundred_question_paper_is_accepted(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        text = "\n".join(f"Câu {i}: Nội dung {i}?\nA. một\nB. hai\nĐA: A\nĐiểm: 1" for i in range(1, 101))
        questions = papers.parse_text(text)["questions"]
        exam = self.client.post(f"/api/rooms/{room_id}/exams",
                                json={"title": "Đề 100 câu", "duration_minutes": 90, "questions": questions})
        self.assertEqual(exam.status_code, 200, exam.text)
        self.assertEqual(exam.json()["question_count"], 100)
        self.assertEqual(exam.json()["max_points"], 100)

    def test_pdf_docx_csv_txt_import(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        txt = "Câu 1: Hỏi một\nA. a\nB. b\nĐA: A\nĐiểm: 2\n\nCâu 2: Hỏi hai\nA. c\nB. d\nĐA: B\nĐiểm: 2"
        for name, payload, count in (
            ("de.txt", txt.encode(), 2),
            ("de.csv", "question,A,B,answer,points\nHỏi một,a,b,A,2\n".encode(), 1),
        ):
            response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                        files={"file": (name, io.BytesIO(payload), "text/plain")},
                                        data={"title": f"Từ {name}", "duration": "45"})
            self.assertEqual(response.status_code, 200, response.text)
            self.assertEqual(response.json()["question_count"], count)

        import docx

        buffer = io.BytesIO()
        document = docx.Document()
        for line in txt.split("\n"):
            document.add_paragraph(line)
        document.save(buffer)
        buffer.seek(0)
        response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                    files={"file": ("de.docx", buffer, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
                                    data={"title": "Từ Word", "duration": "60"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["question_count"], 2)

    def test_upload_rejects_legacy_doc_and_unknown_type(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        for name, body in (("de.doc", b"doc"), ("de.xlsx", b"xlsx")):
            response = self.client.post(f"/api/rooms/{room_id}/exams/import",
                                        files={"file": (name, io.BytesIO(body), "application/octet-stream")})
            self.assertEqual(response.status_code, 422, response.text)

    def test_paste_preview_needs_no_room_and_blocks_students(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        text = "Câu 1: Hỏi một\nA. a\nB. b\nĐA: B"
        parsed = self.client.post("/api/papers/parse", data={"text": text}).json()
        self.assertEqual(parsed["questions"][0]["answer"], 1)
        self.assertEqual(self.client.post("/api/papers/parse", data={"text": "   "}).status_code, 422)
        self.assertEqual(self.join(roster).post("/api/papers/parse", data={"text": text}).status_code, 401)

    def test_editing_is_allowed_while_no_submitted_paper_yet(self):
        """Mới vào làm thì cô vẫn sửa đề được — chỉ bài đã nộp mới khóa đề lại."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster).post(f"/api/exams/{exam_id}/start")
        response = self.client.put(f"/api/exams/{exam_id}", json={"title": "Sửa đề", "duration_minutes": 30, "questions": PAPER})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["question_count"], len(PAPER))

    def test_submitted_paper_locks_the_exam_until_the_teacher_clears_it(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "1": 1, "2": "Bài tự luận"}})
        locked = self.client.put(f"/api/exams/{exam_id}", json={"title": "Sửa đề", "duration_minutes": 30, "questions": PAPER})
        self.assertEqual(locked.status_code, 409)
        self.assertIn("xóa bài", locked.json()["detail"])

        # thi thử xong, cô xóa mọi bài làm của đề để lớp làm lại thật -> sửa được, mở lại được
        cleared = self.client.post(f"/api/exams/{exam_id}/reset")
        self.assertEqual(cleared.json()["reset"], 1)
        self.assertEqual(self.client.put(f"/api/exams/{exam_id}",
                                         json={"title": "Đề chính thức", "duration_minutes": 45, "questions": PAPER}).status_code, 200)
        again = student.post(f"/api/exams/{exam_id}/start").json()
        self.assertIsNone(again["submitted_at"])
        self.assertGreater(again["remaining_ms"], 44 * 60_000)
        self.assertEqual(again["answers"], {})

    def test_one_student_can_be_sent_back_to_their_own_paper(self):
        """Xóa bài một em để em đó làm lại mà không ảnh hưởng các em đã nộp."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        first, second = self.join(roster, 0), self.join(roster, 1)
        first.post(f"/api/exams/{exam_id}/start")
        second.post(f"/api/exams/{exam_id}/start")
        kept = second.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 1}}).json()
        dropped = first.post(f"/api/exams/{exam_id}/submit",
                             json={"answers": {"0": 0}, "tab_ms": 4000, "tab_events": 3, "paste_count": 1}).json()

        response = self.client.post(f"/api/attempts/{dropped['id']}/reset")
        self.assertEqual(response.status_code, 200, response.text)
        rows = self.client.get(f"/api/exams/{exam_id}/results").json()["attempts"]
        self.assertEqual(next(row for row in rows if row["id"] == kept["id"])["submitted_at"], kept["submitted_at"])
        fresh = next(row for row in rows if row["id"] == dropped["id"])
        self.assertIsNone(fresh["started_at"])
        self.assertEqual(fresh["score"], None)
        self.assertEqual((fresh["tab_events"], fresh["paste_count"], fresh["answers"]), (0, 0, {}))

        # em được làm lại có đồng hồ mới, các em khác vẫn giữ nguyên kết quả
        paper = first.post(f"/api/exams/{exam_id}/start").json()
        self.assertGreater(paper["remaining_ms"], 29 * 60_000)
        self.assertEqual(first.get(f"/api/exams/{exam_id}/result").status_code, 409)

    def test_reset_needs_a_real_attempt_and_the_right_room(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        attempt_id = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}}).json()["id"]
        self.assertEqual(self.client.post("/api/attempts/khong-ton-tai/reset").status_code, 404)
        other_room = self.client.post("/api/rooms", json={"title": "Lớp khác"}).json()["id"]
        other_exam = self.client.post(f"/api/rooms/{other_room}/exams",
                                      json={"title": "Đề lớp khác", "duration_minutes": 20, "questions": PAPER}).json()
        self.assertEqual(self.client.post(f"/api/exams/{other_exam['id']}/reset").json()["reset"], 0)
        self.assertEqual(self.client.post(f"/api/attempts/{attempt_id}/reset").status_code, 200)

    def test_reset_keeps_the_watchdog_events_as_evidence(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        for index in range(3):
            student.post(f"/api/exams/{exam_id}/event", json={"rule": "tab_left", "client_id": f"may-{index}"})
        student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}})
        self.assertEqual(self.client.post(f"/api/exams/{exam_id}/reset").json()["reset"], 1)
        rows = self.application.state.store.all("SELECT rule FROM events WHERE exam_id = ?", exam_id)
        self.assertEqual([row["rule"] for row in rows], ["tab_left"] * 3)

    def test_unpublished_exam_invisible_to_students(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id, published=False)
        student = self.join(roster)
        self.assertEqual(student.get("/api/exams").json(), [])
        self.assertEqual(student.get(f"/api/exams/{exam_id}/paper").status_code, 409)

    def test_other_room_cannot_see_exam(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        exam_id = self.open_exam(room_id)
        other_room = self.client.post("/api/rooms", json={"title": "Lớp khác"}).json()
        other_students = self.client.put(f"/api/rooms/{other_room['id']}/students",
                                         json={"students": [{"student_code": "X01", "name": "Em Khác"}]}).json()["students"]
        room_code = next(room["code"] for room in self.client.get("/api/rooms").json() if room["title"] == "Lớp khác")
        outsider = self.new_client()
        joined = outsider.post("/api/join", json={"room_code": room_code, "student_code": "X01",
                                                 "access_code": other_students[0]["join_code"]})
        self.assertEqual(joined.status_code, 200, joined.text)
        self.assertEqual(outsider.get(f"/api/exams/{exam_id}/paper").status_code, 404)

    # ------------------------------------------------- bài tập về nhà và tải đề về

    def test_homework_validation(self):
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        now = int(time.time() * 1000)
        base = {"title": "Bài tập", "duration_minutes": 240, "questions": PAPER, "kind": "baotap"}
        for extra in ({"kind": "khac"}, {"open_from": now + 60_000, "open_until": now}):
            response = self.client.post(f"/api/rooms/{room_id}/exams", json={**base, **extra})
            self.assertEqual(response.status_code, 422, response.text)
        created = self.client.post(f"/api/rooms/{room_id}/exams", json={**base, "open_until": now + 3600_000})
        self.assertEqual(created.status_code, 200, created.text)
        self.assertEqual(created.json()["kind"], "baotap")
        self.assertEqual(created.json()["open_until"], now + 3600_000)

    def test_homework_clock_follows_the_deadline_not_the_duration(self):
        """Bài tập về nhà bỏ hẳn đồng hồ đếm ngược: chỉ hạn nộp cô đặt mới chốt được bài."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        until = int(time.time() * 1000) + 24 * 3600_000
        exam_id = self.open_homework(room_id, until=until, duration=5)
        student = self.join(roster)
        sheet = student.post(f"/api/exams/{exam_id}/start").json()
        self.assertTrue(24 * 3600_000 - 5000 <= sheet["remaining_ms"] <= 24 * 3600_000, sheet["remaining_ms"])
        # số liệu em tự báo lên không còn được tin: máy chủ tự đo khoảng lặng
        saved = student.post(f"/api/exams/{exam_id}/save",
                             json={"answers": {"0": 0, "1": 1}, "tab_ms": 3000, "tab_events": 1}).json()
        self.assertEqual((saved["tab_ms"], saved["tab_events"]), (0, 0))
        store = self.client.app.state.store
        # đã qua "5 phút" của đề nhưng còn lâu mới tới hạn nộp → bài vẫn đang làm, chưa auto-chốt
        store.transact(lambda conn: conn.execute("UPDATE attempts SET started_at = ? WHERE exam_id = ?",
                                                 (int(time.time() * 1000) - 6 * 60_000, exam_id)))
        paper = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertIsNone(paper["submitted_at"])
        # tới hạn nộp thì máy chủ tự chốt bằng đáp án đã lưu, em rớt mạng cũng không mất điểm
        store.transact(lambda conn: conn.execute("UPDATE exams SET open_until = ? WHERE id = ?",
                                                 (int(time.time() * 1000) - 10 * 60_000, exam_id)))
        board = self.client.get(f"/api/exams/{exam_id}/results").json()["attempts"][0]
        self.assertEqual(board["score"], 5)
        self.assertEqual(board["tab_events"], 0)
        # vào làm rồi thì qua hạn vẫn xem được bài của mình, chỉ không làm thêm được nữa
        late = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertIsNotNone(late["submitted_at"])
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}}).status_code, 409)

    def test_homework_without_a_deadline_never_closes_by_itself(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_homework(room_id)
        student = self.join(roster)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/start").json()["remaining_ms"], 0)
        store = self.client.app.state.store
        store.transact(lambda conn: conn.execute("UPDATE attempts SET started_at = ? WHERE exam_id = ?",
                                                 (int(time.time() * 1000) - 7 * 24 * 3600_000, exam_id)))
        paper = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertIsNone(paper["submitted_at"])
        self.assertIsNone(paper["open_until"])

    def test_homework_blocked_outside_the_window_but_listed_with_a_reason(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        now = int(time.time() * 1000)
        future = self.open_homework(room_id, until=now + 5 * 3600_000, opens=now + 3600_000)
        expired = self.open_homework(room_id, until=now - 3600_000)
        student = self.join(roster)
        states = {exam["id"]: exam["state"] for exam in student.get("/api/exams").json()}
        self.assertEqual(states[future], "chưa tới giờ mở")
        self.assertEqual(states[expired], "hết hạn nộp")
        for exam_id in (future, expired):
            self.assertEqual(student.get(f"/api/exams/{exam_id}/paper").status_code, 409)
            self.assertEqual(student.post(f"/api/exams/{exam_id}/start").status_code, 409)
        # còn đề thi thường thì hạn bài tập không ảnh hưởng gì
        normal = self.open_exam(room_id)
        self.assertEqual(student.post(f"/api/exams/{normal}/start").status_code, 200)

    def test_teacher_panel_shows_the_same_window_the_student_sees(self):
        """Màn cô giáo không được báo “Đang mở” cho một bài tập đã quá hạn hay chưa tới giờ mở."""
        self.sign_in_teacher()
        room_id, _ = self.make_room()
        now = int(time.time() * 1000)
        future = self.open_homework(room_id, until=now + 5 * 3600_000, opens=now + 3600_000)
        expired = self.open_homework(room_id, until=now - 3600_000)
        open_now = self.open_homework(room_id, until=now + 3600_000)
        draft = self.open_exam(room_id, published=False)
        windows = {row["id"]: row["window"] for row in self.client.get(f"/api/rooms/{room_id}").json()["exams"]}
        self.assertEqual(windows[future], "chưa tới giờ mở")
        self.assertEqual(windows[expired], "hết hạn nộp")
        self.assertEqual(windows[open_now], "đang mở")
        self.assertEqual(windows[draft], "chưa mở")

    def test_download_the_paper_for_printing_stays_teacher_only(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        plain = self.client.get(f"/api/exams/{exam_id}/paper.doc")
        self.assertEqual(plain.status_code, 200, plain.text)
        self.assertIn("msword", plain.headers["content-type"])
        self.assertIn("attachment", plain.headers["content-disposition"])
        self.assertIn("filename*=UTF-8''", plain.headers["content-disposition"])  # tên tệp có dấu theo RFC 5987
        self.assertIn(".doc", plain.headers["content-disposition"])
        self.assertIn("Câu 1", plain.text)
        self.assertIn("Chọn đáp án đúng của 放", plain.text)
        self.assertNotIn("Đáp án", plain.text)
        self.assertNotIn("✔", plain.text)
        key = self.client.get(f"/api/exams/{exam_id}/paper.doc?answers=1")
        self.assertEqual(key.status_code, 200)
        self.assertIn("dap-an-", key.headers["content-disposition"])
        self.assertIn("Đáp án", key.text)
        self.assertIn("Câu 1: A · Câu 2: B", key.text)
        self.assertIn("✔", key.text)
        # bài tập về nhà in ra có dòng "nộp trước …", không có "làm trong … phút"
        homework = self.open_homework(room_id, until=int(time.time() * 1000) + 3600_000)
        sheet = self.client.get(f"/api/exams/{homework}/paper.doc").text
        self.assertIn("Bài tập về nhà", sheet)
        self.assertIn("nộp trước", sheet)
        self.assertNotIn("làm trong", sheet)
        # học sinh và thầy cô lớp khác không lấy được đề, càng không lấy được đáp án
        joined = self.join(roster)
        self.assertEqual(joined.get(f"/api/exams/{exam_id}/paper.doc").status_code, 401)
        self.assertEqual(joined.get(f"/api/exams/{exam_id}/paper.doc?answers=1").status_code, 401)
        self.assertEqual(self.second_teacher().get(f"/api/exams/{exam_id}/paper.doc").status_code, 404)

    # ---------------------------------------------------------------- camera live

    def test_live_camera_only_streams_while_the_teacher_watches(self):
        frame = b"\xff\xd8\xff\xe0" + b"h" * 800
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        first, second = self.join(roster, 0), self.join(roster, 1)
        first.post(f"/api/exams/{exam_id}/start")
        second.post(f"/api/exams/{exam_id}/start")

        # chưa bật camera cho phòng thì chưa xem được em nào
        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/cam/watch",
                                          json={"student_id": roster[0]["id"]}).status_code, 409)
        self.assertEqual(first.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})
        room = self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": True}).json()
        self.assertTrue(room["cam_enabled"])
        self.assertIsNone(room["cam_watching"])
        self.assertFalse(first.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).json()["cam_wanted"])

        self.assertEqual(self.client.post(f"/api/rooms/{room_id}/cam/watch",
                                          json={"student_id": roster[1]["id"]}).json()["watching"], roster[1]["id"])

        # cô đang soi em thứ hai: chỉ em đó được gửi hình, em khác im lặng
        self.assertTrue(second.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).json()["cam_wanted"])
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": True})
        self.assertEqual(first.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})
        live = self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}")
        self.assertEqual(live.status_code, 200)
        self.assertEqual(live.content, frame)
        self.assertEqual(live.headers["content-type"], "image/jpeg")
        self.assertIn("no-store", live.headers["cache-control"])
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[0]['id']}").status_code, 404)

        # ảnh rác thì báo về máy chủ, không có chỗ cho ảnh quá lớn hoặc trống
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=b"").status_code, 422)
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=b"x" * (main.cam.MAX_FRAME_BYTES + 1)).status_code, 422)
        other_room = self.client.post("/api/rooms", json={"title": "Lớp khác"}).json()["id"]
        self.client.patch(f"/api/rooms/{other_room}", json={"cam_enabled": True})
        self.assertEqual(self.client.post(f"/api/rooms/{other_room}/cam/watch",
                                          json={"student_id": roster[1]["id"]}).status_code, 422)

        # em tự tắt camera thì khung xem trống, cô không còn nhận hình
        self.assertEqual(second.delete(f"/api/exams/{exam_id}/cam").json(), {"wanted": False})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}").status_code, 404)

        # nộp bài là hết xem — ảnh không nằm lại trên máy chủ
        self.client.post(f"/api/rooms/{room_id}/cam/watch", json={"student_id": roster[1]["id"]})
        second.put(f"/api/exams/{exam_id}/cam", content=frame)
        second.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[1]['id']}").status_code, 404)
        self.assertEqual(second.put(f"/api/exams/{exam_id}/cam", content=frame).json(), {"wanted": False})

        # tắt camera cho phòng: phòng sạch ảnh, bảng của cô hiện cam_watching = None
        self.client.post(f"/api/rooms/{room_id}/cam/watch", json={"student_id": roster[0]["id"]})
        first.put(f"/api/exams/{exam_id}/cam", content=frame)
        closed = self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": False}).json()
        self.assertIsNone(closed["cam_watching"])
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/cam/{roster[0]['id']}").status_code, 404)

    def test_one_evidence_photo_per_camera_alert(self):
        """Máy em tự báo bất thường: mỗi lần chỉ có MỘT ảnh, ảnh không vào CSDL và không ghi đĩa."""
        photo = b"\xff\xd8\xff\xe0" + b"e" * 400
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")

        # phòng chưa bật camera thì ảnh bị từ chối, em vẫn làm bài bình thường
        refused = student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised&client_id=c1", content=photo)
        self.assertEqual(refused.status_code, 409)

        self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": True})
        saved = student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised&client_id=c1", content=photo)
        self.assertEqual(saved.status_code, 200, saved.text)
        self.assertEqual(saved.json(), {"saved": True})

        shown = self.client.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}")
        self.assertEqual(shown.content, photo)
        self.assertEqual(shown.headers["content-type"], "image/jpeg")
        self.assertIn("no-store", shown.headers["cache-control"])

        # bảng của cô đánh dấu em này, kèm loại dấu hiệu để ghi vào sổ giám thị
        marks = self.client.get(f"/api/rooms/{room_id}").json()["evidence"]
        self.assertEqual([(row["student_id"], row["rule"]) for row in marks], [(roster[0]["id"], "object_raised")])
        alerts = self.client.get(f"/api/rooms/{room_id}").json()["events"]
        self.assertEqual([(row["rule"], row["risk"]) for row in alerts], [("object_raised", 80)])

        # client_id lặp lại không nhân đôi cảnh báo trong sổ; ảnh thì giữ đúng một tấm
        student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised&client_id=c1", content=photo)
        student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised&client_id=c2", content=b"\xff\xd8\xff\xe0" + b"k" * 300)
        self.assertEqual(len(self.client.get(f"/api/rooms/{room_id}").json()["events"]), 2)

        # ảnh rác, ảnh quá cỡ, loại cảnh báo bịa đều không vào được
        self.assertEqual(student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised", content=b"pngpng").status_code, 422)
        self.assertEqual(student.put(f"/api/exams/{exam_id}/evidence?rule=object_raised",
                                     content=b"\xff\xd8" + b"x" * main.cam.MAX_FRAME_BYTES).status_code, 422)
        self.assertEqual(student.put(f"/api/exams/{exam_id}/evidence?rule=dang-quay-phim", content=photo).status_code, 422)

        # học sinh khác không đọc được ảnh của bạn, giám thị phòng khác cũng vậy
        outsider = self.join(roster, 1)
        self.assertEqual(outsider.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}").status_code, 401)
        helper = self.second_teacher()
        self.assertEqual(helper.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}").status_code, 404)

        # nộp bài rồi thì không gửi thêm ảnh được nữa, và tắt camera cho phòng là ảnh biến mất
        self.assertEqual(student.put(f"/api/exams/{exam_id}/evidence?rule=face_gone&client_id=c3", content=photo).status_code, 200)
        student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}})
        self.assertEqual(student.put(f"/api/exams/{exam_id}/evidence?rule=face_gone&client_id=c4", content=photo).json(), {"saved": False})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}").status_code, 200)
        self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": False})
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}").status_code, 404)

    def test_reset_removes_the_pending_evidence_photo(self):
        photo = b"\xff\xd8\xff\xe0" + b"e" * 400
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.client.patch(f"/api/rooms/{room_id}", json={"cam_enabled": True})
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.put(f"/api/exams/{exam_id}/evidence?rule=cam_dark&client_id=c9", content=photo)
        attempt_id = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0}}).json()["id"]
        self.client.post(f"/api/attempts/{attempt_id}/reset")
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}/evidence/{roster[0]['id']}").status_code, 404)
        # còn dòng cảnh báo trong sổ thì vẫn giữ, vì đó là dấu vết cô đã ghi nhận
        self.assertEqual(self.client.get(f"/api/rooms/{room_id}").json()["events"][0]["rule"], "cam_dark")

    # ---------------------------------------------------------------- giờ thi và chấm điểm

    def test_full_exam_flow_and_autosave(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        self.assertEqual(student.get("/api/exams").json()[0]["state"], "chưa vào làm")
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).status_code, 409)
        started = student.post(f"/api/exams/{exam_id}/start").json()
        self.assertEqual(len(started["questions"]), 3)
        self.assertFalse(any("answer" in str(question) for question in started["questions"]))
        self.assertTrue(30 * 60_000 - 3000 <= started["remaining_ms"] <= 30 * 60_000, started["remaining_ms"])
        saved = student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0, "1": 0, "2": "Em đặt câu với 放在."},
                                                                "tab_ms": 4000, "tab_events": 1, "paste_count": 1}).json()
        self.assertEqual(saved["answered"], 3)
        submitted = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "1": 1, "2": "Bài tự luận"}}).json()
        self.assertEqual(submitted["score"], 5)  # chỉ câu 1 đúng (2đ), câu 2 sai, tự luận chờ thầy chấm
        self.assertEqual(student.post(f"/api/exams/{exam_id}/submit", json={"answers": {}}).json()["already"], True)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}}).status_code, 409)
        result = student.get(f"/api/exams/{exam_id}/result").json()
        self.assertEqual(result["answered"], 3)
        self.assertEqual(result["max_points"], 10)

    def test_server_clock_closes_overdue_attempt(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id, duration=5)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0, "1": 1}})
        # đồng hồ chạy trước: đẩy started_at về quá khứ rồi xin giấy thi, máy chủ phải tự chốt điểm
        store = self.client.app.state.store
        store.transact(lambda conn: conn.execute("UPDATE attempts SET started_at = ? WHERE exam_id = ?",
                                                 (int(time.time() * 1000) - 10 * 60_000, exam_id)))
        paper = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertEqual(paper["remaining_ms"], 0)
        self.assertIsNotNone(paper["submitted_at"])
        self.assertEqual(paper["score"], 5)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}}).status_code, 409)
        board = self.client.get(f"/api/exams/{exam_id}/results").json()
        self.assertEqual(board["attempts"][0]["score"], 5)

    def test_grading_ignores_answer_indices_out_of_range(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        saved = student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 9, "7": 1, "x": 2, "1": 1}}).json()
        self.assertEqual(saved["answered"], 1)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/submit", json={"answers": {}}).json()["score"], 3)

    def test_teacher_marks_essay_and_score_updates(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        submitted = student.post(f"/api/exams/{exam_id}/submit", json={"answers": {"0": 0, "2": "Bài làm"}}).json()
        attempt_id = submitted["id"]
        self.assertEqual(self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"0": 2}}).status_code, 422)
        marked = self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"2": 4}}).json()
        self.assertEqual(marked["score"], 6)
        self.assertEqual(self.client.put(f"/api/attempts/{attempt_id}/marks", json={"marks": {"2": 99}}).json()["score"], 7)

    def test_tab_and_paste_alerts_reach_the_board(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        student.post(f"/api/exams/{exam_id}/start")
        self.assertEqual(student.post(f"/api/exams/{exam_id}/event", json={"rule": "tab_left", "duration": 12,
                                                                         "client_id": "abc"}).status_code, 200)
        student.post(f"/api/exams/{exam_id}/event", json={"rule": "tab_left", "duration": 12, "client_id": "abc"})
        self.assertEqual(student.post(f"/api/exams/{exam_id}/event", json={"rule": "camera"}).status_code, 422)
        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual(len(state["events"]), 1)
        self.assertEqual(state["events"][0]["rule"], "tab_left")
        self.assertEqual(state["events"][0]["risk"], 70)

    def test_silence_is_measured_by_the_server_not_the_browser(self):
        """Trình duyệt điện thoại bị đông băng lúc tắt màn hình nên không được tin nó tự báo.

        Máy chủ chỉ nhìn khoảng lặng giữa hai lần máy em báo tin: im quá 8 giây là ghi một mốc.
        """
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        store = self.client.app.state.store
        student.post(f"/api/exams/{exam_id}/start")

        def go_quiet(seconds):
            store.transact(lambda conn: conn.execute("UPDATE attempts SET last_seen = ? WHERE exam_id = ?",
                                                    (int(time.time() * 1000) - seconds * 1000, exam_id)))

        go_quiet(4)
        self.assertEqual(student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 0}}).json()["tab_events"], 0)

        go_quiet(40)
        back = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertEqual(back["tab_events"], 1)
        self.assertTrue(39_000 <= back["tab_ms"] <= 42_000, back["tab_ms"])

        # em reload hay mở đi mở lại trang cũng chỉ có ĐÚNG MỘT mốc cho một khoảng lặng
        for _ in range(3):
            student.get(f"/api/exams/{exam_id}/paper")
            student.post(f"/api/exams/{exam_id}/save", json={"answers": {"0": 1}})
        marks = [row for row in self.client.get(f"/api/rooms/{room_id}").json()["events"] if row["rule"] == "tab_left"]
        self.assertEqual(len(marks), 1)
        self.assertEqual(marks[0]["risk"], 70)
        self.assertEqual(self.client.get(f"/api/exams/{exam_id}/results").json()["attempts"][0]["tab_events"], 1)

    def test_teacher_board_flags_the_gap_before_the_student_comes_back(self):
        """Cô phải thấy em rời cửa sổ NGAY trong lúc em còn chưa bật lại tab — chờ em quay lại là chậm cả kỳ thi."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        store = self.client.app.state.store
        student.post(f"/api/exams/{exam_id}/start")

        def go_quiet(seconds):
            store.transact(lambda conn: conn.execute(
                "UPDATE attempts SET last_seen = ? WHERE exam_id = ?",
                (int(time.time() * 1000) - seconds * 1000, exam_id)))

        def board():
            state = self.client.get(f"/api/rooms/{room_id}").json()
            return state["exams"][0]["attempts"][0], [event for event in state["events"] if event["rule"] == "tab_left"]

        go_quiet(4)  # hụt một nhịp thì chưa được báo, mạng lướt qua không thành cảnh báo
        row, marks = board()
        self.assertTrue(3_500 <= row["quiet_ms"] <= 5_500, row["quiet_ms"])
        self.assertEqual((row["tab_events"], len(marks)), (0, 0))

        go_quiet(9)  # em đang rời đi, chưa gửi thêm một tin nào
        row, marks = board()
        self.assertGreaterEqual(row["quiet_ms"], 9_000)
        self.assertEqual(len(marks), 1, marks)
        self.assertEqual((row["tab_events"], row["tab_ms"]), (0, 0))
        # cô hỏi bảng thêm mấy nhịp nữa cũng chỉ một dấu, không thành danh sách dài
        self.assertEqual(len(board()[1]), 1)

        back = student.get(f"/api/exams/{exam_id}/paper").json()  # em quay lại, số giây thật được ghi đủ
        self.assertEqual(back["tab_events"], 1)
        self.assertGreaterEqual(back["tab_ms"], 9_000)
        marks = board()[1]
        self.assertEqual(len(marks), 1)
        self.assertGreaterEqual(marks[0]["duration"], 9)

    def test_homework_board_does_not_nag_about_silence(self):
        """Bài tập ở nhà: em tắt máy đi chơi là bình thường, bảng cô không đỏ vì khoảng lặng."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_homework(room_id, until=int(time.time() * 1000) + 6 * 3600_000)
        student = self.join(roster)
        store = self.client.app.state.store
        student.post(f"/api/exams/{exam_id}/start")
        store.transact(lambda conn: conn.execute("UPDATE attempts SET last_seen = ? WHERE exam_id = ?",
                                                 (int(time.time() * 1000) - 3600_000, exam_id)))
        state = self.client.get(f"/api/rooms/{room_id}").json()
        self.assertEqual(state["exams"][0]["attempts"][0]["quiet_ms"], 0)
        self.assertEqual([event for event in state["events"] if event["rule"] == "tab_left"], [])

    def test_long_homework_silence_is_neither_recorded_nor_reported(self):
        """Ở nhà em tắt máy ba tiếng rồi bật lại là chuyện thường — không trừ thời gian, không báo cô."""
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_homework(room_id, until=int(time.time() * 1000) + 6 * 3600_000)
        student = self.join(roster)
        store = self.client.app.state.store
        student.post(f"/api/exams/{exam_id}/start")

        def go_quiet(seconds):
            store.transact(lambda conn: conn.execute(
                "UPDATE attempts SET last_seen = ? WHERE exam_id = ?",
                (int(time.time() * 1000) - seconds * 1000, exam_id)))

        go_quiet(3 * 3600)
        away = student.get(f"/api/exams/{exam_id}/paper").json()
        self.assertEqual((away["tab_ms"], away["tab_events"]), (0, 0))
        # nhưng im lặng ngắn trong lúc đang làm bài tập vẫn phải ghi lại
        go_quiet(40)
        self.assertEqual(student.get(f"/api/exams/{exam_id}/paper").json()["tab_events"], 1)
        # bài thi trên lớp thì im lặng lâu vẫn tính như thường
        exam_id = self.open_exam(room_id)
        student.post(f"/api/exams/{exam_id}/start")
        go_quiet(3 * 3600)
        self.assertEqual(student.get(f"/api/exams/{exam_id}/paper").json()["tab_events"], 1)

    def test_student_cannot_read_the_answer_key_or_others_results(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        student = self.join(roster)
        self.assertEqual(student.get(f"/api/exams/{exam_id}").status_code, 401)
        self.assertEqual(student.get(f"/api/exams/{exam_id}/results").status_code, 401)
        self.assertEqual(student.get("/api/rooms").status_code, 401)
        paper = student.get(f"/api/exams/{exam_id}/paper")
        self.assertNotIn('"answer"', paper.text)

    def test_results_csv_lists_every_answer(self):
        self.sign_in_teacher()
        room_id, roster = self.make_room()
        exam_id = self.open_exam(room_id)
        self.join(roster).post(f"/api/exams/{exam_id}/start")
        self.client.post(f"/api/exams/{exam_id}/publish", json={"published": True})
        csv = self.client.get(f"/api/exams/{exam_id}/results.csv")
        self.assertEqual(csv.status_code, 200)
        self.assertIn("Câu 1", csv.text)
        self.assertIn("N01", csv.text)

    def test_templates_download(self):
        self.assertEqual(self.client.get("/api/templates/roster.csv").status_code, 200)
        self.assertIn("question", self.client.get("/api/templates/paper.csv").text)

    def test_health_and_pages(self):
        health = self.client.get("/api/health").json()
        self.assertTrue(health["ok"])
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/teacher").status_code, 200)
        self.assertEqual(self.client.get("/exam").status_code, 200)
