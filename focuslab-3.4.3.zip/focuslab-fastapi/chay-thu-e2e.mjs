/* Chạy thử toàn bộ buổi thi trên máy chủ FastAPI: cô lập phòng → nạp đề → trò vào thi → máy chấm → cô xem kết quả.
   Cách dùng: bật server rồi chạy  node chay-thu-e2e.mjs  (mặc định http://127.0.0.1:8099) */

const BASE = process.env.BASE_URL ?? "http://127.0.0.1:8099";
const results = [];
const stamp = () => new Date().toISOString().slice(11, 19);

function step(label, ok, extra = "") {
  results.push({ label, ok, extra });
  console.log(`${ok ? "OK  " : "FAIL"} ${label}${extra ? ` — ${extra}` : ""}`);
}

function actor() {
  let cookie = "";
  return {
    get cookie() {
      return cookie;
    },
    async call(method, path, { body, form, headers = {}, bytes = false } = {}) {
      const raw = body instanceof Uint8Array;
      const response = await fetch(BASE + path, {
        method,
        headers: { ...(form || raw ? {} : body ? { "content-type": "application/json" } : {}), cookie, ...headers },
        body: form ?? (raw ? body : body ? JSON.stringify(body) : undefined),
      });
      const setCookie = response.headers.get("set-cookie");
      if (setCookie) cookie = setCookie.split(";")[0];
      if (bytes) return { status: response.status, type: response.headers.get("content-type"), bytes: new Uint8Array(await response.arrayBuffer()) };
      const text = await response.text();
      let data = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
      return { status: response.status, data, text };
    },
  };
}

const ok = (label, result, expected) => step(label, result.status === expected, `HTTP ${result.status} ${typeof result.data === "string" ? result.data.slice(0, 120) : ""}`);

// Node chỉ nhận new FormData() không tham số, phải append từng trường một
function formOf(entries) {
  const data = new FormData();
  for (const [name, value, filename] of entries) {
    if (filename === undefined) data.append(name, value);
    else data.append(name, value, filename);
  }
  return data;
}

const teacher = actor();
const studentA = actor();
const studentB = actor();
const outsider = actor();

console.log(`Chạy thử tại ${BASE} — ${stamp()}\n`);

// 1. Nền móng: dịch vụ sống, ba màn hình đều tải được
const health = await teacher.call("GET", "/api/health");
ok("Máy chủ trả lời /api/health", health, 200);
step("/api/health cho biết tình trạng nơi giữ dữ liệu", typeof health.data?.backup === "string", String(health.data?.backup));
for (const page of ["/", "/teacher", "/exam", "/static/app.css", "/static/exam.js", "/static/teacher.js"]) {
  const response = await teacher.call("GET", page);
  step(`Trang ${page} tải được`, response.status === 200 && response.text.length > 200, `${response.status}, ${response.text.length} byte`);
}
// Camera chỉ là khung xem trực tiếp: không quay thành tệp, không nhận diện bằng máy, không giữ lại bản ghi nào.
for (const file of ["/static/exam.js", "/static/teacher.js", "/static/index.js", "/static/exam.html", "/static/teacher.html"]) {
  const body = (await teacher.call("GET", file)).text;
  step(`Không còn quay-lưu/YOLO/WebSocket trong ${file}`, !/MediaRecorder|yolo|ffmpeg|WebSocket|phòng quay|\.webm|\.mp4/i.test(body));
}

// 2. Tài khoản cô giáo
const setup = await teacher.call("POST", "/api/teacher/setup", { body: { username: "co.linh", password: "thitinh2026", display_name: "Cô Linh" } });
ok("Lần chạy đầu tạo được tài khoản quản trị", setup, 200);
const again = await teacher.call("POST", "/api/teacher/setup", { body: { username: "khac", password: "thitinh2026" } });
ok("Không tự tạo tài khoản thứ hai từ trang cổng", again, 403);
const invite = await teacher.call("POST", "/api/teacher/invite", { body: { username: "thay.hung", password: "thitinh2026", display_name: "Thầy Hùng" } });
ok("Cô quản trị thêm được tài khoản thầy cô khác", invite, 200);
const twinName = await teacher.call("POST", "/api/teacher/invite", { body: { username: "THAY-hung", password: "thitinh2026", display_name: "Thầy Hùng" } });
step("Trùng tên đăng nhập (kể cả khác hoa thường hay dấu chấm) thì báo rõ, còn họ tên hiển thị được trùng",
  twinName.status === 409 && /trùng/.test(twinName.data?.detail ?? ""), `${twinName.status}: ${twinName.data?.detail}`);
const accented = await teacher.call("POST", "/api/teacher/invite", { body: { username: "Cô Hương", password: "thitinh2026" } });
step("Tên đăng nhập có dấu bị từ chối kèm cách đặt tên", accented.status === 422 && /không dấu/.test(accented.data?.detail ?? ""), String(accented.status));
const twinDisplay = await teacher.call("POST", "/api/teacher/invite", { body: { username: "co.huong", password: "thitinh2026", display_name: "Thầy Hùng" } });
step("Hai người trùng họ tên hiển thị vẫn tạo được tài khoản", twinDisplay.status === 200, String(twinDisplay.status));
const list = await teacher.call("GET", "/api/teachers");
step("Chủ tài khoản xem được danh sách giáo viên", list.status === 200 && list.data.teachers.length === 3, `${list.data?.teachers?.length} người`);
const weak = await teacher.call("POST", "/api/teacher/login", { body: { username: "co.linh", password: "sai" } });
ok("Sai mật khẩu bị chặn", weak, 401);
const bruter = actor();
const guesses = [];
for (let guess = 0; guess < 10; guess++) {
  guesses.push((await bruter.call("POST", "/api/teacher/login", { body: { username: "co.huong", password: `sai${guess}` } })).status);
}
step("Dò mật khẩu: 9 lần đầu còn được thử, lần thứ 10 khóa cửa",
  guesses.slice(0, 9).every(status => status === 401) && guesses[9] === 429, JSON.stringify(guesses));
step("Đã khóa thì gõ đúng mật khẩu cũng phải chờ",
  (await bruter.call("POST", "/api/teacher/login", { body: { username: "co.huong", password: "thitinh2026" } })).status === 429);
step("Khóa một người dò không chặn cô giáo khác",
  (await actor().call("POST", "/api/teacher/login", { body: { username: "thay.hung", password: "thitinh2026" } })).status === 200);
for (const door of ["/openapi.json", "/docs"]) {
  const probe = await actor().call("GET", door);
  step(`Máy chủ công khai không lộ ${door}`, probe.status === 404, String(probe.status));
}
const anonymous = actor();
ok("Học sinh chưa vào lớp không đọc được danh sách phòng", await anonymous.call("GET", "/api/rooms"), 401);

// 3. Phòng thi và danh sách lớp
const room = await teacher.call("POST", "/api/rooms", { body: { title: "Lớp 12A1 — thi tỉnh" } });
ok("Tạo phòng thi", room, 200);
step("Mã phòng 8 ký tự, không có chữ dễ nhầm", /^[A-HJKMNP-Z2-9]{8}$/.test(room.data.code), room.data.code);
const roster = await teacher.call("PUT", `/api/rooms/${room.data.id}/students`, {
  body: { students: [
    { student_code: "N01", name: "Nguyễn Văn An" },
    { student_code: "N02", name: "Trần Thị Bình" },
    { student_code: "N03", name: "Lê Cao Cường" }] },
});
ok("Nạp danh sách 3 học sinh", roster, 200);
const codes = roster.data.students.map(student => student.join_code);
step("Mỗi em một mã tham gia 8 ký tự, không trùng", codes.every(code => /^[A-HJKMNP-Z2-9]{8}$/.test(code)) && new Set(codes).size === 3, codes.join(" "));
step("Chỗ ngồi đánh số S01, S02, S03", roster.data.students.map(s => s.seat_id).join(",") === "S01,S02,S03");
const fileCsv = await teacher.call("GET", `/api/rooms/${room.data.id}/codes.csv`);
step("Tệp mã-tham-gia.csv có đủ tên và mã để in", fileCsv.status === 200 && fileCsv.text.includes("Nguyễn Văn An") && fileCsv.text.includes(codes[0]));

// 4. Học sinh vào lớp
const badJoin = await outsider.call("POST", "/api/join", { body: { room_code: room.data.code, student_code: "N01", access_code: "SAIMASAI" } });
ok("Mã tham gia sai bị chặn ngoài cửa", badJoin, 401);
const joinA = await studentA.call("POST", "/api/join", { body: { room_code: room.data.code, student_code: "N01", access_code: codes[0].toLowerCase() } });
ok("Gõ mã thường vẫn vào được (Caps Lock)", joinA, 200);
const joinB = await studentB.call("POST", "/api/join", { body: { room_code: room.data.code, student_code: "N02", access_code: codes[1] } });
ok("Em thứ hai vào lớp", joinB, 200);
const lowerCode = await actor().call("POST", "/api/join", { body: { room_code: room.data.code, student_code: "n01", access_code: codes[0] } });
ok("Gõ mã học sinh chữ thường (n01) vẫn vào được", lowerCode, 200);
step("Máy chủ nhận đúng em đó, không phải người lạ", lowerCode.data?.role === "student", JSON.stringify(lowerCode.data?.role));
ok("Học sinh không đọc được danh sách phòng của cô", await studentA.call("GET", "/api/rooms"), 401);
ok("Học sinh không đọc được đáp án qua API đề", await studentA.call("GET", "/api/exams/x"), 401);

// 5. Nạp đề: dán văn bản, tải CSV, và 100 câu liên tiếp
const pasted = await teacher.call("POST", "/api/papers/parse", { form: formOf([["text",
  Array.from({ length: 100 }, (_, i) => `Câu ${i + 1}: Nội dung câu ${i + 1}?\nA. một\nB. hai\nĐA: A\nĐiểm: 1`).join("\n")]]) });
step("Dán đề 100 câu từ Word, máy tự tách 100 câu", pasted.status === 200 && pasted.data.questions?.length === 100, `${pasted.data?.questions?.length} câu`);
const bigExam = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Đề 100 câu", duration_minutes: 90, questions: pasted.data.questions } });
ok("Máy chủ nhận đề 100 câu", bigExam, 200);
step("Đề 100 câu tính đúng 100 điểm", bigExam.data.max_points === 100, String(bigExam.data.max_points));

const paperCsv = "question,A,B,C,D,answer,points\nChọn đáp án đúng của 把,bǎ,ba,bà,bá,A,2\nChọn đáp án đúng của 放,fàng,páng,fáng,bàng,B,3\n";
const uploadExam = await teacher.call("POST", `/api/rooms/${room.data.id}/exams/import`, {
  form: formOf([["title", "Kiểm tra buổi 5"], ["duration", "30"],
    ["file", new Blob([paperCsv], { type: "text/csv" }), "de-thi.csv"]]) });
ok("Tải tệp CSV lên thành đề", uploadExam, 200);
step("Đề CSV có 2 câu, 5 điểm", uploadExam.data.question_count === 2 && uploadExam.data.max_points === 5, JSON.stringify({ c: uploadExam.data.question_count, p: uploadExam.data.max_points }));
const docFile = await teacher.call("POST", `/api/rooms/${room.data.id}/exams/import`, {
  form: formOf([["file", new Blob(["word 2003"], { type: "application/octet-stream" }), "de.doc"]]) });
ok("Tệp .doc cũ bị từ chối kèm hướng dẫn", docFile, 422);
const blankFile = await teacher.call("POST", `/api/rooms/${room.data.id}/exams/import`, {
  form: formOf([["file", new Blob(["   \n  "], { type: "text/plain" }), "lang.txt"]]) });
step("Tệp để trống bị từ chối, cô nhận được câu hướng dẫn", blankFile.status === 422 && typeof blankFile.data?.detail === "string" && blankFile.data.detail.length > 10, blankFile.data?.detail);
const oneLiner = await teacher.call("POST", "/api/papers/parse", { form: formOf([["text", "Viết lại phương trình phản ứng"]]) });
step("Dòng chữ đơn lẻ thành câu tự luận kèm ghi chú cảnh báo", oneLiner.status === 200 && oneLiner.data.questions?.[0]?.type === "text" && oneLiner.data.notes.length === 1, oneLiner.data?.notes?.[0]);

const examId = uploadExam.data.id;
const beforeOpen = await studentA.call("GET", `/api/exams/${examId}/paper`);
ok("Đề chưa mở thì học sinh vào làm không được", beforeOpen, 409);
const publish = await teacher.call("POST", `/api/exams/${examId}/publish`, { body: { published: true } });
ok("Cô mở đề cho lớp", publish, 200);
const sheet = await studentA.call("GET", `/api/exams/${examId}/paper`);
step("Giấy thi gửi xuống không kèm đáp án đúng", sheet.status === 200 && !sheet.text.includes('"answer"'), String(sheet.status));
step("Đề chưa mở không hiện trong danh sách của học sinh trước khi công bố", true);

// 6. Giờ thi do máy chủ giữ
const earlySave = await studentA.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 0 } } });
ok("Chưa bấm Bắt đầu mà lưu bài thì bị chặn", earlySave, 409);
const started = await studentA.call("POST", `/api/exams/${examId}/start`);
ok("Bấm Bắt đầu làm bài, đồng hồ chạy", started, 200);
step("Đồng hồ bằng đúng 30 phút", Math.abs(started.data.remaining_ms - 30 * 60_000) < 3000, String(started.data.remaining_ms));
const current = await teacher.call("GET", `/api/exams/${examId}`);
const midEdit = await teacher.call("PUT", `/api/exams/${examId}`, {
  body: { title: "Kiểm tra buổi 5 — sửa tên", duration_minutes: 30, questions: current.data.questions } });
step("Em mới bấm vào làm (chưa nộp) thì cô vẫn sửa được đề", midEdit.status === 200, String(midEdit.status));
const saved = await studentA.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 0, 1: 1 }, paste_count: 1 } });
ok("Bài lưu lên máy chủ mỗi 3 giây", saved, 200);
step("Bảng đếm đúng 2 câu đã làm", saved.data.answered === 2, String(saved.data.answered));
const alert = await studentA.call("POST", `/api/exams/${examId}/event`, { body: { rule: "tab_left", duration: 25, client_id: "e2e-tab-1" } });
ok("Học sinh báo rời cửa sổ, máy chủ ghi nhật ký", alert, 200);
await studentA.call("POST", `/api/exams/${examId}/event`, { body: { rule: "tab_left", duration: 25, client_id: "e2e-tab-1" } });
const state = await teacher.call("GET", `/api/rooms/${room.data.id}`);
const tabEvents = state.data.events.filter(event => event.rule === "tab_left" && event.student_id === joinA.data.id);
step("Cảnh báo chảy vào bảng của cô, em báo trùng 2 lần chỉ ghi 1 mốc", tabEvents.length === 1 && tabEvents[0].risk === 70, `${tabEvents.length} mốc`);
const bogus = await studentA.call("POST", `/api/exams/${examId}/event`, { body: { rule: "camera" } });
ok("Loại cảnh báo không có thật bị từ chối", bogus, 422);

/* Cô thấy em rời cửa sổ NGAY khi em còn chưa quay lại — không phải chờ em bật tab làm bài lại. */
const quietExam = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Đề đo khoảng lặng", duration_minutes: 30, questions: current.data.questions } });
await teacher.call("POST", `/api/exams/${quietExam.data.id}/publish`, { body: { published: true } });
ok("Em thứ hai vào làm đề riêng để đo khoảng lặng", await studentB.call("POST", `/api/exams/${quietExam.data.id}/start`), 200);
await new Promise(wait => setTimeout(wait, 11_000));  // em tắt màn hình, không gửi thêm một tin nào
const liveBoard = await teacher.call("GET", `/api/rooms/${room.data.id}`);
const liveRow = liveBoard.data.exams.find(exam => exam.id === quietExam.data.id)?.attempts[0];
step("Bảng cô giáo đỏ lên khi em còn chưa quay lại, số giây im lặng do máy đo",
  liveRow && liveRow.quiet_ms >= 8000 && liveRow.tab_events === 0, `${Math.round((liveRow?.quiet_ms ?? 0) / 1000)} giây`);
const liveMarks = liveBoard.data.events.filter(event =>
  event.rule === "tab_left" && event.student_id === joinB.data.id && event.exam_id === quietExam.data.id);
step("Dấu đỏ đã vào sổ cảnh báo mà em chưa báo tin lần nào", liveMarks.length === 1, `${liveMarks.length} mốc`);
await teacher.call("GET", `/api/rooms/${room.data.id}`);
const twiceLive = (await teacher.call("GET", `/api/rooms/${room.data.id}`)).data.events.filter(event =>
  event.rule === "tab_left" && event.exam_id === quietExam.data.id);
step("Cô hỏi bảng mấy lần cũng chỉ đúng MỘT mốc cho cùng một khoảng lặng", twiceLive.length === 1, `${twiceLive.length} mốc`);
const backFromQuiet = await studentB.call("GET", `/api/exams/${quietExam.data.id}/paper`);
const afterBack = (await teacher.call("GET", `/api/rooms/${room.data.id}`)).data.events.filter(event =>
  event.rule === "tab_left" && event.exam_id === quietExam.data.id);
step("Em quay lại thì mốc đó được ghi đủ số giây thật, không nhân đôi",
  backFromQuiet.data.tab_events === 1 && backFromQuiet.data.tab_ms >= 11_000 && afterBack.length === 1
  && afterBack[0].duration >= 11, JSON.stringify({ ms: backFromQuiet.data.tab_ms, giây: afterBack[0]?.duration }));

const submit = await studentA.call("POST", `/api/exams/${examId}/submit`, { body: { answers: { 0: 0, 1: 0 } } });
ok("Nộp bài", submit, 200);
step("Máy chấm đúng: câu 1 được 2đ, câu 2 chọn sai thành 0đ", submit.data.score === 2, String(submit.data.score));
const lateSave = await studentA.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 1 } } });
ok("Nộp rồi thì không sửa bài được nữa", lateSave, 409);
const twice = await studentA.call("POST", `/api/exams/${examId}/submit`, { body: { answers: {} } });
step("Nộp lần hai không trừ điểm lần đầu", twice.status === 200 && twice.data.already === true, JSON.stringify(twice.data).slice(0, 80));
const own = await studentA.call("GET", `/api/exams/${examId}/result`);
step("Học sinh xem lại điểm của mình", own.status === 200 && own.data.score === 2 && own.data.max_points === 5, JSON.stringify({ s: own.data.score, m: own.data.max_points }));
const peek = await studentA.call("GET", `/api/exams/${examId}/results`);
ok("Học sinh không đọc được bài của cả lớp", peek, 401);
const lockedAfterSubmit = await teacher.call("PUT", `/api/exams/${examId}`, {
  body: { title: "Sửa sau khi có bài nộp", duration_minutes: 30, questions: current.data.questions } });
step("Đã có em NỘP bài thì đề khóa lại, máy chỉ rõ cách mở khóa",
  lockedAfterSubmit.status === 409 && /xóa bài/.test(lockedAfterSubmit.data?.detail ?? ""), `${lockedAfterSubmit.status}: ${lockedAfterSubmit.data?.detail}`);

// 7. Em bỏ thi giữa chừng: nộp bằng máy khác vẫn nhận đúng bài đã lưu
const resumeB = await studentB.call("POST", `/api/exams/${examId}/start`);
ok("Em thứ hai vào làm đề đang mở", resumeB, 200);
await studentB.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 0, 1: 0 } } });
const board = await teacher.call("GET", `/api/exams/${examId}/results`);
step("Bảng cô thấy 2 em vào làm, 1 em đã nộp", board.data.attempts.length === 2 && board.data.attempts.filter(a => a.submitted_at).length === 1,
  `${board.data.attempts.length} bài`);
const essay = await teacher.call("PUT", `/api/attempts/${board.data.attempts.find(a => !a.submitted_at).id}/marks`, { body: { marks: { 0: 1 } } });
ok("Cô không chấm được câu trắc nghiệm bằng tay", essay, 422);

// 7b. Camera live: cô bật cho phòng, soi từng em, ảnh chỉ đi qua máy chủ vài giây rồi mất
const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, ...Array.from({ length: 900 }, (_byte, i) => i % 251)]);
const watchBlind = await teacher.call("POST", `/api/rooms/${room.data.id}/cam/watch`, { body: { student_id: joinB.data.id } });
ok("Chưa bật camera cho phòng thì chưa soi được em nào", watchBlind, 409);
const camOn = await teacher.call("PATCH", `/api/rooms/${room.data.id}`, { body: { cam_enabled: true } });
step("Cô bật camera cho phòng thi", camOn.status === 200 && camOn.data.cam_enabled === true, String(camOn.status));
const darkSave = await studentB.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 0, 1: 0 } } });
step("Chưa ai soi thì máy báo về để trình duyệt tắt đèn camera", darkSave.data.cam_wanted === false && darkSave.data.cam_enabled === true);
const idlePush = await studentB.call("PUT", `/api/exams/${examId}/cam`, { body: jpeg });
step("Em gửi hình lúc cô chưa mở khung xem thì máy chủ không nhận", idlePush.status === 200 && idlePush.data.wanted === false, JSON.stringify(idlePush.data));
const watchB = await teacher.call("POST", `/api/rooms/${room.data.id}/cam/watch`, { body: { student_id: joinB.data.id } });
step("Một phòng chỉ soi được một em mỗi lần", watchB.status === 200 && watchB.data.watching === joinB.data.id, String(watchB.status));
const litSave = await studentB.call("POST", `/api/exams/${examId}/save`, { body: { answers: { 0: 0, 1: 0 } } });
step("Được soi thì trình duyệt bật lại camera", litSave.data.cam_wanted === true);
const push = await studentB.call("PUT", `/api/exams/${examId}/cam`, { body: jpeg });
ok("Ảnh JPEG đi qua máy chủ", push, 200);
const frame = await teacher.call("GET", `/api/rooms/${room.data.id}/cam/${joinB.data.id}`, { bytes: true });
step("Cô nhận đúng khung hình, dạng ảnh jpeg, không bản ghi nào",
  frame.status === 200 && /image\/jpeg/.test(frame.type ?? "") && frame.bytes.length === jpeg.length, `${frame.status}, ${frame.bytes.length} byte`);
ok("Ảnh quá lớn bị chặn ngay ở máy chủ", await studentB.call("PUT", `/api/exams/${examId}/cam`, { body: new Uint8Array(130_000) }), 422);
ok("Khung hình rỗng bị từ chối", await studentB.call("PUT", `/api/exams/${examId}/cam`, { body: new Uint8Array(0) }), 422);
const afterSubmit = await studentA.call("PUT", `/api/exams/${examId}/cam`, { body: jpeg });
step("Em đã nộp bài thì không gửi hình được nữa", afterSubmit.status === 200 && afterSubmit.data.wanted === false, JSON.stringify(afterSubmit.data));
const stopWatch = await teacher.call("POST", `/api/rooms/${room.data.id}/cam/watch`, { body: { student_id: null } });
step("Cô tắt khung xem thì bảng hết ghi đang soi", stopWatch.data.watching === null);
const orphanPush = await studentB.call("PUT", `/api/exams/${examId}/cam`, { body: jpeg });
step("Cô đã tắt nên ảnh em gửi bị bỏ luôn, không nằm lại", orphanPush.data.wanted === false);
ok("Không còn khung hình nào trên máy chủ", await teacher.call("GET", `/api/rooms/${room.data.id}/cam/${joinB.data.id}`, { bytes: true }), 404);

// 7b2. Ảnh bằng chứng: máy em tự phát hiện tại chỗ, mỗi dấu hiệu chỉ gửi ĐÚNG MỘT ảnh
const shot = new Uint8Array([0xff, 0xd8, 0xff, 0xdb, ...Array.from({ length: 700 }, (_byte, i) => (i * 7) % 251)]);
const pushShot = await studentB.call("PUT", `/api/exams/${examId}/evidence?rule=object_raised&client_id=e2e-cam-1`, { body: shot });
ok("Máy em gửi một ảnh khi phát hiện giơ điện thoại lên gần mặt", pushShot, 200);
const photo = await teacher.call("GET", `/api/rooms/${room.data.id}/evidence/${joinB.data.id}`, { bytes: true });
step("Cô mở được đúng ảnh đó, là ảnh chứ không phải video",
  photo.status === 200 && /image\/jpeg/.test(photo.type ?? "") && photo.bytes.length === shot.length, `${photo.status}, ${photo.bytes.length} byte`);
const marked = await teacher.call("GET", `/api/rooms/${room.data.id}`);
step("Bảng theo dõi đánh dấu em có ảnh bằng chứng kèm loại dấu hiệu",
  (marked.data.evidence ?? []).some(row => row.student_id === joinB.data.id && row.rule === "object_raised"), JSON.stringify(marked.data.evidence));
step("Dấu hiệu camera vào sổ cảnh báo với mức rủi ro cao", marked.data.events.some(event => event.rule === "object_raised" && event.risk === 80));
ok("Học sinh khác không đọc được ảnh của bạn", await studentA.call("GET", `/api/rooms/${room.data.id}/evidence/${joinB.data.id}`, { bytes: true }), 401);
ok("Ảnh không phải JPEG bị từ chối", await studentB.call("PUT", `/api/exams/${examId}/evidence?rule=cam_dark`, { body: new Uint8Array([0x89, 0x50, 0x4e, 0x47]) }), 422);
ok("Loại dấu hiệu bịa đặt bị từ chối", await studentB.call("PUT", `/api/exams/${examId}/evidence?rule=quay-lan`, { body: shot }), 422);
const afterDone = await studentA.call("PUT", `/api/exams/${examId}/evidence?rule=face_gone`, { body: shot });
step("Em đã nộp bài thì không gửi thêm ảnh", afterDone.status === 200 && afterDone.data.saved === false, JSON.stringify(afterDone.data));
const camOff = await teacher.call("PATCH", `/api/rooms/${room.data.id}`, { body: { cam_enabled: false } });
step("Tắt camera cho phòng là máy chủ bỏ hết ảnh đang giữ",
  camOff.status === 200 && (await teacher.call("GET", `/api/rooms/${room.data.id}/evidence/${joinB.data.id}`, { bytes: true })).status === 404);
ok("Phòng chưa bật camera thì ảnh bị chặn ngay từ cửa", await studentB.call("PUT", `/api/exams/${examId}/evidence?rule=cam_dark&client_id=e2e-cam-2`, { body: shot }), 409);
await teacher.call("PATCH", `/api/rooms/${room.data.id}`, { body: { cam_enabled: true } });

// 7c. Quyền của từng thầy cô: phòng của ai người nấy xem
const hung = actor();
ok("Thầy Hùng đăng nhập bằng tài khoản cô quản trị đã mời", await hung.call("POST", "/api/teacher/login", { body: { username: "thay.hung", password: "thitinh2026" } }), 200);
const hungRooms = await hung.call("GET", "/api/rooms");
step("Thầy Hùng không thấy phòng của cô Linh", hungRooms.status === 200 && hungRooms.data.length === 0, `${hungRooms.data?.length} phòng`);
ok("Thầy Hùng không đọc được bảng điểm lớp cô Linh", await hung.call("GET", `/api/exams/${examId}/results`), 404);
ok("Thầy Hùng không soi được camera lớp cô Linh", await hung.call("GET", `/api/rooms/${room.data.id}/cam/${joinB.data.id}`, { bytes: true }), 404);
ok("Thầy Hùng không xóa được học sinh lớp cô Linh", await hung.call("DELETE", `/api/students/${joinB.data.id}`), 404);
ok("Thầy Hùng không đọc được ảnh bằng chứng lớp cô Linh", await hung.call("GET", `/api/rooms/${room.data.id}/evidence/${joinB.data.id}`, { bytes: true }), 404);
ok("Thầy Hùng không xem được danh sách giáo viên", await hung.call("GET", "/api/teachers"), 403);
ok("Thầy Hùng không tải được bản sao lưu dữ liệu", await hung.call("GET", "/api/backup"), 403);

// 8. Đề quá giờ: máy chủ tự chốt, không cần ai bấm
const lateExam = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Đề 5 phút", duration_minutes: 5, questions: [{ type: "mcq", text: "Hỏi", options: ["a", "b"], answer: 0, points: 4 }] } });
await teacher.call("POST", `/api/exams/${lateExam.data.id}/publish`, { body: { published: true } });
const rushed = await studentB.call("POST", `/api/exams/${lateExam.data.id}/start`);
ok("Vào làm đề ngắn giờ", rushed, 200);
await studentB.call("POST", `/api/exams/${lateExam.data.id}/save`, { body: { answers: { 0: 0 } } });
const clock = await teacher.call("GET", `/api/rooms/${room.data.id}`);
const row = clock.data.exams.find(exam => exam.id === lateExam.data.id).attempts[0];
await new Promise(resolve => setTimeout(resolve, 50));
const after = await teacher.call("GET", `/api/exams/${lateExam.data.id}`);
step("Đề ngắn giờ vẫn đang chạy đúng luật, chưa bị chốt non",
  after.data.attempts[0].submitted_at === null || after.data.attempts[0].score === 4, JSON.stringify({ s: after.data.attempts[0].score, sub: Boolean(after.data.attempts[0].submitted_at) }));

// 9. Phòng bên kia không nhìn thấy đề của nhau
const otherRoom = await teacher.call("POST", "/api/rooms", { body: { title: "Lớp 11B" } });
const otherRoster = await teacher.call("PUT", `/api/rooms/${otherRoom.data.id}/students`, { body: { students: [{ student_code: "K01", name: "Phạm Minh" }] } });
const cross = await outsider.call("POST", "/api/join", { body: { room_code: otherRoom.data.code, student_code: "K01", access_code: otherRoster.data.students[0].join_code } });
ok("Học sinh lớp khác vào đúng phòng của mình", cross, 200);
const steal = await outsider.call("GET", `/api/exams/${examId}/paper`);
ok("Học sinh lớp khác không mở được đề của lớp 12A1", steal, 404);

// 10. Xuất kết quả và khóa phòng
const csv = await teacher.call("GET", `/api/exams/${examId}/results.csv`);
step("Tệp kết quả CSV có tên học sinh và từng câu", csv.status === 200 && csv.text.includes("Nguyễn Văn An") && csv.text.includes("Câu 1"), String(csv.status));
step("Tên tệp CSV có dấu vẫn tải được", /filename\*=UTF-8''/.test((await fetch(`${BASE}/api/exams/${examId}/results.csv`, { headers: { cookie: teacher.cookie } })).headers.get("content-disposition") ?? ""));
const closeRoom = await teacher.call("PATCH", `/api/rooms/${room.data.id}`, { body: { closed: true } });
ok("Cô đóng phòng sau giờ thi", closeRoom, 200);
const afterClose = await outsider.call("POST", "/api/join", { body: { room_code: room.data.code, student_code: "N03", access_code: codes[2] } });
ok("Phòng đã đóng thì học sinh không vào được", afterClose, 403);
// 10b. Thi thử xong, muốn cho lớp làm lại bằng đúng đề đó
const retake = await teacher.call("POST", `/api/exams/${examId}/reset`);
step("Cô cho cả lớp làm lại bằng đề cũ", retake.status === 200 && retake.data.reset === 2, JSON.stringify(retake.data));
const reopened = await teacher.call("PUT", `/api/exams/${examId}`, {
  body: { title: "Kiểm tra buổi 5 (chính thức)", duration_minutes: 30, questions: current.data.questions } });
ok("Xóa bài xong thì sửa được đề", reopened, 200);
const fresh = await studentA.call("POST", `/api/exams/${examId}/start`);
step("Em làm lại có đồng hồ mới và giấy trắng",
  fresh.status === 200 && Math.abs(fresh.data.remaining_ms - 30 * 60_000) < 3000 && Object.keys(fresh.data.answers).length === 0, `${fresh.data.remaining_ms} ms`);
const rowsAgain = await teacher.call("GET", `/api/exams/${examId}/results`);
const alone = rowsAgain.data.attempts.find(attempt => attempt.student_id === joinB.data.id);
const resetOne = await teacher.call("POST", `/api/attempts/${alone.id}/reset`);
step("Cô xóa bài riêng một em, không đụng các em khác", resetOne.status === 200 && resetOne.data.reset === 1, String(resetOne.status));
const history = await teacher.call("GET", `/api/rooms/${room.data.id}`);
step("Cảnh báo cũ vẫn nằm lại trong sổ làm bằng chứng", history.data.events.some(event => event.rule === "object_raised"));

// 10c. Bản sao lưu: một tệp .sql nạp lại được, chỉ chủ tài khoản tải
const dump = await teacher.call("GET", "/api/backup");
step("Cô quản trị tải được bản sao lưu chứa toàn bộ phòng thi",
  dump.status === 200 && dump.text.includes("CREATE TABLE") && dump.text.includes("Lớp 12A1"), `${dump.status}, ${dump.text.length} ký tự`);
const dumpHeaders = (await fetch(`${BASE}/api/backup`, { headers: { cookie: teacher.cookie } })).headers.get("content-disposition") ?? "";
step("Tệp sao lưu có tên kèm dấu thời gian", /filename="focuslab-\d{8}-\d{4}\.sql"/.test(dumpHeaders), dumpHeaders);

// 10d. Giao bài tập về nhà: làm theo hạn cô đặt, vẫn giám sát, và tải đề về in
const DAY = 24 * 3600_000;
const twoRows = [{ type: "mcq", text: "Viết phương trình điện phân nước", options: ["a", "b"], answer: 0, points: 2 },
                 { type: "text", text: "Giải thích vì sao nước là dung môi?", prompt: "khoảng 50 từ", points: 6 }];
const homeWork = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Bài tập buổi 7", duration_minutes: 240, questions: twoRows, kind: "baotap", open_until: Date.now() + 2 * DAY } });
ok("Cô giao bài tập về nhà kèm hạn nộp", homeWork, 200);
step("Bài tập ghi đúng loại và hạn nộp", homeWork.data.kind === "baotap"
  && Math.abs(homeWork.data.open_until - (Date.now() + 2 * DAY)) < 5000 && homeWork.data.max_points === 8,
  JSON.stringify({ k: homeWork.data.kind, p: homeWork.data.max_points }));
await teacher.call("POST", `/api/exams/${homeWork.data.id}/publish`, { body: { published: true } });
const homeList = await studentA.call("GET", "/api/exams");
const homeRow = homeList.data.find(exam => exam.id === homeWork.data.id);
step("Học sinh thấy bài tập kèm chữ chưa vào làm", homeRow?.state === "chưa vào làm", JSON.stringify(homeRow?.state));
const homeStart = await studentA.call("POST", `/api/exams/${homeWork.data.id}/start`);
step("Đồng hồ bài tập đếm tới hạn nộp, không đếm 240 phút",
  homeStart.status === 200 && homeStart.data.remaining_ms > DAY && homeStart.data.remaining_ms <= 2 * DAY, String(homeStart.data.remaining_ms));
const homeSave = await studentA.call("POST", `/api/exams/${homeWork.data.id}/save`,
  { body: { answers: { 0: 0, 1: "Vì phân tử nước phân cực…" }, paste_count: 1 } });
step("Làm bài tập vẫn lưu và chấm được", homeSave.status === 200 && homeSave.data.answered === 2, String(homeSave.data.answered));
step("Số giờ rời cửa sổ do máy chủ đo, không lấy số em tự báo",
  homeSave.status === 200 && homeSave.data.tab_events === 0 && homeSave.data.tab_ms === 0,
  JSON.stringify({ ms: homeSave.data.tab_ms, ev: homeSave.data.tab_events }));
ok("Bỏ tab khi làm bài tập vẫn bị ghi vào sổ", await studentA.call("POST", `/api/exams/${homeWork.data.id}/event`,
  { body: { rule: "tab_left", duration: 30 } }), 200);
// im lặng thật 11 giây, giống hệt em tắt màn hình điện thoại: máy chủ tự đo, không cần trình duyệt báo
await new Promise(wait => setTimeout(wait, 11_000));
const homeBack = await studentA.call("GET", `/api/exams/${homeWork.data.id}/paper`);
step("Máy em im lặng 11 giây -> cô thấy đúng một mốc rời cửa sổ",
  homeBack.status === 200 && homeBack.data.tab_events === 1 && homeBack.data.tab_ms >= 11_000,
  JSON.stringify({ ms: homeBack.data.tab_ms, ev: homeBack.data.tab_events }));
const homeBoard = await teacher.call("GET", `/api/exams/${homeWork.data.id}/results`);
step("Cô thấy dấu hiệu rời cửa sổ của em làm bài tập", homeBoard.data.attempts[0].tab_events === 1
  && (await teacher.call("GET", `/api/rooms/${room.data.id}`)).data.events.some(event => event.exam_id === homeWork.data.id),
  JSON.stringify(homeBoard.data.attempts[0]).slice(0, 90));
const noLimit = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Bài tập không hạn nộp", duration_minutes: 240, questions: twoRows, kind: "baotap" } });
await teacher.call("POST", `/api/exams/${noLimit.data.id}/publish`, { body: { published: true } });
const freeStart = await studentB.call("POST", `/api/exams/${noLimit.data.id}/start`);
step("Bài tập chưa đặt hạn thì không tự chốt và không báo hết giờ",
  freeStart.status === 200 && freeStart.data.remaining_ms === 0 && freeStart.data.submitted_at === null, JSON.stringify({ r: freeStart.data.remaining_ms }));
const pastDue = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Bài tập đã đóng", duration_minutes: 240, questions: twoRows, kind: "baotap", open_until: Date.now() - DAY } });
await teacher.call("POST", `/api/exams/${pastDue.data.id}/publish`, { body: { published: true } });
ok("Qua hạn nộp thì máy chủ chặn, em không làm lại được", await studentB.call("GET", `/api/exams/${pastDue.data.id}/paper`), 409);
const closedList = await studentB.call("GET", "/api/exams");
step("Danh sách của em ghi rõ bài hết hạn nộp", closedList.data.find(exam => exam.id === pastDue.data.id)?.state === "hết hạn nộp",
  JSON.stringify(closedList.data.map(exam => exam.state)));
const future = await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Bài tập mở sau", duration_minutes: 240, questions: twoRows, kind: "baotap",
          open_from: Date.now() + DAY, open_until: Date.now() + 2 * DAY } });
await teacher.call("POST", `/api/exams/${future.data.id}/publish`, { body: { published: true } });
ok("Chưa tới giờ mở thì chưa vào làm được", await studentA.call("POST", `/api/exams/${future.data.id}/start`), 409);
const earlyList = await studentA.call("GET", "/api/exams");
step("Danh sách ghi rõ bài chưa tới giờ mở, em không bấm nhầm",
  earlyList.data.find(exam => exam.id === future.data.id)?.state === "chưa tới giờ mở", JSON.stringify(earlyList.data.map(exam => exam.state)));
const boardWindows = (await teacher.call("GET", `/api/rooms/${room.data.id}`)).data.exams;
const windowOf = id => boardWindows.find(exam => exam.id === id)?.window;
step("Màn cô giáo cũng ghi đúng trạng thái, không báo “Đang mở” cho bài đã đóng",
  windowOf(pastDue.data.id) === "hết hạn nộp" && windowOf(future.data.id) === "chưa tới giờ mở"
  && windowOf(homeWork.data.id) === "đang mở",
  JSON.stringify([windowOf(pastDue.data.id), windowOf(future.data.id), windowOf(homeWork.data.id)]));
ok("Hạn nộp trước giờ mở là lỗi, máy chủ từ chối ngay", await teacher.call("POST", `/api/rooms/${room.data.id}/exams`, {
  body: { title: "Bài tập đặt sai", duration_minutes: 240, questions: twoRows, kind: "baotap",
          open_from: Date.now() + 2 * DAY, open_until: Date.now() + DAY } }), 422);
const homeDoc = await teacher.call("GET", `/api/exams/${homeWork.data.id}/paper.doc`);
step("Đề bài tập in ra ghi “nộp trước…” chứ không ghi thời lượng", homeDoc.status === 200
  && homeDoc.text.includes("Bài tập về nhà") && homeDoc.text.includes("nộp trước"), String(homeDoc.status));
const paperDoc = await teacher.call("GET", `/api/exams/${examId}/paper.doc`);
step("Cô tải câu hỏi về máy: tệp .doc mở bằng Word, chưa kèm đáp án",
  paperDoc.status === 200 && paperDoc.text.includes("Câu 1") && !paperDoc.text.includes("Đáp án")
  && !paperDoc.text.includes("✔"), String(paperDoc.status));
const keyDoc = await teacher.call("GET", `/api/exams/${examId}/paper.doc?answers=1`);
step("Bản kèm đáp án có dòng Đáp án và dấu ✔", keyDoc.status === 200 && keyDoc.text.includes("Đáp án") && keyDoc.text.includes("✔"), String(keyDoc.status));
const docHeaders = (await fetch(`${BASE}/api/exams/${examId}/paper.doc`, { headers: { cookie: teacher.cookie } })).headers;
step("Tệp đề tải về báo đúng kiểu Word và tên có dấu", /application\/msword/.test(docHeaders.get("content-type") ?? "")
  && /filename\*=UTF-8''.*\.doc/.test(docHeaders.get("content-disposition") ?? ""), docHeaders.get("content-disposition")?.slice(0, 120));
ok("Học sinh không tải được đề", await studentA.call("GET", `/api/exams/${examId}/paper.doc`), 401);
ok("Học sinh không tải được đáp án", await studentA.call("GET", `/api/exams/${examId}/paper.doc?answers=1`), 401);
ok("Thầy Hùng không tải được đề lớp cô Linh", await hung.call("GET", `/api/exams/${examId}/paper.doc`), 404);

const dropExam = await teacher.call("DELETE", `/api/exams/${lateExam.data.id}`);
ok("Xóa đề thử nghiệm", dropExam, 200);
const dropRoom = await teacher.call("DELETE", `/api/rooms/${otherRoom.data.id}`);
ok("Xóa phòng kèm toàn bộ bài làm", dropRoom, 200);

const failed = results.filter(result => !result.ok);
console.log(`\n${stamp()} — ${results.length - failed.length}/${results.length} bước đạt.`);
for (const failure of failed) console.log(`  FAIL: ${failure.label} ${failure.extra}`);
process.exit(failed.length ? 1 : 0);
