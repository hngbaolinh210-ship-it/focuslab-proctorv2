/* Chạy thử bộ tự phát hiện trên máy học sinh (measurement + analyze + raise) mà không cần camera thật:
   đưa từng khung hình giả vào, đồng hồ giả chạy nhanh, xem máy có báo đúng dấu hiệu và báo MỘT ảnh hay không.
   Cách dùng:  node chay-thu-phat-hien.mjs  */

import { readFile } from "node:fs/promises";

const source = await readFile(new URL("./static/exam.js", import.meta.url), "utf8");
const start = source.indexOf("const skinPixel");
const end = source.indexOf("async function sendFrame");
if (start < 0 || end < 0) throw new Error("Không tìm thấy đoạn mã tự phát hiện trong static/exam.js.");
const code = source.slice(start, end);

// ---------------------------------------------------------------- khung hình giả
// Mỗi khung hình là một mảng RGB: vụng về nhưng đủ để thử ba công thức màu.
function frame(painter) {
  const width = 96, height = 72;
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const [r, g, b] = painter(x, y, width, height);
      const p = (y * width + x) * 4;
      data[p] = r; data[p + 1] = g; data[p + 2] = b; data[p + 3] = 255;
    }
  }
  return { data, width, height };
}

const SKIN = [200, 150, 120];
const WALL = [90, 100, 110];
const DARK = [8, 8, 8];
const SCREEN = [245, 248, 252];        // màn hình điện thoại: sáng và trắng LẠNH (b >= r)
const SCREEN_WARM = [250, 240, 220];   // bật chế độ lọc ánh sáng vàng: hết mát, chỉ còn so sánh khung hình
const SHIRT = [242, 238, 226];         // áo đồng phục trắng dưới đèn lớp: sáng nhưng ẤM (r > b)
const SUN = [246, 250, 255];           // nắng cửa sổ hắt vào: sáng và MÁT, nhưng chiếm kín khung hình

// Điện thoại giơ trước ngực: quầng sáng GỌN, độ 16% vùng trước ngực — đủ nhỏ để không bị nhầm với cửa sổ.
const inPhone = (x, y, w, h) => y > h * 0.5 && y < h * 0.72 && x > w * 0.4 && x < w * 0.6;

// Em ngồi đúng tư thế: mặt (màu da) choán nửa trên, nửa dưới là áo và bàn tối màu.
const seated = (x, y, w, h) => (y < h * 0.5 && x > w * 0.25 && x < w * 0.75 ? SKIN : WALL);
// Em giơ điện thoại sáng lên gần mặt: vẫn thấy da, thêm quầng sáng mát gọn trước ngực.
const phoneUp = (x, y, w, h) => (inPhone(x, y, w, h) ? SCREEN : seated(x, y, w, h));
const warmPhoneUp = (x, y, w, h) => (inPhone(x, y, w, h) ? SCREEN_WARM : seated(x, y, w, h));
// Em rời khỏi khung hình: chỉ còn tường và áo, không một điểm màu da.
const nobody = (x, y, w, h) => (y < h * 0.5 ? WALL : [60, 70, 80]);
// Camera bị che hoặc tắt đèn.
const covered = () => DARK;
// Áo đồng phục trắng: nửa dưới sáng rực nhưng ẤM và sáng MÃI — bản cũ báo nhầm vì cứ phải so sánh.
const whiteShirt = (x, y, w, h) => (y < h * 0.5 && x > w * 0.25 && x < w * 0.75 ? SKIN : SHIRT);
// Mặc áo trắng rồi giơ điện thoại mát: áo không che được nữa, vì hai màu khác nhau rõ rệt.
const whiteShirtPhone = (x, y, w, h) => (inPhone(x, y, w, h) ? SCREEN : whiteShirt(x, y, w, h));
// Nắng cửa sổ: sáng và mát thật nhưng chiếm kín vùng trước ngực, không phải hình chữ nhật gọn.
const daylight = (x, y, w, h) => (y < h * 0.5 && x > w * 0.25 && x < w * 0.75 ? SKIN : SUN);

// ---------------------------------------------------------------- môi trường giả
let now = 1_000_000;
const alerts = [];
const timers = new Map();

const sandbox = {
  HOLD: { cam_dark: 5000, face_gone: 9000, object_raised: 0 },
  COOLDOWN_MS: 90000,
  scan: null,
  holdSince: {},
  lastAlert: {},
  camStream: { active: true },
  submitted: false,
  paper: { id: "de-1" },
  el: () => ({ videoWidth: 480, videoHeight: 360 }),
  notify: () => {},
  crypto: { randomUUID: () => `id-${alerts.length}` },
  jpegOf: async () => new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]),
  document: {
    hidden: false,
    createElement: () => ({
      width: 0, height: 0,
      getContext: () => ({
        drawImage: (_video, _dx, _dy, w, h) => { sandbox.__size = [w, h]; },
        getImageData: () => sandbox.__pixels,
      }),
    }),
  },
  fetch: async (url) => { alerts.push(url); return { ok: true, json: async () => ({}) }; },
};

const results = [];
const step = (label, ok, extra = "") => {
  results.push({ label, ok, extra });
  console.log(`${ok ? "OK  " : "FAIL"} ${label}${extra ? ` — ${extra}` : ""}`);
};

function run(code, globals) {
  const names = Object.keys(globals);
  const body = `${code}
    return { measure, analyze, raise, state: () => ({ holdSince, lastAlert }) };`;
  // eslint-disable-next-line no-new-func
  return new Function(...names, body)(...names.map(name => globals[name]));
}

// Date.now và setInterval trong đoạn mã dùng đồng hồ thật, nên cho nó một Date giả.
const RealDate = Date;
class FakeDate extends RealDate {
  constructor(...args) {
    super(args.length ? args[0] : now);
  }
  static now() {
    return now;
  }
}
const api = run(code, { ...sandbox, document: sandbox.document, Date: FakeDate, notify: sandbox.notify,
  crypto: sandbox.crypto, fetch: sandbox.fetch, jpegOf: sandbox.jpegOf, el: sandbox.el,
  HOLD: sandbox.HOLD, COOLDOWN_MS: sandbox.COOLDOWN_MS });

// raise() là hàm bất đồng bộ: phải để các lời gọi fetch kịp chạy rồi mới đếm số ảnh gửi lên.
const flush = () => new Promise(resolve => setImmediate(resolve));

async function show(painter) {
  sandbox.__pixels = frame(painter);
  now += 80;                // mỗi lần phân tích cách nhau đúng WATCH_EVERY
  api.analyze();
  await flush();
}

const sent = () => alerts.length;
const rule = (i) => (alerts[i] ?? "").match(/rule=([a-z_]+)/)?.[1] ?? "";

// 1. Ngồi đúng tư thế thì im lặng — đây là điều quan trọng nhất, không được báo nhiễu.
for (let i = 0; i < 80; i++) await show(seated);
step("Em ngồi làm bài bình thường: 6,4 giây phân tích, không báo gì", sent() === 0, `${sent()} ảnh gửi lên`);

// 2. GIƠ CÓ 0,16 GIÂY: máy phải báo ngay lần đo đầu tiên, không chờ giữ dấu hiệu nữa.
await show(phoneUp);
await show(phoneUp);
step("Giơ điện thoại đúng 0,16 giây: vẫn bắt được, gửi 1 ảnh", sent() === 1 && rule(0) === "object_raised", alerts[0] ?? "");

// 2b. Màn hình chỉnh ánh sáng vàng (không còn chất mát) thì so khung hình vẫn phải thấy.
now += 90_000;
for (let i = 0; 8 > i; i++) await show(seated);
const warm = sent();
await show(warmPhoneUp);
await show(warmPhoneUp);
step("Điện thoại bật lọc ánh sáng vàng: máy vẫn thấy nhờ so khung hình", sent() === warm + 1 && rule(warm) === "object_raised", `${sent() - warm} ảnh`);

// 3. Cùng một dấu hiệu liên tiếp không được biến thành bão cảnh báo.
for (let i = 0; 40 > i; i++) await show(phoneUp);
step("Vẫn giơ điện thoại thêm 3,2 giây nữa: không thành bão, vẫn đúng 1 ảnh", sent() === warm + 1, `${sent()} ảnh`);

// 3b. Hạ xuống rồi giơ lại: phải bắt được lần nữa (không phải báo một lần rồi thôi cả buổi).
now += 90_000;
for (let i = 0; 6 > i; i++) await show(seated);
step("Hạ tay xuống: không báo thêm", sent() === warm + 1, `${sent()} ảnh`);
await show(phoneUp);
step("Giơ điện thoại lên lần thứ hai: máy báo lại ngay", sent() === warm + 2 && rule(warm + 1) === "object_raised", `${sent()} ảnh`);

// 3c. Áo đồng phục trắng (hoặc ai bật đèn): cả vùng trước ngực cùng bật sáng một lúc — đổi HẾT khung thì
//     không phải cái điện thoại, máy phải im. Vẫn làm nóng vài khung hình rồi mới tính.
now += 90_000;
const lamp = sent();
for (let i = 0; 8 > i; i++) await show(whiteShirt);
step("Thay đổi sáng chiếu KÍN vùng trước ngực (bật đèn, áo trắng): không báo", sent() === lamp, `${sent() - lamp} ảnh thêm`);
const base = sent();
for (let i = 0; 80 > i; i++) await show(whiteShirt);
step("Cả lớp mặc áo trắng suốt 6,4 giây: không báo nhầm", sent() === base, `${sent() - base} ảnh thêm`);

// 3d. GIƠ ĐIỆN THOẠI TRÊN NỀN ÁO TRẮNG — bản cũ bó tay, bản mới phân biệt được màn hình mát với áo ấm.
await show(whiteShirtPhone);
await show(whiteShirtPhone);
step("Mặc áo trắng mà giơ điện thoại mát 0,16 giây: máy vẫn thấy", sent() === base + 1 && rule(base) === "object_raised", `${sent() - base} ảnh`);

// 3e. Nắng cửa sổ hắt kín khung: sáng và mát thật nhưng không gọn nên phải im.
now += 90_000;
for (let i = 0; 8 > i; i++) await show(whiteShirt);
const sun = sent();
for (let i = 0; 8 > i; i++) await show(daylight);
for (let i = 0; 60 > i; i++) await show(daylight);
step("Cửa sổ nắng chiếu kín vùng trước ngực 5 giây: không báo nhầm", sent() === sun, `${sent() - sun} ảnh thêm`);

// 4. Rời khỏi khung hình: phải chờ đủ 9 giây, không báo vì một cái quay đầu.
now += 90_000;
for (let i = 0; 100 > i; i++) await show(nobody);
step("Em rời khỏi khung hình 8 giây: chưa báo", sent() === sun, `${sent() - sun} ảnh thêm`);
for (let i = 0; 20 > i; i++) await show(nobody);
step("Em không đứng trước camera 10 giây: báo face_gone", sent() === sun + 1 && rule(sun) === "face_gone", alerts[sun] ?? "");

// 5. Che camera: báo cam_dark chứ không phải face_gone.
now += 90_000;
for (let i = 0; 70 > i; i++) await show(covered);
step("Camera bị che: báo cam_dark, không báo nhầm mất mặt",
  sent() === sun + 2 && rule(sun + 1) === "cam_dark", alerts[sun + 1] ?? "");

// 6. Một cái quay đầu nhanh hoặc ngồi sai tư thế không thành cảnh báo.
now += 90_000;
await show(nobody);
await show(seated);
await show(seated);
await show(nobody);
step("Quay đầu 2 lần trong 0,32 giây: không báo", sent() === sun + 2, `${sent()} ảnh`);

// 7. Ảnh gửi lên là JPEG do canvas vẽ lại, kèm client_id riêng để máy chủ chống trùng.
step("Mỗi lần báo gửi đúng một ảnh, có client_id riêng",
  alerts.every(url => /client_id=id-\d+/.test(url)) && new Set(alerts).size === alerts.length);

// 8. Máy mất mạng thì dấu hiệu vẫn được tính, không làm trang làm bài crash.
sandbox.fetch = async () => { throw new Error("mất mạng"); };
const quiet = run(code, { ...sandbox, Date: FakeDate });
now += 90_000;
let crashed = false;
try {
  for (let i = 0; i < 70; i++) { sandbox.__pixels = frame(covered); now += 80; quiet.analyze(); }
  await flush();
} catch { crashed = true; }
step("Mất mạng giữa giờ: máy chỉ thôi gửi ảnh, trang làm bài không lỗi", !crashed);

// 9. measure() phải trả về các tỉ lệ phần thập phân, tính riêng quầng sáng mát của màn hình.
sandbox.__pixels = frame(whiteShirtPhone);
const stats = api.measure({ videoWidth: 480, videoHeight: 360 });
const summary = `da ${(stats.skin * 100).toFixed(0)}%, sáng ${(stats.bright * 100).toFixed(0)}%, mát ${(stats.cool * 100).toFixed(0)}%`;
step("Đo khung hình trả về tỉ lệ phần thập phân (không phải số pixel thô)",
  stats && 0 <= stats.skin && stats.skin <= 1 && 0 <= stats.bright && stats.bright <= 1
    && 0 < stats.cool && stats.cool <= 0.35 && typeof stats.dark === "boolean", summary);

const failed = results.filter(result => !result.ok);
console.log(`\n${failed.length ? failed.length + " bước Hỏng" : "Toàn bộ " + results.length + " bước đạt."}`);
for (const failure of failed) console.log(`  FAIL: ${failure.label} ${failure.extra}`);
process.exit(failed.length ? 1 : 0);
