"""SQLite là kho duy nhất: một tệp trong /data sống sót qua mỗi lần Railway dựng lại dịch vụ."""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS teachers (
  id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL, is_owner INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL, last_login INTEGER
);
CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, title TEXT NOT NULL, owner_id TEXT NOT NULL,
  created_at INTEGER NOT NULL, closed INTEGER NOT NULL DEFAULT 0, cam_enabled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY, room_id TEXT NOT NULL, student_code TEXT NOT NULL, name TEXT NOT NULL,
  seat_id TEXT NOT NULL, join_code TEXT NOT NULL DEFAULT '', join_hash TEXT NOT NULL,
  last_seen INTEGER NOT NULL DEFAULT 0,
  UNIQUE (room_id, student_code), UNIQUE (room_id, seat_id)
);
CREATE TABLE IF NOT EXISTS exams (
  id TEXT PRIMARY KEY, room_id TEXT NOT NULL, title TEXT NOT NULL, duration_minutes INTEGER NOT NULL,
  questions TEXT NOT NULL, max_points INTEGER NOT NULL, published INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
  id TEXT PRIMARY KEY, exam_id TEXT NOT NULL, student_id TEXT NOT NULL,
  started_at INTEGER, submitted_at INTEGER, answers TEXT NOT NULL DEFAULT '{}', score REAL,
  marks TEXT NOT NULL DEFAULT '{}', tab_ms INTEGER NOT NULL DEFAULT 0, tab_events INTEGER NOT NULL DEFAULT 0,
  paste_count INTEGER NOT NULL DEFAULT 0, last_seen INTEGER NOT NULL DEFAULT 0, UNIQUE (exam_id, student_id)
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, room_id TEXT NOT NULL, student_id TEXT, exam_id TEXT,
  rule TEXT NOT NULL, risk INTEGER NOT NULL, duration REAL, client_id TEXT,
  created_at INTEGER NOT NULL, UNIQUE (room_id, client_id)
);
CREATE TABLE IF NOT EXISTS sessions (
  hash TEXT PRIMARY KEY, role TEXT NOT NULL, teacher_id TEXT, student_id TEXT, room_id TEXT, expires INTEGER NOT NULL
);
"""


def new_id() -> str:
    return str(uuid.uuid4())


def now() -> int:
    return int(time.time() * 1000)


def _upgrade(conn: sqlite3.Connection) -> None:
    """Thêm cột của bản mới vào tệp dữ liệu đã có, không xóa gì của giáo viên."""
    def add(table: str, column: str, declaration: str) -> None:
        if column not in {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")

    add("students", "join_code", "TEXT NOT NULL DEFAULT ''")
    add("rooms", "cam_enabled", "INTEGER NOT NULL DEFAULT 0")
    # Bản 3.3: một đề vừa là bài thi vừa là bài tập về nhà (làm trong khoảng thời gian cô đặt).
    add("exams", "kind", "TEXT NOT NULL DEFAULT 'thi'")
    add("exams", "open_from", "INTEGER")
    add("exams", "open_until", "INTEGER")


def connect(path: str | Path) -> sqlite3.Connection:
    file = Path(path)
    file.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(file), check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA)
    _upgrade(db)
    db.commit()
    return db


def questions_of(row: sqlite3.Row) -> list[dict]:
    return json.loads(row["questions"])


def answers_of(row: sqlite3.Row) -> dict:
    return json.loads(row["answers"])


def public_student(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "student_code": row["student_code"], "name": row["name"], "seat_id": row["seat_id"], "last_seen": row["last_seen"]}
