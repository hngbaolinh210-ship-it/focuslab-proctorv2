"""FocusLab Thi Online — một tiến trình FastAPI, một tệp SQLite, ảnh camera chỉ nằm trong RAM."""
from __future__ import annotations

import csv
import hmac
import io
import json
import os
import re
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from html import escape
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import auth, cam, db, papers, vault

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"

GRACE_MS = 90_000  # ân hạn cho lệnh nộp đang đi khi vừa hết giờ
MIN_DURATION, MAX_DURATION = 5, 240
MAX_STUDENTS = 200
MAX_EVENTS = 400
RULES = {"tab_left": 70, "paste": 60, "idle": 40, "cam_off": 65}
# Máy chủ tự đo khoảng lặng giữa hai lần nghe tin từ máy học sinh — trình duyệt điện thoại
# bị đông băng lúc tắt màn hình nên không thể tin nó tự báo "em rời cửa sổ X giây".
# Máy em báo nhịp mỗi 3 giây; im lặng quá 8 giây là chắc chắn bỏ lỡ hơn hai nhịp — đủ nhanh để cô
# thấy ngay, đủ dài để một lần mạng lướt qua không thành cảnh báo oan.
AWAY_MS = 8_000
AWAY_HOME_MS = 60 * 60_000  # làm bài ở nhà mà tắt máy cả tiếng là chuyện bình thường, không ghi, không báo
LOGIN_MAX_FAILS = 10
LOGIN_LOCK_MS = 10 * 60_000  # một máy sai mật khẩu 10 lần thì phải chờ 10 phút
# Ba dấu hiệu máy em học sinh tự nhận ra tại chỗ; mỗi lần báo chỉ gửi lên ĐÚNG MỘT ảnh.
CAM_RULES = {"cam_dark": 60, "face_gone": 55, "object_raised": 80}
ONLINK_MS = 90_000
VN_TIME = timezone(timedelta(hours=7))  # lịch thi in ra CSV phải theo giờ Việt Nam, máy chủ ở múi nào cũng vậy


class FreshFiles(StaticFiles):
    """Trình duyệt phải hỏi lại máy chủ mỗi lần vào phòng thi.

    Không có dòng này thì sau khi cô tải bản mới lên, máy học sinh vẫn dùng tệp
    cũ trong cache — sửa giao diện mà cả lớp không thấy gì là hỏng cả buổi thi.
    """

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        response.headers["cache-control"] = "no-cache"
        return response


class Login(BaseModel):
    username: str
    password: str
    display_name: str = ""


class RoomIn(BaseModel):
    title: str


class RoomPatch(BaseModel):
    title: str | None = None
    closed: bool | None = None
    cam_enabled: bool | None = None


class WatchIn(BaseModel):
    student_id: str | None = None


class StudentIn(BaseModel):
    student_code: str
    name: str


class RosterIn(BaseModel):
    students: list[StudentIn]


class ExamIn(BaseModel):
    title: str
    duration_minutes: int
    questions: list[dict[str, Any]]
    kind: str = "thi"               # "thi": đếm giờ từ lúc bấm bắt đầu; "baotap": làm trong hạn cô đặt
    open_from: int | None = None    # mốc thời gian máy chủ, tính bằng mili giây
    open_until: int | None = None


class PublishIn(BaseModel):
    published: bool = True


class JoinIn(BaseModel):
    room_code: str
    student_code: str
    access_code: str


class AnswersIn(BaseModel):
    answers: dict[str, Any] = {}
    paste_count: int = 0


class EventIn(BaseModel):
    rule: str
    duration: float | None = None
    client_id: str | None = None


class MarksIn(BaseModel):
    marks: dict[str, float] = {}


class Store:
    """Một kết nối SQLite dùng chung, mọi lượt ghi đi qua một ổ khoá."""

    def __init__(self, path: str | Path, vault: vault.Vault | None = None):
        self.conn = db.connect(path)
        self.lock = threading.Lock()
        self.vault = vault
        if vault:
            vault.snapshot = self.backup

    def all(self, sql: str, *args: Any) -> list[sqlite3.Row]:
        return self.conn.execute(sql, args).fetchall()

    def one(self, sql: str, *args: Any) -> sqlite3.Row | None:
        return self.conn.execute(sql, args).fetchone()

    def backup(self) -> bytes:
        with self.lock:
            return vault.dump(self.conn)

    def transact(self, action: Callable[[sqlite3.Connection], Any]) -> Any:
        with self.lock:
            try:
                result = action(self.conn)
                self.conn.commit()
                if self.vault:
                    self.vault.note_write()
                return result
            except Exception:
                self.conn.rollback()
                raise

    def close(self) -> None:
        if self.vault:
            self.vault.close()
        self.conn.close()


def store_of(request: Request) -> Store:
    return request.app.state.store


# ---------------------------------------------------------------- phiên làm việc


def issue(store: Store, response: Any, role: str, *, teacher_id: str = None, student_id: str = None, room_id: str = None) -> None:
    token = auth.session_token()
    response.set_cookie(
        auth.SESSION_COOKIE, token, max_age=auth.SESSION_DAYS // 1000,
        httponly=True, samesite="lax", secure=os.getenv("FOCUSLAB_COOKIE_SECURE") == "1", path="/",
    )
    expires = db.now() + auth.SESSION_DAYS

    def write(conn: sqlite3.Connection) -> None:
        conn.execute("DELETE FROM sessions WHERE expires < ?", (db.now(),))
        conn.execute(
            "INSERT INTO sessions (hash, role, teacher_id, student_id, room_id, expires) VALUES (?,?,?,?,?,?)",
            (auth.digest(token), role, teacher_id, student_id, room_id, expires),
        )

    store.transact(write)


def session_row(store: Store, request: Request) -> sqlite3.Row | None:
    token = request.cookies.get(auth.SESSION_COOKIE)
    if not token:
        return None
    return store.one("SELECT * FROM sessions WHERE hash = ? AND expires > ?", auth.digest(token), db.now())


def login_key(name) -> str:
    """Khóa để so sánh tên đăng nhập: bỏ dấu, bỏ hoa thường, bỏ chấm và gạch. "Co.Linh" với "co_linh" là một người."""
    return re.sub(r"[^a-z0-9]", "", papers.plain(name))


def teacher_required(request: Request, store: Store = Depends(store_of)) -> sqlite3.Row:
    session = session_row(store, request)
    if not session or session["role"] != "teacher":
        raise HTTPException(401, "Cần đăng nhập giáo viên.")
    teacher = store.one("SELECT * FROM teachers WHERE id = ?", session["teacher_id"])
    if not teacher:
        raise HTTPException(401, "Tài khoản không còn tồn tại.")
    return teacher


def student_required(request: Request, store: Store = Depends(store_of)) -> sqlite3.Row:
    session = session_row(store, request)
    if not session or session["role"] != "student":
        raise HTTPException(401, "Em cần vào lại phòng thi bằng mã tham gia.")
    student = store.one("SELECT * FROM students WHERE id = ?", session["student_id"])
    if not student:
        raise HTTPException(401, "Tên em không còn trong danh sách lớp. Nhờ giáo viên kiểm tra lại.")
    return student


# ---------------------------------------------------------------- bài thi


def grade(questions: list[dict], answers: dict, marks: dict) -> tuple[float, float, float]:
    """Trả về (điểm quy đổi, điểm trắc nghiệm máy tự chấm, điểm tự luận giáo viên chấm)."""
    choice = essay = 0.0
    for index, question in enumerate(questions):
        key = str(index)
        value = answers.get(key)
        if question["type"] == "mcq":
            try:
                picked = int(value)
            except (TypeError, ValueError):
                continue
            if picked == question["answer"]:
                choice += question["points"]
        else:
            essay += float(marks.get(key) or 0)
    return round(choice + essay, 2), choice, round(essay, 2)


def deadline_of(exam: sqlite3.Row, attempt: sqlite3.Row) -> int:
    """Bài thi chốt theo đồng hồ đếm ngược; bài tập chốt theo hạn nộp cô đặt, chưa đặt hạn là không tự chốt."""
    if exam["kind"] == "baotap":
        return int(exam["open_until"]) + GRACE_MS if exam["open_until"] else 0
    return int(attempt["started_at"]) + int(exam["duration_minutes"]) * 60_000 + GRACE_MS


def remaining_ms(exam: sqlite3.Row, attempt: sqlite3.Row, moment: int) -> int:
    """Đồng hồ của học sinh: đề thi đếm thời lượng, bài tập đếm tới hạn nộp (0 = còn vô thời hạn)."""
    if attempt["submitted_at"] or not attempt["started_at"]:
        return 0
    if exam["kind"] == "baotap":
        return max(0, int(exam["open_until"]) - moment) if exam["open_until"] else 0
    return max(0, int(attempt["started_at"]) + int(exam["duration_minutes"]) * 60_000 - moment)


def close_overdue(store: Store, exam: sqlite3.Row, attempt: sqlite3.Row, moment: int) -> sqlite3.Row:
    """Hết giờ là máy chủ tự chốt bài đã lưu, để em rớt mạng đúng lúc chuông không mất điểm."""
    if attempt["submitted_at"] or not attempt["started_at"]:
        return attempt
    deadline = deadline_of(exam, attempt)
    if not deadline or moment <= deadline:
        return attempt

    def write(conn: sqlite3.Connection) -> None:
        questions = db.questions_of(exam)
        score, _, _ = grade(questions, db.answers_of(attempt), json.loads(attempt["marks"]))
        conn.execute(
            "UPDATE attempts SET submitted_at = ?, score = ?, last_seen = ? WHERE id = ?",
            (deadline, score, moment, attempt["id"]),
        )

    store.transact(write)
    return store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"])


def quiet_ms(exam: sqlite3.Row, attempt: sqlite3.Row, moment: int) -> int:
    """Bao lâu rồi máy em chưa báo tin. Cô nhìn con số này là biết em đang rời cửa sổ,
    không phải chờ em quay lại làm bài rồi mới thấy mốc trên bảng."""
    if attempt["submitted_at"] or not attempt["started_at"] or exam["kind"] != "thi":
        return 0
    seen = int(attempt["last_seen"] or 0)
    return max(0, moment - seen) if seen else 0


def attempt_public(exam: sqlite3.Row, attempt: sqlite3.Row) -> dict:
    moment = db.now()
    return {
        "id": attempt["id"], "exam_id": attempt["exam_id"], "student_id": attempt["student_id"],
        "started_at": attempt["started_at"], "submitted_at": attempt["submitted_at"],
        "score": attempt["score"], "marks": json.loads(attempt["marks"]),
        "answered": len([v for v in db.answers_of(attempt).values() if v not in (None, "")]),
        "tab_ms": attempt["tab_ms"], "tab_events": attempt["tab_events"], "paste_count": attempt["paste_count"],
        "last_seen": attempt["last_seen"], "remaining_ms": remaining_ms(exam, attempt, moment),
        "quiet_ms": quiet_ms(exam, attempt, moment),
        "max_points": exam["max_points"],
    }


def open_window(exam: sqlite3.Row, moment: int) -> str:
    """Cửa sổ làm bài tính bằng đồng hồ máy chủ — màn cô giáo và màn học sinh phải cùng một trạng thái."""
    if not exam["published"]:
        return "chưa mở"
    if exam["kind"] == "baotap":
        if exam["open_until"] and moment > int(exam["open_until"]) + GRACE_MS:
            return "hết hạn nộp"
        if exam["open_from"] and moment < int(exam["open_from"]):
            return "chưa tới giờ mở"
    return "đang mở"


def exam_public(store: Store, exam: sqlite3.Row) -> dict:
    attempts = store.all("SELECT * FROM attempts WHERE exam_id = ? ORDER BY started_at", exam["id"])
    closed = [close_overdue(store, exam, attempt, db.now()) for attempt in attempts]
    return {
        "id": exam["id"], "room_id": exam["room_id"], "title": exam["title"],
        "duration_minutes": exam["duration_minutes"], "question_count": len(db.questions_of(exam)),
        "max_points": exam["max_points"], "published": bool(exam["published"]), "created_at": exam["created_at"],
        "kind": exam["kind"], "open_from": exam["open_from"], "open_until": exam["open_until"],
        "window": open_window(exam, db.now()),
        "students": store.one("SELECT COUNT(*) AS n FROM students WHERE room_id = ?", exam["room_id"])["n"],
        "attempts": [attempt_public(exam, attempt) for attempt in closed],
    }


def paper_public(questions: list[dict]) -> list[dict]:
    return [{"index": index, "type": question["type"], "text": question["text"], "points": question["points"],
             "options": question.get("options", []), "prompt": question.get("prompt", "")}
            for index, question in enumerate(questions)]


def csv_body(rows: list[list[str]]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\r\n")
    writer.writerows(rows)
    return "\ufeff" + buffer.getvalue()


def stamp(moment: int | None) -> str:
    return datetime.fromtimestamp(moment / 1000, VN_TIME).strftime("%d/%m/%Y %H:%M") if moment else ""


def download(filename: str, body: str, media_type: str = "text/csv; charset=utf-8") -> PlainTextResponse:
    """Tên tệp tiếng Việt phải gửi theo RFC 5987, không trình duyệt nào nhận chuỗi có dấu trong header thường."""
    fallback = re.sub(r"[^A-Za-z0-9._-]", "-", filename).strip("-") or "tai-len.csv"
    return PlainTextResponse(
        body, media_type=media_type,
        headers={"content-disposition": f'attachment; filename="{fallback}"; filename*=UTF-8\'\'{quote(filename)}'},
    )


def paper_document(exam_title: str, room_title: str, exam: sqlite3.Row, questions: list[dict],
                   with_answers: bool) -> str:
    """Tệp mở bằng Word hoặc LibreOffice để cô in ra giao bài tập, kèm đáp án khi cô cần."""
    head = (f"<p style='font-family:Times New Roman'><b>{escape(room_title)}</b> — {escape(exam_title)}</p>"
            f"<p>{'Bài tập về nhà' if exam['kind'] == 'baotap' else 'Đề thi'} · {len(questions)} câu · "
            f"tổng {exam['max_points']} điểm · "
            + (f"nộp trước {stamp(exam['open_until'])}" if exam["open_until"]
               else f"làm trong {exam['duration_minutes']} phút") + "</p><hr>")
    parts = []
    for index, question in enumerate(questions):
        parts.append(f"<p><b>Câu {index + 1}</b> ({question['points']:g} điểm). {escape(question['text'])}</p>")
        if question["type"] != "mcq":
            parts.append(f"<p style='margin-left:24px'><i>{escape(question.get('prompt') or 'Viết bài làm vào giấy nộp.')}</i></p>")
            continue
        for letter, option in zip("ABCDEFGH", question["options"]):
            mark = " ✔" if with_answers and question["answer"] == "ABCDEFGH".index(letter) else ""
            parts.append(f"<p style='margin-left:24px'>{letter}. {escape(option)}{mark}</p>")
    key = ""
    if with_answers:
        key = ("<hr><p><b>Đáp án</b></p><p>"
               + " · ".join(f"Câu {index + 1}: {'ABCDEFGH'[question['answer']]}"
                            for index, question in enumerate(questions) if question["type"] == "mcq") + "</p>")
    return (f"<html><head><meta charset='utf-8'><title>{escape(exam_title)}</title></head><body>"
            f"{head}{''.join(parts)}{key}</body></html>")


def roster_csv(room: sqlite3.Row, students: list[sqlite3.Row]) -> str:
    rows = [["Số thứ tự", "Mã học sinh", "Họ và tên", "Chỗ ngồi", "Mã tham gia", "Phòng thi"]]
    rows += [[str(i + 1), s["student_code"], s["name"], s["seat_id"], s["join_code"], room["code"]] for i, s in enumerate(students)]
    return csv_body(rows)


def parse_roster(data: bytes) -> list[tuple[str, str]]:
    """Nhận CSV danh sách lớp: hai cột đầu là mã học sinh và tên, có thể có dòng tiêu đề."""
    text = papers.decode_text(data)
    rows = [row for row in csv.reader(io.StringIO(text)) if any(cell.strip() for cell in row)]
    if not rows:
        raise HTTPException(422, 'Tệp danh sách đang rỗng.')
    header = papers.plain(" ".join(rows[0][:2]))
    if any(word in header for word in ("ma", "ten", "name", "student", "code", "stt", "so thu tu")):
        rows = rows[1:]
    pairs = []
    for row in rows:
        code = (row[0] if len(row) > 0 else "").strip()
        name = (row[1] if len(row) > 1 else "").strip()
        if not code or not name:
            continue
        if not code.isascii() or not code.replace(".", "").isalnum() or len(code) > 16:
            raise HTTPException(422, f'Mã học sinh “{code}” phải là chữ không dấu kèm số, tối đa 16 ký tự.')
        pairs.append((code, name[:80]))
    if not pairs:
        raise HTTPException(422, 'Không đọc được học sinh nào. Mỗi dòng cần “mã học sinh, họ và tên”.')
    return pairs[:MAX_STUDENTS]


# ---------------------------------------------------------------- ứng dụng


def create_app(database: str | Path | None = None) -> FastAPI:
    application = FastAPI(title="FocusLab Thi Online", docs_url=None, redoc_url=None, openapi_url=None)
    path = str(database or os.getenv("FOCUSLAB_DB", "data/focuslab-thi.db"))
    keeper, backup_note = vault.open_vault(os.getenv("FOCUSLAB_BACKUP_URL"), path)
    application.state.backup_note = backup_note
    application.state.store = Store(path, vault=keeper)
    application.state.keeper = keeper
    store = application.state.store
    camera = cam.CameraBoard()  # chỉ sống trong RAM, mất theo tiến trình, không bao giờ ghi đĩa
    application.state.camera = camera

    # đăng nhập sai 10 lần từ một máy thì khóa máy đó 10 phút — chống dò mật khẩu
    failed_logins: dict[str, list[int]] = {}

    def login_guard(request: Request, username: str, *, mode: str) -> None:
        """mode = "check" trước khi thử mật khẩu, "fail" khi sai, "ok" khi đúng (xóa hết dấu vết)."""
        key = f"{request.client.host if request.client else '-'}|{login_key(username)}"
        moment = db.now()
        recent = [seen for seen in failed_logins.get(key, ()) if moment - seen < LOGIN_LOCK_MS]
        if mode == "ok":
            failed_logins.pop(key, None)
        elif mode == "fail":
            recent.append(moment)
            failed_logins[key] = recent
        for stale in [k for k, v in failed_logins.items() if not v or moment - v[-1] >= LOGIN_LOCK_MS]:
            failed_logins.pop(stale, None)
        if mode in ("check", "fail") and len(recent) >= LOGIN_MAX_FAILS:
            raise HTTPException(429, f"Sai mật khẩu {LOGIN_MAX_FAILS} lần, chờ {LOGIN_LOCK_MS // 60_000} phút rồi thử lại.")

    # ---------------------------------------------------------------- đăng nhập

    @application.get("/api/me")
    def me(request: Request) -> dict:
        session = session_row(store, request)
        if not session:
            return {"role": None}
        if session["role"] == "teacher":
            teacher = store.one("SELECT * FROM teachers WHERE id = ?", session["teacher_id"])
            if not teacher:
                return {"role": None}
            return {"role": "teacher", "username": teacher["username"], "display_name": teacher["display_name"],
                    "is_owner": bool(teacher["is_owner"])}
        student = store.one("SELECT * FROM students WHERE id = ?", session["student_id"])
        if not student:
            return {"role": None}
        room = store.one("SELECT * FROM rooms WHERE id = ?", student["room_id"])
        return {"role": "student", **db.public_student(student), "room_id": room["id"], "room_title": room["title"],
                "room_code": room["code"], "closed": bool(room["closed"])}

    @application.post("/api/teacher/login")
    def login(body: Login, request: Request, response: Response) -> dict:
        rows = store.all("SELECT * FROM teachers")
        if not rows:
            raise HTTPException(404, 'Chưa có tài khoản nào. Bấm “Tạo tài khoản đầu tiên”.')
        login_guard(request, body.username, mode="check")
        match = next((row for row in rows if login_key(row["username"]) == login_key(body.username.strip())), None)
        if not match or not auth.password_matches(body.password, match["password_hash"]):
            login_guard(request, body.username, mode="fail")
            raise HTTPException(401, "Sai tên đăng nhập hoặc mật khẩu.")
        login_guard(request, body.username, mode="ok")

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE teachers SET last_login = ? WHERE id = ?", (db.now(), match["id"]))

        store.transact(write)
        issue(store, response, "teacher", teacher_id=match["id"])
        return {"role": "teacher", "username": match["username"], "display_name": match["display_name"]}

    @application.post("/api/teacher/setup")
    def setup(body: Login, response: Response) -> dict:
        """Chỉ tạo được tài khoản đầu tiên; từ đó về sau phải do chủ tài khoản thêm trong bảng quản trị."""
        if store.one("SELECT COUNT(*) AS n FROM teachers")["n"]:
            raise HTTPException(403, "Phòng đã có tài khoản. Nhờ giáo viên quản trị cấp mã đăng nhập.")
        username = body.username.strip()
        if len(body.password) < 8:
            raise HTTPException(422, "Mật khẩu cần ít nhất 8 ký tự.")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{2,31}", username):
            raise HTTPException(422, "Tên đăng nhập chỉ dùng chữ không dấu, số, dấu chấm, gạch dưới hoặc gạch ngang "
                                     "(3–32 ký tự), ví dụ co.thanh.b. Còn họ tên hiển thị cứ viết tiếng Việt có dấu.")
        teacher_id = db.new_id()

        def write(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO teachers (id, username, display_name, password_hash, is_owner, created_at, last_login)"
                " VALUES (?,?,?,?,?,?,?)",
                (teacher_id, username, body.display_name.strip() or username, auth.password_hash(body.password), 1, db.now(), db.now()),
            )

        store.transact(write)
        issue(store, response, "teacher", teacher_id=teacher_id)
        return {"role": "teacher", "username": username, "display_name": body.display_name.strip() or username}

    @application.get("/api/teachers")
    def teachers(teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Chủ tài khoản xem danh sách giáo viên đang có trong trường."""
        if not teacher["is_owner"]:
            raise HTTPException(403, "Chỉ chủ tài khoản mới xem được danh sách giáo viên.")
        return {"teachers": [{"username": row["username"], "display_name": row["display_name"],
                              "is_owner": bool(row["is_owner"]), "last_login": row["last_login"]}
                             for row in store.all("SELECT * FROM teachers ORDER BY created_at")]}

    @application.post("/api/teacher/invite")
    def invite(body: Login, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Thêm tài khoản giáo viên khác trong cùng trường."""
        if not teacher["is_owner"]:
            raise HTTPException(403, "Chỉ chủ tài khoản mới thêm được giáo viên mới.")
        username = body.username.strip()
        if len(body.password) < 8:
            raise HTTPException(422, "Mật khẩu cần ít nhất 8 ký tự.")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{2,31}", username):
            raise HTTPException(422, "Tên đăng nhập chỉ dùng chữ không dấu, số, dấu chấm, gạch dưới hoặc gạch ngang "
                                     "(3–32 ký tự), ví dụ co.thanh.b. Họ tên hiển thị thì cứ viết tiếng Việt có dấu.")
        if any(login_key(row["username"]) == login_key(username)
               for row in store.all("SELECT username FROM teachers")):
            raise HTTPException(409, f'Tên đăng nhập “{username}” trùng với tài khoản đã có (máy không phân biệt hoa thường, '
                                     "dấu hay dấu chấm). Hãy đặt tên khác, ví dụ co.thanh.b; còn họ tên hiển thị thì được trùng.")

        def write(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO teachers (id, username, display_name, password_hash, is_owner, created_at)"
                " VALUES (?,?,?,?,0,?)",
                (db.new_id(), username, body.display_name.strip() or username, auth.password_hash(body.password), db.now()),
            )

        store.transact(write)
        return {"username": username, "display_name": body.display_name.strip() or username}

    @application.post("/api/logout")
    def logout(request: Request, response: Response) -> dict:
        token = request.cookies.get(auth.SESSION_COOKIE)
        if token:
            def write(conn: sqlite3.Connection) -> None:
                conn.execute("DELETE FROM sessions WHERE hash = ?", (auth.digest(token),))

            store.transact(write)
        response.delete_cookie(auth.SESSION_COOKIE, path="/")
        return {"role": None}

    # ---------------------------------------------------------------- phòng thi

    def mine(room: sqlite3.Row, teacher: sqlite3.Row) -> bool:
        """Phòng của ai người nấy xem; tài khoản quản trị thấy hết để bao quát cả kỳ thi."""
        return bool(teacher["is_owner"]) or room["owner_id"] == teacher["id"]

    def room_of(room_id: str, teacher: sqlite3.Row) -> sqlite3.Row:
        room = store.one("SELECT * FROM rooms WHERE id = ?", room_id)
        if not room or not mine(room, teacher):
            raise HTTPException(404, "Không tìm thấy phòng thi.")
        return room

    def clear_room_images(room_id: str) -> None:
        """Tắt camera hoặc xóa phòng là bỏ hết ảnh đang giữ trong RAM, kể cả ảnh bằng chứng."""
        camera.forget_room(room_id)
        for row in store.all("SELECT id FROM students WHERE room_id = ?", room_id):
            camera.drop(row["id"])

    def exam_of(exam_id: str, teacher: sqlite3.Row) -> sqlite3.Row:
        exam = store.one("SELECT * FROM exams WHERE id = ?", exam_id)
        if not exam:
            raise HTTPException(404, "Không tìm thấy đề thi.")
        room_of(exam["room_id"], teacher)
        return exam

    def student_of(student_id: str, teacher: sqlite3.Row) -> sqlite3.Row:
        student = store.one("SELECT * FROM students WHERE id = ?", student_id)
        if not student:
            raise HTTPException(404, "Không tìm thấy học sinh.")
        room_of(student["room_id"], teacher)
        return student

    @application.get("/api/rooms")
    def list_rooms(teacher: sqlite3.Row = Depends(teacher_required)) -> list[dict]:
        out = []
        for room in store.all("SELECT * FROM rooms ORDER BY created_at DESC"):
            if not mine(room, teacher):
                continue
            students = store.one("SELECT COUNT(*) AS n FROM students WHERE room_id = ?", room["id"])["n"]
            exams = store.one("SELECT COUNT(*) AS n FROM exams WHERE room_id = ?", room["id"])["n"]
            live = store.one("SELECT COUNT(*) AS n FROM students WHERE room_id = ? AND last_seen > ?", room["id"], db.now() - ONLINK_MS)["n"]
            out.append({"id": room["id"], "code": room["code"], "title": room["title"], "closed": bool(room["closed"]),
                        "created_at": room["created_at"], "students": students, "exams": exams, "online": live})
        return out

    @application.post("/api/rooms")
    def create_room(body: RoomIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        title = body.title.strip()
        if not title:
            raise HTTPException(422, "Phòng thi cần có tên.")
        code = auth.room_code()
        while store.one("SELECT id FROM rooms WHERE code = ?", code):
            code = auth.room_code()
        room_id = db.new_id()

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("INSERT INTO rooms (id, code, title, owner_id, created_at) VALUES (?,?,?,?,?)",
                         (room_id, code, title[:120], teacher["id"], db.now()))

        store.transact(write)
        return room_state(room_id)

    def room_state(room_id: str) -> dict:
        room = store.one("SELECT * FROM rooms WHERE id = ?", room_id)
        if not room:
            raise HTTPException(404, "Không tìm thấy phòng thi.")
        students = store.all("SELECT * FROM students WHERE room_id = ? ORDER BY seat_id", room_id)
        exams = store.all("SELECT * FROM exams WHERE room_id = ? ORDER BY created_at DESC", room_id)
        detail = [exam_public(store, exam) for exam in exams]
        mark_open_gaps(exams, db.now())
        events = store.all("SELECT * FROM events WHERE room_id = ? ORDER BY created_at DESC LIMIT ?", room_id, MAX_EVENTS)
        return {
            "id": room["id"], "code": room["code"], "title": room["title"], "closed": bool(room["closed"]),
            "cam_enabled": bool(room["cam_enabled"]), "cam_watching": camera.watched(room_id),
            "evidence": camera.evidence_list([row["id"] for row in students]),
            "created_at": room["created_at"],
            "students": [{**db.public_student(row), "join_code": row["join_code"]} for row in students],
            "exams": detail,
            "events": [{"id": event["id"], "student_id": event["student_id"], "exam_id": event["exam_id"],
                        "rule": event["rule"], "risk": event["risk"], "duration": event["duration"],
                        "created_at": event["created_at"]} for event in events],
        }

    @application.get("/api/rooms/{room_id}")
    def read_room(room_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        return room_state(room_id)

    @application.patch("/api/rooms/{room_id}")
    def patch_room(room_id: str, body: RoomPatch, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        if body.cam_enabled is not None and not body.cam_enabled:
            clear_room_images(room_id)

        def write(conn: sqlite3.Connection) -> None:
            if body.title is not None:
                conn.execute("UPDATE rooms SET title = ? WHERE id = ?", (body.title.strip()[:120] or "Phòng thi", room_id))
            if body.closed is not None:
                conn.execute("UPDATE rooms SET closed = ? WHERE id = ?", (int(bool(body.closed)), room_id))
            if body.cam_enabled is not None:
                conn.execute("UPDATE rooms SET cam_enabled = ? WHERE id = ?", (int(bool(body.cam_enabled)), room_id))

        store.transact(write)
        return room_state(room_id)

    @application.delete("/api/rooms/{room_id}")
    def delete_room(room_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Xóa phòng kéo theo đề, bài làm và cảnh báo — giáo viên đã xác nhận trên giao diện."""
        room_of(room_id, teacher)
        clear_room_images(room_id)
        exam_ids = [row["id"] for row in store.all("SELECT id FROM exams WHERE room_id = ?", room_id)]
        student_ids = [row["id"] for row in store.all("SELECT id FROM students WHERE room_id = ?", room_id)]
        exam_marks = ",".join("?" * len(exam_ids))
        student_marks = ",".join("?" * len(student_ids))

        def write(conn: sqlite3.Connection) -> None:
            if exam_ids:
                conn.execute(f"DELETE FROM attempts WHERE exam_id IN ({exam_marks})", exam_ids)
                conn.execute(f"DELETE FROM exams WHERE id IN ({exam_marks})", exam_ids)
            if student_ids:
                conn.execute(f"DELETE FROM attempts WHERE student_id IN ({student_marks})", student_ids)
                conn.execute(f"DELETE FROM sessions WHERE student_id IN ({student_marks})", student_ids)
            conn.execute("DELETE FROM events WHERE room_id = ?", (room_id,))
            conn.execute("DELETE FROM students WHERE room_id = ?", (room_id,))
            conn.execute("DELETE FROM rooms WHERE id = ?", (room_id,))

        store.transact(write)
        return {"deleted": room_id}

    # ---------------------------------------------------------------- danh sách lớp

    @application.post("/api/rooms/{room_id}/students")
    def add_students(room_id: str, body: RosterIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        pairs = [(item.student_code.strip(), item.name.strip()) for item in body.students]
        pairs = [(code, name) for code, name in pairs if code and name]
        return import_roster(room_id, pairs, replace=False)

    @application.put("/api/rooms/{room_id}/students")
    def replace_students(room_id: str, body: RosterIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        pairs = [(item.student_code.strip(), item.name.strip()) for item in body.students if item.student_code.strip()]
        return import_roster(room_id, pairs, replace=True)

    @application.post("/api/rooms/{room_id}/roster")
    async def upload_roster(room_id: str, file: UploadFile = File(...), teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        data = await file.read()
        return import_roster(room_id, parse_roster(data), replace=True)

    def import_roster(room_id: str, pairs: list[tuple[str, str]], replace: bool) -> dict:
        existing = {row["student_code"] for row in store.all("SELECT student_code FROM students WHERE room_id = ?", room_id)}
        seats = {row["seat_id"] for row in store.all("SELECT seat_id FROM students WHERE room_id = ?", room_id)}
        codes = {row["join_code"] for row in store.all("SELECT join_code FROM students WHERE room_id = ?", room_id)}
        total = store.one("SELECT COUNT(*) AS n FROM students WHERE room_id = ?", room_id)["n"]
        created, skipped = [], 0
        for code, name in pairs:
            if code in existing:
                skipped += 1
                continue
            if total + len(created) >= MAX_STUDENTS:
                break
            seat = next((f"S{n:02d}" for n in range(1, MAX_STUDENTS + 1) if f"S{n:02d}" not in seats), None)
            if not seat:
                break
            access = auth.access_code()
            while access in codes:
                access = auth.access_code()
            student_id = db.new_id()
            seats.add(seat)
            codes.add(access)
            existing.add(code)
            created.append({"id": student_id, "student_code": code, "name": name, "seat_id": seat, "join_code": access})

        def write(conn: sqlite3.Connection) -> None:
            if replace:
                conn.execute("DELETE FROM students WHERE room_id = ?", (room_id,))
                seats.clear()
            for item in created:
                conn.execute(
                    "INSERT INTO students (id, room_id, student_code, name, seat_id, join_code, join_hash) VALUES (?,?,?,?,?,?,?)",
                    (item["id"], room_id, item["student_code"], item["name"], item["seat_id"], item["join_code"],
                     auth.digest(item["join_code"])),
                )

        store.transact(write)
        if replace:
            camera.forget_room(room_id)
            return room_state(room_id)
        return {"added": len(created), "skipped": skipped, "students": created}

    @application.delete("/api/students/{student_id}")
    def remove_student(student_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        student = student_of(student_id, teacher)
        camera.drop(student_id)

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("DELETE FROM attempts WHERE student_id = ?", (student_id,))
            conn.execute("DELETE FROM events WHERE student_id = ?", (student_id,))
            conn.execute("DELETE FROM sessions WHERE student_id = ?", (student_id,))
            conn.execute("DELETE FROM students WHERE id = ?", (student_id,))

        store.transact(write)
        return room_state(student["room_id"])

    @application.get("/api/rooms/{room_id}/codes.csv")
    def codes_download(room_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> PlainTextResponse:
        room = room_of(room_id, teacher)
        students = store.all("SELECT * FROM students WHERE room_id = ? ORDER BY seat_id", room_id)
        return download(f"ma-tham-gia-{room['title'][:40]}.csv", roster_csv(room, students))

    # ---------------------------------------------------------------- đề thi

    @application.post("/api/rooms/{room_id}/exams")
    def create_exam(room_id: str, body: ExamIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_of(room_id, teacher)
        questions = validate_exam(body)
        exam_id = db.new_id()

        def write(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO exams (id, room_id, title, duration_minutes, questions, max_points, created_at, kind, open_from, open_until)"
                " VALUES (?,?,?,?,?,?,?,?,?,?)",
                (exam_id, room_id, body.title.strip()[:120], body.duration_minutes, json.dumps(questions, ensure_ascii=False),
                 papers.max_points(questions), db.now(), body.kind, body.open_from, body.open_until),
            )

        store.transact(write)
        return exam_public(store, store.one("SELECT * FROM exams WHERE id = ?", exam_id))

    @application.put("/api/exams/{exam_id}")
    def update_exam(exam_id: str, body: ExamIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        exam_of(exam_id, teacher)
        if store.one("SELECT COUNT(*) AS n FROM attempts WHERE exam_id = ? AND submitted_at IS NOT NULL", exam_id)["n"]:
            raise HTTPException(409, "Đã có em nộp bài nên không sửa đề được nữa, sửa sẽ làm lệch điểm đã chấm. "
                                     "Muốn thi lại bằng đề này thì xóa bài của các em trước.")
        questions = validate_exam(body)

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE exams SET title = ?, duration_minutes = ?, questions = ?, max_points = ?,"
                         " kind = ?, open_from = ?, open_until = ? WHERE id = ?",
                         (body.title.strip()[:120], body.duration_minutes, json.dumps(questions, ensure_ascii=False),
                          papers.max_points(questions), body.kind, body.open_from, body.open_until, exam_id))

        store.transact(write)
        return exam_public(store, store.one("SELECT * FROM exams WHERE id = ?", exam_id))

    def validate_exam(body: ExamIn) -> list[dict]:
        try:
            questions = papers.normalize_questions(body.questions)
        except papers.PaperError as error:
            raise HTTPException(422, str(error)) from error
        if body.kind not in ("thi", "baotap"):
            raise HTTPException(422, "Đề chỉ là bài thi hoặc bài tập về nhà.")
        if not MIN_DURATION <= body.duration_minutes <= MAX_DURATION:
            raise HTTPException(422, f"Thời lượng làm bài từ {MIN_DURATION} đến {MAX_DURATION} phút.")
        if body.open_from and body.open_until and body.open_until <= body.open_from:
            raise HTTPException(422, "Hạn nộp phải sau giờ mở.")
        if not body.title.strip():
            raise HTTPException(422, "Đề thi cần có tên.")
        return questions

    @application.post("/api/rooms/{room_id}/exams/import")
    async def import_exam(room_id: str, file: UploadFile = File(...), title: str = Form(""),
                          duration: int = Form(45), kind: str = Form("thi"), open_until: int = Form(0),
                          teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Thầy/cô đẩy tệp đề lên: PDF, Word (.docx), CSV, TXT hoặc Markdown."""
        room_of(room_id, teacher)
        data = await file.read()
        try:
            parsed = papers.parse_upload(file.filename, data)
            questions = papers.normalize_questions(parsed["questions"])
        except papers.PaperError as error:
            raise HTTPException(422, str(error)) from error
        if not MIN_DURATION <= duration <= MAX_DURATION:
            raise HTTPException(422, f"Thời lượng làm bài từ {MIN_DURATION} đến {MAX_DURATION} phút.")
        if kind not in ("thi", "baotap"):
            raise HTTPException(422, "Đề chỉ là bài thi hoặc bài tập về nhà.")
        exam_id = db.new_id()

        def write(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO exams (id, room_id, title, duration_minutes, questions, max_points, created_at, kind, open_until)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (exam_id, room_id, (title.strip() or Path(file.filename or "de-thi").stem)[:120], duration,
                 json.dumps(questions, ensure_ascii=False), papers.max_points(questions), db.now(), kind, open_until or None),
            )

        store.transact(write)
        exam = exam_public(store, store.one("SELECT * FROM exams WHERE id = ?", exam_id))
        exam["notes"] = parsed["notes"]
        return exam

    @application.get("/api/exams/{exam_id}/paper.doc")
    def exam_document(exam_id: str, answers: int = 0, teacher: sqlite3.Row = Depends(teacher_required)) -> PlainTextResponse:
        """Tải câu hỏi về máy: mở bằng Word, in ra giao bài tập. Chỉ cô giáo lấy được kèm đáp án."""
        exam = exam_of(exam_id, teacher)
        room = store.one("SELECT * FROM rooms WHERE id = ?", exam["room_id"])
        body = paper_document(exam["title"], room["title"], exam, db.questions_of(exam), bool(answers))
        label = re.sub(r"[^\w\s-]", "", exam["title"]).strip().replace(" ", "-")[:60] or "de-thi"
        name = f"{'dap-an-' if answers else ''}{label}.doc"
        return download(name, body, media_type="application/msword; charset=utf-8")

    @application.post("/api/papers/parse")
    async def parse_paper(text: str = Form(""), file: UploadFile | None = File(None),
                          teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Thầy cô dán đề hoặc chọn tệp: máy chủ dịch ra câu hỏi để sửa lại trước khi lưu thành đề."""
        try:
            parsed = papers.parse_upload(file.filename, await file.read()) if file else papers.parse_text(text)
        except papers.PaperError as error:
            raise HTTPException(422, str(error)) from error
        if not parsed["questions"]:
            raise HTTPException(422, 'Chưa đọc được câu hỏi nào. Mỗi câu cần dòng hỏi, các phương án "A. …", "B. …" rồi dòng "ĐA: B".')
        return parsed

    @application.post("/api/exams/{exam_id}/publish")
    def publish(exam_id: str, body: PublishIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        exam_of(exam_id, teacher)

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE exams SET published = ? WHERE id = ?", (int(body.published), exam_id))

        store.transact(write)
        return exam_public(store, store.one("SELECT * FROM exams WHERE id = ?", exam_id))

    @application.delete("/api/exams/{exam_id}")
    def delete_exam(exam_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        room_id = exam_of(exam_id, teacher)["room_id"]
        for attempt in store.all("SELECT student_id FROM attempts WHERE exam_id = ?", exam_id):
            camera.drop(attempt["student_id"])

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("DELETE FROM attempts WHERE exam_id = ?", (exam_id,))
            conn.execute("DELETE FROM events WHERE exam_id = ?", (exam_id,))
            conn.execute("DELETE FROM exams WHERE id = ?", (exam_id,))

        store.transact(write)
        return room_state(room_id)

    @application.get("/api/exams/{exam_id}")
    def read_exam(exam_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        exam = exam_of(exam_id, teacher)
        out = exam_public(store, exam)
        out["questions"] = db.questions_of(exam)
        return out

    @application.get("/api/exams/{exam_id}/results")
    def results(exam_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        exam = exam_of(exam_id, teacher)
        questions = db.questions_of(exam)
        rows = []
        for attempt in store.all("SELECT * FROM attempts WHERE exam_id = ? ORDER BY submitted_at IS NULL, submitted_at", exam_id):
            close_overdue(store, exam, attempt, db.now())
            attempt = store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"])
            student = store.one("SELECT * FROM students WHERE id = ?", attempt["student_id"])
            rows.append({**attempt_public(exam, attempt), "student_code": student["student_code"],
                         "name": student["name"], "seat_id": student["seat_id"], "answers": db.answers_of(attempt)})
        return {"exam": exam_public(store, exam), "questions": questions, "attempts": rows}

    @application.get("/api/exams/{exam_id}/results.csv")
    def results_csv(exam_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> PlainTextResponse:
        exam = exam_of(exam_id, teacher)
        questions = db.questions_of(exam)
        header = ["Chỗ ngồi", "Mã học sinh", "Họ và tên", "Vào làm", "Nộp bài", "Điểm", "Điểm tối đa",
                  "Số câu đã làm", "Rời cửa sổ (giây)", "Số lần rời", "Số lần dán bài"]
        keys = [f"Câu {i + 1}" + (f" (đáp án {papers.LETTERS[q['answer']]})" if q["type"] == "mcq" else "") + f" ({q['points']}đ)"
                for i, q in enumerate(questions)]
        rows = [header + keys]
        for attempt in store.all("SELECT * FROM attempts WHERE exam_id = ? ORDER BY started_at", exam_id):
            student = store.one("SELECT * FROM students WHERE id = ?", attempt["student_id"])
            answers = db.answers_of(attempt)
            cells = [student["seat_id"], student["student_code"], student["name"], stamp(attempt["started_at"]),
                     stamp(attempt["submitted_at"]), attempt["score"] if attempt["score"] is not None else "",
                     exam["max_points"], len([v for v in answers.values() if v not in (None, "")]),
                     round(attempt["tab_ms"] / 1000), attempt["tab_events"], attempt["paste_count"]]
            rows.append(cells + [answer_text(questions, answers, index) for index in range(len(questions))])
        return download(f"ket-qua-{exam['title'][:40]}.csv", csv_body(rows))

    def answer_text(questions: list[dict], answers: dict, index: int) -> str:
        value = answers.get(str(index))
        if value in (None, ""):
            return ""
        question = questions[index]
        if question["type"] != "mcq":
            return str(value)
        try:
            return f"{papers.LETTERS[int(value)]}. {question['options'][int(value)]}"
        except (IndexError, ValueError):
            return str(value)

    @application.put("/api/attempts/{attempt_id}/marks")
    def set_marks(attempt_id: str, body: MarksIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Giám thị cho điểm từng câu tự luận; máy chủ cộng lại thành điểm toàn bài."""
        attempt = store.one("SELECT * FROM attempts WHERE id = ?", attempt_id)
        if not attempt:
            raise HTTPException(404, "Không tìm thấy bài làm.")
        exam = exam_of(attempt["exam_id"], teacher)
        questions = db.questions_of(exam)
        marks = {}
        for key, value in body.marks.items():
            if not key.isdigit() or int(key) >= len(questions):
                raise HTTPException(422, "Câu cần chấm không có trong đề.")
            if questions[int(key)]["type"] != "text":
                raise HTTPException(422, "Câu trắc nghiệm thì máy đã chấm, không cần sửa.")
            points = max(0.0, min(float(value), questions[int(key)]["points"]))
            marks[key] = points
        score, _, _ = grade(questions, db.answers_of(attempt), marks)

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE attempts SET marks = ?, score = ? WHERE id = ?", (json.dumps(marks), score, attempt_id))

        store.transact(write)
        return attempt_public(exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt_id))

    def clear_attempt(conn: sqlite3.Connection, attempt_id: str) -> None:
        conn.execute(
            "UPDATE attempts SET started_at = NULL, submitted_at = NULL, answers = '{}', score = NULL, marks = '{}',"
            " tab_ms = 0, tab_events = 0, paste_count = 0, last_seen = 0 WHERE id = ?", (attempt_id,))

    @application.post("/api/attempts/{attempt_id}/reset")
    def reset_attempt(attempt_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Xóa bài của một em để em đó làm lại từ đầu; cảnh báo cũ vẫn giữ làm bằng chứng."""
        attempt = store.one("SELECT * FROM attempts WHERE id = ?", attempt_id)
        if not attempt:
            raise HTTPException(404, "Không tìm thấy bài làm.")
        exam = exam_of(attempt["exam_id"], teacher)
        camera.drop(attempt["student_id"])

        def write(conn: sqlite3.Connection) -> None:
            clear_attempt(conn, attempt_id)

        store.transact(write)
        return {"reset": 1, "exam_id": exam["id"]}

    @application.post("/api/exams/{exam_id}/reset")
    def reset_exam_attempts(exam_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Xóa mọi bài của một đề, dùng khi thi thử xong muốn cho lớp làm lại đề đó."""
        exam = exam_of(exam_id, teacher)
        attempts = store.all("SELECT student_id FROM attempts WHERE exam_id = ?", exam_id)
        for attempt in attempts:
            camera.drop(attempt["student_id"])

        def write(conn: sqlite3.Connection) -> None:
            for row in conn.execute("SELECT id FROM attempts WHERE exam_id = ?", (exam_id,)).fetchall():
                clear_attempt(conn, row["id"])

        store.transact(write)
        return {"reset": len(attempts), "exam_id": exam["id"]}

    # ---------------------------------------------------------------- camera live
    @application.post("/api/rooms/{room_id}/cam/watch")
    def cam_watch(room_id: str, body: WatchIn, teacher: sqlite3.Row = Depends(teacher_required)) -> dict:
        """Cô bật/tắt khung xem. Một phòng chỉ soi được một em mỗi lần để mạng phòng thi không nghẽn."""
        room = room_of(room_id, teacher)
        if body.student_id:
            if not room["cam_enabled"]:
                raise HTTPException(409, "Bật camera cho phòng này trước rồi mới xem.")
            student = student_of(body.student_id, teacher)
            if student["room_id"] != room_id:
                raise HTTPException(422, "Em này không thuộc phòng thi này.")
        return {"watching": camera.watch(room_id, body.student_id)}

    @application.get("/api/rooms/{room_id}/cam/{student_id}")
    def cam_frame(room_id: str, student_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> Response:
        room_of(room_id, teacher)
        frame = camera.get(student_id)
        if not frame:
            raise HTTPException(404, "Chưa có hình từ em này.")
        return Response(frame, media_type="image/jpeg", headers={"cache-control": "no-store, max-age=0"})

    # ---------------------------------------------------------------- học sinh vào thi

    @application.post("/api/join")
    def join(body: JoinIn, response: Response) -> dict:
        room_code = body.room_code.strip().upper()
        student_code = body.student_code.strip()
        typed = body.access_code.strip()
        if not (room_code and student_code and typed):
            raise HTTPException(422, "Cần điền đủ mã phòng, mã học sinh và mã tham gia.")
        student = store.one(
            "SELECT s.*, r.closed FROM students s JOIN rooms r ON r.id = s.room_id"
            " WHERE r.code = ? AND s.student_code = ?", room_code, student_code)
        if not student:
            # mã ghi trên giấy là "N01" nhưng em gõ "n01" — không bắt em gõ lại vì hoa thường
            student = store.one(
                "SELECT s.*, r.closed FROM students s JOIN rooms r ON r.id = s.room_id"
                " WHERE r.code = ? AND upper(s.student_code) = upper(?)", room_code, student_code)
        if not student or not (hmac_digest_match(typed, student["join_hash"])):
            raise HTTPException(401, "Mã phòng, mã học sinh hoặc mã tham gia không đúng. Em kiểm tra lại tờ giấy nhé.")
        if student["closed"]:
            raise HTTPException(403, "Phòng thi này đã đóng.")

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE students SET last_seen = ? WHERE id = ?", (db.now(), student["id"]))

        store.transact(write)
        issue(store, response, "student", student_id=student["id"], room_id=student["room_id"])
        return {"role": "student", **db.public_student(store.one("SELECT * FROM students WHERE id = ?", student["id"])),
                "room_id": student["room_id"]}

    @application.get("/api/exams")
    def student_exams(student: sqlite3.Row = Depends(student_required)) -> list[dict]:
        room = store.one("SELECT * FROM rooms WHERE id = ?", student["room_id"])
        out = []
        for exam in store.all("SELECT * FROM exams WHERE room_id = ? AND published = 1 ORDER BY created_at", room["id"]):
            questions = db.questions_of(exam)
            attempt = store.one("SELECT * FROM attempts WHERE exam_id = ? AND student_id = ?", exam["id"], student["id"])
            if attempt:
                attempt = close_overdue(store, exam, attempt, db.now())
            state = "chưa vào làm"
            window = open_window(exam, db.now())
            if attempt and attempt["submitted_at"]:
                state = "đã nộp"
            elif attempt and attempt["started_at"]:
                state = "đang làm"
            elif window in ("hết hạn nộp", "chưa tới giờ mở"):
                state = window
            out.append({"id": exam["id"], "title": exam["title"], "duration_minutes": exam["duration_minutes"],
                        "kind": exam["kind"], "open_from": exam["open_from"], "open_until": exam["open_until"],
                        "question_count": len(questions), "max_points": exam["max_points"], "state": state,
                        "attempt_id": attempt["id"] if attempt else None,
                        "score": attempt["score"] if attempt and attempt["submitted_at"] else None,
                        "remaining_ms": remaining_ms(exam, attempt, db.now()) if attempt else None})
        return out

    def exam_for_student(exam_id: str, student: sqlite3.Row) -> tuple[sqlite3.Row, sqlite3.Row]:
        exam = store.one("SELECT * FROM exams WHERE id = ?", exam_id)
        if not exam or exam["room_id"] != student["room_id"]:
            raise HTTPException(404, "Không tìm thấy đề thi của lớp em.")
        if not exam["published"]:
            raise HTTPException(409, "Cô giáo chưa mở đề này cho lớp.")
        return exam, student

    def window_ok(exam: sqlite3.Row) -> None:
        """Bài tập về nhà làm trong khoảng cô đặt; quá hạn nộp thì đóng hẳn."""
        if exam["kind"] != "baotap":
            return
        moment = db.now()
        if exam["open_from"] and moment < int(exam["open_from"]):
            raise HTTPException(409, f"Bài này mở làm từ {stamp(exam['open_from'])} em ạ.")
        if exam["open_until"] and moment > int(exam["open_until"]) + GRACE_MS:
            raise HTTPException(409, "Hạn nộp bài này đã qua nên không làm được nữa. Em báo cô giáo nhé.")

    def cam_flags(exam: sqlite3.Row, student_id: str | None) -> dict:
        """Camera chỉ bật khi cô mở phòng có camera VÀ đang soi đúng em này."""
        room = store.one("SELECT cam_enabled FROM rooms WHERE id = ?", exam["room_id"])
        enabled = bool(room and room["cam_enabled"])
        return {"cam_enabled": enabled, "cam_wanted": bool(student_id) and enabled and camera.watched(exam["room_id"]) == student_id}

    def build_paper(exam: sqlite3.Row, attempt: sqlite3.Row | None) -> dict:
        """Giấy thi gửi cho học sinh: không bao giờ kèm đáp án đúng."""
        return {
            "id": exam["id"], "title": exam["title"], "duration_minutes": exam["duration_minutes"],
            "kind": exam["kind"], "open_from": exam["open_from"], "open_until": exam["open_until"],
            "max_points": exam["max_points"], "questions": paper_public(db.questions_of(exam)),
            "answers": db.answers_of(attempt) if attempt else {},
            "started_at": attempt["started_at"] if attempt else None,
            "submitted_at": attempt["submitted_at"] if attempt else None,
            "tab_ms": attempt["tab_ms"] if attempt else 0, "tab_events": attempt["tab_events"] if attempt else 0,
            "paste_count": attempt["paste_count"] if attempt else 0,
            "remaining_ms": remaining_ms(exam, attempt, db.now()) if attempt else exam["duration_minutes"] * 60_000,
            "score": attempt["score"] if attempt and attempt["submitted_at"] else None,
            "server_time": db.now(), **cam_flags(exam, attempt["student_id"] if attempt else None),
        }

    @application.get("/api/exams/{exam_id}/paper")
    def student_paper(exam_id: str, student: sqlite3.Row = Depends(student_required)) -> dict:
        exam, student = exam_for_student(exam_id, student)
        attempt = store.one("SELECT * FROM attempts WHERE exam_id = ? AND student_id = ?", exam["id"], student["id"])
        if attempt and attempt["started_at"]:
            # vào làm rồi thì bài của em vẫn còn đó kể cả khi đã qua hạn nộp
            attempt = close_overdue(store, exam, attempt, db.now())
            note_gap(exam, attempt, student["id"], db.now())
            attempt = store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"])
        else:
            window_ok(exam)
        return build_paper(exam, attempt)

    @application.post("/api/exams/{exam_id}/start")
    def start(exam_id: str, student: sqlite3.Row = Depends(student_required)) -> dict:
        exam, student = exam_for_student(exam_id, student)
        attempt = store.one("SELECT * FROM attempts WHERE exam_id = ? AND student_id = ?", exam["id"], student["id"])
        if attempt and attempt["started_at"]:
            return build_paper(exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"]))
        window_ok(exam)
        attempt_id = attempt["id"] if attempt else db.new_id()

        def write(conn: sqlite3.Connection) -> None:
            if attempt:
                conn.execute("UPDATE attempts SET started_at = ?, last_seen = ? WHERE id = ?", (db.now(), db.now(), attempt_id))
            else:
                conn.execute("INSERT INTO attempts (id, exam_id, student_id, started_at, last_seen) VALUES (?,?,?,?,?)",
                             (attempt_id, exam["id"], student["id"], db.now(), db.now()))
            conn.execute("UPDATE students SET last_seen = ? WHERE id = ?", (db.now(), student["id"]))

        store.transact(write)
        return build_paper(exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt_id))

    def open_attempt(exam_id: str, student: sqlite3.Row) -> tuple[sqlite3.Row, sqlite3.Row]:
        exam = store.one("SELECT * FROM exams WHERE id = ?", exam_id)
        if not exam or exam["room_id"] != student["room_id"]:
            raise HTTPException(404, "Không tìm thấy đề thi của lớp em.")
        attempt = store.one("SELECT * FROM attempts WHERE exam_id = ? AND student_id = ?", exam_id, student["id"])
        if not attempt or not attempt["started_at"]:
            raise HTTPException(409, 'Em bấm “Bắt đầu làm bài” trước khi làm nhé.')
        attempt = close_overdue(store, exam, attempt, db.now())
        note_gap(exam, attempt, student["id"], db.now())
        return exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"])

    @application.post("/api/exams/{exam_id}/save")
    def save(exam_id: str, body: AnswersIn, student: sqlite3.Row = Depends(student_required)) -> dict:
        exam, attempt = open_attempt(exam_id, student)
        if attempt["submitted_at"]:
            raise HTTPException(409, "Em đã nộp bài rồi nên bài không sửa được nữa.")
        questions = db.questions_of(exam)
        answers = clean_answers(questions, body.answers, db.answers_of(attempt))

        def write(conn: sqlite3.Connection) -> None:
            # tab_ms / tab_events do máy chủ tự đo (note_gap), không lấy số em học sinh báo lên
            conn.execute("UPDATE attempts SET answers = ?, paste_count = ?, last_seen = ? WHERE id = ?",
                         (json.dumps(answers, ensure_ascii=False), body.paste_count, db.now(), attempt["id"]))
            conn.execute("UPDATE students SET last_seen = ? WHERE id = ?", (db.now(), student["id"]))

        store.transact(write)
        return {**attempt_public(exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"])),
                **cam_flags(exam, student["id"])}

    @application.post("/api/exams/{exam_id}/submit")
    def submit(exam_id: str, body: AnswersIn, student: sqlite3.Row = Depends(student_required)) -> dict:
        exam, attempt = open_attempt(exam_id, student)
        if attempt["submitted_at"]:
            return {**attempt_public(exam, attempt), "already": True}
        questions = db.questions_of(exam)
        answers = clean_answers(questions, body.answers, db.answers_of(attempt))
        marks = json.loads(attempt["marks"])
        score, _, _ = grade(questions, answers, marks)

        def write(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE attempts SET answers = ?, submitted_at = ?, score = ?, paste_count = ?,"
                         " last_seen = ? WHERE id = ?",
                         (json.dumps(answers, ensure_ascii=False), db.now(), score, body.paste_count,
                          db.now(), attempt["id"]))

        store.transact(write)
        camera.drop_view(student["id"])  # nộp bài rồi là tắt hình, cô không xem tiếp được nữa
        return attempt_public(exam, store.one("SELECT * FROM attempts WHERE id = ?", attempt["id"]))

    def clean_answers(questions: list[dict], incoming: dict, keep: dict) -> dict:
        """Chỉ nhận câu có thật trong đề; đáp án lạ bị bỏ qua để không làm hỏng cả bài đã lưu."""
        merged = dict(keep)
        for key, value in (incoming or {}).items():
            if not str(key).isdigit() or int(key) >= len(questions):
                continue
            question = questions[int(key)]
            if value in (None, ""):
                merged.pop(key, None)
                continue
            if question["type"] == "mcq":
                try:
                    picked = int(value)
                except (TypeError, ValueError):
                    continue
                if 0 <= picked < len(question["options"]):
                    merged[key] = picked
            else:
                merged[key] = str(value)[:4000]
        return merged

    @application.post("/api/exams/{exam_id}/event")
    def flag(exam_id: str, body: EventIn, student: sqlite3.Row = Depends(student_required)) -> dict:
        """Học sinh báo rời cửa sổ / dán bài / không làm — bảng giám thị dùng để nhắc nhở, không cắt giờ thi."""
        if body.rule not in RULES:
            raise HTTPException(422, "Loại cảnh báo không được hỗ trợ.")
        exam, attempt = open_attempt(exam_id, student)
        risk = RULES[body.rule]
        log_event(exam, student["id"], body.rule, risk, body.duration, body.client_id or db.new_id())
        return {"risk": risk}

    def log_event(exam: sqlite3.Row, student_id: str, rule: str, risk: int, duration, client_id: str) -> None:
        """Dòng events là dấu vết lâu dài còn ảnh bằng chứng chỉ nằm trong RAM vài chục phút.

        Cùng một client_id chỉ ghi MỘT dòng. Nếu cô đã thấy dấu đỏ trên bảng từ lúc em còn chưa
        quay lại thì lần ghi sau chỉ kéo dài thời gian cho đúng bằng khoảng im lặng thật.
        """
        def write(conn: sqlite3.Connection) -> None:
            conn.execute("INSERT INTO events (room_id, student_id, exam_id, rule, risk, duration, client_id, created_at)"
                         " VALUES (?,?,?,?,?,?,?,?)"
                         " ON CONFLICT (room_id, client_id) DO UPDATE SET duration = MAX(events.duration, excluded.duration)",
                         (exam["room_id"], student_id, exam["id"], rule, risk, duration, client_id[:64], db.now()))

        store.transact(write)

    def mark_open_gaps(exams: list[sqlite3.Row], moment: int) -> None:
        """Bảng cô giáo đỏ lên NGAY khi em im lặng quá nhịp — không chờ em bật lại tab làm bài.

        client_id giống hệt dấu mà note_gap ghi lúc em quay lại, nên một khoảng lặng vẫn chỉ
        có đúng MỘT dòng cảnh báo, chỉ là dòng đó xuất hiện sớm hơn nhiều.
        """
        for exam in exams:
            if exam["kind"] != "thi":
                continue
            for attempt in store.all("SELECT * FROM attempts WHERE exam_id = ? AND started_at IS NOT NULL"
                                     " AND submitted_at IS NULL", exam["id"]):
                seen = int(attempt["last_seen"] or 0)
                if not seen or moment - seen < AWAY_MS:
                    continue
                client_id = f"gap-{attempt['id']}-{seen}"[:64]
                if store.one("SELECT id FROM events WHERE room_id = ? AND client_id = ?", exam["room_id"], client_id):
                    continue
                log_event(exam, attempt["student_id"], "tab_left", RULES["tab_left"], round((moment - seen) / 1000), client_id)

    def note_gap(exam: sqlite3.Row, attempt: sqlite3.Row, student_id: str, moment: int) -> None:
        """Máy im lặng bao lâu thì tính là rời phòng bấy lâu — đo ở máy chủ, không chờ trình duyệt tự báo.

        client_id gắn với mốc last_seen nên cùng một khoảng lặng chỉ ghi đúng một lần, dù em reload
        liên tục — và dù cô đã thấy dấu đỏ trên bảng lúc em chưa quay lại (mark_open_gaps).
        """
        seen = int(attempt["last_seen"] or 0)
        if attempt["submitted_at"] or not attempt["started_at"] or not seen or moment - seen < AWAY_MS:
            return
        gap = moment - seen
        # bài về nhà: em để máy im lặng cả buổi là bình thường, chỉ việc bỏ qua, không trừ thời gian
        report = not (exam["kind"] == "baotap" and gap > AWAY_HOME_MS)

        def write(conn: sqlite3.Connection) -> None:
            if report:
                conn.execute("UPDATE attempts SET tab_ms = tab_ms + ?, tab_events = tab_events + 1, last_seen = ? WHERE id = ?",
                             (gap, moment, attempt["id"]))
            else:
                conn.execute("UPDATE attempts SET last_seen = ? WHERE id = ?", (moment, attempt["id"]))

        store.transact(write)
        if not report:
            return
        log_event(exam, student_id, "tab_left", RULES["tab_left"], round(gap / 1000), f"gap-{attempt['id']}-{seen}")

    @application.put("/api/exams/{exam_id}/evidence")
    async def evidence_push(exam_id: str, request: Request, rule: str, client_id: str = "",
                            student: sqlite3.Row = Depends(student_required)) -> dict:
        """Máy em tự phát hiện bất thường rồi gửi lên ĐÚNG MỘT ảnh. Ảnh không ghi đĩa, không vào CSDL."""
        exam, attempt = open_attempt(exam_id, student)
        if attempt["submitted_at"]:
            return {"saved": False}
        if rule not in CAM_RULES:
            raise HTTPException(422, "Loại cảnh báo không được hỗ trợ.")
        if not cam_flags(exam, student["id"])["cam_enabled"]:
            raise HTTPException(409, "Phòng thi này chưa bật camera nên máy không nhận ảnh.")
        photo = await request.body()
        if not photo.startswith(b"\xff\xd8"):
            raise HTTPException(422, "Ảnh gửi lên không phải JPEG.")
        if not camera.push_evidence(student["id"], rule, photo):
            raise HTTPException(422, f"Ảnh phải nhỏ hơn {cam.MAX_FRAME_BYTES // 1024} KB.")
        log_event(exam, student["id"], rule, CAM_RULES[rule], None, client_id or db.new_id())
        return {"saved": True}

    @application.get("/api/rooms/{room_id}/evidence/{student_id}")
    def cam_evidence(room_id: str, student_id: str, teacher: sqlite3.Row = Depends(teacher_required)) -> Response:
        room_of(room_id, teacher)
        item = camera.evidence(student_id)
        if not item:
            raise HTTPException(404, "Không còn ảnh bằng chứng nào — ảnh chỉ giữ 30 phút trên máy chủ.")
        return Response(item[1], media_type="image/jpeg", headers={"cache-control": "no-store, max-age=0"})

    @application.put("/api/exams/{exam_id}/cam")
    async def cam_push(exam_id: str, request: Request, student: sqlite3.Row = Depends(student_required)) -> dict:
        """Học sinh gửi một khung hình khi cô đang xem. Ảnh chỉ nằm trong RAM vài giây, không ghi đĩa."""
        exam, attempt = open_attempt(exam_id, student)
        if attempt["submitted_at"] or not cam_flags(exam, student["id"])["cam_wanted"]:
            camera.drop(student["id"])
            return {"wanted": False}
        if not camera.put(exam["room_id"], student["id"], await request.body()):
            raise HTTPException(422, f"Ảnh phải nhỏ hơn {cam.MAX_FRAME_BYTES // 1024} KB.")
        return {"wanted": True}

    @application.delete("/api/exams/{exam_id}/cam")
    def cam_stop(exam_id: str, student: sqlite3.Row = Depends(student_required)) -> dict:
        """Em tắt camera: máy chủ thôi xem và bảng của cô ghi rõ em không bật hình; ảnh bằng chứng đã gửi vẫn còn."""
        exam, _ = open_attempt(exam_id, student)
        camera.drop_view(student["id"])
        return {"wanted": False}

    @application.get("/api/exams/{exam_id}/result")
    def own_result(exam_id: str, student: sqlite3.Row = Depends(student_required)) -> dict:
        exam, attempt = open_attempt(exam_id, student)
        if not attempt["submitted_at"]:
            raise HTTPException(409, "Em chưa nộp bài.")
        questions = db.questions_of(exam)
        answers = db.answers_of(attempt)
        marks = json.loads(attempt["marks"])
        _, choice, essay = grade(questions, answers, marks)
        return {"exam_id": exam["id"], "title": exam["title"], "score": attempt["score"], "max_points": exam["max_points"],
                "mcq_points": choice, "essay_points": essay, "submitted_at": attempt["submitted_at"],
                "answered": len([v for v in answers.values() if v not in (None, "")]),
                "question_count": len(questions)}

    # ---------------------------------------------------------------- tiện ích công khai

    @application.get("/api/templates/roster.csv")
    def roster_template() -> PlainTextResponse:
        rows = [["Mã học sinh", "Họ và tên"], ["N01", "Nguyễn Văn An"], ["N02", "Trần Thị Bình"]]
        return download("mau-danh-sach-lop.csv", csv_body(rows))

    @application.get("/api/templates/paper.csv")
    def paper_template() -> PlainTextResponse:
        return download("mau-de-thi.csv", papers.csv_template())

    @application.get("/api/health")
    def health() -> dict:
        out = {"ok": True, "students": store.one("SELECT COUNT(*) AS n FROM students")["n"],
               "exams": store.one("SELECT COUNT(*) AS n FROM exams")["n"], "version": "3.4.3"}
        if not keeper:
            out["backup"] = application.state.backup_note or "off"
        elif keeper.error:
            out["backup"] = f"lỗi: {keeper.error[:80]}"
        elif keeper.updated_at:
            out["backup"] = f"ok {round(time.time() - keeper.updated_at)}s"
        else:
            out["backup"] = "chờ lần ghi đầu tiên"
        return out

    @application.get("/api/backup")
    def backup(teacher: sqlite3.Row = Depends(teacher_required)) -> PlainTextResponse:
        """Chủ tài khoản tải cả kho về máy phòng khi máy chủ hỏng — một tệp .sql nạp lại được."""
        if not teacher["is_owner"]:
            raise HTTPException(403, "Chỉ chủ tài khoản mới tải được bản sao lưu.")
        stamp = datetime.now(VN_TIME).strftime("%Y%m%d-%H%M")
        return PlainTextResponse(store.backup(), media_type="application/sql", headers={
            "content-disposition": f'attachment; filename="focuslab-{stamp}.sql"'})

    if STATIC_DIR.exists():
        application.mount("/static", FreshFiles(directory=STATIC_DIR), name="static")

        def page(name: str) -> FileResponse:
            return FileResponse(STATIC_DIR / name, headers={"cache-control": "no-store"})

        @application.get("/", include_in_schema=False)
        def home() -> FileResponse:
            return page("index.html")

        @application.get("/teacher", include_in_schema=False)
        def teacher_page() -> FileResponse:
            return page("teacher.html")

        @application.get("/exam", include_in_schema=False)
        def exam_page() -> FileResponse:
            return page("exam.html")

    return application


def hmac_digest_match(typed: str, stored: str) -> bool:
    """Gõ hoa, thường hay bật Caps Lock đều vào được vì máy chủ thử cả hai dạng."""
    return any(hmac.compare_digest(auth.digest(candidate), stored) for candidate in {typed, typed.upper()})


app = create_app()

