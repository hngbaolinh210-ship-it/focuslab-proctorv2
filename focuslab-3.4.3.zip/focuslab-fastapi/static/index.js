/* Trang cổng: học sinh vào phòng thi, cô giáo đăng nhập vào bảng điều hành. */
import { api } from "/static/app.js";

const el = id => document.getElementById(id);

/* Hai màn hình gộp trên một trang: đổi bằng nút trên tiêu đề, gắn vào địa chỉ để cô gửi link thẳng. */
const PANES = {
  "ho-sinh": { form: "join-form", tab: "tab-student" },
  "co-giao": { form: "login-form", tab: "tab-teacher" },
};

function showPane(name) {
  for (const [key, pane] of Object.entries(PANES)) {
    const on = key === name;
    el(pane.form).hidden = !on;
    el(pane.tab).classList.toggle("on", on);
    el(pane.tab).setAttribute("aria-selected", String(on));
  }
}

const paneFromUrl = () => (location.hash === "#co-giao" ? "co-giao" : "ho-sinh");

async function boot() {
  const me = await api("/api/me").catch(() => ({ role: null }));
  if (me.role === "teacher") return location.replace("/teacher");
  if (me.role === "student") return location.replace("/exam");

  showPane(paneFromUrl());
  el("pane-tabs").addEventListener("click", event => {
    const tab = event.target.closest("button[data-pane]");
    if (!tab) return;
    showPane(tab.dataset.pane);
    history.replaceState(null, "", `#${tab.dataset.pane}`);
  });

  el("pw-toggle").addEventListener("click", () => {
    const box = el("password");
    box.type = box.type === "password" ? "text" : "password";
    el("pw-toggle").textContent = box.type === "password" ? "Hiện" : "Ẩn";
  });

  el("join-form").addEventListener("submit", async event => {
    event.preventDefault();
    el("join-error").textContent = "";
    try {
      await api("/api/join", {
        method: "POST",
        body: { room_code: el("room_code").value, student_code: el("student_code").value, access_code: el("access_code").value },
      });
      location.replace("/exam");
    } catch (error) {
      el("join-error").textContent = error.message;
    }
  });

  el("setup-toggle").addEventListener("click", () => {
    const open = el("setup-fields").hidden;
    el("setup-fields").hidden = !open;
    el("login-button").textContent = open ? "Tạo tài khoản và vào" : "Đăng nhập";
    el("setup-toggle").textContent = open ? "Chỉ đăng nhập thôi" : "Tạo tài khoản đầu tiên";
  });

  el("login-form").addEventListener("submit", async event => {
    event.preventDefault();
    const body = { username: el("username").value, password: el("password").value, display_name: el("display_name").value };
    const creating = !el("setup-fields").hidden;
    el("login-error").textContent = "";
    try {
      await api(creating ? "/api/teacher/setup" : "/api/teacher/login", { method: "POST", body });
      location.replace("/teacher");
    } catch (error) {
      // Máy chủ báo 404 khi chưa có tài khoản nào: bật sẵn ô tạo tài khoản để cô khỏi tìm.
      if (error.message.includes("Tạo tài khoản đầu tiên") && el("setup-fields").hidden) el("setup-toggle").click();
      el("login-error").textContent = error.message;
    }
  });
}

boot();
