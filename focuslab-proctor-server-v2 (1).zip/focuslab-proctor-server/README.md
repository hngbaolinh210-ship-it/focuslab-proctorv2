# FocusLab Proctor 2 — thiết bị, phòng thi và máy chủ

Ứng dụng hỗ trợ giám sát trên trình duyệt, với máy chủ Node.js 24, SQLite, MediaPipe và YOLOv8n. Một phòng có tối đa **100 học sinh trong danh sách**; hỗ trợ thí sinh dùng thiết bị riêng và camera phòng thi.

## Mở trên Windows

1. Cài **Node.js 24 LTS** từ https://nodejs.org.
2. Dừng cửa sổ FocusLab cũ bằng Ctrl+C. Giải nén **toàn bộ** ZIP vào thư mục mới.
3. Nhấp đúp `start-windows.cmd`. Lần đầu cần Internet để tải thư viện và FFmpeg.
4. Lần đầu, nhập mật khẩu giám thị **từ 12 đến 200 ký tự** rồi Enter. Khi gõ sẽ hiện dấu `*`. Nếu quá ngắn, ứng dụng cho nhập lại. Ghi nhớ mật khẩu này.
5. Website tự mở tại http://localhost:5173. Chọn **Đăng nhập giám thị**.
6. Giữ cửa sổ lệnh mở. Lần sau file mở nhanh dùng lại dependencies nếu lockfile không đổi.

Chạy bằng Terminal:

```sh
npm ci
npm run setup
npm run dev
```

Đừng mở file `.cmd` ngay trong ZIP hoặc kéo riêng nó ra ngoài. Nếu báo thiếu `package-lock.json`, giải nén lại toàn bộ. Node thấp hơn 24 không hỗ trợ cấu hình máy chủ này.

## Tạo phòng và nhập danh sách

- Đăng nhập giám thị, tạo phòng rồi chọn phòng đó.
- Tải CSV mẫu từ giao diện. Các cột là `student_id,name,seat_id`; UTF-8, tối đa 100 dòng/phòng.
- `student_id`: chữ/số/gạch dưới/gạch ngang, tối đa 40 ký tự. `name`: tối đa 120 ký tự. `seat_id`: S01…S100; có thể để trống để đánh số tự động.
- Nhập CSV rồi **tải danh sách mã tham gia ngay**. Mã ngẫu nhiên chỉ trả về trong lần cấp này; máy chủ chỉ lưu mã băm. Giữ tệp mã riêng tư và chuyển đúng mã cho từng học sinh.
- Danh sách không được thêm trùng mã/chỗ, tổng không vượt 100. Muốn làm lại toàn bộ danh sách, tạo phòng mới.
- Học sinh mở link `/join?room=MÃ_PHÒNG`, nhập mã tham gia riêng. Tên/chỗ được tự lấy từ danh sách, không cần gõ/gán tên trong trang phân tích.

**Danh tính không được nhận diện bằng khuôn mặt.** Mã tham gia gắn phiên với tài khoản được cấp. Trong phòng thi tập trung, dữ liệu gắn theo vị trí đã khai báo trong sơ đồ chỗ ngồi; giám thị xác minh người ngồi đúng chỗ. Không có so sánh ảnh thẻ/embedding hoặc kết luận thi hộ.

## Các nguồn hình ảnh

### Điện thoại, laptop, webcam USB

Trong trang quản lý, chọn **Mở camera phòng thi**; học sinh dùng **Mở camera & bắt đầu**. Chọn camera trước, sau hoặc webcam từ danh sách nguồn rồi bật camera. Danh sách thiết bị có tên đầy đủ sau khi cấp quyền.

Mỗi học sinh từ xa dùng một trình duyệt/thiết bị và mã riêng. Giám thị giữ trang quản lý mở để xem thông báo. Trong phòng thi tập trung, có thể chọn các vùng thuộc camera hiện tại từ danh sách rồi **Áp dụng vùng**. Các camera khác có thể mở trang phân tích ở thiết bị hoặc tab riêng và chọn tập chỗ khác.

Chỉnh vùng bao gồm thí sinh và bàn; tránh chồng lấn. Các vùng lấy nhãn từ danh sách, không cần ghép khuôn mặt với tên thủ công. Khi mỗi vùng có đúng một khuôn mặt và các thí sinh nhìn thẳng, bấm **Hiệu chỉnh & bắt đầu**. Góc chuẩn lưu riêng cho từng vùng.

Camera trên điện thoại từ xa cần **HTTPS**, quyền camera, WebGL và trình duyệt tương đối mới (Chrome/Edge hoặc Safari hiện đại). Địa chỉ HTTP mạng nội bộ như `http://192.168.x.x:5173` không đáp ứng điều kiện camera của phần lớn trình duyệt. “Truy cập trên nhiều thiết bị” không có nghĩa mọi trình duyệt cũ/thiết bị yếu đều phân tích được.

### Video có sẵn

- **Video trên thiết bị** trong trang phân tích: chọn file, phát trực tiếp, không gửi tệp lên server.
- **Tải lên máy chủ** trong trang quản lý/thí sinh: nhận MP4/MOV/WebM tối đa 500 MB, 2 giờ, độ phân giải tối đa 4K. Server xác thực người gửi và tạo MP4 H.264/AAC tối đa chiều ngang 1280 và WebM VP8/Opus tối đa chiều ngang 960. Trình duyệt thiếu H.264 sẽ dùng WebM; giới hạn lưu trữ tính cả hai bản.
- Mỗi máy chủ hiện xử lý tối đa 2 video cùng lúc; chờ xử lý xong rồi mở **Video & phân tích**. Dung lượng video lưu mặc định tối đa 5 GB; giám thị có thể xóa video cũ.
- Video chỉ chủ sở hữu và giám thị được xem; hỗ trợ HTTP Range để tua. Khi phân tích, các mốc thời gian quy tắc dùng thời gian video; khi tua, phiên phân tích hiện tại kết thúc và cần hiệu chỉnh lại. Tạm dừng video không bị coi là mất camera.
- Đóng trang trong lúc server đã nhận và xử lý video không dừng tác vụ server. Video/sự kiện lưu qua các lần khởi động lại.

### Camera IP / CCTV (RTSP)

Camera RTSP không chạy trực tiếp trong trình duyệt. Máy chủ dùng FFmpeg chuyển thành HLS; trình duyệt dùng HLS.js hoặc trình phát HLS có sẵn của Safari.

1. Máy chủ phải truy cập được mạng của camera. Với camera trong mạng trường, dùng máy chủ trong mạng đó, VPN/site-to-site, hoặc hạ tầng camera phù hợp. VPS trên Internet không tự truy cập được IP riêng của trường.
2. Cấu hình biến môi trường `CAMERA_HOSTS` chứa hostname/IP được phép, cách nhau bằng dấu phẩy, ví dụ `192.168.1.20,192.168.1.21`.
3. Tại trang giám thị nhập tên camera và URL `rtsp://…` (hoặc `rtsps://…`) do camera cung cấp. Không chia sẻ URL chứa mật khẩu.
4. Đợi luồng khởi động, mở phân tích. Tối đa 4 luồng IP đang chuyển đổi trên máy chủ trong cấu hình này. Dừng luồng từ bảng quản lý khi dùng xong.
5. Luồng RTSP không được lưu bền vững; sau khi khởi động lại máy chủ cần kết nối lại. URL camera chỉ nằm trong bộ nhớ tiến trình, không gửi lại cho trình duyệt khác/ghi vào DB.

Nếu camera chỉ có giao thức riêng của hãng/ONVIF và chưa có URL RTSP, cần lấy URL từ tài liệu hãng. Bridge đã có, nhưng từng camera thật cần kiểm chứng codec, tài khoản, mạng và hiệu năng.

## Cảnh báo về máy chủ

Trình phân tích gửi các quan sát mỗi khoảng 4 giây. Server gắn học sinh theo phiên đăng nhập hoặc `seat_id` từ sơ đồ phòng, lưu SQLite và phát thông báo SSE tới giám thị. Trang quản lý tự kết nối lại và làm mới dự phòng. Giám thị đánh dấu sự kiện đã xem/cần trao đổi; học sinh không được sửa đánh giá hoặc đọc dữ liệu phòng khác.

Sự kiện có khóa để gửi lại không tạo bản sao. Khi mất mạng, trang giữ hàng đợi cục bộ và báo số sự kiện chờ gửi; tối đa 5.000 sự kiện chờ. Giữ trang mở/khôi phục kết nối để gửi tiếp, xuất CSV tại thiết bị nếu cần giữ bản riêng. Dữ liệu máy chủ là **báo cáo từ thiết bị**, không phải bằng chứng chống sửa đổi trên máy thí sinh. Chưa có trình duyệt khóa thi hoặc kiểm tra toàn vẹn thiết bị.

Bảng server hiển thị/xuất 300 sự kiện gần nhất; DB giữ toàn bộ (tối đa 50.000 sự kiện/phòng). CSV tại trang phân tích có toàn bộ phiên tại thiết bị. Đóng phòng ngừng nhận sự kiện mới và mã tham gia; dữ liệu cũ vẫn xem được.

## Quy tắc điểm

| Quan sát | Điều kiện mặc định | Điểm |
|---|---|---|
| Quay đầu | `abs(yaw)>25°` liên tục ≥3 giây | +40 |
| Mở miệng | `MAR>0.50` liên tục ≥2 giây | +30 |
| Điện thoại/sách không được phép | Trong cùng vùng ≥1,5 giây | +60 |
| Không thấy khuôn mặt trong vùng | Liên tục ≥5 giây | +50 |
| Nhiều mặt trong cùng vùng | ≥1 giây | +60 |
| Cúi đầu và vật thể | `pitch<-20°` cùng vật thể ≥1,5 giây | Điểm tối thiểu 85 |

Cộng các quy tắc đang hoạt động, tối đa 100; tổ hợp cúi đầu/vật thể đặt sàn 85 để tránh cộng vật thể hai lần. 40–69: cần xem lại; từ 70: ưu tiên cao. Đây không phải xác suất hoặc kết luận gian lận. MAR không xác định lời nói. Cảnh báo do mất mặt có thể là che khuất/ánh sáng. Giám thị cần kiểm tra bối cảnh trước khi xử lý.

YOLOv8n COCO chỉ dùng `cell phone` và `book`; giấy/tai nghe chưa được hỗ trợ. Có lựa chọn cho phép sách. Kết quả vật thể quá 3 giây không được sử dụng; khoảng cách các lần suy luận trên 1,5 giây đặt lại bộ đếm liên tục.

## Giới hạn 100 học sinh

100 là giới hạn danh sách/API và số vùng có thể cấu hình. Đã kiểm tra 100 phiên học sinh giả lập cùng gửi sự kiện. **Chưa kiểm tra 100 luồng video trực tiếp hoặc 100 mặt trong một khung hình**. Tốc độ phụ thuộc camera, kích thước khuôn mặt và CPU/GPU. Một camera xa không đủ chi tiết để đo mắt/miệng của cả hội trường. Chia vùng cho nhiều camera/thiết bị, thử tải thực tế trước khi dùng.

Hiện phân tích AI chạy ở trình duyệt, giám thị phải giữ trang phân tích mở. Server lưu cảnh báo, video và chuyển đổi RTSP/video; server chưa tự chạy nhận diện khuôn mặt/YOLO nếu không có trình duyệt phân tích. Khi ẩn trang camera, phiên dừng. Mỗi phiên tối đa 2 giờ.

## Đưa lên Internet qua HTTPS

Bản ZIP không tự có đường link công khai. Bạn cần tài khoản hosting hoặc VPS. Có cấu hình `render.yaml` cho Render với Node 24 và ổ đĩa bền vững; dịch vụ/ổ đĩa này có chi phí theo bảng giá của Render.

1. Đưa mã nguồn (không có `data/`, mật khẩu, `node_modules/`) lên repository Git của bạn.
2. Trên Render, tạo **Blueprint** từ repository chứa `render.yaml`.
3. Nhập `ADMIN_PASSWORD` riêng ít nhất 12 ký tự khi được hỏi. Mật khẩu chỉ dùng tạo quản trị lần đầu và được băm vào ổ đĩa.
4. Build: `npm ci && npm run build`. Start: `npm start`. Health: `/api/health`.
5. Khi deploy xong, dùng địa chỉ HTTPS Render cấp để đăng nhập, tạo phòng, gửi link và mã tham gia cho học sinh.
6. Nếu dùng camera IP, thiết lập mạng tới camera và `CAMERA_HOSTS` trước; đây là việc riêng với khả năng mở website công khai.

Có thể triển khai trên VPS Node 24, reverse proxy HTTPS (Nginx/Caddy), ổ đĩa bền vững. Chạy build rồi `npm start`; cấu hình `PORT`, `DATA_DIR`, `COOKIE_SECURE=true`, `TRUST_PROXY=true` khi chỉ có một proxy tin cậy. Không đưa cổng backend trực tiếp ra Internet khi bật trust proxy. Xem `.env.example`; các giá trị phải được đặt trong môi trường shell/hosting (ứng dụng không tự đọc `.env`).

Sao lưu thư mục `DATA_DIR`: DB/SQLite WAL, hash quản trị, video. Không công khai thư mục dữ liệu, không đưa vào Git/ZIP. Để SQLite nhất quán, dừng server trước khi sao lưu toàn bộ hoặc dùng công cụ SQLite backup. Cấu hình này dành cho một instance máy chủ; không dùng nhiều replica cùng một file SQLite.

## Phát triển và kiểm tra

```sh
npm test
npm run build
npm start
```

- `server/app.mjs`: API, session HTTP-only, quyền truy cập, danh sách/sự kiện/video.
- `server/media.mjs`: FFmpeg/FFprobe, bridge RTSP → HLS.
- `src/portal.js`: đăng nhập, danh sách, bảng giám thị và tải video.
- `src/main.js`: camera/nguồn video và phân tích tại thiết bị.
- `src/monitor-sync.js`: hàng đợi gửi cảnh báo.
- `src/proctoring.js`, `src/yolo.js`: quy tắc, hình học và ONNX.

Đã kiểm thử API/giới hạn 100/đúng quyền/CSV/quy tắc, FFmpeg với video tổng hợp, SSE và build. Webcam/điện thoại/camera IP thật và độ chính xác mô hình trong phòng thi cần kiểm tra trên thiết bị thật. File mở nhanh Windows phiên bản mới chưa được thực thi trong sandbox Linux. Chưa triển khai lên hosting Internet.

## Mô hình và giấy phép

Face Landmarker float16 v1 từ https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task (MediaPipe Apache-2.0).

YOLOv8n ONNX từ https://github.com/Hyuto/yolov8-onnxruntime-web commit `fc4a52c466d15ad4519873a0cef22fbc935b93b6`, `public/model/yolov8n.onnx`; SHA-256 `505648ada344cd9f3f31e51d49c489c070819bc96cc758258a8fd51488e00579`. Ultralytics AGPL-3.0; bản phân phối mã nguồn dùng AGPL-3.0, thư viện bên thứ ba giữ giấy phép riêng. Xem `LICENSE` và `licenses/`.

WASM được tạo lại khi `npm ci` qua `postinstall`; chạy `npm run prepare:assets` nếu đã bỏ qua script. FFmpeg/FFprobe được lấy theo hệ điều hành từ package dependencies; có thể cấu hình `FFMPEG_PATH`, `FFPROBE_PATH` để dùng binary đã cài trên máy chủ.
