import './style.css';
import './proctor.css';
import { FaceLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';
import { pose } from './analysis.js';
import { bounds, mouthAspectRatio, makeSeats, assignToSeats, ProctorSession, RULES, eventsCsv, riskPriority } from './proctoring.js';
import { connectMonitor } from './monitor-sync.js';
import { api } from './api.js';
import { YoloDetector } from './yolo.js';

const $ = id => document.getElementById(id);
const escape = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.title = 'FocusLab Proctor · Hỗ trợ giám sát thi';
document.querySelector('#app').innerHTML = `
<aside class="sidebar"><a class="brand" href="#overview"><span class="brand-icon">f<span>•</span></span>FocusLab<span class="brand-dot">.</span></a><div class="workspace-label">PROCTOR · GIÁM SÁT THI</div><nav><a class="active" href="#overview">▦<span>Phòng giám sát</span></a><a href="#camera-panel">◉<span>Camera phòng thi</span></a><a href="#seats-panel">▥<span>Chỗ ngồi & mã thí sinh</span></a><a href="#events-panel">☷<span>Nhật ký cảnh báo</span></a></nav><div class="sidebar-note"><div class="small-icon">◎</div><strong>Quan sát rõ ràng.<br>Đánh giá bởi giám thị.</strong><p>Quy tắc hỗ trợ phát hiện tín hiệu cần xem lại trong phiên thi.</p><span>XỬ LÝ TẠI THIẾT BỊ</span></div><div class="profile"><span class="avatar">FL</span><div><strong>FocusLab Proctor</strong><small>Giám sát qua một camera</small></div></div></aside>
<main id="overview"><header><div class="breadcrumb">Giám sát thi <span>/</span><a href="/">Trang quản lý</a></div><div class="local-badge"><span></span> Camera, video & kết nối máy chủ</div></header><section class="page-heading"><div><div class="eyebrow">AI PROCTORING · HỖ TRỢ GIÁM THỊ</div><h1>Phòng giám sát thi<span>.</span></h1><p>Quan sát theo chỗ ngồi, ghi nhận sự kiện và xem lại cảnh báo.</p></div><button id="export" class="button secondary" disabled>↧ <span>Xuất nhật ký CSV</span></button></section>
<div class="notice">ⓘ Cảnh báo và chỉ số quy tắc không chứng minh gian lận. Giám thị cần kiểm tra bối cảnh trước khi xử lý. Danh sách/mã tham gia gắn phiên với thí sinh; hệ thống không xác minh danh tính bằng khuôn mặt.</div>
<section class="source-controls card"><div class="card-heading"><h2>Nguồn hình ảnh</h2><a href="/">Quản lý & tải video lên ↗</a></div><div class="source-grid"><label>Nguồn<select id="source-kind"><option value="camera">Camera điện thoại / máy tính / USB</option><option value="file">Video trên thiết bị</option></select></label><label id="device-label">Chọn camera<select id="camera-device"><option value="user">Camera trước / mặc định</option><option value="environment">Camera sau</option></select></label><label id="file-label" hidden>Chọn video<input id="local-video" type="file" accept="video/*"/></label></div><div id="roster-source" hidden><label>Vùng thuộc camera này — có thể chọn nhiều<select id="roster-seats" multiple size="4"></select></label><button id="apply-roster" class="button secondary">Áp dụng vùng từ danh sách</button></div><p id="server-state" role="status">Đang kiểm tra kết nối máy chủ…</p><p id="source-note">Camera cần HTTPS khi mở từ điện thoại. Video được xử lý trên trang; dùng trang quản lý nếu muốn lưu video lên máy chủ.</p></section><section class="summary"><article><div class="summary-icon mint">◷</div><div><span>Thời gian giám sát</span><strong id="duration">00:00</strong><small id="session-label">Thiết lập camera trước khi bắt đầu</small></div></article><article><div class="summary-icon lavender">◎</div><div><span>Khuôn mặt / chỗ ngồi</span><strong id="face-count">0 <em>/ 1</em></strong><small id="model-state">MediaPipe · chưa khởi động</small></div></article><article><div class="summary-icon peach">⚑</div><div><span>Sự kiện cần xem lại</span><strong id="event-count">0 <em>sự kiện</em></strong><small id="pending-count">0 sự kiện chưa xem</small></div></article></section>
<div class="dashboard"><section class="card camera-card" id="camera-panel"><div class="card-heading"><h2>◉ Camera phòng thi</h2><span class="pill" id="live-pill">CHƯA BẮT ĐẦU</span></div><div class="camera-stage proctor-stage"><video id="video" autoplay muted playsinline></video><canvas id="overlay"></canvas><div class="camera-empty" id="camera-empty"><div class="camera-symbol">◉</div><h3>Thiết lập phòng giám sát</h3><p>1. Chọn số chỗ ngồi và bật camera.<br>2. Chỉnh vùng bao gồm người ngồi và bàn thi.<br>3. Yêu cầu nhìn thẳng, rồi bắt đầu giám sát.</p><button id="start" class="button primary">Bật camera</button><small>Camera cần HTTPS hoặc localhost, và WebGL</small></div></div><div class="camera-footer"><span id="camera-state">Camera đang tắt</span><div><button id="arm" class="button primary" disabled>Hiệu chỉnh & bắt đầu</button><button id="stop" class="stop-button" disabled>■ Dừng camera</button></div></div><p id="message" role="status" aria-live="polite">Chọn số chỗ thực sự có người thi. Mỗi vùng cần một khuôn mặt khi bắt đầu.</p><div id="object-state" class="object-state">YOLOv8n · chưa khởi động</div></section>
<section class="card settings" id="settings"><div class="card-heading"><h2>Cấu hình phiên thi</h2><span class="subtle">☷</span></div><div class="form-fields"><label for="seat-count">Số chỗ ngồi (1–100)</label><input id="seat-count" type="number" min="1" max="100" value="1"/><label for="yaw-threshold">Ngưỡng quay đầu <output id="yaw-value">25°</output></label><input id="yaw-threshold" type="range" min="10" max="45" value="25"/><small>Quay quá ngưỡng liên tục ≥ 3 giây.</small><label for="mar-threshold">Ngưỡng mở miệng <output id="mar-value">0.50</output></label><input id="mar-threshold" type="range" min="0.15" max="0.75" step="0.01" value="0.50"/><small>MAR quá ngưỡng liên tục ≥ 2 giây; không xác định lời nói.</small><label class="check-label"><input id="objects-enabled" type="checkbox" checked/> Nhận diện điện thoại / sách (YOLOv8n)</label><label class="check-label"><input id="allow-books" type="checkbox"/> Đề thi cho phép sử dụng sách</label><label for="confidence">Ngưỡng tin cậy vật thể <output id="confidence-value">45%</output></label><input id="confidence" type="range" min="0.25" max="0.90" step="0.05" value="0.45"/><small>Giấy và tai nghe chưa được mô hình này hỗ trợ.</small><div class="settings-note">Không thấy mặt ≥ 5 giây → ưu tiên xem lại.<br>Cúi đầu dưới −20° + vật thể trong cùng vùng ≥ 1,5 giây → ưu tiên cao.<br>Quay đầu +40 · vật thể +60 · mở miệng +30; tổng tối đa 100.<br>Từ 40: cần xem lại · từ 70: ưu tiên cao. Không phải xác suất gian lận.</div></div></section></div>
<section class="card wide-card" id="seats-panel"><div class="card-heading"><div><h2>Chỗ ngồi & mã thí sinh</h2><p>Vị trí cố định; mã không phải kết quả nhận diện khuôn mặt.</p></div><span class="pill" id="setup-pill">THIẾT LẬP</span></div><div class="seat-tools"><label for="selected-seat">Vùng cần chỉnh</label><select id="selected-seat"></select><button id="edit-region" class="button secondary" disabled>Vẽ lại vùng trên camera</button><button id="reset-regions" class="text-button">Đặt lại lưới</button><span>Trong ảnh hiển thị, S01 bắt đầu từ phía bên phải.</span></div><div class="table-wrap"><table><thead><tr><th>Chỗ</th><th>Mã thí sinh</th><th>Khuôn mặt</th><th>Yaw / Pitch</th><th>MAR</th><th>Chỉ số quy tắc</th><th>Tín hiệu hiện tại</th></tr></thead><tbody id="seat-rows"></tbody></table></div></section>
<section class="card wide-card" id="events-panel"><div class="card-heading"><div><h2>Nhật ký cảnh báo</h2><p>Một sự kiện cho mỗi lần quy tắc bắt đầu; tự kết thúc khi tín hiệu hết.</p></div><select id="event-filter" aria-label="Lọc sự kiện"><option value="all">Tất cả sự kiện</option><option value="pending">Chưa xem lại</option><option value="active">Đang diễn ra</option></select></div><div class="table-wrap"><table><thead><tr><th>Thời gian</th><th>Chỗ / thí sinh</th><th>Quan sát</th><th>Ưu tiên</th><th>Thời lượng</th><th>Giám thị xem lại</th></tr></thead><tbody id="event-rows"></tbody></table><div id="event-empty" class="empty-events">Chưa có sự kiện. Bật camera, thiết lập các vùng rồi bắt đầu giám sát.</div></div></section>
<footer><span><span class="footer-logo">f•</span> FocusLab Proctor <span class="footer-separator">/</span> Hỗ trợ quan sát trong phiên thi</span><span>Nhật ký lưu tạm trên thiết bị</span></footer></main>`;

let faceModel, detector, stream, running = false, starting = false, monitoring = false, epoch = 0;
let seats = makeSeats(1), session = null, faces = [], objects = [], objectCapturedAt = -Infinity, objectBusy = false, objectFailed = false;
let raf, lastFrame = -Infinity, lastVideoTime = -1, lastVideoProgress = 0, lastObjectAttempt = -Infinity, lastRender = -Infinity;
let connection=null, hls=null, fileUrl=null, sourceKind='camera', mirrored=true, sourceReady=true;
const sourceParams=new URLSearchParams(location.search);
const sessionClock=()=>['file','server-video'].includes(sourceKind)?$('video').currentTime*1000:performance.now();
let lastRuleTime=0;
let latest = null, drawing = false, dragStart = null, draft = null, totalFaces = 0;
const trackedJobs = new Set();
function message(text) { $('message').textContent = text; }
const thresholds = () => ({yaw:Number($('yaw-threshold').value), mar:Number($('mar-threshold').value)});
const formatDuration = ms => { const seconds=Math.max(0,Math.floor(ms/1000)); return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`; };
function setLocked(locked) {
  for (const id of ['seat-count','reset-regions','objects-enabled','allow-books','yaw-threshold','mar-threshold','confidence','source-kind','camera-device','local-video','roster-seats','apply-roster']) $(id).disabled = locked || starting;
  document.querySelectorAll('.candidate-input').forEach(input => input.disabled = locked);
  $('edit-region').disabled = !running || locked;
  if(running)for(const id of ['source-kind','camera-device','local-video'])$(id).disabled=true;
  if(connection?.me.role==='student'){$('seat-count').disabled=true;document.querySelectorAll('.candidate-input').forEach(i=>i.disabled=true);}
  $('setup-pill').textContent = locked ? 'VÙNG ĐÃ KHÓA' : 'THIẾT LẬP';
}
function renderSeatSetup() {
  $('selected-seat').innerHTML = seats.map(seat=>`<option value="${seat.id}">${seat.id}</option>`).join('');
  $('seat-rows').innerHTML = seats.map(seat=>`<tr id="row-${seat.id}"><td><strong>${seat.id}</strong></td><td><input class="candidate-input" data-seat="${seat.id}" aria-label="Mã thí sinh chỗ ${seat.id}" maxlength="40" value="${escape(seat.label)}"/></td><td class="seat-face">—</td><td class="seat-pose">—</td><td class="seat-mar">—</td><td class="seat-risk">—</td><td class="seat-status">Chờ thiết lập</td></tr>`).join('');
  $('face-count').innerHTML = `${faces.length} <em>/ ${seats.length}</em>`;
}
function renderReadings(readings) {
  for (const reading of readings) {
    const row=$(`row-${reading.seat.id}`);
    row.querySelector('.seat-face').textContent = `${reading.count} mặt`;
    row.querySelector('.seat-pose').textContent = reading.yaw === null ? '—' : `${reading.yaw.toFixed(1)}° / ${reading.pitch.toFixed(1)}°`;
    row.querySelector('.seat-mar').textContent = Number.isFinite(reading.mar) ? reading.mar.toFixed(2) : '—';
    row.querySelector('.seat-risk').innerHTML = monitoring ? `<span class="risk ${riskPriority(reading.risk)}">${reading.risk}/100</span>` : '—';
    row.querySelector('.seat-status').textContent = reading.activeRules?.length ? `${reading.risk>=70?'Ưu tiên cao':reading.risk>=40?'Cần xem lại':'Quan sát'}: ${reading.activeRules.map(key=>RULES[key].label).join(' · ')}` : monitoring ? (reading.count===1 ? 'Chưa có cảnh báo' : 'Đang chờ đủ thời gian') : (reading.count===1 ? 'Sẵn sàng hiệu chỉnh' : reading.count>1 ? 'Vùng có nhiều mặt — cần chỉnh' : 'Chưa thấy mặt');
  }
}
function renderEvents() {
  const events=session?.events ?? [];
  connection?.push(events,['file','server-video'].includes(sourceKind)?$('video').currentTime:null);
  const filter=$('event-filter').value;
  const shown=events.filter(e=>filter==='pending' ? e.review==='pending' : filter==='active' ? !e.resolved : true);
  $('event-count').innerHTML = `${events.length} <em>sự kiện</em>`;
  $('pending-count').textContent = `${events.filter(e=>e.review==='pending').length} sự kiện chưa xem`;
  $('export').disabled = !events.length;
  if (document.activeElement?.matches('[data-event]')) return;
  // Latest 200 rows keep the UI responsive; CSV contains the full session.
  $('event-rows').innerHTML=shown.slice(-200).reverse().map(e=>`<tr><td>${escape(new Date(e.time).toLocaleTimeString('vi-VN'))}<small>${e.resolved ? 'Đã kết thúc' : 'Đang diễn ra'}</small></td><td>${e.seatId}<small>${escape(e.candidate)}</small></td><td>${escape(e.label)}${e.objects ? `<small>${escape(e.objects)}</small>` : ''}</td><td><span class="risk ${e.severity}">${e.severity==='high'?'Cao':e.severity==='medium'?'Vừa':'Thấp'}</span></td><td>${((e.lastMs-e.startMs)/1000).toFixed(1)} giây</td><td><select data-event="${e.id}" aria-label="Xem lại sự kiện ${e.id}"><option value="pending" ${e.review==='pending'?'selected':''}>Chưa xem</option><option value="dismissed" ${e.review==='dismissed'?'selected':''}>Đã xem: không cần xử lý</option><option value="followup" ${e.review==='followup'?'selected':''}>Đã xem: cần trao đổi</option></select></td></tr>`).join('');
  $('event-empty').hidden = shown.length>0;
  $('event-empty').textContent = filter !== 'all' ? 'Không có sự kiện phù hợp bộ lọc.' : 'Chưa có cảnh báo trong nhật ký. Xuất dữ liệu trước khi bắt đầu phiên mới.';
}
function finishSession() {
  if (monitoring) session.finish(Math.max(session.startedAt,lastRuleTime),new Date().toISOString());
  monitoring=false; renderEvents();connection?.flush();
}
function stop(text='Camera đã tắt. Xuất nhật ký trước khi bắt đầu phiên mới hoặc đóng trang.') {
  epoch++; running=false; finishSession(); cancelAnimationFrame(raf);
  stream?.getTracks().forEach(track=>track.stop()); stream=null;
  $('video').pause();$('video').srcObject=null;$('video').removeAttribute('src');hls?.destroy();hls=null;if(fileUrl){URL.revokeObjectURL(fileUrl);fileUrl=null;} faces=[]; objects=[]; latest=null; objectCapturedAt=-Infinity; drawing=false; draft=null;
  $('camera-empty').hidden=false; $('overlay').getContext('2d').clearRect(0,0,$('overlay').width,$('overlay').height);
  $('overlay').classList.remove('drawing'); $('edit-region').textContent='Vẽ lại vùng trên camera';
  $('stop').disabled=true; $('arm').disabled=true; $('start').disabled=starting;
  $('live-pill').textContent='CAMERA ĐÃ TẮT'; $('live-pill').classList.remove('live');
  $('camera-state').textContent='Camera đang tắt'; $('session-label').textContent=session?'Phiên đã kết thúc':'Chưa bắt đầu giám sát';
  $('face-count').innerHTML=`0 <em>/ ${seats.length}</em>`;
  $('object-state').textContent='Phát hiện vật thể đã dừng';
  seats.forEach(seat=>{const row=$(`row-${seat.id}`); ['seat-face','seat-pose','seat-mar','seat-risk'].forEach(c=>row.querySelector('.'+c).textContent='—'); row.querySelector('.seat-status').textContent='Camera đã tắt';});
  setLocked(false); message(text);
}
function startupError(error) {
  if (error.name==='NotAllowedError') return 'Hãy cho phép camera trong cài đặt trình duyệt rồi thử lại.';
  if (error.name==='NotFoundError') return 'Không tìm thấy camera. Kết nối webcam rồi bật lại.';
  if (error.message==='WEBGL_UNAVAILABLE') return 'Trình duyệt cần WebGL. Bật tăng tốc phần cứng hoặc thử Chrome/Edge mới nhất.';
  if (error.message==='SECURE_CONTEXT') return 'Camera cần HTTPS hoặc localhost. Mở website bằng địa chỉ HTTPS.';
  if (error.message==='PAGE_HIDDEN') return 'Trang đã bị ẩn. Mở lại trang và bật camera.';
  if (error.message==='YOLO_LOAD') return 'Không tải được YOLOv8. Kiểm tra tệp mô hình hoặc bỏ chọn nhận diện vật thể để chỉ dùng quy tắc khuôn mặt.';
  if(!['SECURE_CONTEXT','WEBGL_UNAVAILABLE','PAGE_HIDDEN','YOLO_LOAD'].includes(error.message)&&error.name==='Error') return error.message;
  return 'Không thể khởi động bộ phân tích hoặc camera. Đóng ứng dụng đang dùng camera và thử lại.';
}
async function start() {
  if (starting || running || !sourceReady) return;
  starting=true; const token=++epoch; setLocked(false); $('start').disabled=true; $('start').textContent='Đang chuẩn bị…';
  try {
    // A previous async ONNX inference must finish before reusing its session.
    await Promise.allSettled([...trackedJobs]);
    sourceKind=$('source-kind').value;mirrored=sourceKind==='camera';$('video').style.transform=mirrored?'scaleX(-1)':'none';
    $('video').controls=sourceKind==='file'||sourceKind==='server-video';
    if(sourceKind==='camera'){
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('SECURE_CONTEXT');
      const choice=$('camera-device').value;
      const videoOptions={width:{ideal:1280},height:{ideal:720},...(['user','environment'].includes(choice)?{facingMode:{ideal:choice}}:{deviceId:{exact:choice}})};
      const newStream=await navigator.mediaDevices.getUserMedia({video:videoOptions,audio:false});
      if (token!==epoch) {newStream.getTracks().forEach(t=>t.stop()); return;}
      stream=newStream;await refreshDevices();
    }
    $('stop').disabled=false;
    const probe=document.createElement('canvas'), gl=probe.getContext('webgl2')||probe.getContext('webgl');
    if (!gl) throw new Error('WEBGL_UNAVAILABLE');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    message('Đang tải mô hình khuôn mặt…');
    if (!faceModel) {
      const files=await FilesetResolver.forVisionTasks('/wasm');
      faceModel=await FaceLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:'/models/face_landmarker.task',delegate:'CPU'},runningMode:'VIDEO',numFaces:Math.min(100,seats.length+2),outputFacialTransformationMatrixes:true});
    } else await faceModel.setOptions({numFaces:Math.min(100,seats.length+2)});
    if (token!==epoch) return;
    objectFailed=false;
    if ($('objects-enabled').checked && !detector) {
      message('Đang tải YOLOv8n để nhận diện điện thoại / sách…');
      const candidate=new YoloDetector();
      try {await candidate.load(); detector=candidate;} catch {await candidate.close(); throw new Error('YOLO_LOAD');}
    }
    if (token!==epoch) return;
    if (document.hidden) throw new Error('PAGE_HIDDEN');
    await attachSource(token); if(token!==epoch)return; await $('video').play();
    if (token!==epoch) return;
    running=true; monitoring=false; faces=[]; objects=[]; lastVideoTime=-1; lastFrame=-Infinity; lastVideoProgress=performance.now(); lastObjectAttempt=-Infinity; objectCapturedAt=-Infinity;
    $('camera-empty').hidden=true; $('start').disabled=true; $('stop').disabled=false; $('edit-region').disabled=false;
    $('live-pill').textContent='THIẾT LẬP CAMERA'; $('live-pill').classList.add('live');
    $('camera-state').textContent='Camera đã kết nối · chưa ghi sự kiện';
    $('model-state').textContent=`MediaPipe · tối đa ${Math.min(100,seats.length+2)} khuôn mặt`;
    $('object-state').textContent=$('objects-enabled').checked?'YOLOv8n · đang chờ khung hình':'Nhận diện vật thể đang tắt; các cảnh báo vật thể không hoạt động.';
    $('session-label').textContent='Chưa bắt đầu — đang thiết lập';
    setLocked(false); for(const id of ['seat-count','objects-enabled','source-kind','camera-device','local-video'])$(id).disabled=true;
    stream?.getVideoTracks()[0]?.addEventListener('ended',()=>{if(running)stop('Camera bị ngắt kết nối. Phiên giám sát đã dừng.');});
    message('Chỉnh vùng bao gồm cả bàn thi. Mỗi chỗ cần một khuôn mặt nhìn thẳng; sau đó bấm “Hiệu chỉnh & bắt đầu”.');
    raf=requestAnimationFrame(processFrame);
  } catch(error) { if(token===epoch) stop(startupError(error)); }
  finally {starting=false; $('start').disabled=running; $('start').textContent='Bật camera'; if(!running)setLocked(false);}
}
function launchObjects(now) {
  if (!$('objects-enabled').checked || objectFailed || objectBusy || now-lastObjectAttempt<1000) return;
  const token=epoch, capturedAt=performance.now(); objectBusy=true; lastObjectAttempt=now;
  // Snapshot the frame so results refer to this image even if video advances.
  const snapshot=document.createElement('canvas'); snapshot.width=$('video').videoWidth; snapshot.height=$('video').videoHeight;
  snapshot.getContext('2d').drawImage($('video'),0,0);
  const job=detector.detect(snapshot,Number($('confidence').value),$('allow-books').checked).then(result=>{
    if(token!==epoch || !running) return;
    objects=result; objectCapturedAt=capturedAt;
    $('object-state').textContent=`YOLOv8n · ${result.length} vật thể cần kiểm tra · xử lý ${Math.round(performance.now()-capturedAt)} ms`;
  }).catch(error=>{
    if(token!==epoch) return;
    console.error('YOLO failed',error); objectFailed=true; objects=[]; objectCapturedAt=-Infinity;
    $('object-state').textContent='YOLOv8 bị gián đoạn; cảnh báo vật thể không hoạt động. Dừng và bật lại để thử lại.';
  }).finally(()=>{objectBusy=false; trackedJobs.delete(job);});
  trackedJobs.add(job);
}
function processFrame(now) {
  if(!running) return;
  try {
    const video=$('video');
    if(video.currentTime!==lastVideoTime && video.readyState>=2 && !video.seeking && now-lastFrame>=200) {
      lastVideoProgress=performance.now(); lastVideoTime=video.currentTime; lastFrame=now;
      const results=faceModel.detectForVideo(video,performance.now());
      const observedAt=performance.now(), ruleTime=sessionClock();
      faces=results.faceLandmarks.map((points,i)=>({points,box:bounds(points),pose:pose(results.facialTransformationMatrixes?.[i]?.data),mar:mouthAspectRatio(points,video.videoWidth,video.videoHeight)}));
      totalFaces=faces.length; $('face-count').innerHTML=`${totalFaces} <em>/ ${seats.length}</em>`;
      const available=$('objects-enabled').checked&&!objectFailed&&observedAt-objectCapturedAt<=3000;
      const freshObjects=available?objects:[];
      const mapping=assignToSeats(seats,faces,freshObjects);
      if(monitoring) {
        latest=session.update(faces,freshObjects,ruleTime,new Date().toISOString(),available);lastRuleTime=ruleTime;
        $('duration').textContent=formatDuration(ruleTime-session.startedAt);
        if(ruleTime-session.startedAt>=2*60*60*1000) {stop('Đã kết thúc phiên 2 giờ. Xuất nhật ký trước khi bắt đầu phiên mới.');return;}
        if(latest.unassignedFaces.length||latest.unassignedObjects.length) message(`Có ${latest.unassignedFaces.length} khuôn mặt và ${latest.unassignedObjects.length} vật thể ngoài vùng hoặc thuộc vùng chồng lấn. Giám thị cần kiểm tra; chưa gán chúng cho thí sinh.`);
        else message('Đang giám sát. Chỉ số quy tắc hỗ trợ ưu tiên xem lại, không phải xác suất gian lận.');
      } else {
        latest={readings:seats.map(seat=>{const value=mapping.assigned.get(seat.id),face=value.faces.length===1?value.faces[0]:null; return {seat,count:value.faces.length,face,mar:face?.mar??null,yaw:null,pitch:null,risk:0,activeRules:[],objects:value.objects};})};
        $('arm').disabled=drawing||!seats.every(seat=>{const f=mapping.assigned.get(seat.id).faces; return f.length===1&&f[0].pose&&Number.isFinite(f[0].mar);});
      }
      drawOverlay(freshObjects);
      if(observedAt-lastRender>=700) {lastRender=observedAt; renderReadings(latest.readings);renderEvents();}
      if($('objects-enabled').checked&&!objectFailed&&objectCapturedAt!==-Infinity&&!available) $('object-state').textContent='Kết quả vật thể đã quá 3 giây; tạm ngừng quy tắc vật thể đến khi có kết quả mới.';
      launchObjects(observedAt);
    } else if(!(['file','server-video'].includes(sourceKind)&&video.paused)&&performance.now()-lastVideoProgress>5000) {stop('Luồng camera không có khung hình mới trong 5 giây. Phiên đã dừng; đây không phải cảnh báo thí sinh vắng mặt.');return;}
    raf=requestAnimationFrame(processFrame);
  } catch(error) {console.error('Face analysis failed',error);stop('Bộ phân tích khuôn mặt bị gián đoạn. Phiên đã dừng; hãy bật lại camera.');faceModel?.close();faceModel=null;}
}
function drawOverlay(freshObjects=[]) {
  const canvas=$('overlay'), video=$('video');
  if(!video.videoWidth)return;
  canvas.width=video.videoWidth;canvas.height=video.videoHeight;
  const ctx=canvas.getContext('2d'), w=canvas.width,h=canvas.height;
  // Mirror coordinates in code so labels stay readable while the video is mirrored.
  const drawBox=(box,label,color,dashed=false)=>{
    const x=(mirrored?1-box.x-box.width:box.x)*w,y=box.y*h,bw=box.width*w,bh=box.height*h;
    ctx.strokeStyle=color;ctx.lineWidth=2;ctx.setLineDash(dashed?[7,5]:[]);ctx.strokeRect(x,y,bw,bh);ctx.setLineDash([]);
    ctx.font=`${Math.max(13,Math.round(w/75))}px sans-serif`;const textWidth=ctx.measureText(label).width;
    ctx.fillStyle=color;ctx.fillRect(x,Math.max(0,y-23),textWidth+10,23);ctx.fillStyle='#fff';ctx.fillText(label,x+5,Math.max(16,y-7));
  };
  for(const seat of seats) drawBox(seat.region,`${seat.id} · ${seat.label}`,'#428caa',true);
  const mapping=assignToSeats(seats,faces,freshObjects);
  faces.forEach(face=>{const matches=seats.filter(seat=>mapping.assigned.get(seat.id).faces.includes(face));const reading=latest?.readings.find(r=>r.seat.id===matches[0]?.id);drawBox(face.box,matches.length===1?`${matches[0].id} · khuôn mặt`:'Ngoài vùng / chồng lấn',reading?.risk>0?'#d7754c':'#45ba91');});
  freshObjects.forEach(object=>drawBox(object.box,`${object.label} ${Math.round(object.score*100)}%`,'#d29c34'));
  if(draft) drawBox(draft,'Vùng mới','#c069d8',true);
}
function pointerPosition(event) {
  const rect=$('overlay').getBoundingClientRect(),v=$('video');
  const scale=Math.min(rect.width/v.videoWidth,rect.height/v.videoHeight);
  const width=v.videoWidth*scale,height=v.videoHeight*scale;
  const x=(event.clientX-rect.left-(rect.width-width)/2)/width;
  const y=(event.clientY-rect.top-(rect.height-height)/2)/height;
  return {x:mirrored?1-Math.max(0,Math.min(1,x)):Math.max(0,Math.min(1,x)),y:Math.max(0,Math.min(1,y))};
}
renderSeatSetup();
$('start').addEventListener('click',start);
$('stop').addEventListener('click',()=>stop());
$('seat-count').addEventListener('change',()=>{if(running||starting||connection?.me.role==='student')return;seats=makeSeats($('seat-count').value);$('seat-count').value=seats.length;renderSeatSetup();});
$('seat-rows').addEventListener('input',event=>{if(!monitoring&&event.target.matches('.candidate-input')){const seat=seats.find(s=>s.id===event.target.dataset.seat);seat.label=event.target.value.trim()||seat.id;}});
$('reset-regions').addEventListener('click',()=>{if(monitoring)return;const grid=makeSeats(seats.length);seats.forEach((seat,i)=>seat.region=grid[i].region);drawOverlay();});
$('edit-region').addEventListener('click',()=>{if(!running||monitoring)return;drawing=!drawing;dragStart=null;draft=null;$('overlay').classList.toggle('drawing',drawing);$('edit-region').textContent=drawing?'Hủy vẽ vùng':'Vẽ lại vùng trên camera';$('arm').disabled=drawing;message(drawing?'Kéo chuột trên ảnh camera để vẽ vùng cho chỗ đang chọn. Bao gồm cả bàn thi; tránh chồng lấn vùng khác.':'Đã thoát chế độ vẽ vùng.');});
$('overlay').addEventListener('pointerdown',event=>{if(!drawing)return;dragStart=pointerPosition(event);$('overlay').setPointerCapture(event.pointerId);});
$('overlay').addEventListener('pointermove',event=>{if(!drawing||!dragStart)return;const end=pointerPosition(event);draft={x:Math.min(dragStart.x,end.x),y:Math.min(dragStart.y,end.y),width:Math.abs(dragStart.x-end.x),height:Math.abs(dragStart.y-end.y)};drawOverlay();});
$('overlay').addEventListener('pointerup',()=>{if(!drawing||!draft)return;if(draft.width>=.03&&draft.height>=.03){seats.find(s=>s.id===$('selected-seat').value).region={...draft};message('Đã cập nhật vùng. Chọn chỗ khác để chỉnh tiếp, hoặc bấm “Hủy vẽ vùng” để hiệu chỉnh.');}draft=null;dragStart=null;drawOverlay();});
$('overlay').addEventListener('pointercancel',()=>{draft=null;dragStart=null;drawOverlay();});
$('arm').addEventListener('click',()=>{
  if(!running||monitoring||drawing)return;
  const mapping=assignToSeats(seats,faces,[]);const baselines=new Map();
  for(const seat of seats){const f=mapping.assigned.get(seat.id).faces;if(f.length!==1||!f[0].pose||!Number.isFinite(f[0].mar)){message('Mỗi chỗ cần đúng một khuôn mặt có góc đầu hợp lệ. Chỉnh vùng và thử lại.');return;}baselines.set(seat.id,{...f[0].pose});}
  if(session?.events.length && !window.confirm('Phiên mới sẽ xóa nhật ký cũ trên trang. Bạn đã xuất dữ liệu cần giữ chưa?'))return;
  session=new ProctorSession(seats,sessionClock(),baselines,thresholds());lastRuleTime=session.startedAt;monitoring=true;setLocked(true);$('arm').disabled=true;renderEvents();
  $('duration').textContent='00:00';$('live-pill').textContent='ĐANG GIÁM SÁT';$('camera-state').textContent='Camera đã kết nối · đang ghi sự kiện';$('session-label').textContent='Phiên giám sát đang diễn ra';message('Đã lưu góc chuẩn của từng chỗ. Không đổi vị trí camera hoặc đổi chỗ trong phiên.');
});
for(const name of ['yaw','mar','confidence']) $(name==='confidence'?'confidence':name+'-threshold').addEventListener('input',event=>{$(name+'-value').textContent=name==='yaw'?`${event.target.value}°`:name==='mar'?Number(event.target.value).toFixed(2):`${Math.round(Number(event.target.value)*100)}%`;});
$('events-panel').addEventListener('change',event=>{if(event.target.matches('[data-event]')){const item=session?.events.find(e=>e.id===Number(event.target.dataset.event));if(item)item.review=event.target.value;renderEvents();}});
$('event-filter').addEventListener('change',renderEvents);
$('export').addEventListener('click',()=>{if(!session?.events.length)return;const url=URL.createObjectURL(new Blob([eventsCsv(session.events)],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download=`focuslab-proctor-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
window.addEventListener('pagehide',()=>{stop();connection?.close();faceModel?.close();faceModel=null;const oldDetector=detector;detector=null;Promise.allSettled([...trackedJobs]).then(()=>oldDetector?.close());});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&(running||starting))stop('Trang bị ẩn nên camera và phiên giám sát đã dừng. Đây không phải cảnh báo thí sinh vắng mặt.');});

async function refreshDevices(){
 if(!navigator.mediaDevices?.enumerateDevices)return;
 const selected=$('camera-device').value;
 const devices=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='videoinput');
 $('camera-device').innerHTML='<option value="user">Camera trước / mặc định</option><option value="environment">Camera sau</option>'+devices.map((d,i)=>`<option value="${escape(d.deviceId)}">${escape(d.label||`Camera ${i+1}`)}</option>`).join('');
 if([...$('camera-device').options].some(o=>o.value===selected))$('camera-device').value=selected;
}
async function attachSource(token){
 const video=$('video');
 if(sourceKind==='camera'){video.srcObject=stream;return;}
 if(sourceKind==='file'){
   const file=$('local-video').files[0];if(!file)throw new Error('Chọn một tệp video trước khi bắt đầu.');
   fileUrl=URL.createObjectURL(file);video.src=fileUrl;
 }else if(sourceKind==='server-video'){
   const info=await api(`/api/videos/${sourceParams.get('video')}`);if(info.status!=='ready')throw new Error('Video trên máy chủ chưa sẵn sàng.');
   video.src=`/api/videos/${info.id}/content${video.canPlayType('video/mp4; codecs="avc1.42E01E"')?'':'?format=webm'}`;
 }else if(sourceKind==='ip'){
   const {default:Hls}=await import('hls.js');
   const url=`/api/cameras/${sourceParams.get('camera')}/index.m3u8`;
   if(video.canPlayType('application/vnd.apple.mpegurl'))video.src=url;
   else if(Hls.isSupported()){
     await new Promise((resolve,reject)=>{hls=new Hls();let settled=false;const timer=setTimeout(()=>finish(new Error('Camera IP chưa có hình ảnh sau 30 giây.')),30000);
       const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve();};
       hls.on(Hls.Events.MANIFEST_PARSED,()=>finish());hls.on(Hls.Events.ERROR,(_event,data)=>{if(data.fatal)finish(new Error('Không đọc được luồng camera IP. Kiểm tra máy chủ và kết nối camera.'));});hls.loadSource(url);hls.attachMedia(video);
     });
   }else throw new Error('Trình duyệt không hỗ trợ phát luồng camera IP này.');
 }
 if(token!==epoch)return;
 if(video.readyState<1)await new Promise((resolve,reject)=>{const timer=setTimeout(()=>finish(new Error('Không tải được video.')),20000);const finish=error=>{clearTimeout(timer);video.removeEventListener('loadedmetadata',ready);video.removeEventListener('error',failed);error?reject(error):resolve();};const ready=()=>finish(),failed=()=>finish(new Error('Định dạng video chưa được trình duyệt hỗ trợ. Hãy tải lên máy chủ để chuyển sang định dạng phù hợp.'));video.addEventListener('loadedmetadata',ready,{once:true});video.addEventListener('error',failed,{once:true});});
}
$('source-kind').addEventListener('change',()=>{$('device-label').hidden=$('source-kind').value!=='camera';$('file-label').hidden=$('source-kind').value!=='file';});
$('video').addEventListener('ended',()=>{if(running)stop('Video đã kết thúc. Nhật ký đã được giữ; có thể xuất CSV.');});
$('video').addEventListener('error',()=>{if(running)stop('Nguồn video bị lỗi. Hãy kiểm tra kết nối hoặc tệp đã chọn.');});
$('video').addEventListener('seeking',()=>{if(monitoring&&['file','server-video'].includes(sourceKind)){finishSession();setLocked(false);$('arm').disabled=true;$('live-pill').textContent='CHỜ HIỆU CHỈNH LẠI';message('Đã tua video. Phiên trước kết thúc; hãy hiệu chỉnh để phân tích đoạn mới.');}});
$('apply-roster').addEventListener('click',()=>{
 if(monitoring||starting)return;
 const selected=[...$('roster-seats').selectedOptions].map(o=>o.value),roster=connection?.roster.filter(s=>selected.includes(s.seat_id))??[];
 if(!roster.length){message('Chọn ít nhất một vùng từ danh sách.');return;}
 if(running){stop('Đã đổi vùng. Bật lại nguồn để tải đúng số khuôn mặt.');}
 seats=makeSeats(roster.length).map((s,i)=>({...s,id:roster[i].seat_id,label:roster[i].student_code}));$('seat-count').value=seats.length;renderSeatSetup();
});
async function configureConnection(){
 sourceReady=false;$('start').disabled=true;
 try{
   connection=await connectMonitor(sourceParams.get('room'),text=>$('server-state').textContent=text);
   if(connection){
     const roster=connection.roster??[];
     if(roster.length){seats=makeSeats(roster.length).map((s,i)=>({...s,id:roster[i].seat_id,label:roster[i].student_code}));$('seat-count').value=seats.length;renderSeatSetup();}
     if(connection.me.role==='admin'&&roster.length){$('roster-source').hidden=false;$('roster-seats').innerHTML=roster.map(s=>`<option selected value="${escape(s.seat_id)}">${escape(s.seat_id)} · ${escape(s.student_code)} · ${escape(s.name)}</option>`).join('');}
     if(connection.me.role==='student'){$('seat-count').disabled=true;$('seats-panel').querySelectorAll('.candidate-input').forEach(i=>i.disabled=true);}
   }
   if(sourceParams.get('video')||sourceParams.get('camera')){
     const value=sourceParams.has('video')?'server-video':'ip';const option=document.createElement('option');option.value=value;option.textContent=value==='ip'?'Camera IP từ máy chủ':'Video đã tải lên máy chủ';$('source-kind').append(option);$('source-kind').value=value;$('source-kind').dispatchEvent(new Event('change'));
   }
   sourceReady=true;$('start').disabled=false;
 }catch(error){$('server-state').textContent=error.message+' Mở Trang quản lý để kết nối lại.';}
 refreshDevices().catch(()=>{});
}
configureConnection();
