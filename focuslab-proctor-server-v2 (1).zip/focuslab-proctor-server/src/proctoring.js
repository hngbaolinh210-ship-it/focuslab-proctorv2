import { angleDifference } from './analysis.js';

export const RULES = {
  away: { label: 'Quay đầu kéo dài', severity: 'medium', risk: 40 },
  mouth: { label: 'Mở miệng kéo dài', severity: 'medium', risk: 30 },
  absent: { label: 'Không thấy khuôn mặt tại chỗ', severity: 'high', risk: 50 },
  multiple: { label: 'Nhiều khuôn mặt trong cùng vùng', severity: 'high', risk: 60 },
  object: { label: 'Vật thể cần kiểm tra trong vùng', severity: 'high', risk: 60 },
  combined: { label: 'Cúi đầu kèm vật thể cần kiểm tra', severity: 'high', risk: 85 },
};
export const riskPriority = score => score >= 70 ? 'high' : score >= 40 ? 'medium' : 'low';
export function aggregateRisk(activeRules) {
  const unique = [...new Set(activeRules)];
  const sum = unique.filter(key => key !== 'combined').reduce((total, key) => total + (RULES[key]?.risk ?? 0), 0);
  // The downward-pose combination sets a minimum, so the same object is not counted twice.
  return Math.min(100, Math.max(sum, unique.includes('combined') ? RULES.combined.risk : 0));
}
export const DEFAULT_THRESHOLDS = { yaw: 25, pitch: -20, mar: 0.5, awayMs: 3000, mouthMs: 2000, absentMs: 5000, objectMs: 1500 };
export function mouthAspectRatio(points, width, height) {
  const d = (a, b) => Math.hypot((points[a].x - points[b].x) * width, (points[a].y - points[b].y) * height);
  const horizontal = d(78, 308);
  return horizontal > 0 ? d(13, 14) / horizontal : null;
}
export function bounds(points) {
  const xs = points.map(p => p.x), ys = points.map(p => p.y);
  return { x: Math.max(0, Math.min(...xs)), y: Math.max(0, Math.min(...ys)), width: Math.min(1, Math.max(...xs)) - Math.max(0, Math.min(...xs)), height: Math.min(1, Math.max(...ys)) - Math.max(0, Math.min(...ys)) };
}
export const contains = (region, x, y) => x >= region.x && x < region.x + region.width && y >= region.y && y < region.y + region.height;
export function makeSeats(count) {
  count = Math.max(1, Math.min(100, Math.floor(Number(count) || 1)));
  const cols = count === 1 ? 1 : Math.ceil(Math.sqrt(count * 1.5));
  const rows = Math.ceil(count / cols);
  return Array.from({length: count}, (_, i) => ({ id: `S${String(i + 1).padStart(2, '0')}`, label: `S${String(i + 1).padStart(2, '0')}`, region: { x: (i % cols) / cols, y: Math.floor(i / cols) / rows, width: 1 / cols, height: 1 / rows } }));
}
// Geometry assigns observations to fixed seats; it never tracks or identifies people.
export function assignToSeats(seats, faces, objects) {
  const assigned = new Map(seats.map(seat => [seat.id, { faces: [], objects: [] }]));
  const unassignedFaces = [], unassignedObjects = [];
  const place = (items, key, unmatched) => items.forEach(item => {
    const rect = item.box;
    const matches = seats.filter(seat => contains(seat.region, rect.x + rect.width / 2, rect.y + rect.height / 2));
    if (matches.length === 1) assigned.get(matches[0].id)[key].push(item);
    else unmatched.push(item); // Overlap is ambiguous; no seat is accused.
  });
  place(faces, 'faces', unassignedFaces); place(objects, 'objects', unassignedObjects);
  return { assigned, unassignedFaces, unassignedObjects };
}
export class ProctorSession {
  constructor(seats, startedAt, baselines, thresholds = {}) {
    this.seats = seats;
    this.startedAt = startedAt;
    this.thresholds = {...DEFAULT_THRESHOLDS, ...thresholds};
    this.states = new Map(seats.map(seat => [seat.id, { baseline: baselines.get(seat.id), timers: {}, active: new Map(), lastFrame: null }]));
    this.events = [];
  }
  update(faces, objects, now, wallTime, objectsAvailable = true) {
    const {assigned, unassignedFaces, unassignedObjects} = assignToSeats(this.seats, faces, objects);
    const readings = this.seats.map(seat => {
      const state = this.states.get(seat.id), observations = assigned.get(seat.id);
      const count = observations.faces.length;
      const face = count === 1 ? observations.faces[0] : null;
      // Never let gaps in inference count as continuously observed gaze/mouth/object activity.
      if (state.lastFrame !== null && now - state.lastFrame > 1500) state.timers = {};
      state.lastFrame = now;
      const pitch = face?.pose && state.baseline ? angleDifference(face.pose.pitch, state.baseline.pitch) : null;
      const yaw = face?.pose && state.baseline ? angleDifference(face.pose.yaw, state.baseline.yaw) : null;
      const mar = face?.mar ?? null;
      const t = this.thresholds;
      const hold = (key, condition, duration) => {
        if (!condition) { delete state.timers[key]; return false; }
        state.timers[key] ??= now;
        return now - state.timers[key] >= duration;
      };
      const hasObjects = objectsAvailable && observations.objects.length > 0;
      const flags = {
        away: hold('away', yaw !== null && Math.abs(yaw) > t.yaw, t.awayMs),
        mouth: hold('mouth', Number.isFinite(mar) && mar > t.mar, t.mouthMs),
        absent: hold('absent', count === 0, t.absentMs),
        multiple: hold('multiple', count > 1, 1000),
        object: hold('object', hasObjects, t.objectMs),
        combined: hold('combined', hasObjects && pitch !== null && pitch < t.pitch, t.objectMs),
      };
      const activeRules = Object.keys(flags).filter(key => flags[key]);
      const risk = aggregateRisk(activeRules);
      for (const key of activeRules) {
        if (!state.active.has(key)) {
          const event = { id: this.events.length + 1, seatId: seat.id, candidate: seat.label, rule: key, ...RULES[key], ruleWeight: RULES[key].risk, risk, severity: riskPriority(risk), time: wallTime, startMs: now, lastMs: now, resolved: null, review: 'pending', yaw, pitch, mar, objects: observations.objects.map(o => o.label).join('; ') };
          this.events.push(event); state.active.set(key, event);
        } else { const event = state.active.get(key); event.lastMs = now; event.risk = Math.max(event.risk, risk); event.severity = riskPriority(event.risk); }
      }
      for (const [key, event] of state.active) if (!flags[key]) { event.resolved = wallTime; event.lastMs = now; state.active.delete(key); }
      return {seat, count, face, pitch, yaw, mar, risk, activeRules, objects: observations.objects};
    });
    return { readings, unassignedFaces, unassignedObjects };
  }
  finish(now, wallTime) {
    for (const state of this.states.values()) {
      for (const event of state.active.values()) { event.resolved = wallTime; event.lastMs = Math.max(event.lastMs, now); }
      state.active.clear();
    }
  }
}
export function csvCell(value) {
  let text = String(value ?? '');
  if (/^[\s]*[=+@-]/.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}
export function eventsCsv(events) {
  const reviewLabels = {pending: 'Chưa xem', dismissed: 'Đã xem: không cần xử lý', followup: 'Đã xem: cần trao đổi'};
  const rows = [['ID', 'Chỗ ngồi', 'Mã thí sinh (gán thủ công)', 'Bắt đầu UTC', 'Kết thúc UTC', 'Thời lượng giây', 'Quan sát', 'Mức ưu tiên', 'Chỉ số tổng cao nhất trong sự kiện (không phải xác suất)', 'Yaw', 'Pitch', 'MAR', 'Vật thể', 'Giám thị xem lại'], ...events.map(e => [e.id, e.seatId, e.candidate, e.time, e.resolved ?? '', ((e.lastMs - e.startMs) / 1000).toFixed(1), e.label, e.severity, e.risk, e.yaw?.toFixed(1), e.pitch?.toFixed(1), e.mar?.toFixed(3), e.objects, reviewLabels[e.review]])];
  return '\uFEFF' + rows.map(row => row.map(csvCell).join(',')).join('\r\n');
}
