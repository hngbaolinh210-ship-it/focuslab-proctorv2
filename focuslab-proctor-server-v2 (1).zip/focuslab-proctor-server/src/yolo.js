export const OBJECT_LABELS = { 67: 'Điện thoại', 73: 'Sách' };
export function iou(a, b) {
  const w = Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x));
  const h = Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
  const intersection = w * h;
  const union = a.width * a.height + b.width * b.height - intersection;
  return union > 0 ? intersection / union : 0;
}
export function letterbox(width, height, size = 640) {
  const scale = Math.min(size / width, size / height);
  const resizedWidth = Math.round(width * scale), resizedHeight = Math.round(height * scale);
  return { scale, padX: Math.floor((size - resizedWidth) / 2), padY: Math.floor((size - resizedHeight) / 2), resizedWidth, resizedHeight, size, width, height };
}
export function decodeYolo(data, dims, geometry, threshold = .45, allowBooks = false) {
  if (dims.length !== 3 || dims[0] !== 1 || dims[1] !== 84) throw new Error('YOLO_SHAPE');
  const count = dims[2], candidates = [];
  const {size, padX, padY, resizedWidth, resizedHeight, width, height} = geometry;
  for (let i = 0; i < count; i++) {
    // Only the strongest class wins: don't relabel a different object as a phone/book.
    let classId = -1, score = 0;
    for (let c = 0; c < 80; c++) if (data[(4 + c) * count + i] > score) { classId = c; score = data[(4 + c) * count + i]; }
    if (!OBJECT_LABELS[classId] || score < threshold || (allowBooks && classId === 73)) continue;
    const cx = data[i], cy = data[count + i], w = data[2 * count + i], h = data[3 * count + i];
    const x = Math.max(0, Math.min(1, (cx - w / 2 - padX) / resizedWidth));
    const y = Math.max(0, Math.min(1, (cy - h / 2 - padY) / resizedHeight));
    const right = Math.max(0, Math.min(1, (cx + w / 2 - padX) / resizedWidth));
    const bottom = Math.max(0, Math.min(1, (cy + h / 2 - padY) / resizedHeight));
    if (right <= x || bottom <= y) continue;
    candidates.push({classId, score, label: OBJECT_LABELS[classId], box: {x, y, width: right - x, height: bottom - y}});
  }
  candidates.sort((a,b) => b.score - a.score);
  const selected = [];
  for (const candidate of candidates) if (!selected.some(item => item.classId === candidate.classId && iou(item.box, candidate.box) > .45)) selected.push(candidate);
  return selected.slice(0,100);
}
export class YoloDetector {
  async load() {
    this.ort = await import('onnxruntime-web/wasm');
    this.ort.env.wasm.wasmPaths = {wasm: new URL('/ort/ort-wasm-simd-threaded.wasm', location.href).href};
    this.ort.env.wasm.numThreads = 1;
    this.ort.env.wasm.proxy = false;
    this.session = await this.ort.InferenceSession.create('/models/yolov8n.onnx', {executionProviders: ['wasm']});
    this.canvas = document.createElement('canvas'); this.canvas.width = this.canvas.height = 640;
    this.context = this.canvas.getContext('2d', {willReadFrequently:true});
  }
  async detect(source, threshold, allowBooks) {
    const width = source.videoWidth || source.naturalWidth || source.width;
    const height = source.videoHeight || source.naturalHeight || source.height;
    if (!width || !height) return [];
    const geometry = letterbox(width,height);
    this.context.fillStyle = 'rgb(114,114,114)'; this.context.fillRect(0,0,640,640);
    this.context.drawImage(source,geometry.padX,geometry.padY,geometry.resizedWidth,geometry.resizedHeight);
    const pixels = this.context.getImageData(0,0,640,640).data;
    const plane = 640 * 640, data = new Float32Array(plane * 3);
    for (let i=0;i<plane;i++) { data[i] = pixels[i*4]/255; data[plane+i]=pixels[i*4+1]/255; data[plane*2+i]=pixels[i*4+2]/255; }
    const tensor = new this.ort.Tensor('float32',data,[1,3,640,640]);
    let output;
    try {
      output = await this.session.run({[this.session.inputNames[0]]:tensor});
      const detections = output[this.session.outputNames[0]];
      return decodeYolo(detections.data,detections.dims,geometry,threshold,allowBooks);
    } finally { tensor.dispose(); if (output) Object.values(output).forEach(value => value.dispose()); }
  }
  async close() { await this.session?.release(); this.session = null; }
}
