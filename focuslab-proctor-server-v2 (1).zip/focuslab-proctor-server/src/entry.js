if (location.pathname === '/monitor') await import('./main.js');
else await import('./portal.js');
