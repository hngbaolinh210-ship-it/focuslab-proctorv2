export const LEFT_EYE = [362, 385, 387, 263, 373, 380];
export const RIGHT_EYE = [33, 160, 158, 133, 153, 144];
export function ear(landmarks, indices, width, height) {
  const points = indices.map(i => [landmarks[i].x * width, landmarks[i].y * height]);
  const distance = (a, b) => Math.hypot(points[a][0] - points[b][0], points[a][1] - points[b][1]);
  const horizontal = distance(0, 3);
  return horizontal > 0 ? (distance(1, 5) + distance(2, 4)) / (2 * horizontal) : null;
}
export function pose(matrix) {
  if (!matrix || matrix.length !== 16 || !matrix.every(Number.isFinite)) return null;
  const degrees = 180 / Math.PI;
  return { pitch: Math.atan2(matrix[6], matrix[10]) * degrees, yaw: Math.atan2(-matrix[2], Math.hypot(matrix[0], matrix[1])) * degrees };
}
export const angleDifference = (angle, baseline) => ((angle - baseline + 540) % 360) - 180;
export function classify(eye, pitch, yaw, threshold, yawThreshold, closedMs) {
  if (![eye, pitch, yaw].every(Number.isFinite)) return { score: null, label: 'Chưa đủ dữ liệu', kind: 'idle' };
  if (eye < threshold && closedMs >= 800) return { score: 10, label: 'Mắt nhắm kéo dài', kind: 'warning' };
  if (Math.abs(yaw) > yawThreshold || Math.abs(pitch) > 20) return { score: 40, label: 'Đang nhìn lệch hướng', kind: 'warning' };
  return { score: 100, label: 'Đang hướng về màn hình', kind: 'good' };
}
