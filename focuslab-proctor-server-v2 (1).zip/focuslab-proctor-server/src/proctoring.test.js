import test from 'node:test';
import assert from 'node:assert/strict';
import { makeSeats, assignToSeats, ProctorSession, mouthAspectRatio, eventsCsv, csvCell, aggregateRisk, riskPriority } from './proctoring.js';
const face=(x=.5,{yaw=0,pitch=0,mar=.1}={})=>({box:{x:x-.04,y:.25,width:.08,height:.1},pose:{yaw,pitch},mar});
const object=(x=.5)=>({box:{x:x-.03,y:.6,width:.06,height:.1},label:'Điện thoại',score:.9});
const time=ms=>new Date(1700000000000+ms).toISOString();
function create(count=1) {const seats=makeSeats(count);return new ProctorSession(seats,0,new Map(seats.map(s=>[s.id,{yaw:0,pitch:0}])));}
function tick(session,until,faces,objects=[],available=true,from=0) {let result;for(let now=from;now<=until;now+=200)result=session.update(faces,objects,now,time(now),available);return result;}
test('fixed seats keep observations assigned regardless of face array order',()=>{
 const seats=makeSeats(2),a=face(.25),b=face(.75);
 assert.equal(assignToSeats(seats,[a,b],[]).assigned.get('S01').faces[0],a);
 assert.equal(assignToSeats(seats,[b,a],[]).assigned.get('S01').faces[0],a);
});
test('objects associate only with their seat; overlapping regions are unassigned',()=>{
 const seats=makeSeats(2),item=object(.75);
 assert.equal(assignToSeats(seats,[],[item]).assigned.get('S01').objects.length,0);
 assert.equal(assignToSeats(seats,[],[item]).assigned.get('S02').objects.length,1);
 seats[1].region={...seats[0].region};
 const result=assignToSeats(seats,[face(.25)],[object(.25)]);
 assert.equal(result.unassignedFaces.length,1);assert.equal(result.unassignedObjects.length,1);
});
test('yaw requires three continuous seconds; normal gaze resets the timer',()=>{
 const session=create();assert.equal(tick(session,2800,[face(.5,{yaw:26})]).readings[0].risk,0);
 assert.equal(session.update([face(.5,{yaw:26})],[],3000,time(3000)).readings[0].risk,40);
 assert.equal(session.events.length,1);
 tick(session,3800,[face(.5,{yaw:26})],[],true,3200);assert.equal(session.events.length,1);
 session.update([face()],[],4000,time(4000));assert.equal(session.events[0].resolved,time(4000));
 tick(session,7000,[face(.5,{yaw:26})],[],true,4200);assert.equal(session.events.length,1);
 session.update([face(.5,{yaw:26})],[],7200,time(7200));assert.equal(session.events.length,2);
});
test('mouth requires two seconds and missing landmarks clear its timer',()=>{
 const session=create();assert.equal(tick(session,1800,[face(.5,{mar:.6})]).readings[0].risk,0);
 assert.equal(session.update([face(.5,{mar:.6})],[],2000,time(2000)).readings[0].risk,30);
 session.update([face(.5,{mar:null})],[],2200,time(2200));assert.ok(session.events[0].resolved);
});
test('absence waits five seconds, is per seat, and ends on return',()=>{
 const session=create(2);const present=[face(.75)];
 assert.equal(tick(session,4800,present).readings[0].risk,0);
 const result=session.update(present,[],5000,time(5000));assert.equal(result.readings[0].risk,50);assert.equal(result.readings[1].risk,0);
 session.update([face(.25),face(.75)],[],5200,time(5200));assert.equal(session.events[0].resolved,time(5200));
});
test('downward pitch and object must be in the same seat for high priority',()=>{
 const session=create(2);
 const first=tick(session,2000,[face(.25,{pitch:-25}),face(.75)],[object(.75)]);
 assert.equal(first.readings[0].risk,0);assert.equal(first.readings[1].risk,60);
 const second=tick(session,4000,[face(.25,{pitch:-25}),face(.75)],[object(.25)],true,2200);
 assert.equal(second.readings[0].risk,85);assert.equal(second.readings[1].risk,0);
});
test('expired/failed detector results cannot sustain object alerts',()=>{
 const session=create();tick(session,2000,[face(.5,{pitch:-25})],[object()]);
 const result=session.update([face(.5,{pitch:-25})],[object()],2200,time(2200),false);
 assert.equal(result.readings[0].risk,0);assert.ok(session.events.every(e=>e.resolved));
});
test('inference gaps do not count as continuous behavior',()=>{
 const session=create();tick(session,2000,[face(.5,{yaw:40})]);
 const result=session.update([face(.5,{yaw:40})],[],6000,time(6000));assert.equal(result.readings[0].risk,0);
});
test('ambiguous multiple faces suppress person-specific mouth/gaze attribution',()=>{
 const session=create();const faces=[face(.45,{yaw:40,mar:.6}),face(.55,{yaw:40,mar:.6})];
 const result=tick(session,4000,faces);assert.deepEqual(result.readings[0].activeRules,['multiple']);
});
test('calibration cancels resting head angles; finish resolves all active events',()=>{
 const session=create();session.states.get('S01').baseline={yaw:30,pitch:-30};
 assert.equal(tick(session,4000,[face(.5,{yaw:30,pitch:-30})]).readings[0].risk,0);
 tick(session,8000,[face(.5,{yaw:70,pitch:-30})],[],true,4200);
 session.finish(8200,time(8200));assert.ok(session.events[0].resolved);assert.equal(session.states.get('S01').active.size,0);
});
test('MAR is computed in pixels; degenerate mouth returns null',()=>{
 const points=Array.from({length:478},()=>({x:.5,y:.5}));
 points[78]={x:.3,y:.5};points[308]={x:.7,y:.5};points[13]={x:.5,y:.4};points[14]={x:.5,y:.6};
 assert.ok(Math.abs(mouthAspectRatio(points,200,100)-.25)<1e-9);
 points[308]=points[78];assert.equal(mouthAspectRatio(points,200,100),null);
});
test('CSV preserves quotes/newlines, neutralizes formula-like candidate IDs, includes reviews',()=>{
 assert.equal(csvCell('=SUM(1,2)'), '"\'=SUM(1,2)"');
 assert.equal(csvCell(' A"B\nC'),'" A""B\nC"');
 const session=create();session.seats[0].label='@evil';tick(session,4000,[face(.5,{yaw:40})]);session.events[0].review='dismissed';
 const csv=eventsCsv(session.events);assert.ok(csv.startsWith('\uFEFF'));assert.ok(csv.includes("'@evil"));assert.ok(csv.includes('Đã xem: không cần xử lý'));
});
test('seat count clamps to supported bounds',()=>{assert.equal(makeSeats(150).length,100);assert.equal(makeSeats(0).length,1);});

test('additive scoring follows user weights, is capped at 100 and has exact priority boundaries',()=>{
 assert.equal(aggregateRisk(['away']),40);
 assert.equal(aggregateRisk(['object']),60);
 assert.equal(aggregateRisk(['mouth']),30);
 assert.equal(aggregateRisk(['away','mouth']),70);
 assert.equal(aggregateRisk(['object','mouth']),90);
 assert.equal(aggregateRisk(['away','object','mouth']),100);
 assert.equal(aggregateRisk(['object','combined']),85);
 assert.equal(aggregateRisk(['object','object']),60);
 assert.equal(riskPriority(39),'low');assert.equal(riskPriority(40),'medium');
 assert.equal(riskPriority(69),'medium');assert.equal(riskPriority(70),'high');
});
test('MAR default uses strict greater-than 0.5 and event CSV keeps aggregate peak',()=>{
 const session=create();assert.equal(tick(session,3000,[face(.5,{mar:.5})]).readings[0].risk,0);
 const result=tick(session,7000,[face(.5,{yaw:30,mar:.6})],[object()],true,3200);
 assert.equal(result.readings[0].risk,100);assert.ok(session.events.every(e=>e.risk===100));
 assert.ok(session.events.every(e=>e.severity==='high'));
});

test('ending after backward video seek cannot make event duration negative',()=>{
 const session=create();tick(session,5000,[face(.5,{yaw:40})]);
 const last=session.events[0].lastMs;session.finish(1000,time(6000));
 assert.equal(session.events[0].lastMs,last);assert.ok(session.events[0].lastMs>=session.events[0].startMs);
});
