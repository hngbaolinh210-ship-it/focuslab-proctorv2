import {api,post} from './api.js';
export async function connectMonitor(roomId,status) {
  let me;try{me=await api('/api/me');}catch(error){if(roomId)throw new Error('Hãy đăng nhập trên trang quản lý hoặc tham gia phòng trước khi mở phân tích.');status('Chế độ tại thiết bị · chưa gửi về phòng thi');return null;}
  roomId=me.role==='student'?me.roomId:roomId;
  if(!roomId){status('Chưa chọn phòng · mở trang quản lý để kết nối máy chủ');return null;}
  const details=await api(`/api/rooms/${roomId}`);if(details.room.closed)throw new Error('Phòng đã đóng.');
  const key=`focuslab-outbox-${roomId}-${me.student?.id||'admin'}:`;
  let queued=new Map();try{for(let i=0;i<localStorage.length;i++){const name=localStorage.key(i);if(name.startsWith(key)){const item=JSON.parse(localStorage.getItem(name));queued.set(item.clientId,item);}}}catch{}
  const known=new Map();let busy=false,stopped=false;
  function save(item){try{localStorage.setItem(key+item.clientId,JSON.stringify(item));}catch{status('Không lưu được bộ đệm. Giữ trang mở để gửi sự kiện.');}}
  async function flush(){if(busy||!queued.size||stopped)return;busy=true;const batch=[...queued.values()].slice(0,100);try{await post(`/api/rooms/${roomId}/events`,{events:batch});for(const e of batch){if(queued.get(e.clientId)===e)queued.delete(e.clientId);try{if(localStorage.getItem(key+e.clientId)===JSON.stringify(e))localStorage.removeItem(key+e.clientId);}catch{}}status(`Đã kết nối phòng ${details.room.code} · ${queued.size} sự kiện chờ gửi`);}catch(error){status(`Chưa gửi được: ${error.message} · ${queued.size} sự kiện đang chờ`);if(error.status===401||error.status===403||error.status===409)stopped=true;}finally{busy=false;}}
  const timer=setInterval(()=>{flush();post('/api/heartbeat',{}).catch(()=>{});},4000);
  status(`Đã kết nối phòng ${details.room.code} · cảnh báo gửi về máy chủ`);flush();
  return {me,room:details.room,roster:me.role==='admin'?details.students:[me.student],
    push(events,offset=null){for(const e of events){e.syncId??=crypto.randomUUID();if(!Object.hasOwn(e,'offset'))e.offset=offset;const value={clientId:e.syncId,seatId:e.seatId,rule:e.rule,risk:e.risk,time:e.time,resolved:e.resolved,duration:Number(((e.lastMs-e.startMs)/1000).toFixed(1)),offset:e.offset??null};const serialized=JSON.stringify(value);if(known.get(e.syncId)===serialized)continue;if(queued.size>=5000&&!queued.has(e.syncId)){status('Bộ đệm đầy. Giữ trang mở và xuất nhật ký CSV để lưu các sự kiện chưa gửi.');continue;}queued.set(e.syncId,value);known.set(e.syncId,serialized);save(value);}},
    flush,
    close(){clearInterval(timer);flush();},
    get pending(){return queued.size;}
  };
}
