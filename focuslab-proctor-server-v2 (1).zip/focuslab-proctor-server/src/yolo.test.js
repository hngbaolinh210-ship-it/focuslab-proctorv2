import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeYolo, letterbox, iou } from './yolo.js';
function output(boxes) {
 const n=boxes.length,data=new Float32Array(84*n);
 boxes.forEach((b,i)=>{[b.x??320,b.y??320,b.w??100,b.h??100].forEach((v,row)=>data[row*n+i]=v);data[(4+(b.classId??67))*n+i]=b.score??.9; if(b.other!==undefined)data[(4+b.other)*n+i]=.99;});
 return {data,dims:[1,84,n]};
}
test('YOLO recognizes only phone/book, with confidence and book permission filtering',()=>{
 const {data,dims}=output([{classId:67},{classId:73,x:500},{classId:0},{classId:67,score:.2}]);
 const geometry=letterbox(640,640);
 assert.deepEqual(decodeYolo(data,dims,geometry).map(x=>x.classId),[67,73]);
 assert.deepEqual(decodeYolo(data,dims,geometry,.45,true).map(x=>x.classId),[67]);
});
test('stronger unrelated class cannot be relabeled as phone',()=>{
 const {data,dims}=output([{classId:67,score:.8,other:0}]);assert.equal(decodeYolo(data,dims,letterbox(640,640)).length,0);
});
test('letterbox converts boxes back to source-relative coordinates',()=>{
 const g=letterbox(1280,720);assert.equal(g.padY,140);assert.equal(g.resizedHeight,360);
 const {data,dims}=output([{x:320,y:320,w:320,h:180}]);const box=decodeYolo(data,dims,g)[0].box;
 assert.deepEqual(box,{x:.25,y:.25,width:.5,height:.5});
});
test('NMS removes overlapping duplicates within a class but keeps distinct classes',()=>{
 const {data,dims}=output([{score:.8},{score:.9,x:321},{score:.7,classId:73}]);
 const items=decodeYolo(data,dims,letterbox(640,640));assert.equal(items.length,2);assert.equal(items[0].classId,67);
 assert.equal(iou({x:0,y:0,width:1,height:1},{x:0,y:0,width:1,height:1}),1);
});
test('unexpected output layout fails instead of fabricating detections',()=>{assert.throws(()=>decodeYolo(new Float32Array(8),[1,1,8],letterbox(640,640)),/YOLO_SHAPE/);});
