import {readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
try {
  const hash=createHash('sha256').update(readFileSync('package-lock.json')).digest('hex');
  const marker=readFileSync('node_modules/.focuslab-lock-hash','utf8');
  if(hash!==marker||!existsSync('public/wasm/vision_wasm_internal.wasm')||!existsSync('public/ort/ort-wasm-simd-threaded.wasm'))process.exit(1);
  for(const dependency of ['express','multer','ffmpeg-static','ffprobe-static','@mediapipe/tasks-vision'])await import(dependency);
}catch{process.exit(1);}
