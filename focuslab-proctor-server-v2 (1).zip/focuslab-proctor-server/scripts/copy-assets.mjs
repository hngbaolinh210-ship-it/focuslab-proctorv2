import { mkdir, cp, copyFile, readFile, writeFile } from 'node:fs/promises';
await mkdir('public/wasm',{recursive:true});
await cp('node_modules/@mediapipe/tasks-vision/wasm','public/wasm',{recursive:true});
await mkdir('public/ort',{recursive:true});
for(const file of ['ort-wasm-simd-threaded.mjs','ort-wasm-simd-threaded.wasm']) {
  await copyFile(`node_modules/onnxruntime-web/dist/${file}`,`public/ort/${file}`);
}
console.log('MediaPipe and ONNX runtime assets prepared.');

const {createHash}=await import('node:crypto');
await writeFile('node_modules/.focuslab-lock-hash',createHash('sha256').update(await readFile('package-lock.json')).digest('hex'));
