@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto folder_error
for %%F in ("package.json" "package-lock.json" "scripts\copy-assets.mjs" "server\index.mjs" "server\setup.mjs" "public\models\face_landmarker.task" "public\models\yolov8n.onnx") do (
  if not exist "%%~F" (
    echo Thieu file: %%~F
    goto missing_files
  )
)
where node >nul 2>nul
if errorlevel 1 goto node_missing
where npm.cmd >nul 2>nul
if errorlevel 1 goto node_missing
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 goto node_missing
node scripts\check-install.mjs
if errorlevel 1 (
  echo Dang cai thu vien. Hay giu cua so nay mo...
  call npm.cmd ci
  if errorlevel 1 goto install_failed
)
call npm.cmd run setup
if errorlevel 1 goto install_failed
echo Dang mo FocusLab Proctor. Giu cua so nay mo khi su dung.
call npm.cmd run dev -- --open
pause
exit /b 0

:missing_files
echo.
echo Chua co du file de chay FocusLab.
echo Khong mo start-windows truc tiep ben trong file ZIP.
echo Hay bam chuot phai vao ZIP, chon Extract All / Giai nen tat ca.
echo Sau do mo thu muc da giai nen va chay start-windows.cmd.
echo Thu muc hien tai: "%CD%"
pause
exit /b 1

:install_failed
echo.
echo Cai dat chua thanh cong. Keo len xem dong npm error dau tien.
echo Neu npm bao thieu package-lock.json, giai nen lai toan bo ZIP.
echo Gui anh phan dau loi npm error de duoc ho tro.
pause
exit /b 1

:node_missing
echo Hay cai Node.js 24 LTS tu https://nodejs.org roi mo lai file nay.
pause
exit /b 1

:folder_error
echo Khong mo duoc thu muc du an. Hay giai nen vao Downloads roi thu lai.
pause
exit /b 1
