import express from 'express';
import multer from 'multer';
import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { mkdirSync, rmSync, statSync, readdirSync, readFileSync, existsSync, openSync, readSync, closeSync } from 'node:fs';
import path from 'node:path';
import { initializeAdmin, passwordMatches, token, digest } from './auth.mjs';
import { probeVideo, transcodeVideo, validateCameraUrl, createRelay } from './media.mjs';
import { RULES } from '../src/proctoring.js';
export function createApp({dataDir,adminPassword,secureCookies=false,trustProxy=false,cameraHosts=[],maxUploadBytes=500*1024*1024,maxStorageBytes=5*1024**3,mediaTools={probeVideo,transcodeVideo}}) {
  mkdirSync(dataDir,{recursive:true,mode:0o700});const adminHash=initializeAdmin(dataDir,adminPassword);
  const mediaDir=path.join(dataDir,'videos'),tmpDir=path.join(dataDir,'incoming'),relayDir=path.join(dataDir,'relays');
  for(const dir of [mediaDir,tmpDir,relayDir])mkdirSync(dir,{recursive:true});
  const db=new DatabaseSync(path.join(dataDir,'focuslab.sqlite'));
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
  CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY,code TEXT UNIQUE,title TEXT NOT NULL,created_at INTEGER,closed INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS students(id TEXT PRIMARY KEY,room_id TEXT REFERENCES rooms(id),student_code TEXT,name TEXT,seat_id TEXT,join_hash TEXT UNIQUE,last_seen INTEGER DEFAULT 0,UNIQUE(room_id,student_code),UNIQUE(room_id,seat_id));
  CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,role TEXT,student_id TEXT,room_id TEXT,expires INTEGER);
  CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,room_id TEXT REFERENCES rooms(id),source TEXT,client_id TEXT,student_id TEXT,seat_id TEXT,rule TEXT,risk INTEGER,payload TEXT,review TEXT DEFAULT 'pending',received_at INTEGER,UNIQUE(room_id,source,client_id));
  CREATE INDEX IF NOT EXISTS events_room ON events(room_id,id);
  CREATE TABLE IF NOT EXISTS videos(id TEXT PRIMARY KEY,room_id TEXT REFERENCES rooms(id),owner TEXT,name TEXT,status TEXT,file TEXT,size INTEGER,duration REAL,error TEXT,created_at INTEGER);`);
  db.prepare("UPDATE videos SET status='failed',error='Máy chủ đã khởi động lại trong lúc xử lý.' WHERE status='processing'").run();
  for(const file of readdirSync(tmpDir))rmSync(path.join(tmpDir,file),{force:true});
  const app=express();if(trustProxy)app.set('trust proxy',1);app.disable('x-powered-by');
  app.use(express.json({limit:'256kb'}));
  app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','SAMEORIGIN');if(req.path.startsWith('/api/'))res.setHeader('Cache-Control','no-store');next();});
  app.use('/api',(req,res,next)=>{if(!['GET','HEAD','OPTIONS'].includes(req.method)){const origin=req.headers.origin;if(req.headers['sec-fetch-site']==='cross-site')return res.status(403).json({error:'Nguồn yêu cầu không được phép.'});if(origin){try{if(new URL(origin).host!==req.get('host'))return res.status(403).json({error:'Nguồn yêu cầu không được phép.'});}catch{return res.status(403).json({error:'Nguồn không hợp lệ.'});}}}next();});
  const limits=new Map();const clients=new Map(),relays=new Map(),jobs=new Set();let activeUploads=0;
  const cleanup=setInterval(()=>{const now=Date.now();for(const [key,value]of limits)if(now>value.until)limits.delete(key);db.prepare('DELETE FROM sessions WHERE expires < ?').run(now);},60000);cleanup.unref();
  const notify=room=>{for(const response of clients.get(room)??[])if(!response.writableEnded)response.write('event: change\ndata: {}\n\n');};
  const fail=(res,status,error)=>res.status(status).json({error});
  function rate(scope,max){return(req,res,next)=>{const key=scope+req.ip;let record=limits.get(key);if(!record||record.until<Date.now()){if(limits.size>10000)return fail(res,429,'Máy chủ đang bận.');record={count:0,until:Date.now()+600000};limits.set(key,record);}if(++record.count>max)return fail(res,429,'Quá nhiều lần thử. Thử lại sau 10 phút.');next();};}
  function auth(req,res,next){const cookie=req.headers.cookie?.split(';').map(v=>v.trim()).find(v=>v.startsWith('focuslab_session='))?.slice(17);const session=cookie&&db.prepare('SELECT * FROM sessions WHERE hash=? AND expires>?').get(digest(cookie),Date.now());if(!session)return fail(res,401,'Hãy đăng nhập hoặc nhập mã tham gia.');req.identity=session;next();}
  function admin(req,res,next){if(req.identity.role!=='admin')return fail(res,403,'Chỉ giám thị được thực hiện thao tác này.');next();}
  const accessRoom=(req,res,next)=>{const room=db.prepare('SELECT * FROM rooms WHERE id=?').get(req.params.roomId);if(!room)return fail(res,404,'Không tìm thấy phòng.');if(req.identity.role!=='admin'&&req.identity.room_id!==room.id)return fail(res,403,'Không có quyền truy cập phòng.');req.room=room;next();};
  const roomOpen=(req,res,next)=>req.room.closed?fail(res,409,'Phòng đã đóng.'):next();
  function login(res,role,studentId=null,roomId=null){const value=token();db.prepare('INSERT INTO sessions VALUES(?,?,?,?,?)').run(digest(value),role,studentId,roomId,Date.now()+24*3600000);res.cookie('focuslab_session',value,{httpOnly:true,secure:secureCookies,sameSite:'strict',maxAge:24*3600000,path:'/'});}
  const currentStudent=req=>req.identity.student_id?db.prepare('SELECT id,student_code,name,seat_id,room_id FROM students WHERE id=?').get(req.identity.student_id):null;
  app.get('/api/health',(_req,res)=>res.json({ok:true,maxStudents:100}));
  app.post('/api/login',rate('login',25),(req,res)=>{const password=req.body?.password;if(typeof password!=='string'||password.length>200||!passwordMatches(password,adminHash))return fail(res,401,'Mật khẩu giám thị không đúng.');login(res,'admin');res.json({role:'admin'});});
  app.post('/api/join',rate('join',1000),(req,res)=>{const {roomCode,accessCode}=req.body??{};if(typeof roomCode!=='string'||typeof accessCode!=='string'||accessCode.length>100)return fail(res,400,'Nhập mã phòng và mã tham gia.');const student=db.prepare('SELECT s.* FROM students s JOIN rooms r ON r.id=s.room_id WHERE r.code=? AND s.join_hash=? AND r.closed=0').get(roomCode.trim().toUpperCase(),digest(accessCode.trim()));if(!student)return fail(res,401,'Mã tham gia không đúng hoặc phòng đã đóng.');login(res,'student',student.id,student.room_id);res.json({roomId:student.room_id,name:student.name});});
  app.post('/api/logout',auth,(req,res)=>{db.prepare('DELETE FROM sessions WHERE hash=?').run(req.identity.hash);res.clearCookie('focuslab_session',{path:'/'});res.json({ok:true});});
  app.get('/api/me',auth,(req,res)=>res.json({role:req.identity.role,student:currentStudent(req),roomId:req.identity.room_id}));
  app.post('/api/heartbeat',auth,(req,res)=>{if(req.identity.student_id)db.prepare('UPDATE students SET last_seen=? WHERE id=?').run(Date.now(),req.identity.student_id);res.json({ok:true});});
  app.get('/api/rooms',auth,admin,(_req,res)=>res.json(db.prepare('SELECT r.*, (SELECT COUNT(*) FROM students s WHERE s.room_id=r.id) student_count FROM rooms r ORDER BY created_at DESC').all()));
  app.post('/api/rooms',auth,admin,(req,res)=>{const title=req.body?.title;if(typeof title!=='string'||!title.trim()||title.length>120)return fail(res,400,'Tên phòng cần từ 1 đến 120 ký tự.');const id=randomUUID(),code=token().replace(/[^a-zA-Z0-9]/g,'').slice(0,8).toUpperCase();db.prepare('INSERT INTO rooms(id,code,title,created_at) VALUES(?,?,?,?)').run(id,code,title.trim(),Date.now());res.status(201).json({id,code,title});});
  app.post('/api/rooms/:roomId/close',auth,admin,accessRoom,(req,res)=>{db.prepare('UPDATE rooms SET closed=1 WHERE id=?').run(req.room.id);for(const [id,r]of relays)if(r.roomId===req.room.id){r.relay.stop();relays.delete(id);}notify(req.room.id);res.json({ok:true});});
  app.post('/api/rooms/:roomId/students',auth,admin,accessRoom,roomOpen,(req,res)=>{
    const students=req.body?.students;if(!Array.isArray(students)||students.length<1||students.length>100)return fail(res,400,'Nhập 1–100 học sinh mỗi lần.');
    const existing=db.prepare('SELECT student_code,seat_id FROM students WHERE room_id=?').all(req.room.id);
    if(existing.length+students.length>100)return fail(res,409,'Mỗi phòng tối đa 100 học sinh.');
    const codes=new Set(existing.map(s=>s.student_code)),seats=new Set(existing.map(s=>s.seat_id));const entries=[];
    for(const [index,s]of students.entries()){
      if(!s||typeof s!=='object')return fail(res,400,'Dòng học sinh không hợp lệ.');
      const code=String(s.student_id??'').trim(),name=String(s.name??'').trim(),seatId=String(s.seat_id||`S${String(existing.length+index+1).padStart(2,'0')}`).trim();
      if(!/^[\w-]{1,40}$/.test(code)||!name||name.length>120||!/^S(?:0[1-9]|[1-9]\d|100)$/.test(seatId)||codes.has(code)||seats.has(seatId))return fail(res,400,'Mã học sinh hoặc chỗ ngồi trùng/không hợp lệ. Chỗ ngồi: S01–S100.');
      codes.add(code);seats.add(seatId);entries.push({id:randomUUID(),student_id:code,name,seat_id:seatId,access_code:token()});
    }
    db.exec('BEGIN');try{for(const s of entries)db.prepare('INSERT INTO students(id,room_id,student_code,name,seat_id,join_hash) VALUES(?,?,?,?,?,?)').run(s.id,req.room.id,s.student_id,s.name,s.seat_id,digest(s.access_code));db.exec('COMMIT');}catch(error){db.exec('ROLLBACK');throw error;}
    notify(req.room.id);res.status(201).json({roomCode:req.room.code,students:entries});
  });
  app.get('/api/rooms/:roomId',auth,accessRoom,(req,res)=>{
    if(req.identity.role!=='admin')return res.json({room:req.room,student:currentStudent(req)});
    const students=db.prepare('SELECT id,student_code,name,seat_id,last_seen FROM students WHERE room_id=? ORDER BY CAST(SUBSTR(seat_id,2) AS INTEGER)').all(req.room.id);
    const events=db.prepare('SELECT e.*,s.name,s.student_code FROM events e LEFT JOIN students s ON s.id=e.student_id WHERE e.room_id=? ORDER BY e.id DESC LIMIT 300').all(req.room.id).map(e=>({...e,payload:JSON.parse(e.payload)}));
    const videos=db.prepare('SELECT id,name,status,size,duration,error,created_at,owner FROM videos WHERE room_id=? ORDER BY created_at DESC').all(req.room.id);
    res.json({room:req.room,students,events,eventCount:db.prepare('SELECT COUNT(*) AS n FROM events WHERE room_id=?').get(req.room.id).n,videos,cameras:[...relays].filter(([,r])=>r.roomId===req.room.id).map(([id,r])=>({id,name:r.name,status:r.status}))});
  });
  app.get('/api/rooms/:roomId/stream',auth,admin,accessRoom,(req,res)=>{
    const room=req.room.id;if((clients.get(room)?.size??0)>=10)return fail(res,429,'Tối đa 10 bảng giám thị cùng phòng.');
    res.setHeader('Content-Type','text/event-stream');res.setHeader('X-Accel-Buffering','no');res.flushHeaders();if(!clients.has(room))clients.set(room,new Set());clients.get(room).add(res);res.write('event: change\ndata: {}\n\n');const heartbeat=setInterval(()=>res.write(': keepalive\n\n'),20000);req.on('close',()=>{clearInterval(heartbeat);clients.get(room)?.delete(res);});
  });
  app.post('/api/rooms/:roomId/events',auth,accessRoom,roomOpen,(req,res)=>{
    const events=req.body?.events;if(!Array.isArray(events)||events.length>100)return fail(res,400,'Tối đa 100 sự kiện mỗi gói.');
    const source=req.identity.role==='admin'?'room-camera':req.identity.student_id;
    for(const e of events)if(!e||typeof e.clientId!=='string'||!/^[\w:-]{1,100}$/.test(e.clientId)||!Object.hasOwn(RULES,e.rule)||!Number.isFinite(e.risk)||e.risk<0||e.risk>100||typeof e.seatId!=='string'||e.seatId.length>40||!Number.isFinite(e.duration)||e.duration<0||e.duration>7200||!Number.isFinite(Date.parse(e.time))|| (e.resolved!==null&&!Number.isFinite(Date.parse(e.resolved))) || (e.offset!==null&&(!Number.isFinite(e.offset)||e.offset<0||e.offset>7200)))return fail(res,400,'Sự kiện không hợp lệ.');
    const incoming=[...new Set(events.map(e=>e.clientId))].filter(id=>!db.prepare('SELECT id FROM events WHERE room_id=? AND source=? AND client_id=?').get(req.room.id,source,id)).length;
    if(db.prepare('SELECT COUNT(*) n FROM events WHERE room_id=?').get(req.room.id).n+incoming>50000)return fail(res,409,'Phòng đạt giới hạn lưu 50.000 sự kiện.');
    db.exec('BEGIN');try{for(const e of events){
      const s=req.identity.role==='admin'?db.prepare('SELECT id,seat_id FROM students WHERE room_id=? AND seat_id=?').get(req.room.id,e.seatId):currentStudent(req);
      const payload={time:e.time,resolved:e.resolved,duration:e.duration,offset:e.offset,rule:e.rule};
      db.prepare(`INSERT INTO events(room_id,source,client_id,student_id,seat_id,rule,risk,payload,received_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(room_id,source,client_id) DO UPDATE SET risk=MAX(events.risk,excluded.risk),payload=CASE WHEN json_extract(excluded.payload,'$.duration') >= json_extract(events.payload,'$.duration') AND (json_extract(events.payload,'$.resolved') IS NULL OR json_extract(excluded.payload,'$.resolved') IS NOT NULL) THEN excluded.payload ELSE events.payload END,received_at=excluded.received_at`).run(req.room.id,source,e.clientId,s?.id??null,s?.seat_id??e.seatId,e.rule,Math.round(e.risk),JSON.stringify(payload),Date.now());
    }db.exec('COMMIT');}catch(error){db.exec('ROLLBACK');throw error;}if(req.identity.student_id)db.prepare('UPDATE students SET last_seen=? WHERE id=?').run(Date.now(),req.identity.student_id);notify(req.room.id);res.json({accepted:events.length});
  });
  app.patch('/api/rooms/:roomId/events/:eventId',auth,admin,accessRoom,(req,res)=>{if(!['pending','dismissed','followup'].includes(req.body?.review))return fail(res,400,'Trạng thái không hợp lệ.');const result=db.prepare('UPDATE events SET review=? WHERE room_id=? AND id=?').run(req.body.review,req.room.id,req.params.eventId);if(!result.changes)return fail(res,404,'Không thấy sự kiện.');notify(req.room.id);res.json({ok:true});});
  const upload=multer({dest:tmpDir,limits:{fileSize:maxUploadBytes,files:1,fields:0}}).single('video');
  app.post('/api/rooms/:roomId/videos',auth,accessRoom,roomOpen,(req,res,next)=>{
    if(activeUploads>=2)return fail(res,429,'Đang xử lý 2 video; hãy thử lại sau.');
    const used=db.prepare("SELECT COALESCE(SUM(size),0) n FROM videos WHERE status!='failed'").get().n;
    if(used>=maxStorageBytes)return fail(res,507,'Dung lượng video đã đầy. Giám thị cần xóa video cũ.');
    activeUploads++;let completed=false;const release=()=>{if(!completed){completed=true;activeUploads--;}};
    req.once('aborted',()=>{release();if(req.file)rmSync(req.file.path,{force:true});});
    upload(req,res,async error=>{
      try {
      if(error){release();return next(error);}
      if(req.aborted){if(req.file)rmSync(req.file.path,{force:true});release();return;}
      if(!req.file){release();return fail(res,400,'Chọn tệp video.');}
      const input=req.file.path;let metadata;
      try{const head=Buffer.alloc(12),fd=openSync(input,'r');try{readSync(fd,head,0,12,0);}finally{closeSync(fd);}if(head.subarray(4,8).toString()!=='ftyp'&&!head.subarray(0,4).equals(Buffer.from([0x1a,0x45,0xdf,0xa3])))throw new Error('FORMAT');metadata=await mediaTools.probeVideo(input);}catch{rmSync(input,{force:true});release();return fail(res,400,'Chỉ nhận MP4/MOV/WebM có video, tối đa 2 giờ, độ phân giải 4K.');}
      const id=randomUUID(),output=path.join(mediaDir,id+'.mp4');
      db.prepare('INSERT INTO videos VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,req.room.id,req.identity.student_id??'admin',String(req.file.originalname).slice(0,160),'processing',id+'.mp4',req.file.size,metadata.duration,null,Date.now());
      const job=mediaTools.transcodeVideo(input,output).then(()=>{
        const size=statSync(output).size+statSync(output.replace(/\.mp4$/,'.webm')).size;const total=db.prepare("SELECT COALESCE(SUM(size),0) n FROM videos WHERE status!='failed' AND id!=?").get(id).n;
        if(total+size>maxStorageBytes)throw new Error('QUOTA');db.prepare("UPDATE videos SET status='ready',size=? WHERE id=?").run(size,id);
      }).catch(()=>{rmSync(output,{force:true});rmSync(output.replace(/\.mp4$/,'.webm'),{force:true});db.prepare("UPDATE videos SET status='failed',error='Không chuyển đổi được video hoặc hết dung lượng.' WHERE id=?").run(id);}).finally(()=>{rmSync(input,{force:true});release();jobs.delete(job);notify(req.room.id);});jobs.add(job);notify(req.room.id);res.status(202).json({id,status:'processing'});
      }catch(error){if(req.file)rmSync(req.file.path,{force:true});release();next(error);}
    });
  });
  function videoAccess(req,res,next){const v=db.prepare('SELECT * FROM videos WHERE id=?').get(req.params.videoId);if(!v)return fail(res,404,'Không thấy video.');if(req.identity.role!=='admin'&&(v.owner!==req.identity.student_id||v.room_id!==req.identity.room_id))return fail(res,403,'Không có quyền xem video.');req.media=v;next();}
  app.get('/api/videos/:videoId',auth,videoAccess,(req,res)=>res.json({id:req.media.id,name:req.media.name,status:req.media.status,duration:req.media.duration,error:req.media.error,roomId:req.media.room_id}));
  app.get('/api/videos/:videoId/content',auth,videoAccess,(req,res)=>{if(req.media.status!=='ready')return fail(res,409,'Video chưa sẵn sàng.');const webm=req.query.format==='webm';res.type(webm?'video/webm':'video/mp4');res.sendFile(path.join(mediaDir,webm?req.media.file.replace(/\.mp4$/,'.webm'):req.media.file));});
  app.delete('/api/videos/:videoId',auth,admin,videoAccess,(req,res)=>{if(req.media.status==='processing')return fail(res,409,'Video đang xử lý.');rmSync(path.join(mediaDir,req.media.file),{force:true});rmSync(path.join(mediaDir,req.media.file.replace(/\.mp4$/,'.webm')),{force:true});db.prepare('DELETE FROM videos WHERE id=?').run(req.media.id);notify(req.media.room_id);res.json({ok:true});});
  app.post('/api/rooms/:roomId/cameras',auth,admin,accessRoom,roomOpen,(req,res)=>{
    if(relays.size>=4)return fail(res,409,'Tối đa 4 luồng IP hoạt động trên máy chủ này.');let url;try{url=validateCameraUrl(req.body?.url,cameraHosts);}catch(error){return fail(res,400,error.message);}
    const id=randomUUID();const record={roomId:req.room.id,name:String(req.body?.name||'Camera IP').slice(0,100),status:'starting'};
    record.relay=createRelay({id,url,root:relayDir,onExit:()=>{record.status='failed';notify(record.roomId);}});relays.set(id,record);notify(req.room.id);res.status(201).json({id});
  });
  app.get('/api/cameras/:cameraId/:file',auth,admin,(req,res)=>{const r=relays.get(req.params.cameraId);if(!r)return fail(res,404,'Camera không hoạt động.');if(!/^(index\.m3u8|segment-\d+\.ts)$/.test(req.params.file))return fail(res,404,'Không thấy tệp.');const file=path.join(r.relay.directory,req.params.file);if(!existsSync(file))return fail(res,503,'Camera chưa có hình ảnh.');r.status='ready';res.type(req.params.file.endsWith('.m3u8')?'application/vnd.apple.mpegurl':'video/mp2t');res.sendFile(file);});
  app.delete('/api/cameras/:cameraId',auth,admin,(req,res)=>{const r=relays.get(req.params.cameraId);if(r){r.relay.stop();r.relay.cleanup();relays.delete(req.params.cameraId);notify(r.roomId);}res.json({ok:true});});
  app.use('/api',(_req,res)=>fail(res,404,'Không có API này.'));
  app.use((error,_req,res,_next)=>{if(error instanceof multer.MulterError)return fail(res,413,'Tệp quá lớn hoặc gói tải lên không hợp lệ.');if(error.type==='entity.parse.failed')return fail(res,400,'JSON không hợp lệ.');if(error.type==='entity.too.large')return fail(res,413,'Dữ liệu quá lớn.');console.error('Request failed:',error.code||error.name);fail(res,500,'Không thể xử lý yêu cầu.');});
  return {app,db,jobs,async close(){clearInterval(cleanup);for(const group of clients.values())for(const res of group)res.end();for(const r of relays.values())r.relay.stop();await Promise.allSettled([...jobs]);db.close();}};
}
