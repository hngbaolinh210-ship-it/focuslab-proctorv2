import path from 'node:path';
import { existsSync } from 'node:fs';
import { emitKeypressEvents } from 'node:readline';
import { initializeAdmin } from './auth.mjs';
const dataDir=path.resolve(process.env.DATA_DIR||'data');
if(existsSync(path.join(dataDir,'admin.json'))){console.log('Mat khau giam thi da duoc thiet lap.');process.exit(0);}
let password=process.env.ADMIN_PASSWORD;
if(!password){
  if(!process.stdin.isTTY){console.error('Set ADMIN_PASSWORD with at least 12 characters for first setup.');process.exit(1);}
  console.log('Nhap mat khau tu 12 den 200 ky tu. Khi go se hien dau *. Nhan Enter de luu.');
  try {
    do {
      password=await readMaskedPassword();
      if(password.length<12||password.length>200)console.log('Mat khau chua hop le: can tu 12 den 200 ky tu. Hay nhap lai.');
    } while(password.length<12||password.length>200);
  } catch(error){console.error(error.message);process.exit(1);}
}
if(password.length>200){console.error('Mat khau chi duoc toi da 200 ky tu.');process.exit(1);}
try{initializeAdmin(dataDir,password);console.log('Da tao tai khoan giam thi. Ghi nho mat khau de dang nhap.');}catch(error){console.error(error.message);process.exit(1);}

function readMaskedPassword(){
  const input=process.stdin;
  const wasRaw=Boolean(input.isRaw);
  emitKeypressEvents(input);
  return new Promise((resolve,reject)=>{
    const characters=[];
    const finish=(error)=>{
      input.removeListener('keypress',onKey);
      input.removeListener('end',onEnd);
      input.setRawMode(wasRaw);
      input.pause();
      process.stdout.write('\n');
      if(error)reject(error);else resolve(characters.join(''));
    };
    const onEnd=()=>finish(new Error('Da dung tao mat khau. Mo lai start-windows.cmd de thu lai.'));
    const onKey=(text,key={})=>{
      if(key.ctrl&&(key.name==='c'||key.name==='d'))return onEnd();
      if(key.name==='return'||key.name==='enter')return finish();
      if(key.name==='backspace'){
        if(characters.length){characters.pop();process.stdout.write('\b \b');}
        return;
      }
      if(key.ctrl||key.meta||!text||/[\u0000-\u001f\u007f]/u.test(text))return;
      for(const character of text){
        if(characters.join('').length+character.length>200)continue;
        characters.push(character);
        process.stdout.write('*');
      }
    };
    input.on('keypress',onKey);
    input.once('end',onEnd);
    input.setRawMode(true);
    input.resume();
    process.stdout.write('Mat khau giam thi: ');
  });
}
