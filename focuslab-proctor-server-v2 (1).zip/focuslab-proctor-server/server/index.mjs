import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import {spawn} from 'node:child_process';
import { createApp } from './app.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dev=process.argv.includes('--dev');
const system=createApp({dataDir:path.resolve(process.env.DATA_DIR||path.join(root,'data')),adminPassword:process.env.ADMIN_PASSWORD,secureCookies:process.env.COOKIE_SECURE==='true',trustProxy:process.env.TRUST_PROXY==='true',cameraHosts:(process.env.CAMERA_HOSTS||'').split(',').map(s=>s.trim()).filter(Boolean)});
let vite;
if(dev){const {createServer}=await import('vite');vite=await createServer({root,server:{middlewareMode:true,fs:{deny:['.env','.env.*','*.{crt,pem,key}','**/.git/**','**/data/**','**/admin.json','**/*.sqlite*',path.resolve(process.env.DATA_DIR||path.join(root,'data')).replaceAll('\\','/')+'/**']}},appType:'spa'});system.app.use(vite.middlewares);}
else{system.app.use(express.static(path.join(root,'dist')));system.app.get('/{*splat}',(_req,res)=>res.sendFile(path.join(root,'dist/index.html')));}
const port=Number(process.env.PORT||5173);
const server=system.app.listen(port,'0.0.0.0',()=>{console.log(`FocusLab server ready: http://localhost:${port}`);if(process.argv.includes('--open')){const url=`http://localhost:${port}`;const command=process.platform==='win32'?'cmd':process.platform==='darwin'?'open':'xdg-open';const args=process.platform==='win32'?['/c','start','',url]:[url];const opener=spawn(command,args,{stdio:'ignore'});opener.on('error',()=>console.log(`Open ${url} in your browser.`));}});
async function close(){server.close();await vite?.close();await system.close();process.exit(0);}
process.on('SIGTERM',close);process.on('SIGINT',close);
