import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import path from 'node:path';
export const token = () => randomBytes(24).toString('base64url');
export const digest = value => createHash('sha256').update(value).digest('hex');
export function passwordHash(password) {
  const salt=randomBytes(16).toString('hex');
  return `${salt}:${scryptSync(password,salt,64).toString('hex')}`;
}
export function passwordMatches(password, stored) {
  const [salt,hash]=stored.split(':');const expected=Buffer.from(hash,'hex');const actual=scryptSync(password,salt,64);
  return expected.length===actual.length&&timingSafeEqual(expected,actual);
}
export function initializeAdmin(dataDir,password) {
  mkdirSync(dataDir,{recursive:true,mode:0o700});const file=path.join(dataDir,'admin.json');
  if(existsSync(file))return JSON.parse(readFileSync(file,'utf8')).passwordHash;
  if(typeof password!=='string'||password.length<12)throw new Error('Chạy npm run setup để tạo mật khẩu giám thị từ 12 ký tự.');
  const hash=passwordHash(password);writeFileSync(file,JSON.stringify({passwordHash:hash}),{mode:0o600,flag:'wx'});return hash;
}
