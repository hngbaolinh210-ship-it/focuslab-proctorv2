import { spawn } from 'node:child_process';
import { mkdirSync, rmSync, existsSync } from 'node:fs';
import path from 'node:path';
import ffmpegStatic from 'ffmpeg-static';
import ffprobeStatic from 'ffprobe-static';
export const binaries={ffmpeg:process.env.FFMPEG_PATH||ffmpegStatic,ffprobe:process.env.FFPROBE_PATH||ffprobeStatic.path};
function run(binary,args,{timeout=15000}={}) {
  return new Promise((resolve,reject)=>{
    const process=spawn(binary,args,{stdio:['ignore','pipe','ignore']});let output='',done=false;
    const finish=(error)=>{if(done)return;done=true;clearTimeout(timer);error?reject(error):resolve(output);};
    const timer=setTimeout(()=>{process.kill('SIGKILL');finish(new Error('MEDIA_TIMEOUT'));},timeout);
    process.stdout.on('data',chunk=>{output+=chunk;if(output.length>256000){process.kill('SIGKILL');finish(new Error('MEDIA_OUTPUT_LIMIT'));}});
    process.on('error',()=>finish(new Error('MEDIA_TOOL_UNAVAILABLE')));process.on('exit',code=>finish(code===0?null:new Error('MEDIA_INVALID')));
  });
}
export async function probeVideo(file) {
  const data=JSON.parse(await run(binaries.ffprobe,['-v','error','-protocol_whitelist','file,pipe','-show_entries','format=duration:stream=codec_type,width,height','-of','json',file]));
  const duration=Number(data.format?.duration);const video=data.streams?.find(s=>s.codec_type==='video');
  if(!video||!Number.isFinite(duration)||duration<=0||duration>7200||video.width*video.height>3840*2160)throw new Error('VIDEO_LIMIT');
  return {duration,width:video.width,height:video.height};
}
export async function transcodeVideo(input,output) {
  await run(binaries.ffmpeg,['-nostdin','-y','-v','error','-protocol_whitelist','file,pipe','-i',input,'-map','0:v:0','-map','0:a:0?','-vf','scale=w=min(1280\\,iw):h=-2','-c:v','libx264','-preset','veryfast','-crf','25','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',output],{timeout:30*60*1000});
  const webm=output.replace(/\.mp4$/,'.webm');
  await run(binaries.ffmpeg,['-nostdin','-y','-v','error','-protocol_whitelist','file,pipe','-i',input,'-map','0:v:0','-map','0:a:0?','-vf','scale=w=min(960\\,iw):h=-2','-c:v','libvpx','-deadline','realtime','-cpu-used','8','-b:v','1M','-pix_fmt','yuv420p','-c:a','libopus',webm],{timeout:30*60*1000});
}
export function validateCameraUrl(value,allowedHosts) {
  let url;try{url=new URL(value);}catch{throw new Error('URL camera không hợp lệ.');}
  if(!['rtsp:','rtsps:'].includes(url.protocol)||!allowedHosts.includes(url.hostname))throw new Error('Chỉ cho phép RTSP từ host có trong CAMERA_HOSTS trên máy chủ.');
  if(value.length>2000)throw new Error('URL quá dài.');return url.href;
}
export function createRelay({id,url,root,onExit}) {
  const directory=path.join(root,id);mkdirSync(directory,{recursive:true});
  const process=spawn(binaries.ffmpeg,['-nostdin','-v','error','-protocol_whitelist','rtsp,rtsps,tcp,udp,rtp,tls,crypto','-rtsp_transport','tcp','-i',url,'-an','-vf','scale=w=min(1280\\,iw):h=-2','-c:v','libx264','-preset','veryfast','-tune','zerolatency','-pix_fmt','yuv420p','-g','50','-sc_threshold','0','-f','hls','-hls_time','2','-hls_list_size','5','-hls_flags','delete_segments+independent_segments','-hls_segment_filename',path.join(directory,'segment-%06d.ts'),path.join(directory,'index.m3u8')],{stdio:'ignore'});
  let closed=false;const finish=()=>{if(closed)return;closed=true;clearTimeout(timer);onExit();};
  process.on('error',finish);process.on('exit',finish);
  // Abort cameras which never produce a playable manifest; don't expose credentials in errors.
  const timer=setTimeout(()=>{if(!existsSync(path.join(directory,'index.m3u8')))process.kill('SIGKILL');},30000);
  return {directory,process,stop(){process.kill('SIGKILL');finish();},cleanup(){rmSync(directory,{recursive:true,force:true});}};
}
