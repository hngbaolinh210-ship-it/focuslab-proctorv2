/* Trang làm bài của học sinh: đồng hồ do máy chủ giữ, bài tự lưu mỗi 5 giây, bảng câu hỏi bên phải. */
import { api, escape, notify, countDown, clock, dateTime } from "/static/app.js";

const LETTERS = "ABCDEFGH";
const SAVE_EVERY = 5000;
const AWAY_MS = 10000;  // máy chủ báo "rời cửa sổ" khi im lặng quá chừng này giây
const CAM_EVERY = 1200;
const WATCH_EVERY = 80;
// Mỗi dấu hiệu phải giữ liên tục đủ lâu mới được báo, để một cái quay đầu không thành cảnh báo.
// object_raised = 0: giơ điện thoại 0,1 giây là phải có ảnh, không được chờ; ổ 90 giây đã chặn báo dồn dập.
const HOLD = { cam_dark: 5000, face_gone: 9000, object_raised: 0 };
const COOLDOWN_MS = 90000;
const el = id => document.getElementById(id);

let me, paper, questions = [], answers = {}, index = 0, remaining = 0;
let tickTimer, saveTimer, wired = false;
let dirty = false, submitted = false;
let pasteCount = 0, hiddenAt = 0;
let camStream, camTimer, watchTimer, watchRaf, camSending = false, camStarting = false, camOff = false, camWaiting = false;
let scan = null, holdSince = {}, lastAlert = {};

const draftKey = () => `focuslab-de-${paper.id}-${me.student_code}`;
const isAnswered = i => answers[String(i)] !== undefined && answers[String(i)] !== "";
const answeredCount = () => questions.reduce((total, _question, i) => total + (isAnswered(i) ? 1 : 0), 0);

async function boot() {
  try {
    me = await api("/api/me");
  } catch {
    el("loading").textContent = "Không nối được máy chủ. Em tải lại trang sau vài giây nhé.";
    return;
  }
  if (me.role !== "student") return location.replace("/");
  el("loading").hidden = true;
  el("lobby").hidden = false;
  el("leave").addEventListener("click", leave);
  el("back").addEventListener("click", () => show("lobby"));
  el("restore-yes").addEventListener("click", useDraft);
  el("restore-no").addEventListener("click", () => { el("restore").hidden = true; localStorage.removeItem(draftKey()); });
  wireDeskOnce();
  await renderLobby();
  const wanted = new URLSearchParams(location.search).get("de");
  if (wanted) openExam(wanted);
}

function show(name) {
  for (const id of ["lobby", "desk", "finish"]) el(id).hidden = id !== name;
}

async function leave() {
  await api("/api/logout", { method: "POST" }).catch(() => {});
  location.replace("/");
}

async function renderLobby() {
  const exams = await api("/api/exams");
  el("lobby-title").textContent = me.room_title;
  el("lobby-student").textContent = `${me.name} · chỗ ngồi ${me.seat_id}`;
  el("lobby-list").innerHTML = exams.length
    ? exams.map(exam => {
        const closed = exam.state === "hết hạn nộp" || exam.state === "chưa tới giờ mở";
        return `<article class="card flex flex-wrap items-center justify-between gap-3 p-4">
        <div>
          <h3 class="font-bold text-slate-900">${escape(exam.title)}</h3>
          <p class="text-xs text-slate-500">${exam.question_count} câu ·
            ${exam.kind !== "baotap" ? `${exam.duration_minutes} phút`
              : exam.open_until ? `bài tập về nhà, nộp trước ${dateTime(exam.open_until)}` : "bài tập về nhà, chưa đặt hạn nộp"} · ${exam.max_points} điểm ·
            <span class="pill ${exam.state === "đã nộp" ? "bg-moss-soft text-moss" : "bg-slate-100 text-slate-600"}">${escape(exam.state)}</span>
            ${exam.score === null || exam.score === undefined ? "" : ` · ${exam.score}/${exam.max_points} điểm`}</p>
        </div>
        ${exam.state === "đã nộp" ? `<button class="btn-ghost" data-open="${exam.id}">Xem lại điểm</button>`
          : closed ? `<button class="btn-ghost" disabled>${exam.state === "hết hạn nộp" ? "Đã qua hạn nộp" : "Chưa tới giờ mở"}</button>`
          : `<button class="btn-primary" data-open="${exam.id}">${exam.state === "đang làm" ? "Tiếp tục làm bài" : "Bắt đầu làm bài"}</button>`}
      </article>`; }).join("")
    : '<p class="card p-6 text-center text-sm text-slate-500">Cô giáo chưa mở đề nào cho lớp. Em ngồi tại chỗ, đề mở ra sẽ hiện ở đây.</p>';
  el("lobby-list").querySelectorAll("[data-open]").forEach(button =>
    button.addEventListener("click", () => openExam(button.dataset.open)));
  show("lobby");
  return exams;
}

async function openExam(id) {
  history.replaceState(null, "", `?de=${id}`);
  let sheet;
  try {
    sheet = await api(`/api/exams/${id}/paper`);
  } catch (error) {
    notify(document, error.message, true);
    return renderLobby();
  }
  if (!sheet.started_at) {
    const homework = sheet.kind === "baotap";
    const ready = confirm(`Đề "${sheet.title}" có ${sheet.questions.length} câu, `
      + (homework ? (sheet.open_until ? `cô cho làm ở nhà, nộp trước ${dateTime(sheet.open_until)}.` : "cô không đặt hạn nộp.")
        : `làm trong ${sheet.duration_minutes} phút.\n\nMáy chủ bắt đầu tính giờ ngay khi em bấm Bắt đầu và sẽ tự nộp bài khi hết giờ.`)
      + (sheet.cam_enabled ? "\n\nPhòng thi này có bật camera: máy em tự kiểm tra tại chỗ và chỉ gửi cho cô ĐÚNG MỘT ảnh "
        + "khi phát hiện bất thường (che camera, rời khỏi khung hình, giơ màn hình điện thoại lên gần mặt). Không có video nào được quay." : "")
      + "\nEm đã sẵn sàng chưa?");
    if (!ready) return;
    sheet = await api(`/api/exams/${id}/start`, { method: "POST" });
  }
  paper = sheet;
  questions = sheet.questions;
  answers = { ...sheet.answers };
  pasteCount = sheet.paste_count;
  submitted = Boolean(sheet.submitted_at);
  camOff = false;
  if (submitted) return showFinish(sheet.score, sheet.max_points);
  renderDesk();
  show("desk");
  runClock(sheet.remaining_ms);
  startAutosave();
  watchPresence();
  offerDraft();
  syncCamera(sheet);
}

function renderDesk() {
  el("desk-title").textContent = paper.title;
  el("desk-meta").textContent = `${me.room_title} · ${questions.length} câu · ${paper.max_points} điểm`;
  el("track").innerHTML = questions.map(questionPanel).join("");
  el("palette").innerHTML = questions.map((_question, i) =>
    `<button class="palette-cell w-11 shrink-0 md:w-auto" data-goto="${i}" title="Đến câu ${i + 1}"><span>${i + 1}</span><span class="tick">✓</span></button>`).join("");
  el("submit").textContent = "Nộp bài";
  paint();
  goTo(0);
}

function questionPanel(question, i) {
  const chosen = answers[String(i)];
  const body = question.type === "mcq"
    ? `<div class="grid gap-2">${question.options.map((option, j) => optionButton(question, i, option, j, chosen)).join("")}</div>`
    : `<textarea data-essay rows="7" class="field" placeholder="Em viết bài làm vào đây…">${escape(answers[String(i)] ?? "")}</textarea>
       ${question.prompt ? `<p class="mt-2 text-xs text-slate-500">Hướng dẫn: ${escape(question.prompt)}</p>` : ""}`;
  return `<section data-question="${i}" class="p-5">
      <p class="mb-4 text-lg leading-relaxed text-slate-800">${escape(question.text)}</p>${body}
    </section>`;
}

const optionButton = (question, i, option, j, chosen) => `<button data-pick="${j}" class="${optionClass(j === chosen)}">
    <span class="grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs
      ${j === chosen ? "border-moss bg-moss text-white" : "border-slate-300 text-slate-600"}">${LETTERS[j]}</span>
    <span>${escape(option)}</span></button>`;

const optionClass = on => `option flex items-start gap-3 rounded-lg border p-3 text-left text-sm transition
  ${on ? "border-moss bg-moss-soft font-semibold text-moss" : "border-slate-300 bg-white hover:border-moss"}`;

/* Một lượt nghe duy nhất cho cả trang: đổi đề, chuyển câu đều không phải gắn lại listener. */
function wireDeskOnce() {
  if (wired) return;
  wired = true;
  el("track").addEventListener("click", event => {
    const button = event.target.closest("[data-pick]");
    if (!button) return;
    pick(Number(button.closest("[data-question]").dataset.question), Number(button.dataset.pick));
  });
  el("track").addEventListener("input", event => {
    if (!event.target.matches("[data-essay]")) return;
    answers[String(event.target.closest("[data-question]").dataset.question)] = event.target.value;
    touch();
  });
  el("track").addEventListener("paste", () => {
    pasteCount += 1;
    flag("paste");
  });
  el("palette").addEventListener("click", event => {
    const cell = event.target.closest("[data-goto]");
    if (cell) goTo(Number(cell.dataset.goto));
  });
  el("prev").addEventListener("click", () => goTo(index - 1));
  el("next").addEventListener("click", () => goTo(index + 1));
  el("submit").addEventListener("click", () => submitNow());
  el("cam-stop").addEventListener("click", refuseCamera);
  document.addEventListener("keydown", keys);
}

function paint() {
  el("q-counter").textContent = `Câu ${index + 1} / ${questions.length}`;
  el("q-points").textContent = `${questions[index].points} điểm`;
  el("prev").disabled = index === 0;
  el("next").disabled = index === questions.length - 1;
  const done = answeredCount();
  el("progress").textContent = `Đã làm ${done}/${questions.length} câu · còn ${questions.length - done} câu chưa làm`;
  el("palette").querySelectorAll("[data-goto]").forEach((cell, i) => {
    cell.classList.toggle("done", isAnswered(i));
    cell.classList.toggle("current", i === index);
  });
  el("track").querySelectorAll("[data-question]").forEach(panel => {
    const i = Number(panel.dataset.question);
    if (questions[i].type !== "mcq") return;
    panel.querySelectorAll("[data-pick]").forEach(button => {
      const on = Number(button.dataset.pick) === answers[String(i)];
      button.className = optionClass(on);
      button.firstElementChild.className = `grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs
        ${on ? "border-moss bg-moss text-white" : "border-slate-300 text-slate-600"}`;
    });
  });
}

function goTo(target) {
  index = Math.max(0, Math.min(questions.length - 1, target));
  el("track").style.transform = `translateX(-${index * 100}%)`;
  // Màn hẹp thì bảng số câu nằm ngay trên, khung câu hỏi ở dưới: bấm xong phải tự cuộn xuống để em thấy câu mới.
  if (window.innerWidth < 768) el("desk-card").scrollIntoView({ behavior: "smooth", block: "start" });
  paint();
}

function keys(event) {
  if (el("desk").hidden || event.target.matches("textarea") || submitted) return;
  if (event.key === "ArrowRight") goTo(index + 1);
  if (event.key === "ArrowLeft") goTo(index - 1);
}

function pick(i, option) {
  answers[String(i)] = option;
  touch();
  const blank = nextBlank(i);
  if (blank !== null) setTimeout(() => { if (!submitted) goTo(blank); }, 260);
}

/* Câu còn trống gần nhất kể từ câu vừa làm, quay vòng hết một lượt — bấm đáp án xong là nhảy tới chỗ cần làm. */
function nextBlank(from) {
  for (let step = 1; step <= questions.length; step++) {
    const candidate = (from + step) % questions.length;
    if (!isAnswered(candidate)) return candidate;
  }
  return null;
}

function touch() {
  dirty = true;
  localStorage.setItem(draftKey(), JSON.stringify({ answers, saved: Date.now() }));
  paint();
}

const payload = () => ({ answers, paste_count: pasteCount });

async function save({ keepalive = false } = {}) {
  if (submitted) return;
  dirty = false;
  try {
    const sheet = await api(`/api/exams/${paper.id}/save`, { method: "POST", body: payload(), keepalive });
    remaining = sheet.remaining_ms;
    el("save-state").textContent = `Đã lưu lên máy chủ lúc ${clock(Date.now())}`;
    if (!keepalive) syncCamera(sheet);
  } catch {
    dirty = true;
    el("save-state").textContent = "Chưa lưu được lên máy chủ. Bài vẫn giữ trên máy này, em kiểm tra mạng nhé.";
  }
}

function startAutosave() {
  clearInterval(saveTimer);
  // Cửa sổ bị ẩn thì KHÔNG gửi gì cả — im lặng bao lâu chính là dấu vết để máy chủ đo.
  saveTimer = setInterval(() => { if (!document.hidden) save(); }, SAVE_EVERY);
  window.addEventListener("pagehide", () => { if (dirty) save({ keepalive: true }); });
}

/* Camera: phòng nào bật camera thì máy em mở ống kính và TỰ KIỂM TRA tại chỗ — mỗi 0,6 giây
   đọc một khung hình nhỏ ngay trong trình duyệt. Ảnh chỉ rời khỏi máy em khi phát hiện dấu hiệu,
   và mỗi dấu hiệu chỉ có đúng MỘT ảnh. Không quay liên tục, không gửi video. */
function syncCamera(sheet) {
  if (camOff || submitted || !(sheet.cam_enabled || sheet.cam_wanted)) return stopCamera();
  camWaiting = Boolean(sheet.cam_wanted);
  startCamera();
}

async function startCamera() {
  if (camStream) return setWanted(camWaiting);
  if (camStarting) return;
  camStarting = true;
  try {
    camStream = await askCamera();
  } catch {
    camOff = true;
    camStarting = false;
    notify(document, "Máy này chưa cho phép dùng camera. Em bấm Cho phép ở thanh địa chỉ rồi tải lại trang, hoặc báo cô giám thị.", true);
    await api(`/api/exams/${paper.id}/cam`, { method: "DELETE" }).catch(() => {});
    return;
  }
  camStarting = false;
  if (camOff || submitted) return stopCamera();
  el("cam-feed").srcObject = camStream;
  el("cam").hidden = false;
  startWatch();
  setWanted(camWaiting);
}

/* setInterval chỉ đánh thức máy 1 lần/600ms, em giơ điện thoại 0,1 giây là lọt. Ở đây xin trình duyệt
   báo đúng mỗi khung hình camera rồi đo, cách nhau không dưới WATCH_EVERY. */
function startWatch() {
  stopWatch();
  const video = el("cam-feed");
  if (!video.requestVideoFrameCallback) {
    watchTimer = setInterval(analyze, WATCH_EVERY);
    return;
  }
  let last = 0;
  const step = () => {
    watchRaf = video.requestVideoFrameCallback(step);
    const moment = Date.now();
    if (moment - last < WATCH_EVERY) return;
    last = moment;
    analyze();
  };
  watchRaf = video.requestVideoFrameCallback(step);
}

function stopWatch() {
  clearInterval(watchTimer);
  watchTimer = null;
  if (watchRaf !== undefined && watchRaf !== null) {
    el("cam-feed").cancelVideoFrameCallback?.(watchRaf);
    watchRaf = null;
  }
}

/* Cô chuyển sang xem em khác là ngừng gửi hình, còn máy vẫn tự kiểm tra tại chỗ. */
function setWanted(wanted) {
  clearInterval(camTimer);
  if (!camStream) return;
  el("cam").hidden = false;
  el("cam-label").textContent = wanted ? "Cô giám thị đang xem hình của em" : "Camera đang bật để máy tự kiểm tra";
  if (!wanted) return;
  sendFrame();
  camTimer = setInterval(sendFrame, CAM_EVERY);
}

/* Đầu tiên là máy chủ phải còn mạng, sau đó mới tới quyền của trình duyệt. */
function askCamera() {
  if (!navigator.mediaDevices?.getUserMedia) return Promise.reject(new Error("Trình duyệt này không dùng được camera."));
  return navigator.mediaDevices.getUserMedia({ video: { width: 480, height: 360, facingMode: "user" }, audio: false });
}

function stopCamera() {
  clearInterval(camTimer);
  stopWatch();
  camTimer = null;
  el("cam").hidden = true;
  if (!camStream) return;
  for (const track of camStream.getTracks()) track.stop();
  camStream = null;
  el("cam-feed").srcObject = null;
}

const skinPixel = (r, g, b) => r > 95 && g > 40 && b > 20 && Math.max(r, g, b) - Math.min(r, g, b) > 15 && r - g > 15 && r > b;
const brightPixel = (r, g, b) => 0.299 * r + 0.587 * g + 0.114 * b > 190 && b >= r - 30 && g >= r - 40;
/* Màn hình điện thoại phát sáng trắng XANH (b >= r); áo trắng, đèn sợi đốt và nắng hắt đều ấm (r > b). */
const coolPixel = (r, g, b) => 0.299 * r + 0.587 * g + 0.114 * b > 185 && b >= r && g >= r - 20;

/* Hai dấu hiệu cùng chỉ một cái điện thoại trước mặt:
   - MẢNG LẠNH GỌN: màn hình là quầng sáng mát chiếm vài phần trăm vùng trước ngực. Cửa sổ hay đèn
     trần chiếu HẾT khung nên bị COOL_MAX loại — nhờ vậy áo trắng hay tường sáng không báo nhầm.
     Dấu hiệu này không cần so sánh, nên em GIƠ SẴN từ trước lúc bật camera vẫn bị bắt.
   - SO SÁNH: vùng trước ngực vừa bật sáng thêm so với 0,4 giây trước, bắt luôn màn hình lên màu vàng.
   Máy đo 80ms một lần và báo ngay lần đo đầu tiên, nên em giơ 0,1 giây vẫn rơi vào một lần đo. */
const RAISE_LAG = 4;          // 4 khung hình ~ 0,3 giây
const RAISE_DIFF = 0.08;      // 8% điểm vùng trước ngực vừa bật sáng là khác thường
const RAISE_MAX = 0.5;        // bật sáng HẾT vùng là bật đèn hoặc mở cửa sổ, không phải cái điện thoại
const COOL_MIN = 0.03;        // dưới 3% là chấm sáng lẻ loi, chưa đủ kết luận
const COOL_MAX = 0.35;        // trên 35% là đèn hoặc cửa sổ, không phải điện thoại
let bandRing = [];

/* Ba con số đủ để nhận ra bất thường: sáng trung bình, tỉ lệ màu da, và mảng sáng của màn hình. */
function measure(video) {
  scan ??= document.createElement("canvas");
  scan.width = 96;
  scan.height = 72;
  const ctx = scan.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(video, 0, 0, scan.width, scan.height);
  const { data } = ctx.getImageData(0, 0, scan.width, scan.height);
  const x0 = Math.floor(scan.width * 0.25), x1 = Math.floor(scan.width * 0.75), y0 = Math.floor(scan.height * 0.45);
  const band = new Uint8Array((x1 - x0) * (scan.height - y0));
  let lum = 0, skin = 0, bright = 0, cool = 0, k = 0;
  for (let y = 0; y < scan.height; y++) {
    for (let x = 0; x < scan.width; x++) {
      const p = (y * scan.width + x) * 4;
      const r = data[p], g = data[p + 1], b = data[p + 2];
      lum += 0.299 * r + 0.587 * g + 0.114 * b;
      if (skinPixel(r, g, b)) skin++;
      // vùng giữa, từ ngang mũi trở xuống: đây là chỗ tay hoặc điện thoại giơ lên trước mặt
      if (y >= y0 && x >= x0 && x < x1) {
        band[k++] = brightPixel(r, g, b) ? 1 : 0;
        if (brightPixel(r, g, b)) bright++;
        if (coolPixel(r, g, b)) cool++;
      }
    }
  }
  const pixels = scan.width * scan.height;
  return { dark: lum / pixels < 30, skin: skin / pixels, bright: k ? bright / k : 0, cool: k ? cool / k : 0, band };
}

/* So khung hình hiện tại với khung hình 0,3 giây trước: chỉ đếm những điểm BẬT sáng thêm.
   Quầng sáng phải GỌN: bật một cái điện thoại thì vài phần trăm vùng đổi khác, còn bật đèn lớp thì đổi hết. */
function raised(seen) {
  bandRing.push(seen.band);
  if (bandRing.length > RAISE_LAG + 1) bandRing.shift();
  if (bandRing.length < RAISE_LAG + 1) return false;
  const past = bandRing[0];
  if (past.length !== seen.band.length) return false;
  let flips = 0;
  for (let i = 0; i < past.length; i++) if (seen.band[i] && !past[i]) flips++;
  const ratio = flips / past.length;
  return ratio > RAISE_DIFF && ratio < RAISE_MAX;
}

function analyze() {
  const video = el("cam-feed");
  if (!camStream || submitted || document.hidden || !video.videoWidth) return;
  const now = Date.now();
  const seen = measure(video);
  const flipped = raised(seen);  // phải luôn so, dù có báo hay không, để đồng hồ so khớp luôn chạy
  const signs = {
    cam_dark: seen.dark,
    face_gone: !seen.dark && seen.skin < 0.02,
    object_raised: !seen.dark && seen.skin >= 0.02 && (flipped || (seen.cool >= COOL_MIN && seen.cool <= COOL_MAX)),
  };
  for (const [rule, on] of Object.entries(signs)) {
    if (!on) {
      holdSince[rule] = 0;
      continue;
    }
    if (!holdSince[rule]) holdSince[rule] = now;
    if (now - holdSince[rule] >= HOLD[rule]) {
      holdSince[rule] = 0;
      raise(rule);
    }
  }
}

async function raise(rule) {
  if (Date.now() - (lastAlert[rule] || 0) < COOLDOWN_MS) return;
  lastAlert[rule] = Date.now();
  const blob = await jpegOf(el("cam-feed"));
  if (!blob) return;
  notify(document, "Máy vừa ghi nhận một dấu hiệu bất thường và gửi cho cô giám thị đúng một ảnh. Em cứ làm bài bình thường.", true);
  try {
    await fetch(`/api/exams/${paper.id}/evidence?rule=${rule}&client_id=${crypto.randomUUID()}`,
      { method: "PUT", credentials: "same-origin", body: blob });
  } catch {
    /* mất mạng thì coi như không có ảnh — đừng làm em học sinh lo giữa giờ thi */
  }
}

async function sendFrame() {
  const video = el("cam-feed");
  if (!camStream || camSending || submitted || !video.videoWidth) return;
  camSending = true;
  try {
    const blob = await jpegOf(video);
    if (!blob) return;
    const answer = await fetch(`/api/exams/${paper.id}/cam`, { method: "PUT", credentials: "same-origin", body: blob });
    if (answer.ok && !(await answer.json()).wanted) {
      camWaiting = false;
      setWanted(false);
    }
  } catch {
    /* mất vài khung hình khi mạng phòng thi chập chờn là bình thường */
  } finally {
    camSending = false;
  }
}

function jpegOf(video) {
  const canvas = document.createElement("canvas");
  canvas.width = 320;
  canvas.height = 240;
  const zoom = Math.max(canvas.width / video.videoWidth, canvas.height / video.videoHeight);
  const w = video.videoWidth * zoom, h = video.videoHeight * zoom;
  canvas.getContext("2d").drawImage(video, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
  return new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.45));
}

async function refuseCamera() {
  camOff = true;
  stopCamera();
  notify(document, "Em đã tắt camera. Cô giám thị sẽ thấy trên bảng theo dõi.");
  await api(`/api/exams/${paper.id}/cam`, { method: "DELETE" }).catch(() => {});
  flag("cam_off", 0);
}

async function flag(rule, duration) {
  try {
    await api(`/api/exams/${paper.id}/event`, { method: "POST", body: { rule, duration, client_id: crypto.randomUUID() } });
  } catch { /* mất một cảnh báo thì cô nhắc bằng lời, đừng làm gián đoạn bài thi */ }
}

/* Máy chủ tự đo khoảng lặng giữa hai lần máy em báo tin, nên trình duyệt điện thoại có bị
   đông băng lúc tắt màn hình thì cô vẫn thấy em rời phòng. Ở đây chỉ cần gửi nhịp cuối
   ngay khi tắt và ngay khi mở màn hình lại — không tự đếm, không tự báo. */
function watchPresence() {
  document.addEventListener("visibilitychange", () => {
    if (el("desk").hidden || submitted) return;
    if (document.hidden) {
      hiddenAt = Date.now();
      save({ keepalive: true });
    } else if (hiddenAt) {
      const away = Math.round((Date.now() - hiddenAt) / 1000);
      hiddenAt = 0;
      save();
      if (away * 1000 >= AWAY_MS) {
        el("save-state").textContent = `Em rời cửa sổ ${away} giây — cô giáo đã thấy trên bảng theo dõi.`;
      }
    }
  });
}

function offerDraft() {
  const draft = readDraft();
  if (draft && Object.keys(answers).length === 0 && Object.keys(draft.answers).length) el("restore").hidden = false;
}

const readDraft = () => JSON.parse(localStorage.getItem(draftKey()) || "null");

function useDraft() {
  answers = { ...(readDraft()?.answers || {}) };
  el("restore").hidden = true;
  el("track").innerHTML = questions.map(questionPanel).join("");
  dirty = true;
  paint();
}

function runClock(ms) {
  clearInterval(tickTimer);
  // Bài tập về nhà không có hạn nộp thì không có đồng hồ nào cả — đừng để em bị "hết giờ" giả.
  if (paper.kind === "baotap" && !paper.open_until) {
    remaining = 0;
    el("timer").textContent = "Không giới hạn thời gian";
    el("timer").className = "text-sm font-semibold text-moss";
    return;
  }
  remaining = Math.max(0, ms ?? 0);
  paintTimer();
  tickTimer = setInterval(() => {
    remaining = Math.max(0, remaining - 1000);
    paintTimer();
    if (remaining === 0) submitNow({ auto: true });
  }, 1000);
}

function paintTimer() {
  const homework = paper.kind === "baotap";
  el("timer").textContent = countDown(remaining);
  el("timer").className = `font-mono text-3xl font-bold ${remaining < 300000 ? "text-red-600" : "text-moss"}`;
  if (homework) el("timer").title = "Còn lại tới hạn nộp cô đặt";
}

async function submitNow(options = {}) {
  const auto = Boolean(options.auto);
  if (!auto) {
    const left = questions.length - answeredCount();
    if (!confirm(left ? `Em còn ${left} câu chưa làm.\n\nBấm OK để nộp ngay, Cancel để ở lại làm tiếp.` : "Em nộp bài bây giờ nhé?")) return;
  }
  clearInterval(tickTimer);
  clearInterval(saveTimer);
  stopCamera();
  submitted = true;
  el("submit").disabled = true;
  try {
    const sheet = await api(`/api/exams/${paper.id}/submit`, { method: "POST", body: payload() });
    localStorage.removeItem(draftKey());
    showFinish(sheet.score, sheet.max_points, auto);
  } catch (error) {
    submitted = false;
    notify(document, `${error.message} Em thử nộp lại sau vài giây nhé.`, true);
    runClock(Math.max(remaining, 15000));
  }
}

function showFinish(score, max, auto = false) {
  stopCamera();
  el("finish-body").textContent = score === null || score === undefined
    ? "Bài của em đã được ghi nhận. Cô giáo sẽ chấm phần tự luận rồi cộng điểm."
    : `Điểm của em: ${score}/${max}.${auto ? " Máy chủ tự nộp khi hết giờ nên bài vẫn được chấm đủ." : ""}`;
  history.replaceState(null, "", location.pathname);
  show("finish");
}

boot();
