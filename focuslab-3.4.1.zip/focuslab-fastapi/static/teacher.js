/* Bảng điều hành của cô: phòng thi, danh sách lớp, soạn đề, theo dõi giờ thi và chấm tự luận. */
import { api, escape, notify, minutes, clock, dateTime } from "/static/app.js";

const el = id => document.getElementById(id);
const LETTERS = "ABCDEFGH";
const POLL_MS = 10000;
const CAM_POLL_MS = 1200;
const CAM_WAIT_MS = 6000;
const ONLINK_MS = 90000;
const TONES = {
  ok: "bg-moss-soft text-moss",
  warn: "bg-amber-100 text-amber-800",
  alert: "bg-red-100 text-red-700",
  done: "bg-slate-200 text-slate-700",
  idle: "bg-slate-100 text-slate-500",
};

let me, rooms = [], roomId = null, room = null, tab = "roster";
let editor = null, detail = null, previous = new Map(), pollTimer;
let paperFilter = "all", paperQuery = "";
let camStudent = null, camTimer = null, camUrl = null, camWaited = 0;

async function boot() {
  try {
    me = await api("/api/me");
  } catch {
    el("who").textContent = "Không nối được máy chủ.";
    return;
  }
  if (me.role !== "teacher") return location.replace("/");
  el("who").textContent = me.display_name;
  el("team-open").hidden = !me.is_owner;
  wire();
  showTab("roster");
  await loadRooms();
}

/* ---------------------------------------------------------------- khung trang */

function wire() {
  el("logout").addEventListener("click", async () => {
    await api("/api/logout", { method: "POST" }).catch(() => {});
    location.replace("/");
  });
  el("new-room").addEventListener("click", createRoom);
  el("copy-code").addEventListener("click", () => navigator.clipboard?.writeText(room.code) && notify(document, `Đã copy mã phòng ${room.code}.`));
  el("toggle-close").addEventListener("click", toggleRoom);
  el("toggle-cam").addEventListener("click", toggleCam);
  el("drop-room").addEventListener("click", dropRoom);
  el("codes-csv").addEventListener("click", () => location.href = `/api/rooms/${roomId}/codes.csv`);
  el("roster-add").addEventListener("click", () => sendRoster("post"));
  el("roster-replace").addEventListener("click", () => sendRoster("put"));
  el("roster-file").addEventListener("change", uploadRoster);
  el("new-exam").addEventListener("click", () => openEditor({ ...blankEditor(), kind: "thi" }));
  el("new-homework").addEventListener("click", () => openEditor({ ...blankEditor(), kind: "baotap" }));
  el("paper-filters").addEventListener("click", event => {
    const chip = event.target.closest("[data-filter]");
    if (!chip) return;
    paperFilter = chip.dataset.filter;
    paintExams();
  });
  el("paper-search").addEventListener("input", () => { paperQuery = el("paper-search").value; paintExams(); });
  el("exam-file").addEventListener("change", uploadExam);
  el("team-open").addEventListener("click", openTeam);
  el("team-close").addEventListener("click", () => { el("team-modal").hidden = true; });
  el("team-add").addEventListener("click", addTeacher);
  el("tabs").addEventListener("click", event => {
    const button = event.target.closest("[data-tab]");
    if (button) showTab(button.dataset.tab);
  });
  el("room-list").addEventListener("click", event => {
    const card = event.target.closest("[data-room]");
    if (card) selectRoom(card.dataset.room);
  });
  el("exam-editor").addEventListener("click", editQuestions);
  el("exam-editor").addEventListener("change", switchType);
  el("exam-list").addEventListener("click", examActions);
  el("exam-list").addEventListener("change", saveMarks);
  el("board").addEventListener("click", camActions);
  el("cam-close").addEventListener("click", stopWatch);
  clearInterval(pollTimer);
  pollTimer = setInterval(() => (tab === "board" ? refresh() : loadRooms().catch(() => {})), POLL_MS);
}

function showTab(name) {
  tab = name;
  el("tabs").querySelectorAll("[data-tab]").forEach(button => button.classList.toggle("on", button.dataset.tab === name));
  document.querySelectorAll("[data-panel]").forEach(panel => { panel.hidden = panel.dataset.panel !== name; });
}

async function loadRooms() {
  rooms = await api("/api/rooms");
  el("empty").hidden = rooms.length > 0;
  el("workspace").hidden = rooms.length === 0;
  el("room-list").innerHTML = rooms.map(item => `<button data-room="${item.id}"
      class="rounded-lg border p-3 text-left transition hover:border-moss ${item.id === roomId ? "border-moss bg-moss-soft" : "border-slate-200"}">
      <span class="block text-sm font-bold text-slate-900">${escape(item.title)}</span>
      <span class="block font-mono text-xs text-moss">${escape(item.code)}</span>
      <span class="mt-1 block text-xs text-slate-500">${item.students} học sinh · ${item.exams} đề · ${item.online} em đang online
        ${item.closed ? " · đã đóng" : ""}</span></button>`).join("");
  if (!roomId || !rooms.some(item => item.id === roomId)) selectRoom(rooms[0]?.id);
}

async function selectRoom(id) {
  if (!id) return;
  if (camStudent && id !== roomId) stopWatch();
  roomId = id;
  editor = null;
  detail = null;
  previous = new Map();
  await loadRooms();
  await refresh();
}

async function refresh() {
  if (!roomId) return;
  room = await api(`/api/rooms/${roomId}`);
  paintRoom();
}

async function createRoom() {
  const title = prompt("Tên phòng thi (ví dụ: Lớp 12A1):");
  if (!title) return;
  try {
    const created = await api("/api/rooms", { method: "POST", body: { title } });
    roomId = created.id;
    await loadRooms();
    await refresh();
    notify(document, `Đã tạo phòng ${created.title}. Mã phòng là ${created.code}.`);
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function toggleRoom() {
  await api(`/api/rooms/${roomId}`, { method: "PATCH", body: { closed: !room.closed } });
  await refresh();
}

async function toggleCam() {
  if (room.cam_enabled && !confirm("Tắt camera cho phòng này? Khung xem đang mở sẽ đóng và máy chủ bỏ mọi ảnh đang chờ.")) return;
  try {
    await api(`/api/rooms/${roomId}`, { method: "PATCH", body: { cam_enabled: !room.cam_enabled } });
    if (room.cam_enabled) stopWatch();
    await refresh();
    notify(document, room.cam_enabled
      ? "Đã bật camera: máy các em sẽ tự phát hiện bất thường và gửi một ảnh bằng chứng. Nhớ báo trước cho các em và phụ huynh."
      : "Đã tắt camera cho phòng này; mọi ảnh đang chờ trên máy chủ bị bỏ.");
  } catch (error) {
    notify(document, error.message, true);
  }
}

/* ---------------------------------------------------------------- khung xem camera */

async function camActions(event) {
  const photo = event.target.closest("[data-photo]");
  if (photo) return showPhoto(photo);
  const button = event.target.closest("[data-cam]");
  if (!button) return;
  if (button.dataset.cam === room.cam_watching) return stopWatch();
  try {
    await api(`/api/rooms/${roomId}/cam/watch`, { method: "POST", body: { student_id: button.dataset.cam } });
    camStudent = button.dataset.cam;
    camWaited = 0;
    el("cam-who").textContent = `${button.dataset.who} · đang gửi hình`;
    el("cam-modal").hidden = false;
    camHint("Đang chờ hình từ máy em này…");
    clearInterval(camTimer);
    pullFrame();
    camTimer = setInterval(pullFrame, CAM_POLL_MS);
    paintBoard();
  } catch (error) {
    notify(document, error.message, true);
  }
}

/* Ảnh bằng chứng: một ảnh duy nhất, máy em gửi lúc phát hiện bất thường, giữ 30 phút trên máy chủ. */
function showPhoto(button) {
  stopWatch();
  el("cam-who").textContent = `${button.dataset.who} · ${CAM_LABELS[button.dataset.rule] ?? button.dataset.rule}`;
  el("cam-modal").hidden = false;
  if (camUrl) {
    URL.revokeObjectURL(camUrl);
    camUrl = null;
  }
  const frame = el("cam-frame");
  frame.onerror = () => camHint("Ảnh này đã hết hạn — máy chủ chỉ giữ 30 phút. Dòng cảnh báo vẫn còn trong mục Cảnh báo.");
  frame.src = `/api/rooms/${roomId}/evidence/${button.dataset.photo}`;
  frame.hidden = false;
  el("cam-hint").hidden = true;
}

async function stopWatch() {
  clearInterval(camTimer);
  camTimer = null;
  if (camStudent && roomId) await api(`/api/rooms/${roomId}/cam/watch`, { method: "POST", body: { student_id: null } }).catch(() => {});
  camStudent = null;
  el("cam-modal").hidden = true;
  showFrame(null);
  if (room) paintBoard();
}

async function pullFrame() {
  if (!camStudent) return;
  let blob = null;
  try {
    const answer = await fetch(`/api/rooms/${roomId}/cam/${camStudent}`, { credentials: "same-origin", cache: "no-store" });
    if (answer.ok) blob = await answer.blob();
  } catch { /* mất mạng vài giây thì để nguyên khung hình cuối */ }
  if (blob && blob.size) {
    camWaited = 0;
    showFrame(blob);
    return;
  }
  camWaited += CAM_POLL_MS;
  if (camWaited >= CAM_WAIT_MS) camHint("Em này chưa gửi hình — có thể em chưa bấm Cho phép camera, đã tắt camera, hoặc đã nộp bài.");
}

function showFrame(blob) {
  if (camUrl) URL.revokeObjectURL(camUrl);
  camUrl = blob ? URL.createObjectURL(blob) : null;
  const frame = el("cam-frame");
  frame.onerror = null;
  frame.src = camUrl ?? "";
  frame.hidden = !camUrl;
  if (camUrl) el("cam-hint").hidden = true;
}

function camHint(message) {
  el("cam-hint").textContent = message;
  el("cam-hint").hidden = false;
}

/* ---------------------------------------------------------------- giáo viên & tài khoản */

async function openTeam() {
  el("team-modal").hidden = false;
  await paintTeam();
  await paintBackup();
}

async function paintTeam() {
  try {
    const { teachers } = await api("/api/teachers");
    el("team-list").innerHTML = teachers.map(row => `<div class="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-2">
        <span><strong class="text-sm">${escape(row.display_name)}</strong>
          <span class="block font-mono text-xs text-slate-500">${escape(row.username)}</span></span>
        <span class="pill ${row.is_owner ? "bg-moss-soft text-moss" : "bg-slate-100 text-slate-600"}">${row.is_owner ? "quản trị" : "giám thị"}</span>
        <span class="w-full text-xs text-slate-500">Vào lần cuối: ${dateTime(row.last_login)}</span></div>`).join("");
  } catch (error) {
    el("team-list").innerHTML = `<p class="text-sm text-red-700">${escape(error.message)}</p>`;
  }
}

async function paintBackup() {
  const box = el("team-backup-state");
  try {
    const health = await api("/api/health");
    if (health.backup === "off") {
      box.textContent = "Máy chủ này chưa bật nơi giữ dữ liệu thứ hai. Cô nhớ bấm tải bản sao lưu trước mỗi buổi thi.";
    } else if (!/^ok|^chờ/.test(health.backup)) {
      box.textContent = `Bản sao tự động đang trục trặc (${health.backup}). Giờ thi vẫn chạy bình thường, nhưng cô nên tải tệp .sql để chắc chắn.`;
    } else {
      box.textContent = `Bản sao tự động: ${health.backup}.`;
    }
  } catch {
    box.textContent = "Không kiểm tra được bản sao lưu vì máy chủ không trả lời.";
  }
}

async function addTeacher() {
  const username = el("team-username").value.trim();
  const password = el("team-password").value;
  if (!username || !password) return notify(document, "Cô điền tên đăng nhập và mật khẩu nhé.", true);
  try {
    await api("/api/teacher/invite", { method: "POST", body: { username, password, display_name: el("team-name").value.trim() } });
    for (const id of ["team-username", "team-password", "team-name"]) el(id).value = "";
    await paintTeam();
    notify(document, `Đã tạo tài khoản ${username}. Cô gửi tên đăng nhập và mật khẩu này riêng cho người đó.`);
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function dropRoom() {
  if (!confirm(`Xóa phòng “${room.title}”? Toàn bộ đề, bài làm và cảnh báo của phòng này sẽ mất theo.`)) return;
  await api(`/api/rooms/${roomId}`, { method: "DELETE" });
  roomId = null;
  await loadRooms();
  notify(document, "Đã xóa phòng.");
}

/* ---------------------------------------------------------------- vẽ phòng */

function paintRoom() {
  el("workspace").hidden = false;
  el("room-title").textContent = room.title;
  el("room-code").textContent = room.code;
  el("room-state").textContent = room.closed ? "Đã đóng, học sinh không vào được" : "Đang mở cho học sinh vào";
  el("room-state").className = `pill ${room.closed ? "bg-slate-200 text-slate-600" : "bg-moss-soft text-moss"}`;
  el("toggle-close").textContent = room.closed ? "Mở lại phòng" : "Đóng phòng";
  el("toggle-cam").textContent = room.cam_enabled ? "Tắt camera của phòng" : "Bật camera cho phòng";
  if (!room.cam_enabled && camStudent) stopWatch();
  const submitted = room.exams.reduce((total, exam) => total + exam.attempts.filter(attempt => attempt.submitted_at).length, 0);
  const away = room.exams.reduce((total, exam) => total + exam.attempts.filter(attempt =>
    statusOf(attempt, previous.get(attempt.id), Date.now()).tone === "alert").length, 0);
  el("counters").innerHTML = counter("Học sinh", room.students.length)
    + counter("Đang vào lớp", room.students.filter(student => Date.now() - student.last_seen < ONLINK_MS).length)
    + counter("Đề đã mở", room.exams.filter(exam => exam.published).length)
    + counter("Em rời cửa sổ", away, away ? "alert" : "");
  paintRoster();
  paintExams();
  paintBoard();
  paintAlerts();
}

const counter = (label, value, tone = "") =>
  `<div class="rounded-lg border border-slate-200 p-3"><p class="text-xs uppercase tracking-wide text-slate-500">${label}</p>
    <p class="text-2xl font-bold ${tone === "alert" ? "text-red-600" : "text-moss"}">${value}</p></div>`;

function paintRoster() {
  el("roster-table").innerHTML = `<thead><tr><th>Chỗ</th><th>Mã học sinh</th><th>Họ và tên</th><th>Mã tham gia</th><th>Vào lớp</th><th></th></tr></thead>
    <tbody>${room.students.map(student => `<tr>
      <td class="font-mono text-xs">${escape(student.seat_id)}</td><td class="font-mono text-xs">${escape(student.student_code)}</td>
      <td>${escape(student.name)}</td>
      <td><code class="rounded bg-moss-soft px-2 py-1 font-mono font-bold text-moss">${escape(student.join_code)}</code></td>
      <td class="text-xs text-slate-500">${student.last_seen ? clock(student.last_seen) : "chưa vào"}</td>
      <td><button class="btn-danger px-2 py-1 text-xs" data-drop-student="${student.id}">Xóa</button></td></tr>`).join("")
      || '<tr><td colspan="6" class="text-sm text-slate-500">Chưa có học sinh. Dán danh sách hoặc tải tệp CSV lên.</td></tr>'}</tbody>`;
  el("roster-table").querySelectorAll("[data-drop-student]").forEach(button =>
    button.addEventListener("click", async () => {
      if (!confirm("Xóa em này khỏi danh sách? Bài làm của em cũng bị xóa.")) return;
      await api(`/api/students/${button.dataset.dropStudent}`, { method: "DELETE" });
      await refresh();
    }));
}

function parseRoster(text) {
  return text.split(/\r?\n/).filter(line => line.trim()).map(line => {
    const [code, ...rest] = line.split(/[,;\t]/);
    return { student_code: code.trim(), name: rest.join(", ").trim() };
  }).filter(item => item.student_code && item.name);
}

async function sendRoster(method) {
  const students = parseRoster(el("roster-paste").value);
  if (!students.length) return notify(document, "Chưa có dòng nào dạng “mã học sinh, họ và tên”.", true);
  if (method === "put" && !confirm(`Thay thế cả danh sách bằng ${students.length} em vừa dán? Danh sách cũ sẽ bị xóa.`)) return;
  try {
    await api(`/api/rooms/${roomId}/students`, { method: method === "put" ? "PUT" : "POST", body: { students } });
    el("roster-paste").value = "";
    await refresh();
    notify(document, `Đã nạp ${students.length} em và cấp mã tham gia.`);
  } catch (error) {
    notify(document, error.message, true);
  }
}

async function uploadRoster(event) {
  const file = event.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  try {
    await api(`/api/rooms/${roomId}/roster`, { method: "POST", form });
    await refresh();
    notify(document, `Đã nạp danh sách từ ${file.name}.`);
  } catch (error) {
    notify(document, error.message, true);
  } finally {
    event.target.value = "";
  }
}

/* ---------------------------------------------------------------- đề thi */

const blankEditor = (exam = null) => ({
  id: exam?.id ?? null,
  title: exam?.title ?? "",
  duration: exam?.duration_minutes ?? 45,
  kind: exam?.kind ?? "thi",
  openFrom: exam?.open_from ?? null,
  openUntil: exam?.open_until ?? null,
  questions: exam ? exam.questions.map(question => ({ ...question, options: [...(question.options || [])] })) : [blankQuestion()],
});

const blankQuestion = () => ({ type: "mcq", text: "", options: ["", "", "", ""], answer: 0, points: 2 });

function openEditor(next) {
  editor = next;
  el("exam-editor").hidden = false;
  el("exam-editor").innerHTML = `
    <div class="mb-3 grid gap-3 sm:grid-cols-[2fr_1fr_1fr]">
      <div><label class="label" for="exam-title">Tên đề</label><input id="exam-title" class="field" maxlength="120"
        value="${escape(editor.title)}" placeholder="Ví dụ: Kiểm tra buổi 5"></div>
      <div><label class="label" for="exam-kind">Dùng làm gì</label><select id="exam-kind" class="field">
        <option value="thi"${editor.kind === "thi" ? " selected" : ""}>Bài thi trên lớp</option>
        <option value="baotap"${editor.kind === "baotap" ? " selected" : ""}>Bài tập về nhà</option></select></div>
      <div id="exam-time-box"><label class="label" id="exam-time-label" for="exam-time">${editor.kind === "baotap" ? "Hạn nộp" : "Thời lượng (phút)"}</label>
        <input id="exam-time" class="field" ${editor.kind === "baotap" ? 'type="datetime-local"' : 'type="number" min="5" max="240"'}
          value="${editor.kind === "baotap" ? localStamp(editor.openUntil) : editor.duration}"></div>
    </div>
    <details class="mb-3 rounded-lg border border-slate-200 p-3 text-sm">
      <summary class="cursor-pointer font-semibold text-moss">Dán đề từ Word hoặc tệp văn bản để máy tự tách câu</summary>
      <p class="mt-2 text-xs text-slate-500">Một câu là một khối cách nhau một dòng trống, hoặc bắt đầu bằng dòng “Câu 12:” / “12.”.
        Trắc nghiệm: dòng hỏi, các dòng “A. …”, “B. …”, rồi “ĐA: B” và “Điểm: 2”. Tự luận: thêm dòng “Tự luận: hướng dẫn chấm”.</p>
      <textarea id="exam-paste" rows="6" class="field mt-2" placeholder="Câu 1: Chọn đáp án đúng&#10;A. phương án một&#10;B. phương án hai&#10;ĐA: A&#10;Điểm: 2"></textarea>
      <div class="mt-2 flex flex-wrap gap-2">
        <button id="exam-parse" class="btn-primary">Dịch thành câu hỏi</button>
        <button id="exam-add" class="btn-ghost">+ Thêm 1 câu trắng</button>
      </div>
    </details>
    <div id="exam-rows" class="grid gap-3"></div>
    <p id="exam-errors" class="mt-2 text-sm text-red-700" role="alert"></p>
    <div class="mt-3 flex flex-wrap gap-2">
      <button id="exam-save" class="btn-primary">${editor.id ? "Lưu thay đổi" : "Lưu đề (chưa mở cho học sinh)"}</button>
      <button id="exam-cancel" class="btn-ghost">Đóng</button>
      <span id="exam-count" class="self-center text-xs text-slate-500"></span>
    </div>`;
  el("exam-title").focus();
  paintRows();
  el("exam-editor").scrollIntoView({ block: "start", behavior: "smooth" });
}

function rowHtml(question, i) {
  const options = question.type === "mcq"
    ? `<div class="mt-2 grid gap-2">${question.options.map((option, j) => `<div class="flex items-center gap-2">
        <input type="radio" name="key-${i}" value="${j}" ${question.answer === j ? "checked" : ""} title="Đây là đáp án đúng"
          class="h-4 w-4 accent-moss">
        <input data-option="${j}" value="${escape(option)}" class="field" placeholder="${LETTERS[j]}. phương án ${LETTERS[j]}">
        <button data-drop-option="${j}" class="btn-ghost px-2 py-1 text-xs" title="Bỏ phương án">×</button></div>`).join("")}
      ${question.options.length < 8 ? '<button data-add-option class="btn-ghost w-fit px-3 py-1 text-xs">+ Thêm phương án</button>' : ""}
      <p class="text-xs text-slate-500">Chấm tròn đang chọn là đáp án đúng. Máy tự chấm trắc nghiệm, câu tự luận cô chấm.</p></div>`
    : `<input data-field="prompt" class="field mt-2" value="${escape(question.prompt ?? "")}" placeholder="Hướng dẫn chấm, ví dụ: viết khoảng 30 từ">`;
  return `<div data-row="${i}" class="rounded-lg border border-slate-200 p-3">
      <div class="mb-2 flex flex-wrap items-center gap-2">
        <strong class="text-sm text-slate-700">Câu ${i + 1}</strong>
        <select data-field="type" class="field w-auto py-1 text-xs">
          <option value="mcq" ${question.type === "mcq" ? "selected" : ""}>Trắc nghiệm</option>
          <option value="text" ${question.type === "text" ? "selected" : ""}>Tự luận</option></select>
        <label class="flex items-center gap-1 text-xs text-slate-600">Điểm
          <input data-field="points" type="number" min="0.25" max="20" step="0.25" value="${question.points}" class="field w-16 py-1 text-xs"></label>
        <span class="ml-auto flex gap-1">
          ${i > 0 ? `<button data-up class="btn-ghost px-2 py-1 text-xs">↑</button>` : ""}
          ${i < editor.questions.length - 1 ? `<button data-down class="btn-ghost px-2 py-1 text-xs">↓</button>` : ""}
          <button data-drop-row class="btn-danger px-2 py-1 text-xs">Xóa</button></span>
      </div>
      <textarea data-field="text" rows="2" class="field" placeholder="Nội dung câu hỏi">${escape(question.text)}</textarea>
      ${options}</div>`;
}

function paintRows() {
  el("exam-rows").innerHTML = editor.questions.map(rowHtml).join("");
  el("exam-count").textContent = `${editor.questions.length} câu · ${editor.questions.reduce((total, row) => total + (Number(row.points) || 0), 0)} điểm`;
}

/* Cô giáo có thể đang gõ dở, nên đọc lại màn hình trước khi dựng lại bảng câu. */
function collectRows() {
  return [...el("exam-rows").querySelectorAll("[data-row]")].map((node, i) => {
    const type = node.querySelector("[data-field=type]").value;
    const base = { type, text: node.querySelector("[data-field=text]").value, points: Number(node.querySelector("[data-field=points]").value), index: i };
    if (type === "text") return { ...base, prompt: node.querySelector("[data-field=prompt]")?.value ?? "" };
    const checked = node.querySelector(`input[name="key-${i}"]:checked`);
    return { ...base, options: [...node.querySelectorAll("[data-option]")].map(input => input.value), answer: checked ? Number(checked.value) : 0 };
  });
}

async function editQuestions(event) {
  const button = event.target.closest("button");
  if (!button || !editor) return;
  const row = event.target.closest("[data-row]");
  const i = row ? Number(row.dataset.row) : -1;
  if (button.id === "exam-cancel") { editor = null; el("exam-editor").hidden = true; return; }
  if (button.id === "exam-add") { editor.questions = collectRows(); editor.questions.push(blankQuestion()); return paintRows(); }
  if (button.id === "exam-parse") return parsePaste();
  if (button.id === "exam-save") return saveExam();
  if (i < 0) return;
  editor.questions = collectRows();
  if (button.dataset.up !== undefined || button.dataset.down !== undefined) {
    const to = i + (button.dataset.up !== undefined ? -1 : 1);
    if (editor.questions[to]) [editor.questions[i], editor.questions[to]] = [editor.questions[to], editor.questions[i]];
  } else if (button.dataset.dropRow !== undefined) editor.questions.splice(i, 1);
  else if (button.dataset.addOption !== undefined) editor.questions[i].options.push("");
  else if (button.dataset.dropOption !== undefined) {
    const dropped = Number(button.dataset.dropOption);
    editor.questions[i].options.splice(dropped, 1);
    editor.questions[i].answer = Math.min(editor.questions[i].answer, Math.max(0, editor.questions[i].options.length - 1));
  } else return;
  paintRows();
}

async function parsePaste() {
  try {
    const parsed = await api("/api/papers/parse", { form: new FormData([["text", el("exam-paste").value]]) });
    editor.questions = editor.questions.filter(question => question.text).concat(parsed.questions);
    el("exam-errors").textContent = parsed.notes.join(" · ");
    paintRows();
    notify(document, `Đã dịch ${parsed.questions.length} câu. Cô rà lại đáp án rồi bấm lưu đề.`);
  } catch (error) {
    el("exam-errors").textContent = error.message;
  }
}

async function saveExam() {
  editor.questions = collectRows();
  const kind = el("exam-kind").value;
  const time = el("exam-time").value;
  if (kind === "baotap" && !time) { el("exam-errors").textContent = "Bài tập về nhà cần cô đặt hạn nộp."; return; }
  const body = {
    title: el("exam-title").value.trim(),
    duration_minutes: kind === "baotap" ? 240 : Number(time),  // bài tập không đếm giờ, chỉ cần giá trị hợp lệ
    kind,
    open_until: kind === "baotap" ? new Date(time).getTime() : null,
    questions: editor.questions,
  };
  try {
    await api(editor.id ? `/api/exams/${editor.id}` : `/api/rooms/${roomId}/exams`, { method: editor.id ? "PUT" : "POST", body });
    editor = null;
    el("exam-editor").hidden = true;
    await refresh();
    notify(document, "Đã lưu đề. Đề vẫn ở trạng thái chưa mở — bấm “Mở cho học sinh” đúng lúc cả lớp đã vào.");
  } catch (error) {
    el("exam-errors").textContent = error.message;
  }
}

async function uploadExam(event) {
  const file = event.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  form.append("title", file.name.replace(/\.[^.]+$/, ""));
  form.append("duration", "45");
  try {
    const exam = await api(`/api/rooms/${roomId}/exams/import`, { method: "POST", form });
    await refresh();
    notify(document, `Đã nạp ${exam.question_count} câu từ ${file.name}.${exam.notes?.length ? ` Lưu ý: ${exam.notes.join(" · ")}` : ""}`);
  } catch (error) {
    notify(document, error.message, true);
  } finally {
    event.target.value = "";
  }
}

function dueNote(exam) {
  if (exam.kind !== "baotap" || !exam.open_until) return "";
  const left = Number(exam.open_until) - Date.now();
  return left < 0 ? `<span class="pill ${TONES.alert}">Đã quá hạn nộp</span>`
    : `<span class="pill ${TONES.done}">Còn ${dueLeft(left)}</span>`;
}

function examCard(exam) {
  const attempts = exam.attempts;
  const submitted = attempts.filter(attempt => attempt.submitted_at).length;
  return `<article class="card p-4" data-exam="${exam.id}">
    <div class="flex flex-wrap items-center justify-between gap-3">
      <div><h4 class="font-bold text-slate-900">${escape(exam.title)}
        <span class="pill ${exam.published ? "bg-moss-soft text-moss" : "bg-slate-100 text-slate-600"}">${exam.published ? "Đang mở" : "Chưa mở"}</span>
        ${dueNote(exam)}</h4>
        <p class="text-xs text-slate-500">${exam.kind === "baotap" ? "Bài tập về nhà" : "Bài thi trên lớp"} ·
          ${exam.question_count} câu ·
          ${exam.kind === "baotap" ? `nộp trước ${dateTime(exam.open_until)}` : `${exam.duration_minutes} phút`} ·
          ${exam.max_points} điểm ·
          ${attempts.length}/${exam.students} em vào làm · ${submitted} em đã nộp</p></div>
      <div class="flex flex-wrap gap-2">
        <button data-publish="${exam.published ? "false" : "true"}" class="${exam.published ? "btn-ghost" : "btn-primary"} px-3 py-1 text-xs">
          ${exam.published ? "Đóng đề" : exam.kind === "baotap" ? "Giao bài tập" : "Mở cho học sinh"}</button>
        <button data-edit class="btn-ghost px-3 py-1 text-xs">Sửa đề</button>
        <button data-detail class="btn-ghost px-3 py-1 text-xs">${detail?.id === exam.id ? "Ẩn bài làm" : "Xem bài & chấm"}</button>
        <button data-doc class="btn-ghost px-3 py-1 text-xs" title="Mở bằng Word, in ra giao bài tập offline">Tải câu hỏi</button>
        <button data-doc="1" class="btn-ghost px-3 py-1 text-xs" title="Chỉ cô giáo có bản này, đừng phát cho học sinh">Tải đáp án</button>
        <button data-csv class="btn-ghost px-3 py-1 text-xs">Tải kết quả CSV</button>
        ${attempts.length ? '<button data-reset class="btn-ghost px-3 py-1 text-xs" title="Xóa bài làm để cả lớp thi lại đề này">Cho lớp làm lại</button>' : ""}
        <button data-drop class="btn-danger px-3 py-1 text-xs">Xóa</button>
      </div>
    </div>${submitted ? `<p class="mt-2 text-xs text-amber-800">Đã có ${submitted} em nộp bài nên đề này đang khóa, sửa sẽ bị báo lỗi.
      Muốn thi lại bằng đề này thì bấm “Cho lớp làm lại”.</p>` : ""}${detail?.id === exam.id ? detailHtml(exam) : ""}</article>`;
}

function detailHtml(exam) {
  const questions = detail.questions;
  return `<div class="mt-4 grid gap-3 border-t border-slate-200 pt-4">
    ${detail.attempts.map(attempt => `<details class="rounded-lg border border-slate-200 p-3">
      <summary class="cursor-pointer text-sm font-semibold">
        ${escape(attempt.seat_id)} ${escape(attempt.name)} · ${attempt.submitted_at ? `${attempt.score ?? 0}/${exam.max_points} điểm` : "chưa nộp"}
        · rời cửa sổ ${minutes(attempt.tab_ms)} · dán ${attempt.paste_count} lần
        <button data-reset-one="${attempt.id}" data-who="${escape(attempt.seat_id)} ${escape(attempt.name)}"
          class="btn-ghost ml-2 px-2 py-1 text-xs">Cho em làm lại</button></summary>
      <ol class="mt-3 grid gap-2 text-sm">
        ${questions.map((question, i) => {
          const value = attempt.answers[String(i)];
          const blank = value === undefined || value === "";
          const shown = blank ? "<em class=\"text-slate-400\">bỏ trống</em>"
            : question.type === "mcq" ? escape(`${LETTERS[Number(value)]}. ${question.options[Number(value)] ?? value}`) : escape(value);
          const verdict = question.type !== "mcq" || blank ? ""
            : Number(value) === question.answer ? ' <span class="pill bg-moss-soft text-moss">đúng</span>' : ' <span class="pill bg-red-100 text-red-700">sai</span>';
          const mark = question.type === "text" && attempt.submitted_at
            ? `<label class="ml-2 inline-flex items-center gap-1 text-xs text-slate-600">Chấm
                <input data-mark="${i}" data-attempt="${attempt.id}" type="number" min="0" max="${question.points}" step="0.25"
                  value="${attempt.marks?.[String(i)] ?? ""}" class="field w-20 py-1 text-xs">/${question.points}đ</label>` : "";
          return `<li><strong>Câu ${i + 1}</strong> (${question.points}đ) — ${shown}${verdict}${mark}</li>`;
        }).join("")}
      </ol></details>`).join("") || '<p class="text-sm text-slate-500">Chưa em nào vào làm đề này.</p>'}</div>`;
}

const PAPER_FILTERS = { all: "Tất cả", thi: "Đề thi", baotap: "Bài tập", open: "Đang mở", shut: "Chưa mở" };

/* Cô gõ "kiem tra" vẫn tìm ra "Kiểm tra" — bỏ dấu rồi so sánh. */
const fold = text => text.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d");

function paperShown(filter, exam) {
  if (filter === "thi" || filter === "baotap") return exam.kind === filter;
  if (filter === "open") return exam.published;
  if (filter === "shut") return !exam.published;
  return true;
}

const dueLeft = ms => ms >= 86_400_000 ? `${Math.ceil(ms / 86_400_000)} ngày`
  : ms >= 3_600_000 ? `${Math.round(ms / 3_600_000)} giờ` : `${Math.max(1, Math.round(ms / 60_000))} phút`;

function paintExams() {
  const exams = [...room.exams].sort((a, b) => b.created_at - a.created_at);
  el("paper-filters").innerHTML = Object.entries(PAPER_FILTERS).map(([key, label]) => {
    const count = exams.filter(exam => paperShown(key, exam)).length;
    return `<button data-filter="${key}" class="pill cursor-pointer ${
      paperFilter === key ? "bg-moss text-white" : "bg-slate-100 text-slate-600"}">${label} · ${count}</button>`;
  }).join("");
  const needle = fold(paperQuery.trim());
  const shown = exams.filter(exam => paperShown(paperFilter, exam) && (!needle || fold(exam.title).includes(needle)));
  const turnedIn = exams.reduce((total, exam) => total + exam.attempts.filter(attempt => attempt.submitted_at).length, 0);
  el("paper-summary").textContent = shown.length
    ? `${shown.length}/${exams.length} bài · ${exams.filter(exam => exam.published).length} bài đang mở cho lớp · ${turnedIn} bài đã nộp`
    : "Không có bài nào khớp bộ lọc này.";
  el("exam-list").innerHTML = shown.map(examCard).join("")
    || '<p class="card p-6 text-center text-sm text-slate-500">Chưa có bài nào. Bấm “+ Giao bài tập về nhà” hoặc “+ Soạn đề thi trên lớp”.</p>';
}

async function examActions(event) {
  const button = event.target.closest("button");
  if (!button) return;
  const exam = room.exams.find(item => item.id === button.closest("[data-exam]")?.dataset.exam);
  if (!exam) return;
  try {
    if (button.dataset.publish !== undefined) {
      await api(`/api/exams/${exam.id}/publish`, { method: "POST", body: { published: button.dataset.publish === "true" } });
      await refresh();
      return notify(document, button.dataset.publish === "true" ? "Đã mở đề cho lớp." : "Đã đóng đề, học sinh không vào làm được nữa.");
    }
    if (button.dataset.edit !== undefined) return openEditor(blankEditor(await api(`/api/exams/${exam.id}`)));
    if (button.dataset.detail !== undefined) {
      detail = detail?.id === exam.id ? null : { id: exam.id, ...(await api(`/api/exams/${exam.id}/results`)) };
      return paintExams();
    }
    if (button.dataset.csv !== undefined) return openCsv(exam);
    if (button.dataset.doc !== undefined) {
      // Máy trình tự tải: tên tệp và đáp án do máy chủ quyết định, cô chỉ bấm là tệp rơi xuống.
      location.href = `/api/exams/${exam.id}/paper.doc${button.dataset.doc ? "?answers=1" : ""}`;
      return notify(document, button.dataset.doc
        ? "Đang tải bản có đáp án — tệp này chỉ cô giữ, đừng phát cho học sinh."
        : "Đang tải bộ câu hỏi — mở bằng Word rồi in ra giao bài tập được luôn.");
    }
    if (button.dataset.reset !== undefined) {
      if (!confirm(`Xóa bài làm của cả lớp trong đề “${exam.title}” để thi lại? Điểm đã chấm sẽ mất, còn cảnh báo rời cửa sổ thì máy giữ lại làm bằng chứng.`)) return;
      const done = await api(`/api/exams/${exam.id}/reset`, { method: "POST" });
      detail = null;
      await refresh();
      return notify(document, done.reset
        ? `Đã xóa ${done.reset} bài làm. Đề vẫn còn nguyên, cô bấm “Mở cho học sinh” khi cả lớp sẵn sàng.`
        : "Đề này chưa có bài làm nào để xóa.");
    }
    if (button.dataset.resetOne !== undefined) {
      event.preventDefault();
      if (!confirm(`Xóa bài của ${button.dataset.who} để em làm lại từ đầu? Các em khác không bị ảnh hưởng.`)) return;
      await api(`/api/attempts/${button.dataset.resetOne}/reset`, { method: "POST" });
      if (detail?.id === exam.id) detail = { id: exam.id, ...(await api(`/api/exams/${exam.id}/results`)) };
      await refresh();
      return notify(document, `Đã cho ${button.dataset.who} làm lại. Em mở lại đề sẽ có đủ thời gian mới.`);
    }
    if (button.dataset.drop !== undefined) {
      if (!confirm(`Xóa đề “${exam.title}”? Bài làm và cảnh báo của đề này sẽ bị xóa theo.`)) return;
      await api(`/api/exams/${exam.id}`, { method: "DELETE" });
      detail = null;
      await refresh();
    }
  } catch (error) {
    notify(document, error.message, true);
  }
}

function openCsv(exam) {
  if (!detail || detail.id !== exam.id) return notify(document, "Bấm “Xem bài & chấm” trước để máy chủ gửi kèm đáp án vào tệp.", true);
  location.href = `/api/exams/${exam.id}/results.csv`;
}

async function saveMarks(event) {
  const input = event.target.closest("[data-mark]");
  if (!input) return;
  const marks = {};
  el("exam-list").querySelectorAll(`[data-mark][data-attempt="${input.dataset.attempt}"]`).forEach(cell => {
    if (cell.value !== "") marks[cell.dataset.mark] = Number(cell.value);
  });
  try {
    await api(`/api/attempts/${input.dataset.attempt}/marks`, { method: "PUT", body: { marks } });
    detail = { id: detail.id, ...(await api(`/api/exams/${detail.id}/results`)) };
    paintExams();
    await refresh();
    notify(document, "Đã lưu điểm và cộng vào bài thi.");
  } catch (error) {
    notify(document, error.message, true);
  }
}

/* Đổi một câu từ trắc nghiệm sang tự luận phải vẽ lại thân câu để hiện ô hướng dẫn chấm. */
function switchType(event) {
  if (event.target.id === "exam-kind") {
    editor = { ...editor, questions: collectRows(), kind: event.target.value, openUntil: null };
    return openEditor(editor);   // hạn nộp là ô datetime-local, phải vẽ lại khi đổi loại
  }
  const select = event.target.closest("[data-field=type]");
  if (!select || !editor) return;
  editor.questions = collectRows();
  editor.questions[Number(select.closest("[data-row]").dataset.row)].type = select.value;
  paintRows();
}

/* Ô chọn ngày giờ của trình duyệt dùng dạng "2026-10-25T20:00" theo giờ máy cô, còn máy chủ giữ mili giây. */
function localStamp(moment) {
  if (!moment) return "";
  const d = new Date(Number(moment));
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/* ---------------------------------------------------------------- bảng theo dõi */

function statusOf(attempt, past, now) {
  if (!attempt) return { tone: "idle", label: "Chưa vào làm" };
  if (attempt.submitted_at) return { tone: "done", label: "Đã nộp" };
  const elapsed = past ? Math.max(POLL_MS, now - past.at) : 0;
  const away = past ? Math.max(0, attempt.tab_ms - past.tab_ms) : 0;
  if (away > elapsed * 0.6) return { tone: "alert", label: "Đang rời cửa sổ" };
  if (now - attempt.last_seen > ONLINK_MS) return { tone: "idle", label: "Máy mất kết nối" };
  if (!attempt.answered) return { tone: "warn", label: "Vào làm, chưa trả lời câu nào" };
  return { tone: "ok", label: `Đang làm ${attempt.answered} câu` };
}

const CAM_LABELS = {
  cam_dark: "Camera bị che hoặc quá tối",
  face_gone: "Không thấy mặt em trước camera",
  object_raised: "Em giơ vật sáng lên gần mặt",
  cam_off: "Em tắt camera giữa giờ",
  tab_left: "Rời cửa sổ làm bài",
  paste: "Dán bài vào ô trả lời",
  idle: "Ngừng làm bài",
};

const camCell = student => {
  const mark = (room.evidence || []).find(item => item.student_id === student.id);
  if (!room.cam_enabled && !mark) return "";
  const who = `${escape(student.seat_id)} ${escape(student.name)}`;
  return `<td class="whitespace-nowrap">
    ${mark ? `<button data-photo="${student.id}" data-who="${who}" data-rule="${mark.rule}"
      class="btn-danger px-2 py-1 text-xs" title="${escape(CAM_LABELS[mark.rule] ?? mark.rule)} · ${Math.round(mark.age_ms / 1000)} giây trước">
      Ảnh bằng chứng</button>` : ""}
    ${room.cam_enabled ? `<button data-cam="${student.id}" data-who="${who}"
      class="${student.id === room.cam_watching ? "btn-danger" : "btn-ghost"} ml-1 px-2 py-1 text-xs">
      ${student.id === room.cam_watching ? "Đang soi" : "Xem"}</button>` : ""}</td>`;
};

function paintBoard() {
  const now = Date.now();
  el("board").innerHTML = room.exams.filter(exam => exam.attempts.length || exam.published).map(exam => {
    const bySeat = new Map(exam.attempts.map(attempt => [attempt.student_id, attempt]));
    return `<article class="card overflow-hidden">
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-2">
        <h4 class="font-bold text-slate-900">${escape(exam.title)} <span class="pill bg-slate-100 text-slate-600">${
          exam.kind === "baotap" ? `bài tập · nộp trước ${dateTime(exam.open_until)}` : `${exam.duration_minutes} phút`}</span></h4>
        <p class="text-xs text-slate-500">${exam.attempts.length}/${exam.students} em vào làm ·
          ${exam.attempts.filter(attempt => attempt.submitted_at).length} em đã nộp</p>
      </div>
      <div class="overflow-x-auto"><table class="table w-full"><thead><tr>
        <th>Chỗ</th><th>Học sinh</th><th>Trạng thái</th><th>Đã làm</th><th>Điểm</th><th>Rời cửa sổ</th><th>Dán bài</th><th>Lưu cuối</th>${room.cam_enabled || (room.evidence || []).length ? "<th>Hình ảnh</th>" : ""}</tr></thead>
        <tbody>${room.students.map(student => {
          const attempt = bySeat.get(student.id);
          const status = statusOf(attempt, previous.get(attempt?.id), now);
          return `<tr><td class="font-mono text-xs">${escape(student.seat_id)}</td>
            <td>${escape(student.name)}<span class="block font-mono text-xs text-slate-400">${escape(student.student_code)}</span></td>
            <td><span class="pill ${TONES[status.tone]}">${status.label}</span></td>
            <td>${attempt ? `${attempt.answered}/${exam.question_count}` : "—"}</td>
            <td>${attempt?.score ?? "—"}</td><td>${attempt ? `${minutes(attempt.tab_ms)} · ${attempt.tab_events} lần` : "—"}</td>
            <td>${attempt?.paste_count ?? 0}</td><td>${attempt ? clock(attempt.last_seen) : "—"}</td>${camCell(student)}</tr>`;
        }).join("")}</tbody></table></div></article>`;
  }).join("") || '<p class="card p-6 text-center text-sm text-slate-500">Chưa có đề nào đang mở cho lớp này.</p>';
  const counters = new Map();
  for (const exam of room.exams) for (const attempt of exam.attempts) counters.set(attempt.id, { tab_ms: attempt.tab_ms, at: now });
  // Chỉ giữ số liệu cũ trong 10 phút: bài đã đóng không được khiến dòng đỏ mãi trên bảng.
  previous = new Map([...[...previous].filter(([id, seen]) => !counters.has(id) && now - seen.at <= 600000), ...counters]);
}

function paintAlerts() {
  const names = new Map(room.students.map(student => [student.id, `${student.seat_id} ${student.name}`]));
  el("alerts").innerHTML = room.events.length
    ? room.events.map(event => `<div class="flex flex-wrap items-center gap-2 px-4 py-2 text-sm">
        <time class="w-40 text-xs text-slate-500">${dateTime(event.created_at)}</time>
        <span class="font-medium">${escape(names.get(event.student_id) ?? "Học sinh đã rời lớp")}</span>
        <span class="pill ${event.risk >= 60 ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-800"}">${escape(CAM_LABELS[event.rule] ?? event.rule)}</span>
        ${event.duration ? `<span class="text-xs text-slate-500">${Math.round(event.duration)} giây</span>` : ""}</div>`).join("")
    : '<p class="p-6 text-center text-sm text-slate-500">Chưa có cảnh báo nào trong phòng này.</p>';
}

boot();
